ALTER TABLE patients
ADD COLUMN IF NOT EXISTS military_rank VARCHAR(100) NULL AFTER patient_type;
