ALTER TABLE patients
ADD COLUMN IF NOT EXISTS serial_number VARCHAR(100) NULL AFTER military_rank;
