<?php
session_start();
header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

require_once 'db.php';

$historyLookupError = '';
$historyLookupPatient = null;
$medicalHistory = [];
$queueHistory = [];
$appointmentHistory = [];

function queueTrackingEscape($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function queueTrackingFormatDate($value): string
{
    if (!$value) {
        return '—';
    }
    $timestamp = strtotime((string)$value);
    return $timestamp === false ? (string)$value : date('M j, Y g:i A', $timestamp);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'lookup_history') {
    $now = time();
    if (
        !isset($_SESSION['queue_history_lookup'])
        || !is_array($_SESSION['queue_history_lookup'])
        || $now - (int)($_SESSION['queue_history_lookup']['window_started'] ?? 0) >= 900
    ) {
        $_SESSION['queue_history_lookup'] = ['window_started' => $now, 'failed_attempts' => 0, 'blocked_until' => 0];
    }

    $rateLimit = &$_SESSION['queue_history_lookup'];
    if ((int)$rateLimit['blocked_until'] > $now) {
        $historyLookupError = 'Too many unsuccessful attempts. Please wait 15 minutes before trying again.';
    } else {
        $mrnInput = $_POST['mrn'] ?? '';
        $dobInput = $_POST['dob'] ?? '';
        $validMrn = is_string($mrnInput) && preg_match('/^[0-9]{1,10}$/', $mrnInput) === 1 && (int)$mrnInput > 0;
        $dobDate = is_string($dobInput) ? DateTime::createFromFormat('!Y-m-d', $dobInput) : false;
        $dobErrors = DateTime::getLastErrors();
        $validDob = $dobDate
            && $dobDate->format('Y-m-d') === $dobInput
            && (!$dobErrors || ($dobErrors['warning_count'] === 0 && $dobErrors['error_count'] === 0));

        if ($validMrn && $validDob) {
            $patientStmt = $conn->prepare("SELECT mrn, first_name, middle_name, last_name, suffix, dob FROM patients WHERE mrn = ? AND dob = ? LIMIT 1");
            if (!$patientStmt) {
                error_log('Queue tracking patient lookup prepare failed: ' . $conn->error);
                $historyLookupError = 'Patient history is temporarily unavailable. Please try again later.';
            } else {
                $mrn = (int)$mrnInput;
                $dob = $dobDate->format('Y-m-d');
                $patientStmt->bind_param('is', $mrn, $dob);
                if (!$patientStmt->execute()) {
                    error_log('Queue tracking patient lookup failed: ' . $patientStmt->error);
                    $historyLookupError = 'Patient history is temporarily unavailable. Please try again later.';
                } else {
                    $historyLookupPatient = $patientStmt->get_result()->fetch_assoc();
                    if (!$historyLookupPatient) {
                        $rateLimit['failed_attempts'] = (int)$rateLimit['failed_attempts'] + 1;
                        if ($rateLimit['failed_attempts'] >= 6) {
                            $rateLimit['blocked_until'] = $now + 900;
                        }
                        $historyLookupError = 'We could not verify those details. Check the MRN and date of birth and try again.';
                    } else {
                        $rateLimit = ['window_started' => $now, 'failed_attempts' => 0, 'blocked_until' => 0];
                        $historyQueries = [
                            'medical' => [
                                "SELECT diagnosis, medications, allergies, notes, created_at FROM medical_history WHERE patient_mrn = ? ORDER BY created_at DESC, id DESC",
                                &$medicalHistory
                            ],
                            'queue' => [
                                "SELECT q.queue_number, q.priority, q.status, q.department, q.created_at, q.called_at, q.completed_at, CONCAT(COALESCE(qs.prefix, 'Q'), LPAD(q.queue_number, 3, '0')) AS display_number FROM queue q LEFT JOIN queue_settings qs ON qs.department = q.department WHERE q.patient_mrn = ? ORDER BY q.created_at DESC, q.id DESC",
                                &$queueHistory
                            ],
                            'appointments' => [
                                "SELECT `date`, `time`, provider, type, department, status, notes, doctor_notes, created_at, completed_at FROM appointments WHERE patient_mrn = ? ORDER BY `date` DESC, `time` DESC, id DESC",
                                &$appointmentHistory
                            ]
                        ];

                        foreach ($historyQueries as $queryName => &$historyQuery) {
                            $historyStmt = $conn->prepare($historyQuery[0]);
                            if (!$historyStmt) {
                                error_log('Queue tracking ' . $queryName . ' history prepare failed: ' . $conn->error);
                                $historyLookupError = 'Some patient history could not be loaded. Please try again later.';
                                $historyLookupPatient = null;
                                break;
                            }
                            $historyStmt->bind_param('i', $mrn);
                            if (!$historyStmt->execute()) {
                                error_log('Queue tracking ' . $queryName . ' history query failed: ' . $historyStmt->error);
                                $historyLookupError = 'Some patient history could not be loaded. Please try again later.';
                                $historyStmt->close();
                                $historyLookupPatient = null;
                                break;
                            }
                            $historyQuery[1] = $historyStmt->get_result()->fetch_all(MYSQLI_ASSOC);
                            $historyStmt->close();
                        }
                        unset($historyQuery);
                    }
                }
                $patientStmt->close();
            }
        } else {
            $rateLimit['failed_attempts'] = (int)$rateLimit['failed_attempts'] + 1;
            if ($rateLimit['failed_attempts'] >= 6) {
                $rateLimit['blocked_until'] = $now + 900;
            }
            $historyLookupError = 'We could not verify those details. Check the MRN and date of birth and try again.';
        }
    }
    unset($rateLimit);
}

$token = $_GET['token'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="referrer" content="no-referrer">
    <title>Track Your Queue | CESH</title>
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>tailwind.config = { darkMode: 'class' };</script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-100 px-4 py-8 text-slate-800 dark:bg-slate-950 dark:text-slate-100">
    <main class="mx-auto max-w-xl">
        <header class="mb-6 text-center">
            <div class="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300">
                <i class="fas fa-ticket-alt text-2xl"></i>
            </div>
            <h1 class="text-2xl font-extrabold">Track Your Queue</h1>
            <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Check the latest status of your hospital visit.</p>
        </header>

        <form id="trackingForm" class="mb-5 flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:flex-row">
            <label for="trackingCode" class="sr-only">Queue ticket tracking code</label>
            <input id="trackingCode" type="text" required autocomplete="off" spellcheck="false"
                placeholder="Enter the tracking code from your ticket"
                class="min-w-0 flex-1 rounded-xl border border-slate-300 bg-slate-50 px-4 py-3 font-mono text-sm outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-800">
            <button type="submit" class="rounded-xl bg-sky-600 px-5 py-3 text-sm font-bold text-white hover:bg-sky-500">
                <i class="fas fa-search mr-2"></i>Track
            </button>
        </form>

        <p id="trackingMessage" role="status" class="mb-4 hidden rounded-xl border px-4 py-3 text-sm"></p>

        <section id="trackingResult" aria-live="polite" class="hidden overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div class="bg-slate-900 px-6 py-6 text-center text-white dark:bg-slate-800">
                <p class="text-xs font-bold uppercase tracking-[0.2em] text-slate-300">Your Queue Number</p>
                <p id="queueNumber" class="mt-2 font-mono text-5xl font-black text-sky-300"></p>
                <p id="queueDepartment" class="mt-2 text-sm text-slate-300"></p>
            </div>
            <div class="space-y-4 p-6">
                <div class="flex items-center justify-between gap-4">
                    <span class="text-sm text-slate-500 dark:text-slate-400">Current status</span>
                    <span id="queueStatus" class="rounded-full px-3 py-1 text-xs font-bold"></span>
                </div>
                <div id="positionPanel" class="hidden rounded-xl bg-sky-50 p-4 dark:bg-sky-500/10">
                    <p class="text-xs font-bold uppercase tracking-wider text-sky-700 dark:text-sky-300">Your place in line</p>
                    <p class="mt-1 text-lg font-bold text-sky-900 dark:text-sky-100"><span id="queuePosition"></span></p>
                </div>
                <div id="servingPanel" class="hidden justify-between rounded-xl bg-slate-50 p-4 dark:bg-slate-800">
                    <span class="text-sm text-slate-500 dark:text-slate-400">Currently serving</span>
                    <span id="currentlyServing" class="font-mono font-bold text-slate-900 dark:text-white"></span>
                </div>
                <p id="lastUpdated" class="text-center text-xs text-slate-400"></p>
            </div>
        </section>

        <section class="mt-8">
            <div class="mb-4">
                <h2 class="text-xl font-extrabold">View Your CESH Medical & Visit History</h2>
                <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Verify your identity with the MRN and date of birth on your patient record.</p>
            </div>
            <form method="post" action="queue_tracking.php" class="mb-5 grid gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:grid-cols-2">
                <input type="hidden" name="action" value="lookup_history">
                <div>
                    <label for="historyMrn" class="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Medical Record Number (MRN)</label>
                    <input id="historyMrn" name="mrn" type="text" inputmode="numeric" pattern="[0-9]{1,10}" maxlength="10" required autocomplete="off"
                        class="w-full rounded-xl border border-slate-300 bg-slate-50 px-4 py-3 font-mono text-sm outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-800">
                </div>
                <div>
                    <label for="historyDob" class="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Date of Birth</label>
                    <input id="historyDob" name="dob" type="date" required autocomplete="bday"
                        class="w-full rounded-xl border border-slate-300 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-800">
                </div>
                <button type="submit" class="rounded-xl bg-sky-600 px-5 py-3 text-sm font-bold text-white hover:bg-sky-500 sm:col-span-2">
                    <i class="fas fa-lock mr-2"></i>Verify & View History
                </button>
            </form>

            <?php if ($historyLookupError !== ''): ?>
                <p role="alert" class="mb-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300"><?= queueTrackingEscape($historyLookupError) ?></p>
            <?php endif; ?>

            <?php if ($historyLookupPatient): ?>
                <?php
                $verifiedNameParts = array_filter([
                    $historyLookupPatient['first_name'],
                    $historyLookupPatient['middle_name'],
                    $historyLookupPatient['last_name'],
                    $historyLookupPatient['suffix']
                ], static fn($part) => trim((string)$part) !== '');
                ?>
                <div class="mb-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 dark:border-emerald-900 dark:bg-emerald-950/30">
                    <p class="text-xs font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-300">Identity verified</p>
                    <p class="mt-1 font-bold text-emerald-950 dark:text-emerald-100"><?= queueTrackingEscape(implode(' ', $verifiedNameParts)) ?> · MRN <?= queueTrackingEscape(str_pad((string)$historyLookupPatient['mrn'], 6, '0', STR_PAD_LEFT)) ?></p>
                    <p class="text-xs text-emerald-800 dark:text-emerald-200">Only share this page with the patient or their authorized caregiver.</p>
                </div>

                <div class="space-y-5">
                    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
                        <h3 class="mb-3 flex items-center gap-2 font-bold"><i class="fas fa-notes-medical text-sky-500"></i> Medical History</h3>
                        <?php if (!$medicalHistory): ?><p class="text-sm text-slate-500 dark:text-slate-400">No medical history records are available.</p><?php endif; ?>
                        <?php foreach ($medicalHistory as $record): ?>
                            <article class="border-t border-slate-100 py-4 first:border-0 first:pt-0 dark:border-slate-800">
                                <p class="mb-3 text-xs text-slate-400"><?= queueTrackingEscape(queueTrackingFormatDate($record['created_at'])) ?></p>
                                <?php foreach (['diagnosis' => 'Diagnosis', 'medications' => 'Medications', 'allergies' => 'Allergies', 'notes' => 'Notes'] as $field => $label): ?>
                                    <?php if (trim((string)$record[$field]) !== ''): ?>
                                        <div class="mb-2">
                                            <p class="text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400"><?= $label ?></p>
                                            <p class="whitespace-pre-wrap break-words text-sm"><?= queueTrackingEscape($record[$field]) ?></p>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </article>
                        <?php endforeach; ?>
                    </section>

                    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
                        <h3 class="mb-3 flex items-center gap-2 font-bold"><i class="fas fa-ticket-alt text-amber-500"></i> Queue Transactions</h3>
                        <?php if (!$queueHistory): ?><p class="text-sm text-slate-500 dark:text-slate-400">No queue transactions are available.</p><?php endif; ?>
                        <?php foreach ($queueHistory as $record): ?>
                            <div class="border-t border-slate-100 py-3 first:border-0 first:pt-0 dark:border-slate-800">
                                <div class="flex flex-wrap items-center justify-between gap-2">
                                    <p class="font-mono font-bold"><?= queueTrackingEscape($record['display_number']) ?> <span class="font-sans font-normal">· <?= queueTrackingEscape($record['department'] === '0' ? 'Department not recorded' : $record['department']) ?></span></p>
                                    <span class="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold dark:bg-slate-800"><?= queueTrackingEscape($record['status']) ?></span>
                                </div>
                                <p class="text-xs text-slate-500 dark:text-slate-400"><?= queueTrackingEscape(queueTrackingFormatDate($record['created_at'])) ?> · <?= queueTrackingEscape($record['priority']) ?></p>
                            </div>
                        <?php endforeach; ?>
                    </section>

                    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
                        <h3 class="mb-3 flex items-center gap-2 font-bold"><i class="fas fa-calendar-check text-emerald-500"></i> Appointment Transactions</h3>
                        <?php if (!$appointmentHistory): ?><p class="text-sm text-slate-500 dark:text-slate-400">No appointment records are available.</p><?php endif; ?>
                        <?php foreach ($appointmentHistory as $record): ?>
                            <article class="border-t border-slate-100 py-3 first:border-0 first:pt-0 dark:border-slate-800">
                                <div class="flex flex-wrap items-center justify-between gap-2">
                                    <p class="font-semibold"><?= queueTrackingEscape($record['type'] ?: 'Appointment') ?> · <?= queueTrackingEscape($record['department'] ?: 'Department not recorded') ?></p>
                                    <span class="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold dark:bg-slate-800"><?= queueTrackingEscape($record['status']) ?></span>
                                </div>
                                <p class="text-xs text-slate-500 dark:text-slate-400"><?= queueTrackingEscape($record['date']) ?> <?= queueTrackingEscape($record['time']) ?> · <?= queueTrackingEscape($record['provider']) ?></p>
                                <?php foreach (['notes' => 'Notes', 'doctor_notes' => 'Provider notes'] as $field => $label): ?>
                                    <?php if (trim((string)$record[$field]) !== ''): ?>
                                        <p class="mt-2 whitespace-pre-wrap break-words text-sm"><span class="font-bold"><?= $label ?>:</span> <?= queueTrackingEscape($record[$field]) ?></p>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </article>
                        <?php endforeach; ?>
                    </section>
                </div>
            <?php endif; ?>
        </section>

        <p class="mt-5 text-center text-xs text-slate-500 dark:text-slate-400">
            Your tracking code is private. Keep it with your queue ticket.
        </p>
    </main>

    <script>
        const form = document.getElementById('trackingForm');
        const codeInput = document.getElementById('trackingCode');
        const message = document.getElementById('trackingMessage');
        const result = document.getElementById('trackingResult');
        let refreshTimer;

        function showMessage(text, isError = true) {
            message.textContent = text;
            message.className = `mb-4 rounded-xl border px-4 py-3 text-sm ${isError
                ? 'border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300'
                : 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-300'}`;
        }

        function formatDateTime(value) {
            if (!value) return '';
            const date = new Date(String(value).replace(' ', 'T'));
            return Number.isNaN(date.getTime()) ? '' : date.toLocaleString();
        }

        async function refreshTracking(token) {
            try {
                const response = await fetch(`queue_tracking_api.php?token=${encodeURIComponent(token)}`, {
                    cache: 'no-store',
                    headers: { 'Accept': 'application/json' }
                });
                const data = await response.json();
                if (!response.ok || !data.success) {
                    result.classList.add('hidden');
                    showMessage(data.error || 'Unable to load queue status.');
                    clearInterval(refreshTimer);
                    return;
                }

                document.getElementById('queueNumber').textContent = data.queue_number;
                document.getElementById('queueDepartment').textContent = data.department;
                const status = document.getElementById('queueStatus');
                status.textContent = data.status;
                const statusColors = {
                    'Waiting': 'bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300',
                    'In Consultation': 'bg-sky-100 text-sky-800 dark:bg-sky-500/15 dark:text-sky-300',
                    'Completed': 'bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300',
                    'Cancelled': 'bg-rose-100 text-rose-800 dark:bg-rose-500/15 dark:text-rose-300',
                    'No Show': 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200'
                };
                status.className = `rounded-full px-3 py-1 text-xs font-bold ${statusColors[data.status] || statusColors['No Show']}`;

                const positionPanel = document.getElementById('positionPanel');
                positionPanel.classList.toggle('hidden', data.status !== 'Waiting');
                if (data.status === 'Waiting') {
                    document.getElementById('queuePosition').textContent =
                        `You are #${data.position} in line.`;
                }

                const servingPanel = document.getElementById('servingPanel');
                servingPanel.classList.toggle('hidden', !data.currently_serving);
                servingPanel.style.display = data.currently_serving ? 'flex' : '';
                document.getElementById('currentlyServing').textContent = data.currently_serving || '';

                let updateText = `Registered ${formatDateTime(data.created_at)}`;
                if (data.status === 'In Consultation' && data.called_at) {
                    updateText = `Called ${formatDateTime(data.called_at)}`;
                } else if (data.status === 'Completed' && data.completed_at) {
                    updateText = `Completed ${formatDateTime(data.completed_at)}`;
                }
                document.getElementById('lastUpdated').textContent = updateText;
                message.classList.add('hidden');
                result.classList.remove('hidden');
                if (['Completed', 'Cancelled', 'No Show'].includes(data.status)) {
                    clearInterval(refreshTimer);
                }
            } catch (error) {
                showMessage('Could not refresh queue status. Check your connection and try again.');
                console.error('Queue tracking refresh failed:', error);
            }
        }

        form.addEventListener('submit', event => {
            event.preventDefault();
            const token = codeInput.value.trim();
            if (!/^[a-f0-9]{64}$/i.test(token)) {
                clearInterval(refreshTimer);
                result.classList.add('hidden');
                showMessage('The tracking code should contain 64 letters or numbers from your ticket.');
                return;
            }
            clearInterval(refreshTimer);
            refreshTracking(token);
            refreshTimer = setInterval(() => refreshTracking(token), 10000);
        });

        const initialToken = new URLSearchParams(window.location.search).get('token');
        if (initialToken) {
            codeInput.value = initialToken;
            form.requestSubmit();
        }
    </script>
</body>
</html>
