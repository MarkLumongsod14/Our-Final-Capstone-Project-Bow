<?php
// config/email.php - Email Configuration
// Camp Evangelista Station Hospital

// ============================================
// EMAIL SETTINGS - Configure for your environment
// ============================================

// SMTP Configuration (recommended)
define('SMTP_HOST', 'smtp.gmail.com');      // Your SMTP host
define('SMTP_PORT', 587);                    // 587 for TLS, 465 for SSL
define('SMTP_USERNAME', 'your-email@gmail.com'); // Your email
define('SMTP_PASSWORD', 'your-app-password');    // Your app password
define('SMTP_FROM_EMAIL', 'noreply@camp-evangelista-hospital.com');
define('SMTP_FROM_NAME', 'Camp Evangelista Station Hospital');
define('SMTP_SECURE', 'tls');                // 'tls' or 'ssl'

// Or use PHP's mail() function (fallback)
define('USE_SMTP', true);                    // Set to false to use PHP mail()

// Email templates path
define('EMAIL_TEMPLATE_PATH', __DIR__ . '/../email-templates/');

?>