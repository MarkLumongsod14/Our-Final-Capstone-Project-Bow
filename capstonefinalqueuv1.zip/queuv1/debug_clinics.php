<?php
// debug_clinics.php - Place this in your root folder (C:\xampp\htdocs\queu\)

// Fix: Use the correct path - since this file is in the root, 
// the config is in the config folder
require_once __DIR__ . '/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<h2>Clinic List Debug</h2>";

// Get all clinics
$query = "SELECT id, name, is_active FROM clinics ORDER BY id";
$clinics = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

echo "<table border='1' cellpadding='8'>";
echo "<tr><th>ID</th><th>Name</th><th>is_active</th></tr>";
foreach ($clinics as $clinic) {
    echo "<tr>";
    echo "<td>" . $clinic['id'] . "</td>";
    echo "<td>" . $clinic['name'] . "</td>";
    echo "<td>" . $clinic['is_active'] . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "<h3>Total Clinics: " . count($clinics) . "</h3>";

// Check if ENT and Physical Therapy are active
$check = $db->query("SELECT id, name, is_active FROM clinics WHERE name LIKE '%ENT%' OR name LIKE '%Physical%'");
$found = $check->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>ENT and Physical Therapy:</h3>";
echo "<pre>";
print_r($found);
echo "</pre>";

// Check if any clinics are missing (ID 15 specifically)
$check_id = $db->query("SELECT id, name, is_active FROM clinics WHERE id = 15");
$id_15 = $check_id->fetch(PDO::FETCH_ASSOC);

echo "<h3>Check ID 15 (ENT should be here):</h3>";
if ($id_15) {
    echo "<pre>";
    print_r($id_15);
    echo "</pre>";
} else {
    echo "<p style='color: red;'>❌ ID 15 does NOT exist in the database!</p>";
}
?>