<?php
require_once __DIR__ . '/config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get all clinics
$query = "SELECT id, name, is_active FROM clinics ORDER BY id";
$clinics = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

echo "<h2>All Clinics in Database</h2>";
echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
echo "<tr><th>ID</th><th>Name</th><th>Active</th></tr>";

$ids = [];
foreach ($clinics as $clinic) {
    $ids[] = $clinic['id'];
    echo "<tr>";
    echo "<td>" . $clinic['id'] . "</td>";
    echo "<td>" . $clinic['name'] . "</td>";
    echo "<td>" . ($clinic['is_active'] ? '✅ Active' : '❌ Inactive') . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "<h3>Total: " . count($clinics) . " clinics</h3>";

// Check for duplicates
$names = array_column($clinics, 'name');
$duplicates = array_diff_assoc($names, array_unique($names));

if (!empty($duplicates)) {
    echo "<h3 style='color: red;'>⚠️ DUPLICATES FOUND:</h3>";
    foreach ($duplicates as $key => $name) {
        echo "<p style='color: red;'>Duplicate: " . $name . " at ID " . $clinics[$key]['id'] . "</p>";
    }
} else {
    echo "<h3 style='color: green;'>✅ No duplicates found</h3>";
}

// Check if ENT exists
$ent = $db->query("SELECT id, name FROM clinics WHERE name LIKE '%ENT%'")->fetchAll(PDO::FETCH_ASSOC);
echo "<h3>ENT entries:</h3>";
echo "<pre>";
print_r($ent);
echo "</pre>";

// Check if Physical Therapy exists
$pt = $db->query("SELECT id, name FROM clinics WHERE name LIKE '%Physical%'")->fetchAll(PDO::FETCH_ASSOC);
echo "<h3>Physical Therapy entries:</h3>";
echo "<pre>";
print_r($pt);
echo "</pre>";

echo "<p>IDs in database: " . implode(', ', $ids) . "</p>";
echo "<p>Expected: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16</p>";
?>