<?php
// check-phpmailer.php - Verify PHPMailer installation

echo "<h2>PHPMailer Installation Check</h2>";

// Check if autoload exists
if (file_exists('vendor/autoload.php')) {
    echo "✅ vendor/autoload.php found<br>";
    require_once 'vendor/autoload.php';
} else {
    echo "❌ vendor/autoload.php NOT found<br>";
}

// Check if PHPMailer class exists
if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
    echo "✅ PHPMailer class found!<br>";
    echo "<br><strong style='color: green;'>PHPMailer is ready to use!</strong>";
} else {
    echo "❌ PHPMailer class NOT found<br>";
    
    // Check individual files
    echo "<br><h3>Checking individual files:</h3>";
    
    $files = [
        'vendor/phpmailer/src/PHPMailer.php',
        'vendor/phpmailer/src/SMTP.php',
        'vendor/phpmailer/src/Exception.php'
    ];
    
    foreach ($files as $file) {
        if (file_exists($file)) {
            echo "✅ " . $file . " - Found<br>";
        } else {
            echo "❌ " . $file . " - NOT FOUND<br>";
        }
    }
}
?>