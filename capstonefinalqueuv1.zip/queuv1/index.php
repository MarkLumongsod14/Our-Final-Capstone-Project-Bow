<?php
$ceshAppPath = getenv('CESH_APP_PATH') ?: dirname(__DIR__) . DIRECTORY_SEPARATOR . 'CESH';
require_once rtrim($ceshAppPath, '\\/') . DIRECTORY_SEPARATOR . 'unified_session.php';
header('Location: ' . UnifiedSession::loginUrl());
exit;
// Enable GZIP compression (must be first!)
require_once __DIR__ . '/includes/Compression.php';
Compression::start();

// Start session and load config
session_start();
require_once 'config/database.php';
require_once 'includes/GoogleAuthenticator.php';
require_once 'includes/SessionManager.php';

// Rate limiting configuration
$max_attempts = 5;
$lockout_time = 15;

// Get client IP
$ip_address = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// If already logged in, redirect
if (isset($_SESSION['user_id'])) {
    if (in_array($_SESSION['role'], ['admin', 'admin_dashboard'], true)) {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: staff/clinic-dashboard.php?clinic_id=' . $_SESSION['clinic_id']);
    }
    exit();
}

// Initialize session login attempts
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = [
        'count' => 0,
        'first_attempt' => time(),
        'locked_until' => 0
    ];
}

if (!isset($_SESSION['login_captcha'])) {
    $_SESSION['login_captcha'] = [
        'first' => random_int(1, 9),
        'second' => random_int(1, 9)
    ];
}

// Check if session is locked
if ($_SESSION['login_attempts']['locked_until'] > time()) {
    $remaining_minutes = ceil(($_SESSION['login_attempts']['locked_until'] - time()) / 60);
    $error = "Too many failed attempts. Please try again in {$remaining_minutes} minutes.";
}

// Reset counter if time window passed (30 minutes)
if (time() - $_SESSION['login_attempts']['first_attempt'] > 1800) {
    $_SESSION['login_attempts'] = [
        'count' => 0,
        'first_attempt' => time(),
        'locked_until' => 0
    ];
}

// Function to log login attempts
function logLoginAttempt($db, $username, $success, $reason = null, $user_id = null) {
    global $ip_address, $user_agent;
    
    $query = "INSERT INTO login_history (user_id, username, ip_address, user_agent, success, failure_reason) 
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    $stmt->execute([$user_id, $username, $ip_address, $user_agent, $success, $reason]);

    $activityLogger = new SessionManager($db);
    if ($success) {
        $activityLogger->logActivity('Successful login');
    } else {
        $safe_reason = preg_replace('/[^a-zA-Z0-9 ._-]/', '', (string) ($reason ?: 'Unspecified reason'));
        $activityLogger->logUnauthenticatedActivity('Failed login attempt: ' . $safe_reason);
    }
}

$error = '';
$show_2fa = false;
$temp_user = null;
$stored_username = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_SESSION['login_attempts']['locked_until'] > time()) {
        $error = "Account temporarily locked. Please try again later.";
        $database = new Database();
        $db = $database->getConnection();
        if ($db) {
            logLoginAttempt($db, trim($_POST['username'] ?? ''), 0, 'Session temporarily locked');
        }
    }
    else {
        $database = new Database();
        $db = $database->getConnection();
        
        // Check if this is 2FA verification step - check for 2fa_code OR verify_2fa
        if (isset($_POST['2fa_code']) && !empty($_POST['2fa_code'])) {
            $user_id = $_SESSION['2fa_user_id'] ?? 0;
            $code = trim($_POST['2fa_code'] ?? '');
            $stored_username = $_SESSION['2fa_username'] ?? '';
            
            if (empty($user_id) || empty($code)) {
                $error = 'Invalid verification request';
            } else {
                $query = "SELECT u.*, c.name as clinic_name 
                          FROM users u
                          LEFT JOIN clinics c ON u.clinic_id = c.id
                          WHERE u.id = ?";
                $stmt = $db->prepare($query);
                $stmt->execute([$user_id]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$user) {
                    $error = 'User not found';
                    logLoginAttempt($db, $stored_username, 0, 'User not found during 2FA');
                    error_log("2FA Error: User not found for ID $user_id");
                } 
                elseif ((int) ($user['twofa_enabled'] ?? 0) !== 1) {
                    $error = 'Two-factor authentication is not enabled for this account. Sign in again.';
                    unset($_SESSION['2fa_user_id'], $_SESSION['2fa_username']);
                    logLoginAttempt($db, $stored_username, 0, '2FA no longer enabled', $user_id);
                }
                elseif (!in_array($user['role'], ['admin', 'admin_dashboard'], true) && empty($user['clinic_id'])) {
                    $error = 'Your account has no clinic assigned. Please contact the administrator.';
                    logLoginAttempt($db, $stored_username, 0, 'No clinic assigned', $user_id);
                }
                elseif (empty($user['twofa_secret'])) {
                    $error = '2FA not set up for this user. Please contact administrator.';
                    logLoginAttempt($db, $stored_username, 0, '2FA not set up', $user_id);
                    error_log("2FA Error: No secret for user ID $user_id");
                }
                else {
                    $ga = new GoogleAuthenticator();
                    
                    if ($ga->verifyCode($user['twofa_secret'], $code, 2)) {
                        error_log("2FA Code VERIFIED successfully!");
                        
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['full_name'] = $user['full_name'];
                        $_SESSION['role'] = $user['role'];
                        $_SESSION['clinic_id'] = $user['clinic_id'];
                        $_SESSION['clinic_name'] = $user['clinic_name'];
                        $_SESSION['last_activity'] = time();
                        
                        $update = "UPDATE users SET last_login_time = NOW(), last_login_ip = ? WHERE id = ?";
                        $update_stmt = $db->prepare($update);
                        $update_stmt->execute([$ip_address, $user['id']]);
                        
                        unset($_SESSION['2fa_user_id']);
                        unset($_SESSION['2fa_username']);
                        logLoginAttempt($db, $user['username'], 1, null, $user['id']);
                        
                        if (in_array($user['role'], ['admin', 'admin_dashboard'], true)) {
                            header('Location: admin/dashboard.php');
                        } else {
                            header('Location: staff/clinic-dashboard.php?clinic_id=' . $user['clinic_id']);
                        }
                        exit();
                    } else {
                        $error = 'Invalid 2FA code. Please try again.';
                        logLoginAttempt($db, $stored_username, 0, 'Invalid 2FA code', $user['id']);
                        $_SESSION['login_attempts']['count']++;
                        error_log("2FA Code VERIFICATION FAILED");
                    }
                }
            }
        }
        else {
            // Initial login step - check for username and password
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            
            error_log("Initial Login - Username: $username");
            
            if (empty($username) || empty($password)) {
                $error = 'Username and password are required';
                logLoginAttempt($db, $username, 0, 'Missing username or password');
                error_log("Login Error: Empty username or password");
            } else {
                usleep(rand(100000, 300000));
                
                $query = "SELECT u.*, c.name as clinic_name 
                          FROM users u
                          LEFT JOIN clinics c ON u.clinic_id = c.id
                          WHERE u.username = :username";
                
                $stmt = $db->prepare($query);
                $stmt->bindParam(':username', $username);
                $stmt->execute();
                
                if ($stmt->rowCount() > 0) {
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                    error_log("User found: " . $user['username']);
                    
                    // Check if account is active (if column exists)
                    if (isset($user['is_active']) && $user['is_active'] == 0) {
                        $error = 'Your account has been deactivated. Please contact administrator.';
                        logLoginAttempt($db, $username, 0, 'Account deactivated', $user['id']);
                        error_log("Login Error: Account deactivated");
                    }
                    elseif (isset($user['locked_until']) && $user['locked_until'] && strtotime($user['locked_until']) > time()) {
                        $lockout_minutes = ceil((strtotime($user['locked_until']) - time()) / 60);
                        $error = "Account is locked. Try again in {$lockout_minutes} minutes.";
                        logLoginAttempt($db, $username, 0, 'Account locked', $user['id']);
                        error_log("Login Error: Account locked until " . $user['locked_until']);
                    }
                    elseif (!in_array($user['role'], ['admin', 'admin_dashboard'], true) && empty($user['clinic_id'])) {
                        $error = 'Your account has no clinic assigned. Please contact the administrator.';
                        logLoginAttempt($db, $username, 0, 'No clinic assigned', $user['id']);
                    }
                    elseif ($user['role'] != 'admin' && (int) ($_POST['captcha_answer'] ?? -1) !== (int) ($_SESSION['login_captcha']['first'] + $_SESSION['login_captcha']['second'])) {
                        $error = 'Incorrect CAPTCHA answer. Please try again.';
                        $_SESSION['login_captcha'] = [
                            'first' => random_int(1, 9),
                            'second' => random_int(1, 9)
                        ];
                        logLoginAttempt($db, $username, 0, 'Invalid CAPTCHA', $user['id']);
                    }
                    elseif (password_verify($password, $user['password'])) {
                        error_log("Password VERIFIED for: " . $username);
                        
                        // Check if 2FA is enabled
                        if ((int) ($user['twofa_enabled'] ?? 0) === 1) {
                            // Store user info in session for 2FA verification
                            $_SESSION['2fa_user_id'] = $user['id'];
                            $_SESSION['2fa_username'] = $username;
                            $show_2fa = true;
                            $stored_username = $username;
                            error_log("2FA Required - Showing 2FA form for: " . $username);
                        } else {
                            // No 2FA - login directly
                            error_log("No 2FA - Logging in directly: " . $username);
                            
                            $_SESSION['user_id'] = $user['id'];
                            $_SESSION['username'] = $user['username'];
                            $_SESSION['full_name'] = $user['full_name'];
                            $_SESSION['role'] = $user['role'];
                            $_SESSION['clinic_id'] = $user['clinic_id'];
                            $_SESSION['clinic_name'] = $user['clinic_name'];
                            $_SESSION['last_activity'] = time();
                            
                            // Reset login attempts
                            if (isset($user['login_attempts'])) {
                                $reset = "UPDATE users SET login_attempts = 0, locked_until = NULL WHERE id = ?";
                                $reset_stmt = $db->prepare($reset);
                                $reset_stmt->execute([$user['id']]);
                            }
                            
                            $update = "UPDATE users SET last_login_time = NOW(), last_login_ip = ? WHERE id = ?";
                            $update_stmt = $db->prepare($update);
                            $update_stmt->execute([$ip_address, $user['id']]);
                            
                            logLoginAttempt($db, $username, 1, null, $user['id']);
                            unset($_SESSION['login_captcha']);
                            
                            $_SESSION['login_attempts'] = [
                                'count' => 0,
                                'first_attempt' => time(),
                                'locked_until' => 0
                            ];
                            
                            if (in_array($user['role'], ['admin', 'admin_dashboard'], true)) {
                                header('Location: admin/dashboard.php');
                            } else {
                                header('Location: staff/clinic-dashboard.php?clinic_id=' . $user['clinic_id']);
                            }
                            exit();
                        }
                    } else {
                        $error = 'Invalid username or password';
                        error_log("Login Error: Password verification FAILED for: " . $username);
                        
                        // Update login attempts (if column exists)
                        if (isset($user['login_attempts'])) {
                            $new_attempts = $user['login_attempts'] + 1;
                            
                            if ($new_attempts >= $max_attempts) {
                                $lock_until = date('Y-m-d H:i:s', time() + ($lockout_time * 60));
                                $update = "UPDATE users SET login_attempts = ?, locked_until = ?, last_login_attempt = NOW() WHERE id = ?";
                                $update_stmt = $db->prepare($update);
                                $update_stmt->execute([$new_attempts, $lock_until, $user['id']]);
                                $_SESSION['login_attempts']['locked_until'] = time() + ($lockout_time * 60);
                                $error = "Too many failed attempts. Account locked for {$lockout_time} minutes.";
                            } else {
                                $update = "UPDATE users SET login_attempts = ?, last_login_attempt = NOW() WHERE id = ?";
                                $update_stmt = $db->prepare($update);
                                $update_stmt->execute([$new_attempts, $user['id']]);
                            }
                        }
                        
                        logLoginAttempt($db, $username, 0, 'Invalid password', $user['id']);
                        $_SESSION['login_attempts']['count']++;
                        
                        if ($_SESSION['login_attempts']['count'] >= $max_attempts) {
                            $_SESSION['login_attempts']['locked_until'] = time() + ($lockout_time * 60);
                            $error = "Too many failed attempts. Please try again in {$lockout_time} minutes.";
                        }
                    }
                } else {
                    $error = 'Invalid username or password';
                    logLoginAttempt($db, $username, 0, 'User not found');
                    error_log("Login Error: User not found: " . $username);
                    $_SESSION['login_attempts']['count']++;
                    
                    if ($_SESSION['login_attempts']['count'] >= $max_attempts) {
                        $_SESSION['login_attempts']['locked_until'] = time() + ($lockout_time * 60);
                        $error = "Too many failed attempts. Please try again in {$lockout_time} minutes.";
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Login | 4ID Station Hospital | Camp Evangelista</title>
    
    <!-- Google Fonts & FontAwesome -->
            <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/logo.png">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>

    </script>
</head>
<body class="font-sans antialiased text-zinc-300 bg-zinc-950 min-h-screen flex flex-col lg:flex-row">

    <!-- LEFT SECTION: Branding & Information -->
    <div class="hidden lg:flex lg:w-5/12 xl:w-1/2 bg-zinc-900 relative flex-col justify-between p-12 xl:p-16 overflow-hidden border-r border-zinc-800/50">
        
        <!-- Abstract Background Effects -->
        <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:32px_32px]"></div>
        <div class="absolute -top-40 -left-40 w-96 h-96 bg-sky-600/20 rounded-full blur-[100px]"></div>
        <div class="absolute -bottom-40 -right-40 w-96 h-96 bg-sky-500/10 rounded-full blur-[100px]"></div>

        <!-- Top Badge -->
        <div class="relative z-10 flex items-center justify-center gap-3">
            <i class="fas fa-shield-halved text-sky-500 text-xl"></i>
            <span class="font-bold tracking-widest text-xs text-zinc-400 uppercase">Military Healthcare Portal</span>
        </div>

        <!-- Center Content with Circular Local Logo -->
        <div class="relative z-10 my-auto flex flex-col items-center text-center">
            <div class="w-28 h-28 bg-zinc-800/50 border border-zinc-700/50 rounded-full flex items-center justify-center p-4 mb-8 backdrop-blur-md shadow-[0_0_30px_rgba(14,165,233,0.15)] overflow-hidden">
                <img src="assets/images/logo.png" alt="4ID Station Hospital Logo" class="w-full h-full object-contain">
            </div>
            
            <h1 class="text-4xl xl:text-5xl font-extrabold tracking-tight mb-5 text-white leading-tight">
                4ID Station Hospital
            </h1>
            
            <p class="text-lg xl:text-xl text-zinc-400 font-medium max-w-md leading-relaxed mb-8 mx-auto">
                Camp Evangelista Outpatient Record Management &amp; Smart Queueing System.
            </p>

            <div class="inline-flex items-center gap-3 bg-zinc-800/50 border border-zinc-700/50 px-4 py-2 rounded-full text-xs font-semibold text-zinc-300 backdrop-blur-sm">
                <span class="relative flex h-2 w-2">
                  <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                  <span class="relative inline-flex rounded-full h-2 w-2 bg-sky-500"></span>
                </span>
                Secure System Active
            </div>
        </div>

        <!-- Footer Note -->
        <div class="relative z-10 text-xs text-zinc-500 font-medium text-center">
            &copy; <?php echo date('Y'); ?> 4th Infantry Division. All rights reserved.
        </div>
    </div>

    <!-- RIGHT SECTION: Login Form -->
    <div class="flex-1 flex items-center justify-center min-h-screen relative p-6 sm:p-12 lg:p-16">
        
        <div class="w-full max-w-md relative z-10">
            
            <!-- Mobile Header -->
            <div class="lg:hidden text-center mb-10 mt-4">
                <div class="w-20 h-20 bg-zinc-900 border border-zinc-800 rounded-full flex items-center justify-center mx-auto p-3 mb-4 shadow-[0_0_20px_rgba(14,165,233,0.1)] overflow-hidden">
                    <img src="assets/images/logo.png" alt="4ID Station Hospital Logo" class="w-full h-full object-contain">
                </div>
                <h2 class="text-2xl font-extrabold text-white tracking-tight">4ID Station Hospital</h2>
                <p class="text-xs text-zinc-400 mt-1 font-medium">Camp Evangelista</p>
            </div>

            <!-- Form Welcome Text -->
            <div class="mb-8">
                <h2 class="text-3xl font-bold text-white mb-2"><?php echo $show_2fa ? 'Security Check' : 'Welcome Back'; ?></h2>
                <p class="text-sm text-zinc-400 font-medium">
                    <?php echo $show_2fa ? 'Please verify your identity to continue.' : 'Enter your credentials to access the portal.'; ?>
                </p>
            </div>

            <!-- Attempt Counter Alert -->
            <?php if ($_SESSION['login_attempts']['count'] > 0 && !$show_2fa): ?>
            <div class="flex items-center justify-between text-xs font-medium text-amber-400 bg-amber-900/20 border border-amber-700/30 px-4 py-3 rounded-xl mb-6">
                <span class="flex items-center gap-2">
                    <i class="fas fa-triangle-exclamation text-amber-500"></i>
                    <span>Failed Login Attempts</span>
                </span>
                <span class="bg-amber-900/50 border border-amber-700/30 px-2.5 py-0.5 rounded-md font-bold text-amber-300">
                    <?php echo $_SESSION['login_attempts']['count']; ?> / <?php echo $max_attempts; ?>
                </span>
            </div>
            <?php endif; ?>

            <!-- Error Message Box -->
            <?php if ($error): ?>
                <div class="flex items-start gap-3 px-4 py-3.5 rounded-xl mb-6 text-xs font-medium bg-rose-900/20 border border-rose-800/30 text-rose-400 animate-slide-in shadow-sm">
                    <i class="fas fa-circle-exclamation text-sm mt-0.5 text-rose-500 shrink-0"></i>
                    <div class="leading-relaxed"><?php echo $error; ?></div>
                </div>
            <?php endif; ?>

            <!-- Forms Container -->
            <?php if ($show_2fa): ?>
                <!-- 2FA Verification Step -->
                <form method="POST" class="space-y-5" id="twofaForm">
                    <div>
                        <label class="block mb-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">
                            Authentication Code
                        </label>
                        <div class="relative flex items-center">
                            <span class="absolute left-4 text-sky-500">
                                <i class="fas fa-qrcode text-lg"></i>
                            </span>
                            <input type="text" name="2fa_code" id="twofa_code"
                                   class="w-full pl-12 pr-4 py-3.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-center text-xl font-mono tracking-[8px] font-bold transition duration-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none placeholder:tracking-normal placeholder:font-sans placeholder:text-sm placeholder:font-normal placeholder:text-zinc-600 shadow-sm"
                                   placeholder="000000" maxlength="6" pattern="[0-9]{6}" autocomplete="off" required>
                        </div>
                        <p class="mt-2 text-[11px] text-zinc-500 flex items-center gap-1.5">
                            <i class="fas fa-info-circle text-zinc-400"></i>
                            Enter the 6-digit code from your authenticator app.
                        </p>
                    </div>

                    <button type="submit" id="verifyButton"
                            class="w-full py-3.5 px-5 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 rounded-xl text-white text-sm font-bold flex items-center justify-center gap-2 transition duration-200 shadow-[0_0_20px_rgba(14,165,233,0.25)] cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed">
                        <i class="fas fa-shield-check"></i> Verify &amp; Login
                    </button>

                    <a href="index.php"
                       class="w-full py-3.5 px-5 bg-zinc-900 hover:bg-zinc-800 rounded-xl text-zinc-300 text-sm font-semibold flex items-center justify-center gap-2 transition duration-200 no-underline border border-zinc-800 shadow-sm">
                        <i class="fas fa-arrow-left"></i> Cancel
                    </a>
                </form>
            <?php else: ?>
                <!-- Standard Login Step -->
                <form method="POST" class="space-y-5" id="loginForm">
                    <div>
                        <label class="block mb-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">
                            Username
                        </label>
                        <div class="relative flex items-center">
                            <span class="absolute left-4 text-zinc-500">
                                <i class="fas fa-user"></i>
                            </span>
                            <input type="text" name="username"
                                   class="w-full pl-11 pr-4 py-3.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm font-medium transition duration-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none placeholder:text-zinc-600 shadow-sm"
                                   placeholder="Enter your military ID / username"
                                   value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
                        </div>
                    </div>

                    <div>
                        <div class="flex items-center justify-between mb-2">
                            <label class="block text-xs font-bold text-zinc-400 uppercase tracking-wider">
                                Password
                            </label>
                        </div>
                        <div class="relative flex items-center">
                            <span class="absolute left-4 text-zinc-500">
                                <i class="fas fa-lock"></i>
                            </span>
                            <input type="password" name="password" id="loginPassword"
                                   class="w-full pl-11 pr-12 py-3.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm font-medium transition duration-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none placeholder:text-zinc-600 shadow-sm"
                                   placeholder="Enter your password" required>
                            <button type="button" id="toggleLoginPassword"
                                    class="absolute right-3 p-2 text-zinc-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-lg transition"
                                    aria-label="Show password" title="Show password" aria-pressed="false">
                                <i class="fas fa-eye" aria-hidden="true"></i>
                            </button>
                        </div>
                    </div>

                    <div>
                        <label class="block mb-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">
                            Security Check <span class="normal-case text-zinc-500">(non-admin accounts)</span>
                        </label>
                        <div class="relative flex items-center">
                            <span class="absolute left-4 text-zinc-500">
                                <i class="fas fa-calculator"></i>
                            </span>
                            <div class="w-full pl-11 pr-4 py-3.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm font-bold">
                                What is <?php echo $_SESSION['login_captcha']['first']; ?> + <?php echo $_SESSION['login_captcha']['second']; ?>?
                            </div>
                        </div>
                        <input type="number" name="captcha_answer" min="2" max="18" inputmode="numeric"
                               class="w-full mt-2 px-4 py-3.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm font-medium transition duration-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none placeholder:text-zinc-600 shadow-sm"
                               placeholder="Enter the answer (required for non-admin accounts)">
                    </div>

                    <button type="submit" id="loginButton"
                            class="w-full py-3.5 px-5 mt-2 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 rounded-xl text-white text-sm font-bold flex items-center justify-center gap-2 transition duration-200 shadow-[0_0_20px_rgba(14,165,233,0.2)] cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed">
                        <i class="fas fa-right-to-bracket"></i> Sign In
                    </button>
                </form>
            <?php endif; ?>

            <!-- Interactive Staff Demo Credentials Accordion -->
            <div class="mt-8 pt-6 border-t border-zinc-800/60">
                <details class="group bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
                    <summary class="flex items-center justify-between cursor-pointer list-none p-4 text-xs font-bold text-zinc-300 uppercase tracking-wider select-none hover:bg-zinc-800/50 transition">
                        <span class="flex items-center gap-2">
                            <i class="fas fa-id-card-clip text-sky-500 text-lg"></i>
                            <span>View Demo Credentials</span>
                        </span>
                        <i class="fas fa-chevron-down text-zinc-500 text-sm transition-transform duration-300 group-open:rotate-180"></i>
                    </summary>
                    
                    <div class="p-4 pt-0 border-t border-zinc-800/50 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] bg-zinc-900">
                        <div class="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 shadow-sm">
                            <div class="font-semibold text-zinc-300 flex items-center gap-1.5 mb-1"><i class="fas fa-crown text-amber-500"></i> Administrator</div>
                            <div class="font-mono text-sky-400 font-medium">admin / admin123</div>
                        </div>
                        <div class="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 shadow-sm">
                            <div class="font-semibold text-zinc-300 flex items-center gap-1.5 mb-1"><i class="fas fa-hospital-user text-zinc-400"></i> Registration</div>
                            <div class="font-mono text-sky-400 font-medium">reg_staff / clinic123</div>
                        </div>
                        <div class="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 shadow-sm">
                            <div class="font-semibold text-zinc-300 flex items-center gap-1.5 mb-1"><i class="fas fa-heartbeat text-rose-400"></i> Vital Signs</div>
                            <div class="font-mono text-sky-400 font-medium">vital_staff / clinic123</div>
                        </div>
                        <div class="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 shadow-sm">
                            <div class="font-semibold text-zinc-300 flex items-center gap-1.5 mb-1"><i class="fas fa-vial text-purple-400"></i> Laboratory</div>
                            <div class="font-mono text-sky-400 font-medium">lab_tech / clinic123</div>
                        </div>
                        <div class="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 shadow-sm">
                            <div class="font-semibold text-zinc-300 flex items-center gap-1.5 mb-1"><i class="fas fa-x-ray text-zinc-400"></i> X-Ray</div>
                            <div class="font-mono text-sky-400 font-medium">xray_tech / clinic123</div>
                        </div>
                        <div class="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 shadow-sm">
                            <div class="font-semibold text-zinc-300 flex items-center gap-1.5 mb-1"><i class="fas fa-wave-square text-blue-400"></i> ECG</div>
                            <div class="font-mono text-sky-400 font-medium">ecg_tech / clinic123</div>
                        </div>
                        <div class="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 shadow-sm">
                            <div class="font-semibold text-zinc-300 flex items-center gap-1.5 mb-1"><i class="fas fa-tooth text-zinc-400"></i> Dental</div>
                            <div class="font-mono text-sky-400 font-medium">dentist / clinic123</div>
                        </div>
                        <div class="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 shadow-sm">
                            <div class="font-semibold text-zinc-300 flex items-center gap-1.5 mb-1"><i class="fas fa-eye text-sky-500"></i> Optometry</div>
                            <div class="font-mono text-sky-400 font-medium">optometrist / clinic123</div>
                        </div>
                        <div class="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 shadow-sm sm:col-span-2">
                            <div class="font-semibold text-zinc-300 flex items-center gap-1.5 mb-1"><i class="fas fa-stethoscope text-zinc-400"></i> General Medicine</div>
                            <div class="font-mono text-sky-400 font-medium">dr_general / clinic123</div>
                        </div>
                    </div>
                </details>
            </div>

            <!-- Patient Portal Quick Redirect Button -->
            <div class="mt-8 text-center">
                <a href="patient-portal/track-queue.php"
                   class="group inline-flex items-center justify-center gap-2 text-sky-500 hover:text-sky-400 text-sm font-bold transition duration-200 no-underline">
                    <i class="fas fa-desktop group-hover:scale-110 transition-transform"></i>
                    Switch to Public Queue Monitor
                </a>
            </div>

        </div>
    </div>

    <script>
        document.getElementById('toggleLoginPassword')?.addEventListener('click', function() {
            const password = document.getElementById('loginPassword');
            const showPassword = password.type === 'password';
            password.type = showPassword ? 'text' : 'password';
            this.setAttribute('aria-label', showPassword ? 'Hide password' : 'Show password');
            this.setAttribute('title', showPassword ? 'Hide password' : 'Show password');
            this.setAttribute('aria-pressed', String(showPassword));
            this.querySelector('i').className = showPassword ? 'fas fa-eye-slash' : 'fas fa-eye';
        });

        // Disable button on submit to prevent double submission
        document.getElementById('loginForm')?.addEventListener('submit', function(e) {
            const btn = this.querySelector('button[type="submit"]');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            }
        });
        
        document.getElementById('twofaForm')?.addEventListener('submit', function(e) {
            const btn = this.querySelector('button[type="submit"]');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
            }
        });
    </script>
</body>
</html>