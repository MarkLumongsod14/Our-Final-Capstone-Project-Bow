<?php
require_once dirname(__DIR__) . '/config/database.php';

header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');

$clinic_id = filter_input(INPUT_GET, 'clinic_id', FILTER_VALIDATE_INT);
$since = $_GET['since'] ?? null;

if (!$clinic_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'A valid clinic_id is required']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    $clinic_stmt = $db->prepare('SELECT id, name FROM clinics WHERE id = ?');
    $clinic_stmt->execute([$clinic_id]);
    $clinic = $clinic_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$clinic) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Clinic not found']);
        exit();
    }

    $active_stmt = $db->prepare("SELECT q.queue_number, q.status, q.called_at,
                                        p.first_name, p.last_name
                                 FROM queue_entries q
                                 JOIN patients p ON p.id = q.patient_id
                                 WHERE q.clinic_id = ?
                                   AND DATE(q.registered_at) = CURDATE()
                                   AND q.status IN ('waiting', 'called', 'in-progress')
                                 ORDER BY FIELD(q.status, 'in-progress', 'called', 'waiting'),
                                          FIELD(q.priority_level, 'PR1', 'PR2', 'PR3'),
                                          q.registered_at ASC");
    $active_stmt->execute([$clinic_id]);
    $active = $active_stmt->fetchAll(PDO::FETCH_ASSOC);

    $current = null;
    $called_current = null;
    $waiting = [];
    foreach ($active as $patient) {
        if ($patient['status'] === 'in-progress' && $current === null) {
            $current = $patient;
        } elseif ($patient['status'] === 'called' && $called_current === null) {
            $called_current = $patient;
        } elseif (in_array($patient['status'], ['called', 'waiting'], true)) {
            $waiting[] = $patient;
        }
    }

    if ($current === null && $called_current !== null) {
        $current = $called_current;
    } elseif ($current !== null && $called_current !== null) {
        array_unshift($waiting, $called_current);
    }

    $announcements = [];
    if ($since) {
        $announcement_stmt = $db->prepare("SELECT q.queue_number, q.called_at
                                            FROM queue_entries q
                                            WHERE q.clinic_id = ?
                                              AND q.called_at > ?
                                            ORDER BY q.called_at ASC");
        $announcement_stmt->execute([$clinic_id, $since]);
        $announcements = $announcement_stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    echo json_encode([
        'success' => true,
        'clinic' => $clinic,
        'current' => $current,
        'waiting' => array_slice($waiting, 0, 5),
        'waiting_count' => count($waiting),
        'announcements' => $announcements
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Unable to load clinic queue']);
}
