<?php
// check-email-log.php - Check email debug logs

echo "<h2>📧 Email Debug Log Check</h2>";

// Check if error log exists
$log_paths = [
    'error_log',
    '../error_log',
    '../logs/error.log',
    ini_get('error_log')
];

$found = false;
foreach ($log_paths as $path) {
    if ($path && file_exists($path)) {
        echo "<h3>Checking: " . $path . "</h3>";
        $lines = file($path);
        $last_lines = array_slice($lines, -50);
        
        $email_lines = [];
        foreach ($last_lines as $line) {
            if (strpos($line, '📧') !== false || 
                strpos($line, 'email') !== false || 
                strpos($line, 'Brevo') !== false ||
                strpos($line, 'SMTP') !== false ||
                strpos($line, 'mail') !== false) {
                $email_lines[] = $line;
            }
        }
        
        if (!empty($email_lines)) {
            echo "<pre style='background: #1a1a2e; color: #00ff00; padding: 15px; border-radius: 5px; overflow: auto; max-height: 400px;'>";
            foreach ($email_lines as $line) {
                echo htmlspecialchars($line);
            }
            echo "</pre>";
            $found = true;
        } else {
            echo "<p style='color: orange;'>No email-related logs found in this file.</p>";
        }
    }
}

if (!$found) {
    echo "<p style='color: red;'>❌ No error logs found. Please check your InfinityFree control panel.</p>";
}

echo "<br><a href='index.php'>Back</a>";
?>