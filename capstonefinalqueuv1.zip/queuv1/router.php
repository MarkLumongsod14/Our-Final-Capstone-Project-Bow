<?php
// router.php - Main Router for Clean URLs

// Get the request URI
$request = $_SERVER['REQUEST_URI'];

// Remove query string
$request = strtok($request, '?');

// Remove the project mount point when running below the web root (for example, in XAMPP).
$basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
if ($basePath !== '' && strpos($request, $basePath . '/') === 0) {
    $request = substr($request, strlen($basePath));
}

// Remove trailing slash
$request = rtrim($request, '/');

// If request is empty or just '/', serve index.php
if ($request == '' || $request == '/') {
    include 'index.php';
    exit;
}

// ============================================
// ROUTE MAPPING
// ============================================

$routes = [
    // Admin routes
    '/admin/dashboard' => 'admin/dashboard.php',
    '/admin/patients' => 'admin/patients.php',
    '/admin/queue-monitor' => 'admin/queue-monitor.php',
    '/admin/clinic-congestion' => 'admin/clinic-congestion.php',
    '/admin/reports' => 'admin/reports.php',
    '/admin/users' => 'admin/users.php',
    '/admin/login-monitor' => 'admin/login-monitor.php',
    
    // Staff routes
    '/staff/clinic' => 'staff/clinic-dashboard.php',
    '/staff/queue' => 'staff/patient-queue.php',
    '/staff/register' => 'staff/registration.php',
    '/staff/result' => 'staff/submit-result.php',
    '/staff/profile' => 'staff/profile.php',
    
    // Patient Portal routes
    '/portal/track' => 'patient-portal/track-queue.php',
    '/portal/register' => 'patient-portal/self-register.php',
    '/portal/ticket' => 'patient-portal/print-ticket.php',
    
    // Public routes
    '/display' => 'public/display-monitor.php',
    '/announce' => 'public/announcement-display.php',
    
    // Login/Logout
    '/logout' => 'logout.php',
];

// Check if route exists
if (isset($routes[$request])) {
    include $routes[$request];
    exit;
}

// If no route matches, try to serve as a file
$file = ltrim($request, '/');
$phpFile = $file . '.php';
$candidate = is_file(__DIR__ . '/' . $file) ? $file : $phpFile;
$candidatePath = realpath(__DIR__ . '/' . $candidate);
$restrictedPath = preg_match('~^(?:config|includes|cache|vendor|\.agent-cache)(?:/|$)~i', $candidate);
$developmentFile = preg_match('~^(?:check-[^/]+|debug[^/]*|fix_[^/]*|test(?:[-_][^/]*)?|verify_fix|preview-queue-number)\.php$~i', $candidate)
    || preg_match('~^(?:staff|admin)/(?:debug|test)[^/]*\.php$~i', $candidate);

if ($candidatePath && strpos($candidatePath, realpath(__DIR__) . DIRECTORY_SEPARATOR) === 0 && !$restrictedPath && !$developmentFile && !is_dir($candidatePath)) {
    // Serve the file directly
    $ext = pathinfo($candidate, PATHINFO_EXTENSION);
    if ($ext == 'php') {
        include $candidatePath;
    } else {
        readfile($candidatePath);
    }
    exit;
}

// If nothing matches, show 404
http_response_code(404);
echo '<h1>404 - Page Not Found</h1>';
echo '<p>The page you are looking for does not exist.</p>';
?>