SET @drug_test_clinic_id = (
    SELECT id
    FROM clinics
    WHERE name IN ('Pediatrics', 'Drug Test')
    ORDER BY CASE WHEN name = 'Drug Test' THEN 0 ELSE 1 END
    LIMIT 1
);

UPDATE clinics
SET name = 'Drug Test'
WHERE id = @drug_test_clinic_id;

DELETE FROM result_templates
WHERE clinic_id = @drug_test_clinic_id;

INSERT INTO result_templates
    (clinic_id, field_name, field_label, field_type, field_options, is_required, sort_order)
SELECT @drug_test_clinic_id, 'specimen_type', 'Specimen Type', 'text', NULL, 0, 1
WHERE @drug_test_clinic_id IS NOT NULL
UNION ALL
SELECT @drug_test_clinic_id, 'test_method', 'Test Method', 'text', NULL, 0, 2
WHERE @drug_test_clinic_id IS NOT NULL
UNION ALL
SELECT @drug_test_clinic_id, 'test_result', 'Test Result', 'select', '["Negative","Positive","Inconclusive"]', 0, 3
WHERE @drug_test_clinic_id IS NOT NULL
UNION ALL
SELECT @drug_test_clinic_id, 'test_date', 'Test Date', 'date', NULL, 0, 4
WHERE @drug_test_clinic_id IS NOT NULL
UNION ALL
SELECT @drug_test_clinic_id, 'remarks', 'Remarks', 'textarea', NULL, 0, 5
WHERE @drug_test_clinic_id IS NOT NULL;
