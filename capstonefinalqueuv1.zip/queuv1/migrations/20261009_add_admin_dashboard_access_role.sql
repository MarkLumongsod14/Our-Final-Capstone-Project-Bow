ALTER TABLE users
MODIFY COLUMN role ENUM('admin', 'admin_dashboard', 'doctor', 'nurse', 'technician', 'staff') DEFAULT 'staff';
