<?php
// admin/patients.php - Patient Master Directory & Management
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/SessionManager.php';

session_start();
require_once dirname(__DIR__) . '/includes/UnifiedSession.php';

// Access Validation Controls
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'admin_dashboard'], true)) {
    header('Location: ../index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$sessionManager = new SessionManager($db);

$message = '';
$error = '';

// Catch messages passed from the registration redirect
if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
}

// --- BACKEND PROCESSING: HANDLE PATIENT ARCHIVING ---
if (isset($_GET['archive'])) {
    $id = intval($_GET['archive']);
    $query = "UPDATE patients SET status = 'Archived' WHERE id = ? AND status = 'Active'";
    $stmt = $db->prepare($query);
    $stmt->execute([$id]);
    if ($stmt->rowCount() > 0) {
        $message = "Patient record archived successfully.";
        $sessionManager->logActivity('Archived patient record; patient_id=' . $id);
    } else {
        $message = "Patient record was already archived or not found.";
    }
}

// --- BACKEND PROCESSING: HANDLE PATIENT DELETION ---
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    if ($id <= 0) {
        $error = "Invalid patient record.";
    } else {
        try {
            $db->beginTransaction();

            $patient_stmt = $db->prepare("SELECT id FROM patients WHERE id = ? FOR UPDATE");
            $patient_stmt->execute([$id]);
            if (!$patient_stmt->fetch(PDO::FETCH_ASSOC)) {
                $db->rollBack();
                $message = "Patient record was not found.";
            } else {
                $dependent_deletes = [
                    "DELETE FROM clinic_results WHERE patient_id = ?",
                    "DELETE FROM documents WHERE patient_id = ?",
                    "DELETE FROM medical_history WHERE patient_id = ?",
                    "DELETE FROM medical_records WHERE patient_id = ?",
                    "DELETE FROM patient_journey WHERE patient_id = ?",
                    "DELETE FROM appointments WHERE patient_id = ?",
                    "DELETE FROM queue_entries WHERE patient_id = ?",
                    "DELETE FROM patients WHERE id = ?"
                ];

                foreach ($dependent_deletes as $delete_query) {
                    $delete_stmt = $db->prepare($delete_query);
                    $delete_stmt->execute([$id]);
                }

                $db->commit();
                $message = "Patient record and associated history purged successfully.";
                $sessionManager->logActivity('Permanently deleted patient record and history; patient_id=' . $id);
            }
        } catch (PDOException $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            error_log('Patient purge failed for patient_id=' . $id . ': ' . $e->getMessage());
            $error = "Patient record could not be purged. No records were deleted; please contact support.";
        }
    }
}

// --- DATA INTAKE LOGIC: SEARCH FILTER ROUTINES ---
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$type = isset($_GET['type']) ? trim($_GET['type']) : '';
$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
$per_page = 10;

// Build the filtered query once so the result count and table rows stay in sync.
$where = " WHERE p.status = 'Active'";
$params = [];

if (!empty($search)) {
    $where .= " AND (p.first_name LIKE ? OR p.last_name LIKE ? OR p.mrn LIKE ? OR p.contact_number LIKE ?)";
    $search_param = "%{$search}%";
    array_push($params, $search_param, $search_param, $search_param, $search_param);
}

if (!empty($type)) {
    $where .= " AND p.patient_type = ?";
    array_push($params, $type);
}

$count_query = "SELECT COUNT(*) FROM patients p" . $where;
$count_stmt = $db->prepare($count_query);
$count_stmt->execute($params);
$filtered_patient_count = (int) $count_stmt->fetchColumn();
$total_pages = max(1, (int) ceil($filtered_patient_count / $per_page));
$page = min($page, $total_pages);
$offset = ($page - 1) * $per_page;

$query = "SELECT p.*, 
          (SELECT COUNT(*) FROM queue_entries WHERE patient_id = p.id) as total_visits 
          FROM patients p" . $where . " ORDER BY p.last_name ASC, p.first_name ASC LIMIT " . $per_page . " OFFSET " . $offset;
$stmt = $db->prepare($query);
$stmt->execute($params);
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pagination_params = [];
if (!empty($search)) {
    $pagination_params['search'] = $search;
}
if (!empty($type)) {
    $pagination_params['type'] = $type;
}
$pagination_url = function ($target_page) use ($pagination_params) {
    $params = $pagination_params;
    $params['page'] = $target_page;
    return 'patients.php?' . http_build_query($params);
};

// --- SCALAR SUMMARY STATISTICS METRICS ---
$total_patients_count = $db->query("SELECT COUNT(*) FROM patients")->fetchColumn() ?? 0;
$military_count  = $db->query("SELECT COUNT(*) FROM patients WHERE LOWER(patient_type) = 'military'")->fetchColumn() ?? 0;
$dependent_count = $db->query("SELECT COUNT(*) FROM patients WHERE LOWER(patient_type) = 'dependent'")->fetchColumn() ?? 0;
$pwd_count       = $db->query("SELECT COUNT(*) FROM patients WHERE is_pwd = 1")->fetchColumn() ?? 0;
$senior_count    = $db->query("SELECT COUNT(*) FROM patients WHERE is_senior = 1")->fetchColumn() ?? 0;
$pregnant_count  = $db->query("SELECT COUNT(*) FROM patients WHERE is_pregnant = 1")->fetchColumn() ?? 0;

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo ($current_theme === 'dark' ? 'dark' : ''); ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patients Registry | 4ID Station Hospital | Camp Evangelista</title>
             <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
   
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="dashboard.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patients.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patients</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-line text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Monitor</span>
                        </a>
                    </li>
                    <li>
                        <a href="clinic-congestion.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-pie text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Clinic Congestion</span>
                        </a>
                    </li>
                    <li>
                        <a href="reports.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-bar text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Reports</span>
                        </a>
                    </li>
                    <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users-cog text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="login-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-history text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Login/Session Monitor</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5">Patients Directory</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">Authorized clinical demographic registers and medical reference logs</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate">System Administrator</p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5">HOSP-HQ COM</p>
                        </div>
                        <div class="p-1.5">
                            <a href="setup-2fa.php" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                                <i class="fas fa-shield-alt text-sm text-sky-500"></i>
                                <span>Set Up Two-Factor Authentication</span>
                            </a>
                            <a href="../logout.php" onclick="return confirm('Confirm Dashboard Exit?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Notification Alerts -->
        <?php if (!empty($message)): ?>
            <div class="p-4 mb-6 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-between shadow-sm">
                <div class="flex items-center"><i class="fas fa-check-circle mr-3 text-base"></i> <span class="text-xs font-bold uppercase tracking-wide"><?= htmlspecialchars($message) ?></span></div>
                <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-emerald-500"><i class="fas fa-times text-base"></i></button>
            </div>
        <?php endif; ?>
        <?php if (!empty($error)): ?>
            <div class="p-4 mb-6 bg-rose-50 dark:bg-rose-500/10 border border-rose-300 dark:border-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl flex items-center justify-between shadow-sm">
                <div class="flex items-center"><i class="fas fa-exclamation-triangle mr-3 text-base"></i> <span class="text-xs font-bold uppercase tracking-wide"><?= htmlspecialchars($error) ?></span></div>
                <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-rose-500"><i class="fas fa-times text-base"></i></button>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 md:gap-4 mb-6">
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all">
                <div class="flex items-center gap-2 mb-1">
                    <div class="w-8 h-8 bg-sky-50 dark:bg-sky-500/10 rounded-lg flex items-center justify-center text-sky-600 dark:text-sky-400 text-sm">
                        <i class="fas fa-hospital-user"></i>
                    </div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white font-mono"><?= number_format($total_patients_count); ?></div>
                </div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider">Total Registry</div>
            </div>

            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all">
                <div class="flex items-center gap-2 mb-1">
                    <div class="w-8 h-8 bg-emerald-50 dark:bg-emerald-500/10 rounded-lg flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-sm">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white font-mono"><?= number_format($military_count); ?></div>
                </div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider">Military</div>
            </div>

            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all">
                <div class="flex items-center gap-2 mb-1">
                    <div class="w-8 h-8 bg-sky-50 dark:bg-sky-500/10 rounded-lg flex items-center justify-center text-sky-600 dark:text-sky-400 text-sm">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white font-mono"><?= number_format($dependent_count); ?></div>
                </div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider">Dependents</div>
            </div>

            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all">
                <div class="flex items-center gap-2 mb-1">
                    <div class="w-8 h-8 bg-indigo-50 dark:bg-indigo-500/10 rounded-lg flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-sm">
                        <i class="fas fa-wheelchair"></i>
                    </div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white font-mono"><?= number_format($pwd_count); ?></div>
                </div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider">PWD</div>
            </div>

            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all">
                <div class="flex items-center gap-2 mb-1">
                    <div class="w-8 h-8 bg-amber-50 dark:bg-amber-500/10 rounded-lg flex items-center justify-center text-amber-600 dark:text-amber-400 text-sm">
                        <i class="fas fa-blind"></i>
                    </div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white font-mono"><?= number_format($senior_count); ?></div>
                </div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider">Seniors</div>
            </div>

            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all">
                <div class="flex items-center gap-2 mb-1">
                    <div class="w-8 h-8 bg-rose-50 dark:bg-rose-500/10 rounded-lg flex items-center justify-center text-rose-600 dark:text-rose-400 text-sm">
                        <i class="fas fa-baby-carriage"></i>
                    </div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white font-mono"><?= number_format($pregnant_count); ?></div>
                </div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider">Maternal</div>
            </div>
        </div>

        <!-- Filter & Search -->
        <div class="bg-white dark:bg-[#1f2937] p-4 rounded-xl border border-slate-300 dark:border-slate-700/70 shadow-sm mb-6">
            <form method="GET" action="patients.php" class="flex flex-col lg:flex-row gap-3 items-center justify-between">
                <div class="relative w-full lg:max-w-xl flex-1">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400">
                        <i class="fas fa-search text-sm"></i>
                    </span>
                    <input type="text" name="search" value="<?= htmlspecialchars($search); ?>" placeholder="Search by Name, MRN, or Phone..." class="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-xs transition-all">
                </div>
                
                <div class="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto justify-end">
                    <select name="type" class="w-full sm:w-48 px-3 py-2 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 text-xs">
                        <option value="">All Classifications</option>
                        <option value="military" <?= $type === 'military' ? 'selected' : ''; ?>>Military</option>
                        <option value="dependent" <?= $type === 'dependent' ? 'selected' : ''; ?>>Dependent</option>
                    </select>
                    
                    <button type="submit" class="w-full sm:w-auto bg-sky-50 dark:bg-sky-500/10 border border-sky-300 dark:border-sky-500/20 text-sky-600 dark:text-sky-400 hover:bg-sky-100 dark:hover:bg-sky-500/20 font-bold px-5 py-2 rounded-xl text-[0.65rem] uppercase tracking-wider transition-all shrink-0">
                        Execute Query
                    </button>
                    
                    <?php if(!empty($search) || !empty($type)): ?>
                        <a href="patients.php" class="text-[0.65rem] uppercase font-bold tracking-widest text-rose-500 hover:text-rose-600 transition-colors shrink-0 px-2 py-1">Reset</a>
                    <?php endif; ?>
                    
                    <button type="button" onclick="openPatientModal()" class="w-full sm:w-auto inline-flex items-center justify-center px-4 py-2 bg-sky-600 dark:bg-sky-500 text-white font-bold text-[0.65rem] uppercase tracking-wider rounded-xl hover:bg-sky-700 dark:hover:bg-sky-600 transition-all shadow-sm shrink-0">
                        <i class="fas fa-user-plus mr-1.5 text-xs"></i> Register Patient
                    </button>
                    <a href="archived-patients.php" class="w-full sm:w-auto inline-flex items-center justify-center px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-[0.65rem] uppercase tracking-wider rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-all shrink-0">
                        <i class="fas fa-archive mr-1.5 text-xs"></i> Archived Patients
                    </a>
                </div>
            </form>
        </div>

        <!-- Patients Table -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full border-collapse text-left">
                    <thead>
                        <tr class="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider">
                            <th class="py-3 px-4">MRN</th>
                            <th class="py-3 px-4">Patient Name</th>
                            <th class="py-3 px-4">Type</th>
                            <th class="py-3 px-4 text-center">Priority</th>
                            <th class="py-3 px-4">Contact</th>
                            <th class="py-3 px-4 text-center">Visits</th>
                            <th class="py-3 px-4 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium">
                        <?php if (empty($patients)): ?>
                            <tr>
                                <td colspan="7" class="py-8 text-center text-slate-400 font-bold uppercase tracking-wider">No active patient files recorded match parameters.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($patients as $p): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                                    <td class="py-3 px-4 font-mono font-bold text-xs text-sky-600 dark:text-sky-400 select-all"><?= htmlspecialchars($p['mrn']); ?></td>
                                    <td class="py-3 px-4 text-slate-900 dark:text-white font-semibold">
                                        <?= htmlspecialchars($p['last_name'] . ', ' . $p['first_name'] . ' ' . ($p['middle_name'] ?? '')); ?>
                                    </td>
                                    <td class="py-3 px-4">
                                        <span class="px-2 py-0.5 rounded-full text-[0.55rem] font-bold tracking-wide <?= strtolower($p['patient_type']) === 'military' ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400'; ?>">
                                            <?= htmlspecialchars($p['patient_type']); ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 text-center">
                                        <div class="flex gap-1.5 justify-center flex-wrap">
                                            <?php if($p['is_pwd']): ?><span class="px-1.5 py-0.5 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 text-[0.5rem] font-bold uppercase rounded tracking-wide">PWD</span><?php endif; ?>
                                            <?php if($p['is_senior']): ?><span class="px-1.5 py-0.5 bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 text-[0.5rem] font-bold uppercase rounded tracking-wide">Senior</span><?php endif; ?>
                                            <?php if($p['is_pregnant']): ?><span class="px-1.5 py-0.5 bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 text-[0.5rem] font-bold uppercase rounded tracking-wide">Maternal</span><?php endif; ?>
                                            <?php if(!$p['is_pwd'] && !$p['is_senior'] && !$p['is_pregnant']): ?>
                                                <span class="text-slate-400 dark:text-slate-500 text-[0.55rem] font-normal italic">—</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="py-3 px-4 text-slate-500 dark:text-slate-400 font-medium">
                                        <div class="text-slate-700 dark:text-slate-200 text-xs"><?= htmlspecialchars($p['contact_number'] ?: 'N/A'); ?></div>
                                        <div class="text-[0.6rem] text-slate-400 font-normal truncate max-w-[200px] mt-0.5"><?= htmlspecialchars($p['address'] ?: 'No address'); ?></div>
                                    </td>
                                    <td class="py-3 px-4 text-center font-mono font-bold text-slate-700 dark:text-slate-300"><?= number_format($p['total_visits']); ?></td>
                                    <td class="py-3 px-4 text-center whitespace-nowrap">
                                        <div class="flex items-center justify-center gap-1.5">
                                            <a href="patient-results.php?id=<?= $p['id']; ?>" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 hover:bg-sky-600 dark:hover:bg-sky-500 hover:text-white dark:hover:text-white border border-sky-200 dark:border-sky-700/60 transition-colors" title="View Results"><i class="fas fa-file-waveform text-xs"></i></a>
                                            <a href="patient-view.php?id=<?= $p['id']; ?>" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-sky-500 dark:hover:text-sky-400 border border-slate-200 dark:border-slate-700/60 transition-colors" title="View File"><i class="fas fa-eye text-xs"></i></a>
                                            <a href="patient-edit.php?id=<?= $p['id']; ?>" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-amber-500 dark:hover:text-amber-400 border border-slate-200 dark:border-slate-700/60 transition-colors" title="Edit"><i class="fas fa-edit text-xs"></i></a>
                                            <button onclick="archivePatient(<?= $p['id']; ?>, '<?= htmlspecialchars(addslashes($p['first_name'] . ' ' . $p['last_name'])); ?>')" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-amber-500 border border-slate-200 dark:border-slate-700/60 transition-colors" title="Archive"><i class="fas fa-archive text-xs"></i></button>
                                            <button onclick="triggerPurgeRecord(<?= $p['id']; ?>, '<?= htmlspecialchars(addslashes($p['first_name'] . ' ' . $p['last_name'])); ?>')" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-rose-500 border border-slate-200 dark:border-slate-700/60 transition-colors" title="Purge"><i class="fas fa-trash-alt text-xs"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($filtered_patient_count > 0): ?>
                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 px-4 py-4 border-t border-slate-200 dark:border-slate-700/60">
                    <p class="text-[0.65rem] font-bold uppercase tracking-wider text-slate-400">
                        Showing <?= number_format($offset + 1); ?>-<?= number_format($offset + count($patients)); ?> of <?= number_format($filtered_patient_count); ?> patients
                    </p>
                    <?php if ($total_pages > 1): ?>
                        <nav class="flex items-center gap-1" aria-label="Patient list pagination">
                            <?php if ($page > 1): ?>
                                <a href="<?= htmlspecialchars($pagination_url($page - 1)); ?>" class="inline-flex items-center justify-center px-3 h-8 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:text-sky-500 hover:border-sky-400 text-[0.65rem] font-bold uppercase tracking-wider transition-colors">Previous</a>
                            <?php endif; ?>
                            <?php for ($page_number = 1; $page_number <= $total_pages; $page_number++): ?>
                                <a href="<?= htmlspecialchars($pagination_url($page_number)); ?>" class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-[0.7rem] font-bold transition-colors <?= $page_number === $page ? 'bg-sky-600 text-white dark:bg-sky-500' : 'text-slate-500 dark:text-slate-400 hover:text-sky-500 hover:bg-sky-50 dark:hover:bg-sky-500/10'; ?>" aria-current="<?= $page_number === $page ? 'page' : 'false'; ?>"><?= $page_number; ?></a>
                            <?php endfor; ?>
                            <?php if ($page < $total_pages): ?>
                                <a href="<?= htmlspecialchars($pagination_url($page + 1)); ?>" class="inline-flex items-center justify-center px-3 h-8 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:text-sky-500 hover:border-sky-400 text-[0.65rem] font-bold uppercase tracking-wider transition-colors">Next</a>
                            <?php endif; ?>
                        </nav>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
    </style>

    <script>
        // Theme Toggle
        const themeToggleBtn = document.getElementById('themeToggleBtn');
        const themeToggleIcon = document.getElementById('themeToggleIcon');
        const htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
        } else {
            htmlElement.classList.remove('dark');
            themeToggleIcon.className = 'fas fa-moon text-base';
        }

        themeToggleBtn.addEventListener('click', () => {
            if (htmlElement.classList.contains('dark')) {
                htmlElement.classList.remove('dark');
                themeToggleIcon.className = 'fas fa-moon text-base';
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.classList.add('dark');
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                localStorage.setItem('theme', 'dark');
            }
        });

        // Profile Dropdown
        const profileMenuBtn = document.getElementById('profileMenuBtn');
        const profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', () => profileDropdown.classList.add('hidden'));
        }

        // Live Clock
        function updateDateTime() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
            document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', (e) => {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        function triggerPurgeRecord(id, label) {
            if (confirm(`PERMANENT DELETION:\nDelete "${label}" and all linked queue entries, appointments, results, documents, and medical history?\n\nThis cannot be undone.`)) {
                window.location.href = `patients.php?delete=${id}`;
            }
        }

        function archivePatient(id, label) {
            if (confirm(`Archive the patient record for "${label}"? You can restore it from the Archived Patients list.`)) {
                window.location.href = `patients.php?archive=${id}`;
            }
        }

        function openPatientModal() {
            window.location.href = '../staff/registration.php';
        }

        // Auto Logout
        const INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        let inactivityTimer;
        let warningTimer;
        let warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(err => console.log('Heartbeat failed:', err));
        }

        function logoutUser() {
            const logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = `
                <div class="fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
                    <div class="bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700">
                        <i class="fas fa-clock text-5xl text-rose-500 mb-5"></i>
                        <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">Session Expired</h3>
                        <p class="text-slate-500 dark:text-slate-400 text-sm mb-5">You have been logged out due to inactivity.</p>
                        <div class="w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden">
                            <div class="bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full"></div>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(logoutMsg);
            setTimeout(() => { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            const modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = `
                <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4">
                    <div class="bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in">
                        <i class="fas fa-hourglass-half text-5xl text-amber-500 mb-4"></i>
                        <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-1">Session About to Expire</h3>
                        <p class="text-slate-500 dark:text-slate-400 text-sm mb-3">You will be logged out due to inactivity.</p>
                        <p id="countdownText" class="text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4">2:00</p>
                        <button onclick="keepSessionAlive()" class="w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm">
                            <i class="fas fa-mouse-pointer mr-1.5"></i> Keep Session Active
                        </button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            
            let secondsLeft = 120;
            const countdownElement = document.getElementById('countdownText');
            const countdownInterval = setInterval(() => {
                secondsLeft--;
                const minutes = Math.floor(secondsLeft / 60);
                const seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(() => resetInactivityTimer())
                .catch(() => resetInactivityTimer());
        }

        function hideWarningModal() {
            const modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(event => document.addEventListener(event, resetInactivityTimer, false));

        resetInactivityTimer();
        setInterval(() => { if (!warningShown) sendHeartbeat(); }, 5 * 60 * 1000);

        // Auto-dismiss alerts
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.transition = 'all 0.4s ease-in-out';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-10px)';
                setTimeout(() => alert.remove(), 400);
            });
        }, 5000);
    </script>

</body>
</html>