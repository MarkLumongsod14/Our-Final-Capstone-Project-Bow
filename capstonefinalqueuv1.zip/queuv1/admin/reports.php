<?php
// admin/reports.php - Reports & Analytics
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/SessionManager.php';

session_start();
require_once dirname(__DIR__) . '/includes/UnifiedSession.php';
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'admin_dashboard'], true)) {
    header('Location: ../index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

function validReportDate($value, $fallback) {
    if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return $fallback;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $date && $date->format('Y-m-d') === $value ? $value : $fallback;
}

$today = date('Y-m-d');
$date_from = validReportDate($_GET['date_from'] ?? '', date('Y-m-d', strtotime('-29 days')));
$date_to = validReportDate($_GET['date_to'] ?? '', $today);
if ($date_from > $date_to) {
    [$date_from, $date_to] = [$date_to, $date_from];
}
$report_type = ($_GET['report_type'] ?? 'daily') === 'monthly' ? 'monthly' : 'daily';
$selected_clinic_id = filter_var($_GET['clinic_id'] ?? 0, FILTER_VALIDATE_INT);
$selected_clinic_id = $selected_clinic_id !== false && $selected_clinic_id > 0 ? $selected_clinic_id : 0;

$clinic_options = $db->query("SELECT id, name, capacity_per_hour, is_active
                              FROM clinics ORDER BY clinic_order ASC, name ASC")
    ->fetchAll(PDO::FETCH_ASSOC);
$clinic_option_ids = array_map('intval', array_column($clinic_options, 'id'));
if ($selected_clinic_id && !in_array($selected_clinic_id, $clinic_option_ids, true)) {
    $selected_clinic_id = 0;
}

$queue_where = 'q.registered_at >= ? AND q.registered_at < DATE_ADD(?, INTERVAL 1 DAY)';
$queue_params = [$date_from, $date_to];
if ($selected_clinic_id) {
    $queue_where .= ' AND q.clinic_id = ?';
    $queue_params[] = $selected_clinic_id;
}

$summary_query = "SELECT COUNT(DISTINCT q.patient_id) AS total_patients,
                         COUNT(*) AS total_visits,
                         SUM(CASE WHEN q.status = 'completed' THEN 1 ELSE 0 END) AS completed,
                         AVG(CASE WHEN q.completed_at IS NOT NULL AND q.completed_at >= q.registered_at
                             THEN TIMESTAMPDIFF(MINUTE, q.registered_at, q.completed_at) END) AS avg_time_to_complete
                  FROM queue_entries q WHERE $queue_where";
$stmt = $db->prepare($summary_query);
$stmt->execute($queue_params);
$summary = $stmt->fetch(PDO::FETCH_ASSOC);

$current_where = "q.registered_at >= CURDATE()
                  AND q.registered_at < DATE_ADD(CURDATE(), INTERVAL 1 DAY)
                  AND q.status IN ('waiting', 'called', 'in-progress')";
$current_params = [];
if ($selected_clinic_id) {
    $current_where .= ' AND q.clinic_id = ?';
    $current_params[] = $selected_clinic_id;
}
$current_stmt = $db->prepare("SELECT COUNT(*) FROM queue_entries q WHERE $current_where");
$current_stmt->execute($current_params);
$active_queue_now = (int) $current_stmt->fetchColumn();

$priority_query = "SELECT q.priority_level,
                          COUNT(*) AS total,
                          SUM(CASE WHEN q.status = 'completed' THEN 1 ELSE 0 END) AS completed
                   FROM queue_entries q WHERE $queue_where
                   GROUP BY q.priority_level
                   ORDER BY FIELD(q.priority_level, 'PR1', 'PR2', 'PR3'), q.priority_level";
$stmt = $db->prepare($priority_query);
$stmt->execute($queue_params);
$priority_dist = $stmt->fetchAll(PDO::FETCH_ASSOC);

$trend_group = $report_type === 'daily'
    ? 'DATE(q.registered_at)'
    : "DATE_FORMAT(q.registered_at, '%Y-%m')";
$trend_query = "SELECT $trend_group AS period,
                       COUNT(*) AS total,
                       SUM(CASE WHEN q.status = 'completed' THEN 1 ELSE 0 END) AS completed,
                       SUM(CASE WHEN q.priority_level = 'PR1' THEN 1 ELSE 0 END) AS pr1,
                       SUM(CASE WHEN q.priority_level = 'PR2' THEN 1 ELSE 0 END) AS pr2,
                       SUM(CASE WHEN q.priority_level = 'PR3' THEN 1 ELSE 0 END) AS pr3
                FROM queue_entries q WHERE $queue_where
                GROUP BY period ORDER BY period ASC";
$stmt = $db->prepare($trend_query);
$stmt->execute($queue_params);
$trends = $stmt->fetchAll(PDO::FETCH_ASSOC);

$clinic_where = 'q.registered_at >= ? AND q.registered_at < DATE_ADD(?, INTERVAL 1 DAY)';
$clinic_params = [$date_from, $date_to];
if ($selected_clinic_id) {
    $clinic_where .= ' AND q.clinic_id = ?';
    $clinic_params[] = $selected_clinic_id;
}
$clinic_query = "SELECT c.id, c.name, c.capacity_per_hour, c.is_active,
                        COUNT(q.id) AS total_visits,
                        COUNT(DISTINCT q.patient_id) AS unique_patients,
                        SUM(CASE WHEN q.status = 'completed' THEN 1 ELSE 0 END) AS completed,
                        SUM(CASE WHEN q.status IN ('waiting', 'called', 'in-progress')
                                  AND q.registered_at >= CURDATE()
                                  AND q.registered_at < DATE_ADD(CURDATE(), INTERVAL 1 DAY)
                            THEN 1 ELSE 0 END) AS active_today
                 FROM clinics c
                 LEFT JOIN queue_entries q ON c.id = q.clinic_id AND $clinic_where
                 WHERE (? = 0 OR c.id = ?)
                 GROUP BY c.id
                 ORDER BY total_visits DESC, c.clinic_order ASC";
$stmt = $db->prepare($clinic_query);
$stmt->execute(array_merge($clinic_params, [$selected_clinic_id, $selected_clinic_id]));
$clinic_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

$hourly_where = 'registered_at >= ? AND registered_at < DATE_ADD(?, INTERVAL 1 DAY)';
$hourly_params = [$date_from, $date_to];
if ($selected_clinic_id) {
    $hourly_where .= ' AND clinic_id = ?';
    $hourly_params[] = $selected_clinic_id;
}
$hourly_query = "SELECT clinic_id, COUNT(*) AS observed_hours,
                        AVG(hourly_visits) AS avg_hourly_visits,
                        MAX(hourly_visits) AS peak_hourly_visits
                 FROM (
                     SELECT clinic_id, DATE(registered_at) AS queue_date,
                            HOUR(registered_at) AS queue_hour, COUNT(*) AS hourly_visits
                     FROM queue_entries WHERE $hourly_where
                     GROUP BY clinic_id, DATE(registered_at), HOUR(registered_at)
                 ) hourly
                 GROUP BY clinic_id";
$stmt = $db->prepare($hourly_query);
$stmt->execute($hourly_params);
$hourly_by_clinic = [];
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $hourly_row) {
    $hourly_by_clinic[(int) $hourly_row['clinic_id']] = $hourly_row;
}
foreach ($clinic_stats as &$clinic) {
    $hourly = $hourly_by_clinic[(int) $clinic['id']] ?? null;
    $capacity = max((float) $clinic['capacity_per_hour'], 0);
    $clinic['observed_hours'] = (int) ($hourly['observed_hours'] ?? 0);
    $clinic['avg_hourly_visits'] = (float) ($hourly['avg_hourly_visits'] ?? 0);
    $clinic['peak_hourly_visits'] = (int) ($hourly['peak_hourly_visits'] ?? 0);
    $clinic['avg_utilization'] = $capacity > 0 ? ($clinic['avg_hourly_visits'] / $capacity) * 100 : 0;
    $clinic['peak_utilization'] = $capacity > 0 ? ($clinic['peak_hourly_visits'] / $capacity) * 100 : 0;
}
unset($clinic);

$priority_labels = array_map(function ($row) {
    return $row['priority_level'] ?: 'Unassigned';
}, $priority_dist);
$priority_data = array_map('intval', array_column($priority_dist, 'total'));
$trend_labels = array_map(function ($row) use ($report_type) {
    return $report_type === 'daily'
        ? date('M d', strtotime($row['period']))
        : date('M Y', strtotime($row['period'] . '-01'));
}, $trends);
$trend_data = array_map('intval', array_column($trends, 'total'));
$trend_completed = array_map('intval', array_column($trends, 'completed'));

if (($_GET['export'] ?? '') === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="queue-analytics-' . $date_from . '-to-' . $date_to . '.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Section', 'Date or Period', 'Clinic or Priority', 'Volume', 'Completed', 'Rate or Utilization']);

    foreach ($trends as $row) {
        fputcsv($output, ['Flow', $row['period'], '', $row['total'], $row['completed'], '']);
        fputcsv($output, ['Flow Priority', $row['period'], 'PR1', $row['pr1'], '', '']);
        fputcsv($output, ['Flow Priority', $row['period'], 'PR2', $row['pr2'], '', '']);
        fputcsv($output, ['Flow Priority', $row['period'], 'PR3', $row['pr3'], '', '']);
    }
    foreach ($priority_dist as $row) {
        $rate = (int) $row['total'] > 0 ? round(((int) $row['completed'] / (int) $row['total']) * 100, 1) : 0;
        fputcsv($output, ['Priority', '', $row['priority_level'] ?: 'Unassigned', $row['total'], $row['completed'], $rate . '%']);
    }
    foreach ($clinic_stats as $row) {
        fputcsv($output, ['Clinic', '', $row['name'], $row['total_visits'], $row['completed'], round((float) $row['avg_utilization'], 1) . '% avg observed-hour capacity']);
    }
    fclose($output);
    exit();
}

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $current_theme === 'dark' ? 'dark' : ''; ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Outpatient Queue Analytics | 4ID Station Hospital | Camp Evangelista</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
             <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
   
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="dashboard.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patients.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patients</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-line text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Monitor</span>
                        </a>
                    </li>
                    <li>
                        <a href="clinic-congestion.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-pie text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Clinic Congestion</span>
                        </a>
                    </li>
                    <li>
                        <a href="reports.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-bar text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Reports</span>
                        </a>
                    </li>
                    <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users-cog text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="login-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-history text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Login/Session Monitor</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5">Outpatient Queue Analytics</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">Patient flow, priority queues, clinic workload, batches and capacity</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate">System Administrator</p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5">HOSP-HQ COM</p>
                        </div>
                        <div class="p-1.5">
                            <a href="setup-2fa.php" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                                <i class="fas fa-shield-alt text-sm text-sky-500"></i>
                                <span>Set Up Two-Factor Authentication</span>
                            </a>
                            <a href="../logout.php" onclick="return confirm('Confirm Dashboard Exit?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Filter Section -->
        <div class="bg-white dark:bg-[#1f2937] p-5 rounded-xl border border-slate-300 dark:border-slate-700/70 shadow-sm mb-6">
            <form method="GET" class="flex flex-col lg:flex-row gap-4 items-end" id="reportForm">
                <div class="flex-1 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 w-full">
                    <div>
                        <label class="block text-slate-500 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider mb-1.5"><i class="fas fa-calendar-alt text-sky-500 mr-1"></i> Date From</label>
                        <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" id="dateFrom">
                    </div>
                    <div>
                        <label class="block text-slate-500 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider mb-1.5"><i class="fas fa-calendar-check text-sky-500 mr-1"></i> Date To</label>
                        <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" id="dateTo">
                    </div>
                    <div>
                        <label class="block text-slate-500 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider mb-1.5"><i class="fas fa-layer-group text-sky-500 mr-1"></i> Report Type</label>
                        <select name="report_type" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" id="reportType">
                            <option value="daily" <?php echo $report_type === 'daily' ? 'selected' : ''; ?>>Daily</option>
                            <option value="monthly" <?php echo $report_type === 'monthly' ? 'selected' : ''; ?>>Monthly</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-500 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider mb-1.5"><i class="fas fa-hospital text-sky-500 mr-1"></i> Clinic</label>
                        <select name="clinic_id" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all">
                            <option value="0">All clinics</option>
                            <?php foreach ($clinic_options as $clinic_option): ?>
                                <option value="<?php echo (int) $clinic_option['id']; ?>" <?php echo $selected_clinic_id === (int) $clinic_option['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($clinic_option['name'] . ((int) $clinic_option['is_active'] === 1 ? '' : ' (inactive)')); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="w-full lg:w-auto flex flex-wrap gap-2">
                    <button type="submit" class="flex-1 lg:flex-none bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2.5 px-5 rounded-xl transition-all shadow-sm flex items-center justify-center gap-2">
                        <i class="fas fa-sync-alt"></i> <span>Update</span>
                    </button>
                    <a href="?<?php echo htmlspecialchars(http_build_query(['date_from' => $date_from, 'date_to' => $date_to, 'report_type' => $report_type, 'clinic_id' => $selected_clinic_id, 'export' => 'csv'])); ?>" class="flex-1 lg:flex-none bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2.5 px-5 rounded-xl transition-all flex items-center justify-center gap-2">
                        <i class="fas fa-download"></i> <span>CSV</span>
                    </a>
                    <button type="button" onclick="window.print()" class="flex-1 lg:flex-none bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 font-semibold py-2.5 px-5 rounded-xl transition-all flex items-center justify-center gap-2">
                        <i class="fas fa-print"></i> <span>Print</span>
                    </button>
                </div>
            </form>
            <p class="text-[0.65rem] text-slate-400 dark:text-slate-500 mt-3">Queue-entry analytics for <?php echo htmlspecialchars(date('M d, Y', strtotime($date_from))); ?> through <?php echo htmlspecialchars(date('M d, Y', strtotime($date_to))); ?>.</p>
        </div>

        <!-- Statistics Cards -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all">
                <div class="text-slate-400 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider mb-1">Unique Patients</div>
                <div class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?php echo number_format((int) ($summary['total_patients'] ?? 0)); ?></div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all">
                <div class="text-slate-400 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider mb-1">Clinic Queue Entries</div>
                <div class="text-2xl font-black text-slate-900 dark:text-white font-mono"><?php echo number_format((int) ($summary['total_visits'] ?? 0)); ?></div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all">
                <div class="text-slate-400 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider mb-1">Completed</div>
                <div class="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono"><?php echo number_format((int) ($summary['completed'] ?? 0)); ?></div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all">
                <div class="text-slate-400 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider mb-1">Active Queue Today</div>
                <div class="text-2xl font-black text-sky-600 dark:text-sky-400 font-mono"><?php echo number_format($active_queue_now); ?></div>
            </div>
        </div>

        <!-- Patient Flow and Priority -->
        <div class="grid grid-cols-1 xl:grid-cols-3 gap-5 mb-6">
            <section class="xl:col-span-2 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
                <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20">
                    <h2 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2"><i class="fas fa-chart-line text-sky-500"></i> Queue Flow</h2>
                </div>
                <div class="p-5 h-[280px]"><canvas id="trendChart"></canvas></div>
            </section>
            <section class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
                <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20">
                    <h2 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2"><i class="fas fa-layer-group text-sky-500"></i> Priority Mix</h2>
                </div>
                <div class="p-5 h-[280px]"><canvas id="priorityChart"></canvas></div>
            </section>
        </div>

        <!-- Clinic Workload and Capacity -->
        <section class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex flex-wrap items-center justify-between gap-2">
                <h2 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2"><i class="fas fa-hospital-user text-sky-500"></i> Clinic Workload and Capacity</h2>
                <span class="text-[0.6rem] text-slate-400 dark:text-slate-500">Average and peak utilization use observed hours with queue entries.</span>
            </div>
            <div class="grid grid-cols-1 xl:grid-cols-3 gap-0">
                <div class="xl:col-span-2 overflow-x-auto">
                    <table class="w-full border-collapse text-left min-w-[620px]">
                        <thead><tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.58rem] font-bold uppercase tracking-wider">
                            <th class="py-3 px-4">Clinic</th><th class="py-3 px-3 text-center">Entries</th><th class="py-3 px-3 text-center">Completed</th><th class="py-3 px-3 text-center">Active today</th><th class="py-3 px-3 text-center">Capacity/hr</th>
                        </tr></thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium text-slate-700 dark:text-slate-300">
                            <?php if (empty($clinic_stats)): ?>
                                <tr><td colspan="5" class="py-8 text-center text-slate-400">No queue data for this selection.</td></tr>
                            <?php else: foreach ($clinic_stats as $clinic): ?>
                                <?php $completion_rate = (int) $clinic['total_visits'] > 0 ? ((int) $clinic['completed'] / (int) $clinic['total_visits']) * 100 : 0; ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                                    <td class="py-3 px-4 font-semibold text-slate-900 dark:text-white"><?php echo htmlspecialchars($clinic['name']); ?><?php if (!(int) $clinic['is_active']): ?><span class="ml-2 text-[0.55rem] text-slate-400">Inactive</span><?php endif; ?></td>
                                    <td class="py-3 px-3 text-center font-mono"><?php echo number_format((int) $clinic['total_visits']); ?></td>
                                    <td class="py-3 px-3 text-center font-mono text-emerald-600 dark:text-emerald-400"><?php echo number_format((int) $clinic['completed']); ?><span class="block text-[0.55rem] text-slate-400"><?php echo number_format($completion_rate, 0); ?>%</span></td>
                                    <td class="py-3 px-3 text-center font-mono"><?php echo number_format((int) $clinic['active_today']); ?></td>
                                    <td class="py-3 px-3 text-center font-mono"><?php echo number_format((float) $clinic['capacity_per_hour'], 1); ?></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="border-t xl:border-t-0 xl:border-l border-slate-200 dark:border-slate-700/60 p-5 h-[310px]"><canvas id="capacityChart"></canvas></div>
            </div>
        </section>

        <!-- Priority Outcomes -->
        <section class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20">
                <h2 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2"><i class="fas fa-sort-amount-down text-sky-500"></i> Priority Queue Outcomes</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse text-left min-w-[480px]">
                    <thead><tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.58rem] font-bold uppercase tracking-wider">
                        <th class="py-3 px-4">Priority</th><th class="py-3 px-4 text-center">Queue entries</th><th class="py-3 px-4 text-center">Completed</th><th class="py-3 px-4 text-center">Completion rate</th>
                    </tr></thead>
                    <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium text-slate-700 dark:text-slate-300">
                        <?php if (empty($priority_dist)): ?>
                            <tr><td colspan="4" class="py-8 text-center text-slate-400">No priority queue data for this selection.</td></tr>
                        <?php else: foreach ($priority_dist as $priority): ?>
                            <?php $priority_rate = (int) $priority['total'] > 0 ? ((int) $priority['completed'] / (int) $priority['total']) * 100 : 0; ?>
                            <tr>
                                <td class="py-3 px-4 font-bold"><?php echo htmlspecialchars($priority['priority_level'] ?: 'Unassigned'); ?></td>
                                <td class="py-3 px-4 text-center font-mono"><?php echo number_format((int) $priority['total']); ?></td>
                                <td class="py-3 px-4 text-center font-mono text-emerald-600 dark:text-emerald-400"><?php echo number_format((int) $priority['completed']); ?></td>
                                <td class="py-3 px-4 text-center font-mono"><?php echo number_format($priority_rate, 1); ?>%</td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- Period Breakdown -->
        <section class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20">
                <h2 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2"><i class="fas fa-table-list text-sky-500"></i> <?php echo $report_type === 'daily' ? 'Daily' : 'Monthly'; ?> Queue Flow</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse text-left min-w-[640px]">
                    <thead><tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.58rem] font-bold uppercase tracking-wider">
                        <th class="py-3 px-4"><?php echo $report_type === 'daily' ? 'Date' : 'Month'; ?></th><th class="py-3 px-4 text-center">Queue entries</th><th class="py-3 px-4 text-center">Completed</th><th class="py-3 px-4 text-center">PR1</th><th class="py-3 px-4 text-center">PR2</th><th class="py-3 px-4 text-center">PR3</th>
                    </tr></thead>
                    <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium text-slate-700 dark:text-slate-300">
                        <?php if (empty($trends)): ?>
                            <tr><td colspan="6" class="py-8 text-center text-slate-400">No queue-flow data for this selection.</td></tr>
                        <?php else: foreach (array_reverse($trends) as $trend): ?>
                            <tr>
                                <td class="py-3 px-4 font-semibold"><?php echo $report_type === 'daily' ? htmlspecialchars(date('M d, Y', strtotime($trend['period']))) : htmlspecialchars(date('M Y', strtotime($trend['period'] . '-01'))); ?></td>
                                <td class="py-3 px-4 text-center font-mono font-bold"><?php echo number_format((int) $trend['total']); ?></td>
                                <td class="py-3 px-4 text-center font-mono text-emerald-600 dark:text-emerald-400"><?php echo number_format((int) $trend['completed']); ?></td>
                                <td class="py-3 px-4 text-center font-mono"><?php echo number_format((int) $trend['pr1']); ?></td>
                                <td class="py-3 px-4 text-center font-mono"><?php echo number_format((int) $trend['pr2']); ?></td>
                                <td class="py-3 px-4 text-center font-mono"><?php echo number_format((int) $trend['pr3']); ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
        @media print {
            #sidebar, .no-print, #themeToggleBtn, #profileMenuBtn, #mobileMenuBtn { display: none !important; }
            main { margin-left: 0 !important; padding: 0 !important; }
            body { background: white !important; color: black !important; }
            .bg-white { border: 1px solid #E5E7EB !important; box-shadow: none !important; break-inside: avoid; }
        }
    </style>

    <script>
        // ============================================
        // THEME TOGGLE WITH CHART RE-RENDER
        // ============================================
        var themeToggleBtn = document.getElementById('themeToggleBtn');
        var themeToggleIcon = document.getElementById('themeToggleIcon');
        var htmlElement = document.documentElement;

        // Chart instances
        var priorityChartInstance = null;
        var trendChartInstance = null;
        var capacityChartInstance = null;

        function getChartColors() {
            var isDark = htmlElement.classList.contains('dark');
            return {
                textColor: isDark ? '#94A3B8' : '#64748B',
                gridColor: isDark ? '#334155' : '#E2E8F0',
                borderColor: isDark ? '#1f2937' : '#ffffff',
                backgroundColor: isDark ? 'rgba(14, 165, 233, 0.15)' : 'rgba(14, 165, 233, 0.1)'
            };
        }

        function renderCharts() {
            var colors = getChartColors();
            var fontFamily = '"Plus Jakarta Sans", sans-serif';

            // Priority Labels & Data from PHP
            var priorityLabels = <?php echo json_encode($priority_labels, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
            var priorityData = <?php echo json_encode($priority_data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;

            // Trend Labels & Data from PHP
            var trendLabels = <?php echo json_encode($trend_labels, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
            var trendData = <?php echo json_encode($trend_data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
            var completedData = <?php echo json_encode($trend_completed, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
            var capacityLabels = <?php echo json_encode(array_column($clinic_stats, 'name'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
            var avgCapacityData = <?php echo json_encode(array_map(function ($clinic) { return round((float) $clinic['avg_utilization'], 1); }, $clinic_stats), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
            var peakCapacityData = <?php echo json_encode(array_map(function ($clinic) { return round((float) $clinic['peak_utilization'], 1); }, $clinic_stats), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;

            // Priority Chart
            var priorityCtx = document.getElementById('priorityChart');
            if (priorityCtx) {
                if (priorityChartInstance) {
                    priorityChartInstance.destroy();
                }
                priorityChartInstance = new Chart(priorityCtx.getContext('2d'), {
                    type: 'doughnut',
                    data: {
                        labels: priorityLabels,
                        datasets: [{
                            data: priorityData,
                            backgroundColor: ['#EF4444', '#F59E0B', '#10B981'],
                            borderWidth: 0,
                            hoverOffset: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        cutout: '70%',
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    font: { family: fontFamily, size: 11, weight: '600' },
                                    color: colors.textColor,
                                    usePointStyle: true,
                                    boxWidth: 8,
                                    padding: 20
                                }
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        var label = context.label || '';
                                        var value = context.raw || 0;
                                        var total = context.dataset.data.reduce(function(a, b) { return a + b; }, 0);
                                        var percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                        return label + ': ' + value + ' (' + percentage + '%)';
                                    }
                                }
                            }
                        }
                    }
                });
            }

            // Trend Chart
            var trendCtx = document.getElementById('trendChart');
            if (trendCtx) {
                if (trendChartInstance) {
                    trendChartInstance.destroy();
                }
                trendChartInstance = new Chart(trendCtx.getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: trendLabels,
                        datasets: [{
                            label: 'Queue entries',
                            data: trendData,
                            borderColor: '#0ea5e9',
                            backgroundColor: colors.backgroundColor,
                            tension: 0.35,
                            fill: true,
                            pointBackgroundColor: '#0ea5e9',
                            pointBorderColor: colors.borderColor,
                            pointRadius: 4,
                            pointHoverRadius: 6,
                            borderWidth: 2.5
                        }, {
                            label: 'Completed',
                            data: completedData,
                            borderColor: '#0d9488',
                            backgroundColor: 'rgba(13, 148, 136, 0.08)',
                            tension: 0.35,
                            fill: false,
                            pointRadius: 3,
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: { color: colors.textColor, font: { family: fontFamily, size: 10 }, usePointStyle: true, boxWidth: 8 }
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return 'Patients: ' + context.raw;
                                    }
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: { color: colors.gridColor },
                                ticks: { stepSize: 1, font: { family: fontFamily, size: 10, weight: '600' }, color: colors.textColor }
                            },
                            x: {
                                grid: { display: false },
                                ticks: { font: { family: fontFamily, size: 10, weight: '600' }, color: colors.textColor, maxRotation: 45 }
                            }
                        }
                    }
                });
            }

            var capacityCtx = document.getElementById('capacityChart');
            if (capacityCtx) {
                if (capacityChartInstance) capacityChartInstance.destroy();
                capacityChartInstance = new Chart(capacityCtx.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: capacityLabels,
                        datasets: [{
                            label: 'Average observed-hour load',
                            data: avgCapacityData,
                            backgroundColor: '#0ea5e9',
                            borderRadius: 3
                        }, {
                            label: 'Peak observed-hour load',
                            data: peakCapacityData,
                            backgroundColor: '#e09f3e',
                            borderRadius: 3
                        }]
                    },
                    options: {
                        indexAxis: 'y',
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: { color: colors.textColor, font: { family: fontFamily, size: 9 }, usePointStyle: true, boxWidth: 7 }
                            },
                            tooltip: { callbacks: { label: function(context) { return context.dataset.label + ': ' + context.raw + '%'; } } }
                        },
                        scales: {
                            x: {
                                beginAtZero: true,
                                grid: { color: colors.gridColor },
                                ticks: { color: colors.textColor, callback: function(value) { return value + '%'; } }
                            },
                            y: {
                                grid: { display: false },
                                ticks: { color: colors.textColor, font: { family: fontFamily, size: 9 } }
                            }
                        }
                    }
                });
            }
        }

        // Initial theme check
        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
        } else {
            htmlElement.classList.remove('dark');
            themeToggleIcon.className = 'fas fa-moon text-base';
        }

        // Theme toggle with chart re-render
        themeToggleBtn.addEventListener('click', function() {
            if (htmlElement.classList.contains('dark')) {
                htmlElement.classList.remove('dark');
                themeToggleIcon.className = 'fas fa-moon text-base';
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.classList.add('dark');
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                localStorage.setItem('theme', 'dark');
            }
            // Re-render charts with new colors
            setTimeout(renderCharts, 100);
        });

        // Profile Dropdown
        var profileMenuBtn = document.getElementById('profileMenuBtn');
        var profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', function() {
                profileDropdown.classList.add('hidden');
            });
        }

        // Live Clock
        function updateDateTime() {
            var now = new Date();
            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
            document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        var mobileMenuBtn = document.getElementById('mobileMenuBtn');
        var sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', function(e) {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // Initialize charts after page load
        document.addEventListener('DOMContentLoaded', function() {
            renderCharts();
        });

        // Also render on window resize
        var resizeTimer;
        window.addEventListener('resize', function() {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function() {
                renderCharts();
            }, 300);
        });

        // ============================================
        // AUTO-LOGOUT AFTER INACTIVITY
        // ============================================
        var INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        var inactivityTimer;
        var warningTimer;
        var warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(function(err) { console.log('Heartbeat failed:', err); });
        }

        function logoutUser() {
            var logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = '<div class="fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4"><div class="bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700"><i class="fas fa-clock text-5xl text-rose-500 mb-5"></i><h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">Session Expired</h3><p class="text-slate-500 dark:text-slate-400 text-sm mb-5">You have been logged out due to inactivity.</p><div class="w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden"><div class="bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full"></div></div></div></div>';
            document.body.appendChild(logoutMsg);
            setTimeout(function() { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            var modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = '<div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4"><div class="bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in"><i class="fas fa-hourglass-half text-5xl text-amber-500 mb-4"></i><h3 class="text-lg font-bold text-slate-900 dark:text-white mb-1">Session About to Expire</h3><p class="text-slate-500 dark:text-slate-400 text-sm mb-3">You will be logged out due to inactivity.</p><p id="countdownText" class="text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4">2:00</p><button onclick="keepSessionAlive()" class="w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm"><i class="fas fa-mouse-pointer mr-1.5"></i> Keep Session Active</button></div></div>';
            document.body.appendChild(modal);
            
            var secondsLeft = 120;
            var countdownElement = document.getElementById('countdownText');
            var countdownInterval = setInterval(function() {
                secondsLeft--;
                var minutes = Math.floor(secondsLeft / 60);
                var seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = minutes + ':' + (seconds.toString().padStart(2, '0'));
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(function() { resetInactivityTimer(); })
                .catch(function() { resetInactivityTimer(); });
        }

        function hideWarningModal() {
            var modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        var events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(function(event) {
            document.addEventListener(event, resetInactivityTimer, false);
        });

        resetInactivityTimer();
        setInterval(function() {
            if (!warningShown) sendHeartbeat();
        }, 5 * 60 * 1000);
    </script>

</body>
</html>