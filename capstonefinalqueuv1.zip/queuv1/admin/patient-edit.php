<?php
// admin/patient-edit.php - Edit Patient Information
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/patient-validation.php';
require_once dirname(__DIR__) . '/includes/SessionManager.php';

session_start();
require_once dirname(__DIR__) . '/includes/UnifiedSession.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'admin_dashboard'], true)) {
    header('Location: ../index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$sessionManager = new SessionManager($db);

// Get patient ID from URL
$patient_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($patient_id <= 0) {
    header('Location: patients.php');
    exit();
}

// Get patient data
$query = "SELECT * FROM patients WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $patient_id);
$stmt->execute();
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    header('Location: patients.php');
    exit();
}

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_patient'])) {
    
    $first_name = isset($_POST['first_name']) && is_string($_POST['first_name']) ? trim($_POST['first_name']) : '';
    $middle_name = isset($_POST['middle_name']) && is_string($_POST['middle_name']) ? trim($_POST['middle_name']) : '';
    $last_name = isset($_POST['last_name']) && is_string($_POST['last_name']) ? trim($_POST['last_name']) : '';
    $suffix = isset($_POST['suffix']) && is_string($_POST['suffix']) ? trim($_POST['suffix']) : '';
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $contact = trim($_POST['contact'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $patient_type = $_POST['patient_type'];
    $is_pwd = isset($_POST['is_pwd']) ? 1 : 0;
    $is_senior = isset($_POST['is_senior']) ? 1 : 0;
    $is_pregnant = isset($_POST['is_pregnant']) ? 1 : 0;
    $primary_physician = trim($_POST['primary_physician'] ?? '');
    $status = $_POST['status'] ?? 'Active';
    
    // Validate email if provided
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    }
    
    // Validate
    if (empty($first_name) || empty($last_name) || empty($dob) || empty($gender) || empty($patient_type)) {
        $error = "Please fill in all required fields.";
    } elseif (
        !isValidPatientName($first_name)
        || !isValidPatientName($middle_name, true)
        || !isValidPatientName($last_name)
        || !isValidPatientName($suffix, true)
    ) {
        $error = "Name fields may contain letters, spaces, and hyphens (-) only.";
    } elseif (empty($error)) {
        // Update patient
        $query = "UPDATE patients SET 
                    first_name = :first_name,
                    middle_name = :middle_name,
                    last_name = :last_name,
                    suffix = :suffix,
                    date_of_birth = :dob,
                    gender = :gender,
                    contact_number = :contact,
                    email = :email,
                    address = :address,
                    patient_type = :patient_type,
                    is_pwd = :is_pwd,
                    is_senior = :is_senior,
                    is_pregnant = :is_pregnant,
                    primary_physician = :primary_physician,
                    status = :status
                  WHERE id = :id";
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':first_name', $first_name);
        $stmt->bindParam(':middle_name', $middle_name);
        $stmt->bindParam(':last_name', $last_name);
        $stmt->bindParam(':suffix', $suffix);
        $stmt->bindParam(':dob', $dob);
        $stmt->bindParam(':gender', $gender);
        $stmt->bindParam(':contact', $contact);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':patient_type', $patient_type);
        $stmt->bindParam(':is_pwd', $is_pwd);
        $stmt->bindParam(':is_senior', $is_senior);
        $stmt->bindParam(':is_pregnant', $is_pregnant);
        $stmt->bindParam(':primary_physician', $primary_physician);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $patient_id);
        
        if ($stmt->execute()) {
            $message = "Patient information updated successfully!";
            $sessionManager->logActivity('Updated patient record; patient_id=' . $patient_id);
            // Refresh patient data
            $stmt = $db->prepare("SELECT * FROM patients WHERE id = :id");
            $stmt->bindParam(':id', $patient_id);
            $stmt->execute();
            $patient = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $error = "Failed to update patient. Please try again.";
        }
    }
}

// Get patient queue history
$queue_query = "SELECT q.*, c.name as clinic_name
                FROM queue_entries q
                JOIN clinics c ON q.clinic_id = c.id
                WHERE q.patient_id = :patient_id
                ORDER BY q.registered_at DESC
                LIMIT 20";
$queue_stmt = $db->prepare($queue_query);
$queue_stmt->bindParam(':patient_id', $patient_id);
$queue_stmt->execute();
$queue_history = $queue_stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate age
function calculateAge($dob) {
    if (!$dob || $dob == '0000-00-00') return '—';
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    return $today->diff($birthDate)->y;
}

// Get patient status (with fallback)
$patient_status = isset($patient['status']) ? $patient['status'] : 'Active';

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $current_theme === 'dark' ? 'dark' : ''; ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient | <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?> | Camp Evangelista</title>
            <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="dashboard.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patients.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patients</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-line text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Monitor</span>
                        </a>
                    </li>
                    <li>
                        <a href="clinic-congestion.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-pie text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Clinic Congestion</span>
                        </a>
                    </li>
                    <li>
                        <a href="reports.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-bar text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Reports</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users-cog text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="login-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-history text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Login/Session Monitor</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5">Edit Patient Record</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">Update patient demographic properties and registry status</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate">System Administrator</p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5">HOSP-HQ COM</p>
                        </div>
                        <div class="p-1.5">
                            <a href="setup-2fa.php" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                                <i class="fas fa-shield-alt text-sm text-sky-500"></i>
                                <span>Set Up Two-Factor Authentication</span>
                            </a>
                            <a href="../logout.php" onclick="return confirm('Confirm Dashboard Exit?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Patient Summary -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
            <div>
                <h2 class="text-slate-900 dark:text-white text-lg font-bold tracking-tight"><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h2>
                <div class="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
                    <span class="flex items-center gap-1.5"><i class="fas fa-id-card text-slate-400"></i> MRN: <b class="text-slate-700 dark:text-slate-200 font-mono"><?php echo htmlspecialchars($patient['mrn']); ?></b></span>
                    <span class="hidden sm:inline text-slate-300 dark:text-slate-700">|</span>
                    <span class="flex items-center gap-1.5"><i class="fas fa-calendar-alt text-slate-400"></i> Age: <b class="text-slate-700 dark:text-slate-200"><?php echo calculateAge($patient['date_of_birth']); ?> years</b></span>
                    <span class="hidden sm:inline text-slate-300 dark:text-slate-700">|</span>
                    <span class="flex items-center gap-1.5"><i class="fas fa-clock text-slate-400"></i> Registered: <b class="text-slate-700 dark:text-slate-200"><?php echo date('M d, Y', strtotime($patient['created_at'])); ?></b></span>
                    <?php if (!empty($patient['email'])): ?>
                        <span class="hidden sm:inline text-slate-300 dark:text-slate-700">|</span>
                        <span class="flex items-center gap-1.5"><i class="fas fa-envelope text-slate-400"></i> Email: <b class="text-slate-700 dark:text-slate-200"><?php echo htmlspecialchars($patient['email']); ?></b></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 px-4 py-2 rounded-xl text-xs font-bold tracking-wide flex items-center gap-2 border border-sky-100 dark:border-sky-500/10">
                <i class="fas fa-notes-medical"></i> <?php echo count($queue_history); ?> Total Visits
            </div>
        </div>

        <!-- Alerts -->
        <?php if ($message): ?>
            <div class="p-4 mb-6 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-between shadow-sm">
                <div class="flex items-center"><i class="fas fa-check-circle mr-3 text-base"></i> <span class="text-xs font-bold uppercase tracking-wide"><?php echo $message; ?></span></div>
                <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-emerald-500"><i class="fas fa-times text-base"></i></button>
            </div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="p-4 mb-6 bg-rose-50 dark:bg-rose-500/10 border border-rose-300 dark:border-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl flex items-center justify-between shadow-sm">
                <div class="flex items-center"><i class="fas fa-exclamation-triangle mr-3 text-base"></i> <span class="text-xs font-bold uppercase tracking-wide"><?php echo $error; ?></span></div>
                <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-rose-500"><i class="fas fa-times text-base"></i></button>
            </div>
        <?php endif; ?>

        <!-- Action Links -->
        <div class="flex flex-wrap gap-3 mb-6">
            <a href="medical_history.php?patient_id=<?php echo $patient_id; ?>" class="inline-flex items-center gap-2 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold px-4 py-2.5 rounded-xl shadow-sm transition-all">
                <i class="fas fa-notes-medical text-sky-500"></i> Medical History
            </a>
            <a href="patient-results.php?id=<?php echo $patient_id; ?>" class="inline-flex items-center gap-2 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold px-4 py-2.5 rounded-xl shadow-sm transition-all">
                <i class="fas fa-file-alt text-sky-500"></i> Lab Results
            </a>
            <a href="../staff/registration.php?edit=<?php echo $patient_id; ?>" class="inline-flex items-center gap-2 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold px-4 py-2.5 rounded-xl shadow-sm transition-all">
                <i class="fas fa-calendar-plus text-sky-500"></i> Schedule Appointment
            </a>
        </div>

        <!-- Edit Form -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="px-5 py-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/10 flex items-center justify-between">
                <h3 class="text-xs font-extrabold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-user-md text-sky-500 text-sm"></i> Core Profile Management
                </h3>
                <span class="px-3 py-1 rounded-full text-[0.6rem] font-bold uppercase tracking-wider <?php echo $patient_status == 'Active' ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'; ?> flex items-center gap-1">
                    <i class="fas <?php echo $patient_status == 'Active' ? 'fa-check-circle' : 'fa-archive'; ?>"></i> <?php echo $patient_status; ?>
                </span>
            </div>
            
            <div class="p-6">
                <form method="POST">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">First Name <span class="text-rose-500">*</span></label>
                            <input type="text" name="first_name" id="first_name" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" value="<?php echo htmlspecialchars($patient['first_name']); ?>" required>
                        </div>

                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Middle Name</label>
                            <input type="text" name="middle_name" id="middle_name" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" value="<?php echo htmlspecialchars($patient['middle_name'] ?? ''); ?>">
                        </div>
                        
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Last Name <span class="text-rose-500">*</span></label>
                            <input type="text" name="last_name" id="last_name" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" value="<?php echo htmlspecialchars($patient['last_name']); ?>" required>
                        </div>

                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Suffix</label>
                            <input type="text" name="suffix" id="suffix" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" value="<?php echo htmlspecialchars($patient['suffix'] ?? ''); ?>">
                        </div>
                        
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Date of Birth <span class="text-rose-500">*</span></label>
                            <input type="date" name="dob" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" value="<?php echo $patient['date_of_birth']; ?>" required>
                        </div>
                        
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Gender <span class="text-rose-500">*</span></label>
                            <select name="gender" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" required>
                                <option value="Male" <?php echo $patient['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                                <option value="Female" <?php echo $patient['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                                <option value="Other" <?php echo $patient['gender'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                        
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Contact Number</label>
                            <input type="tel" name="contact" class="w-full text-xs font-mono font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" value="<?php echo htmlspecialchars($patient['contact_number']); ?>">
                        </div>
                        
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Email Address</label>
                            <input type="email" name="email" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" value="<?php echo htmlspecialchars($patient['email'] ?? ''); ?>" placeholder="patient@email.com">
                            <p class="text-[0.5rem] text-slate-400 dark:text-slate-500">Optional - Used for patient communication and notifications</p>
                        </div>
                        
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Address</label>
                            <input type="text" name="address" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" value="<?php echo htmlspecialchars($patient['address']); ?>">
                        </div>
                        
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Patient Type <span class="text-rose-500">*</span></label>
                            <select name="patient_type" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" required>
                                <option value="military" <?php echo $patient['patient_type'] == 'military' ? 'selected' : ''; ?>>Military Personnel</option>
                                <option value="dependent" <?php echo $patient['patient_type'] == 'dependent' ? 'selected' : ''; ?>>Dependent</option>
                            </select>
                        </div>
                        
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Primary Physician</label>
                            <input type="text" name="primary_physician" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all" value="<?php echo htmlspecialchars($patient['primary_physician'] ?? ''); ?>">
                        </div>
                        
                        <div class="md:col-span-2 flex flex-col gap-2 mt-2">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Priority Conditions</label>
                            <div class="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-wrap gap-x-6 gap-y-3">
                                <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer select-none">
                                    <input type="checkbox" name="is_pwd" value="1" <?php echo $patient['is_pwd'] ? 'checked' : ''; ?> class="w-4 h-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 accent-sky-600 cursor-pointer">
                                    <span>PWD (Person with Disability)</span>
                                </label>
                                <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer select-none">
                                    <input type="checkbox" name="is_senior" value="1" <?php echo $patient['is_senior'] ? 'checked' : ''; ?> class="w-4 h-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 accent-sky-600 cursor-pointer">
                                    <span>Senior Citizen (60+)</span>
                                </label>
                                <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer select-none">
                                    <input type="checkbox" name="is_pregnant" value="1" <?php echo $patient['is_pregnant'] ? 'checked' : ''; ?> class="w-4 h-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 accent-sky-600 cursor-pointer">
                                    <span>Pregnant</span>
                                </label>
                            </div>
                        </div>
                        
                        <div class="flex flex-col gap-1.5">
                            <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Registry Status</label>
                            <select name="status" class="w-full text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl p-3 outline-none transition-all">
                                <option value="Active" <?php echo $patient_status == 'Active' ? 'selected' : ''; ?>>Active</option>
                                <option value="Archived" <?php echo $patient_status == 'Archived' ? 'selected' : ''; ?>>Archived</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex flex-col sm:flex-row justify-end gap-3 pt-6 mt-6 border-t border-slate-200 dark:border-slate-700/60">
                        <a href="patients.php" class="inline-flex items-center justify-center gap-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold uppercase tracking-wider px-5 py-3 rounded-xl transition-all">
                            <i class="fas fa-arrow-left"></i> Cancel
                        </a>
                        <button type="submit" name="update_patient" class="inline-flex items-center justify-center gap-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold uppercase tracking-wider px-5 py-3 rounded-xl shadow-md hover:shadow-lg transition-all">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </div>
                    <p id="nameError" class="hidden md:col-span-2 text-rose-500 text-xs font-semibold mt-3" role="alert">Name fields may contain letters, spaces, and hyphens (-) only.</p>
                </form>
            </div>
        </div>

        <!-- Queue History -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="px-5 py-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/10 flex items-center justify-between">
                <h3 class="text-xs font-extrabold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-history text-sky-500 text-sm"></i> Queue History
                </h3>
                <span class="text-[0.6rem] font-bold uppercase tracking-wide text-slate-400"><i class="fas fa-clock"></i> Last 20 Visits</span>
            </div>
            
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50/70 dark:bg-slate-900/40 border-b border-slate-200 dark:border-slate-700 text-[0.6rem] font-bold uppercase text-slate-400 tracking-wider">
                            <th class="p-4">Date</th>
                            <th class="p-4">Time</th>
                            <th class="p-4">Queue #</th>
                            <th class="p-4">Clinic</th>
                            <th class="p-4">Priority</th>
                            <th class="p-4 text-right">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50 text-xs font-medium">
                        <?php if (empty($queue_history)): ?>
                            <tr>
                                <td colspan="6" class="p-8 text-center text-slate-400 font-bold uppercase tracking-wider text-[0.6rem]">
                                    <div class="flex flex-col items-center gap-2">
                                        <i class="fas fa-inbox text-2xl text-slate-300 dark:text-slate-700"></i>
                                        <span>No historical queue records found.</span>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($queue_history as $queue): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                                    <td class="p-4 font-semibold text-slate-700 dark:text-slate-300"><?php echo date('M d, Y', strtotime($queue['registered_at'])); ?></td>
                                    <td class="p-4 text-slate-500"><?php echo date('h:i A', strtotime($queue['registered_at'])); ?></td>
                                    <td class="p-4 font-mono font-bold text-sky-600 dark:text-sky-400"><?php echo htmlspecialchars($queue['queue_number']); ?></td>
                                    <td class="p-4 font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($queue['clinic_name']); ?></td>
                                    <td class="p-4">
                                        <?php 
                                            $pr = $queue['priority_level'];
                                            $prColor = $pr == 'PR1' ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400' : ($pr == 'PR2' ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400' : 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400');
                                        ?>
                                        <span class="px-2.5 py-0.5 rounded-full text-[0.6rem] font-extrabold uppercase tracking-wide <?php echo $prColor; ?>">
                                            <?php echo $pr; ?>
                                        </span>
                                    </td>
                                    <td class="p-4 text-right">
                                        <?php 
                                            $qStatus = $queue['status'];
                                            $stColor = $qStatus == 'completed' ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : ($qStatus == 'in-progress' ? 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 animate-pulse' : 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400');
                                        ?>
                                        <span class="inline-block px-2.5 py-0.5 rounded-full text-[0.6rem] font-extrabold uppercase tracking-wide <?php echo $stColor; ?>">
                                            <?php echo ucfirst($qStatus); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
    </style>

    <script>
        // Theme Toggle
        const themeToggleBtn = document.getElementById('themeToggleBtn');
        const themeToggleIcon = document.getElementById('themeToggleIcon');
        const htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
        } else {
            htmlElement.classList.remove('dark');
            themeToggleIcon.className = 'fas fa-moon text-base';
        }

        themeToggleBtn.addEventListener('click', () => {
            if (htmlElement.classList.contains('dark')) {
                htmlElement.classList.remove('dark');
                themeToggleIcon.className = 'fas fa-moon text-base';
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.classList.add('dark');
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                localStorage.setItem('theme', 'dark');
            }
        });

        // Profile Dropdown
        const profileMenuBtn = document.getElementById('profileMenuBtn');
        const profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', () => profileDropdown.classList.add('hidden'));
        }

        // Validate patient names before allowing the update.
        document.querySelector('form[method="POST"]')?.addEventListener('submit', function(event) {
            var namePattern = /^[\p{L} -]+$/u;
            var nameInputs = ['first_name', 'middle_name', 'last_name', 'suffix'].map(function(id) {
                return document.getElementById(id);
            });
            var hasInvalidName = nameInputs.some(function(input) {
                var value = input.value.trim();
                return value !== '' && !namePattern.test(value);
            });
            document.getElementById('nameError').classList.toggle('hidden', !hasInvalidName);
            if (hasInvalidName) {
                event.preventDefault();
                nameInputs.find(function(input) {
                    var value = input.value.trim();
                    return value !== '' && !namePattern.test(value);
                }).focus();
            }
        });

        // Live Clock
        function updateDateTime() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
            document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', (e) => {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // Auto-dismiss alerts
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-8px)';
                setTimeout(() => alert.remove(), 400);
            });
        }, 5000);

        // Auto Logout
        const INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        let inactivityTimer;
        let warningTimer;
        let warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(err => console.log('Heartbeat failed:', err));
        }

        function logoutUser() {
            const logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = `
                <div class="fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
                    <div class="bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700">
                        <i class="fas fa-clock text-5xl text-rose-500 mb-5"></i>
                        <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">Session Expired</h3>
                        <p class="text-slate-500 dark:text-slate-400 text-sm mb-5">You have been logged out due to inactivity.</p>
                        <div class="w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden">
                            <div class="bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full"></div>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(logoutMsg);
            setTimeout(() => { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            const modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = `
                <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4">
                    <div class="bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in">
                        <i class="fas fa-hourglass-half text-5xl text-amber-500 mb-4"></i>
                        <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-1">Session About to Expire</h3>
                        <p class="text-slate-500 dark:text-slate-400 text-sm mb-3">You will be logged out due to inactivity.</p>
                        <p id="countdownText" class="text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4">2:00</p>
                        <button onclick="keepSessionAlive()" class="w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm">
                            <i class="fas fa-mouse-pointer mr-1.5"></i> Keep Session Active
                        </button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            
            let secondsLeft = 120;
            const countdownElement = document.getElementById('countdownText');
            const countdownInterval = setInterval(() => {
                secondsLeft--;
                const minutes = Math.floor(secondsLeft / 60);
                const seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(() => resetInactivityTimer())
                .catch(() => resetInactivityTimer());
        }

        function hideWarningModal() {
            const modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(event => document.addEventListener(event, resetInactivityTimer, false));

        resetInactivityTimer();
        setInterval(() => { if (!warningShown) sendHeartbeat(); }, 5 * 60 * 1000);
    </script>

</body>
</html>