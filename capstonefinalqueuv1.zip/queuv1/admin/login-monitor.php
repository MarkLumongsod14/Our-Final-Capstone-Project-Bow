<?php
// admin/login-monitor.php - Login Security Monitor
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/SessionManager.php';

session_start();
require_once dirname(__DIR__) . '/includes/UnifiedSession.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    if (($_SESSION['role'] ?? '') === 'admin_dashboard') {
        header('Location: dashboard.php');
        exit();
    }
    header('Location: ../index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$sessionManager = new SessionManager($db);

// Get paginated login history
$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
$per_page = 10;
$history_count = (int) $db->query("SELECT COUNT(*) FROM login_history")->fetchColumn();
$total_pages = max(1, (int) ceil($history_count / $per_page));
$page = min($page, $total_pages);
$offset = ($page - 1) * $per_page;

$query = "SELECT h.*, u.full_name 
          FROM login_history h
          LEFT JOIN users u ON h.user_id = u.id
          ORDER BY h.attempt_time DESC
          LIMIT " . $per_page . " OFFSET " . $offset;
$history_stmt = $db->query($query);
$history = $history_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics across the complete login history, not only the current page
$stats_query = "SELECT COUNT(*) AS total_attempts,
                       COALESCE(SUM(success = 1), 0) AS successful_logins,
                       COALESCE(SUM(success = 0), 0) AS failed_logins,
                       COUNT(DISTINCT username) AS unique_users,
                       COALESCE(SUM(DATE(attempt_time) = CURDATE()), 0) AS today_attempts
                FROM login_history";
$stats = $db->query($stats_query)->fetch(PDO::FETCH_ASSOC);
$history = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

// Get locked accounts
$locked = "SELECT username, full_name, login_attempts, locked_until 
           FROM users 
           WHERE locked_until > NOW() 
           ORDER BY locked_until DESC";
$locked_accounts = $db->query($locked)->fetchAll(PDO::FETCH_ASSOC);

$activity_user_id = filter_var($_GET['activity_user_id'] ?? 0, FILTER_VALIDATE_INT);
$activity_user_id = $activity_user_id !== false && $activity_user_id > 0 ? $activity_user_id : 0;
$activity_action_filter = trim((string) ($_GET['activity_action'] ?? ''));
$activity_date_from = is_string($_GET['activity_date_from'] ?? null) ? $_GET['activity_date_from'] : '';
$activity_date_to = is_string($_GET['activity_date_to'] ?? null) ? $_GET['activity_date_to'] : '';
foreach (['activity_date_from', 'activity_date_to'] as $date_filter_name) {
    $date_filter = $$date_filter_name;
    if ($date_filter !== '') {
        $parsed_filter_date = DateTimeImmutable::createFromFormat('!Y-m-d', $date_filter);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_filter)
            || !$parsed_filter_date
            || $parsed_filter_date->format('Y-m-d') !== $date_filter) {
            $$date_filter_name = '';
        }
    }
}
$activity_conditions = [];
$activity_params = [];
if ($activity_user_id) {
    $activity_conditions[] = 'a.user_id = ?';
    $activity_params[] = $activity_user_id;
}
if ($activity_date_from !== '') {
    $activity_conditions[] = 'a.created_at >= ?';
    $activity_params[] = $activity_date_from . ' 00:00:00';
}
if ($activity_date_to !== '') {
    $activity_conditions[] = 'a.created_at < DATE_ADD(?, INTERVAL 1 DAY)';
    $activity_params[] = $activity_date_to;
}
if ($activity_action_filter !== '') {
    $activity_conditions[] = 'a.action LIKE ?';
    $activity_params[] = '%' . $activity_action_filter . '%';
}
$activity_where = $activity_conditions ? ' WHERE ' . implode(' AND ', $activity_conditions) : '';
$activity_per_page = 15;
$activity_page = isset($_GET['activity_page']) ? max(1, (int) $_GET['activity_page']) : 1;
$activity_count_stmt = $db->prepare('SELECT COUNT(*) FROM user_activity a' . $activity_where);
$activity_count_stmt->execute($activity_params);
$activity_count = (int) $activity_count_stmt->fetchColumn();
$activity_total_pages = max(1, (int) ceil($activity_count / $activity_per_page));
$activity_page = min($activity_page, $activity_total_pages);
$activity_offset = ($activity_page - 1) * $activity_per_page;
$activity_query = "SELECT a.user_id, a.action, a.ip_address, a.user_agent, a.created_at,
                          u.username, u.full_name, u.role
                   FROM user_activity a
                   LEFT JOIN users u ON u.id = a.user_id" . $activity_where . "
                   ORDER BY a.created_at DESC
                   LIMIT " . $activity_per_page . " OFFSET " . $activity_offset;
$activity_stmt = $db->prepare($activity_query);
$activity_stmt->execute($activity_params);
$activity_logs = $activity_stmt->fetchAll(PDO::FETCH_ASSOC);
$activity_users = $db->query("SELECT DISTINCT u.id, u.username, u.full_name
                              FROM user_activity a
                              JOIN users u ON u.id = a.user_id
                              ORDER BY u.full_name ASC, u.username ASC")->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$total_attempts = (int) $stats['total_attempts'];
$successful_logins = (int) $stats['successful_logins'];
$failed_logins = (int) $stats['failed_logins'];
$unique_users = (int) $stats['unique_users'];

$success_rate = $total_attempts > 0 ? round(($successful_logins / $total_attempts) * 100) : 0;

$today_attempts = (int) $stats['today_attempts'];

$pagination_url = function ($target_page) {
    return 'login-monitor.php?page=' . $target_page;
};
$activity_pagination_url = function ($target_page) use ($activity_user_id, $activity_action_filter, $activity_date_from, $activity_date_to) {
    return 'login-monitor.php?' . http_build_query(array_filter([
        'activity_page' => $target_page,
        'activity_user_id' => $activity_user_id ?: null,
        'activity_action' => $activity_action_filter !== '' ? $activity_action_filter : null,
        'activity_date_from' => $activity_date_from !== '' ? $activity_date_from : null,
        'activity_date_to' => $activity_date_to !== '' ? $activity_date_to : null
    ], function ($value) { return $value !== null; }));
};

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo ($current_theme === 'dark' ? 'dark' : ''); ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login &amp; System Activity Monitor | 4ID Station Hospital | Camp Evangelista</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
              <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
  
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="dashboard.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patients.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patients</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-line text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Monitor</span>
                        </a>
                    </li>
                    <li>
                        <a href="clinic-congestion.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-pie text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Clinic Congestion</span>
                        </a>
                    </li>
                    <li>
                        <a href="reports.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-bar text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Reports</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users-cog text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="login-monitor.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-history text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Login/Session Monitor</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5">Login &amp; System Activity</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">Review login attempts and identify the account behind system changes</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate">System Administrator</p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5">HOSP-HQ COM</p>
                        </div>
                        <div class="p-1.5">
                            <a href="setup-2fa.php" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                                <i class="fas fa-shield-alt text-sm text-sky-500"></i>
                                <span>Set Up Two-Factor Authentication</span>
                            </a>
                            <a href="../logout.php" onclick="return confirm('Confirm Dashboard Exit?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Statistics Cards -->
        <div class="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-4 mb-6">
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-10 h-10 bg-sky-50 dark:bg-sky-500/10 rounded-xl flex items-center justify-center text-sky-600 dark:text-sky-400 text-base mx-auto mb-2">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo number_format($total_attempts); ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-1">Total Attempts</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-10 h-10 bg-emerald-50 dark:bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-base mx-auto mb-2">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo number_format($successful_logins); ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-1">Successful</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-10 h-10 bg-rose-50 dark:bg-rose-500/10 rounded-xl flex items-center justify-center text-rose-600 dark:text-rose-400 text-base mx-auto mb-2">
                    <i class="fas fa-times-circle"></i>
                </div>
                <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo number_format($failed_logins); ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-1">Failed Attempts</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-10 h-10 bg-indigo-50 dark:bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-base mx-auto mb-2">
                    <i class="fas fa-percent"></i>
                </div>
                <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $success_rate; ?>%</div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-1">Success Rate</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-10 h-10 bg-amber-50 dark:bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-600 dark:text-amber-400 text-base mx-auto mb-2">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo number_format($today_attempts); ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-1">Today's Attempts</div>
            </div>
        </div>

        <!-- Locked Accounts Alert -->
        <?php if (!empty($locked_accounts)): ?>
            <div class="bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 rounded-xl p-4 mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-rose-500 rounded-full flex items-center justify-center text-white text-lg shrink-0">
                        <i class="fas fa-lock"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-bold text-slate-900 dark:text-white">Locked Accounts Detected</h3>
                        <p class="text-xs text-slate-500 dark:text-slate-400">Accounts locked due to multiple failed login attempts</p>
                    </div>
                </div>
                <div class="bg-rose-500 text-white px-4 py-1.5 rounded-full text-sm font-bold shrink-0">
                    <?php echo count($locked_accounts); ?> Account(s) Locked
                </div>
            </div>

            <!-- Locked Accounts Table -->
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
                <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center">
                    <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                        <i class="fas fa-lock text-rose-500 text-sm"></i> Locked Accounts
                    </h3>
                    <span class="text-[0.6rem] font-bold text-slate-400 dark:text-slate-500"><i class="fas fa-clock"></i> Auto-unlocks after lockout period</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full border-collapse text-left">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider">
                                <th class="py-3 px-4">Username</th>
                                <th class="py-3 px-4">Full Name</th>
                                <th class="py-3 px-4 text-center">Failed Attempts</th>
                                <th class="py-3 px-4">Locked Until</th>
                                <th class="py-3 px-4 text-right">Time Remaining</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium text-slate-700 dark:text-slate-300">
                            <?php foreach ($locked_accounts as $locked): 
                                $lock_until = new DateTime($locked['locked_until']);
                                $now = new DateTime();
                                $interval = $now->diff($lock_until);
                                $remaining = '';
                                if ($interval->h > 0) {
                                    $remaining = $interval->h . ' hour(s) ' . $interval->i . ' min';
                                } else {
                                    $remaining = $interval->i . ' minutes';
                                }
                            ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                                    <td class="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($locked['username']); ?></td>
                                    <td class="py-3 px-4 text-slate-600 dark:text-slate-400"><?php echo htmlspecialchars($locked['full_name'] ?? '—'); ?></td>
                                    <td class="py-3 px-4 text-center"><span class="px-2.5 py-0.5 rounded-full text-[0.6rem] font-bold bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400"><?php echo $locked['login_attempts']; ?> attempts</span></td>
                                    <td class="py-3 px-4 font-mono text-slate-500 dark:text-slate-400"><?php echo date('M d, Y h:i A', strtotime($locked['locked_until'])); ?></td>
                                    <td class="py-3 px-4 text-right font-semibold text-slate-600 dark:text-slate-400"><i class="fas fa-hourglass-half text-amber-500 mr-1"></i> <?php echo $remaining; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <!-- Login History Table -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-history text-sky-500 text-sm"></i> Recent Authorization Activity Logs
                </h3>
                <span class="text-[0.6rem] font-bold text-slate-400 dark:text-slate-500">All Authorization Attempts</span>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($history)): ?>
                    <div class="text-center py-12 text-slate-400 dark:text-slate-500">
                        <i class="fas fa-shield-alt text-4xl mb-3 block opacity-50"></i>
                        <p class="text-sm font-bold uppercase tracking-wider">No Security Event History Located</p>
                    </div>
                <?php else: ?>
                    <table class="w-full border-collapse text-left">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider">
                                <th class="py-3 px-4">Attempt Time</th>
                                <th class="py-3 px-4">Username</th>
                                <th class="py-3 px-4">Full Identity</th>
                                <th class="py-3 px-4">IP Address</th>
                                <th class="py-3 px-4 text-center">Status</th>
                                <th class="py-3 px-4">Reason</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium text-slate-700 dark:text-slate-300">
                            <?php foreach ($history as $log): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                                    <td class="py-3 px-4 font-mono text-slate-500 dark:text-slate-400"><?php echo date('M d, Y h:i:s A', strtotime($log['attempt_time'])); ?></td>
                                    <td class="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($log['username']); ?></td>
                                    <td class="py-3 px-4 text-slate-600 dark:text-slate-400"><?php echo htmlspecialchars($log['full_name'] ?? '—'); ?></td>
                                    <td class="py-3 px-4"><span class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-mono text-[0.6rem] border border-slate-200 dark:border-slate-700"><?php echo htmlspecialchars($log['ip_address']); ?></span></td>
                                    <td class="py-3 px-4 text-center">
                                        <?php if ($log['success']): ?>
                                            <span class="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold uppercase tracking-wide text-[0.6rem] bg-emerald-50 dark:bg-emerald-500/10 px-2.5 py-0.5 rounded-full">Success</span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center gap-1 text-rose-600 dark:text-rose-400 font-bold uppercase tracking-wide text-[0.6rem] bg-rose-50 dark:bg-rose-500/10 px-2.5 py-0.5 rounded-full">Failed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 px-4">
                                        <?php
                                        $reason = $log['failure_reason'] ?? '';
                                        if ($reason == 'Invalid password') {
                                            echo '<span class="text-amber-500 flex items-center gap-1.5"><i class="fas fa-key text-[0.6rem]"></i> Invalid Password</span>';
                                        } elseif ($reason == 'User not found') {
                                            echo '<span class="text-slate-400 dark:text-slate-500 flex items-center gap-1.5"><i class="fas fa-user-slash text-[0.6rem]"></i> User Not Found</span>';
                                        } elseif ($reason == 'Invalid 2FA code') {
                                            echo '<span class="text-rose-500 flex items-center gap-1.5"><i class="fas fa-qrcode text-[0.6rem]"></i> Invalid 2FA Code</span>';
                                        } elseif ($reason == 'Account locked') {
                                            echo '<span class="text-rose-500 font-bold uppercase text-[0.6rem] tracking-wide bg-rose-50 dark:bg-rose-500/10 px-2 py-0.5 rounded border border-rose-200 dark:border-rose-500/20 flex items-center w-max gap-1"><i class="fas fa-lock text-[0.5rem]"></i> Account Locked</span>';
                                        } elseif ($reason == 'CAPTCHA failed') {
                                            echo '<span class="text-amber-500 flex items-center gap-1.5"><i class="fas fa-robot text-[0.6rem]"></i> CAPTCHA Failed</span>';
                                        } else {
                                            echo '<span class="text-slate-400 font-mono">—</span>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            <?php if ($history_count > 0): ?>
                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 px-4 py-4 border-t border-slate-200 dark:border-slate-700/60">
                    <p class="text-[0.65rem] font-bold uppercase tracking-wider text-slate-400">
                        Showing <?= number_format($offset + 1); ?>-<?= number_format($offset + count($history)); ?> of <?= number_format($history_count); ?> attempts
                    </p>
                    <?php if ($total_pages > 1): ?>
                        <nav class="flex items-center gap-1" aria-label="Login history pagination">
                            <?php if ($page > 1): ?>
                                <a href="<?= htmlspecialchars($pagination_url($page - 1)); ?>" class="inline-flex items-center justify-center px-3 h-8 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:text-sky-500 hover:border-sky-400 text-[0.65rem] font-bold uppercase tracking-wider transition-colors">Previous</a>
                            <?php endif; ?>
                            <?php for ($page_number = 1; $page_number <= $total_pages; $page_number++): ?>
                                <a href="<?= htmlspecialchars($pagination_url($page_number)); ?>" class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-[0.7rem] font-bold transition-colors <?= $page_number === $page ? 'bg-sky-600 text-white dark:bg-sky-500' : 'text-slate-500 dark:text-slate-400 hover:text-sky-500 hover:bg-sky-50 dark:hover:bg-sky-500/10'; ?>" aria-current="<?= $page_number === $page ? 'page' : 'false'; ?>"><?= $page_number; ?></a>
                            <?php endfor; ?>
                            <?php if ($page < $total_pages): ?>
                                <a href="<?= htmlspecialchars($pagination_url($page + 1)); ?>" class="inline-flex items-center justify-center px-3 h-8 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:text-sky-500 hover:border-sky-400 text-[0.65rem] font-bold uppercase tracking-wider transition-colors">Next</a>
                            <?php endif; ?>
                        </nav>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- System Activity Audit -->
        <section id="activity-log" class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mt-6">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                    <h2 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2"><i class="fas fa-clipboard-list text-sky-500"></i> System Activity Audit</h2>
                    <p class="text-[0.6rem] text-slate-400 dark:text-slate-500 mt-1">Successful changes and account-attributed activity</p>
                </div>
                <form method="GET" class="flex flex-wrap items-end gap-2">
                    <div>
                        <label for="activityUser" class="block text-[0.55rem] font-bold uppercase text-slate-400 mb-1">Account</label>
                        <select id="activityUser" name="activity_user_id" class="px-3 py-2 bg-white dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs">
                        <option value="0">All accounts</option>
                        <?php foreach ($activity_users as $activity_user): ?>
                            <option value="<?php echo (int) $activity_user['id']; ?>" <?php echo $activity_user_id === (int) $activity_user['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars(($activity_user['full_name'] ?: $activity_user['username']) . ' (@' . $activity_user['username'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="activityDateFrom" class="block text-[0.55rem] font-bold uppercase text-slate-400 mb-1">From</label>
                        <input id="activityDateFrom" type="date" name="activity_date_from" value="<?php echo htmlspecialchars($activity_date_from); ?>" class="px-3 py-2 bg-white dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs">
                    </div>
                    <div>
                        <label for="activityDateTo" class="block text-[0.55rem] font-bold uppercase text-slate-400 mb-1">To</label>
                        <input id="activityDateTo" type="date" name="activity_date_to" value="<?php echo htmlspecialchars($activity_date_to); ?>" class="px-3 py-2 bg-white dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs">
                    </div>
                    <div>
                        <label for="activityAction" class="block text-[0.55rem] font-bold uppercase text-slate-400 mb-1">Action</label>
                        <input id="activityAction" type="search" name="activity_action" value="<?php echo htmlspecialchars($activity_action_filter); ?>" maxlength="120" placeholder="Search activity" class="w-36 px-3 py-2 bg-white dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs">
                    </div>
                    <button type="submit" class="h-9 px-3 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold">Filter</button>
                    <?php if ($activity_user_id || $activity_action_filter !== '' || $activity_date_from !== '' || $activity_date_to !== ''): ?>
                        <a href="login-monitor.php#activity-log" class="h-9 inline-flex items-center px-3 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg text-xs font-bold">Clear</a>
                    <?php endif; ?>
                </form>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($activity_logs)): ?>
                    <div class="text-center py-10 text-slate-400 dark:text-slate-500">
                        <i class="fas fa-clipboard-check text-3xl mb-3 block opacity-50"></i>
                        <p class="text-xs font-semibold">No recorded system activity for this account.</p>
                    </div>
                <?php else: ?>
                    <table class="w-full border-collapse text-left min-w-[980px]">
                        <thead><tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.58rem] font-bold uppercase tracking-wider">
                            <th class="py-3 px-4">Time</th><th class="py-3 px-4">Account</th><th class="py-3 px-4">Role</th><th class="py-3 px-4">System activity</th><th class="py-3 px-4">IP address</th><th class="py-3 px-4">User agent</th>
                        </tr></thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium text-slate-700 dark:text-slate-300">
                            <?php foreach ($activity_logs as $activity): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                                    <td class="py-3 px-4 whitespace-nowrap font-mono text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars(date('M d, Y h:i:s A', strtotime($activity['created_at']))); ?></td>
                                    <td class="py-3 px-4">
                                        <?php if ($activity['user_id'] && $activity['username']): ?>
                                            <span class="block font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($activity['full_name'] ?: $activity['username']); ?></span>
                                            <span class="text-[0.6rem] font-mono text-sky-600 dark:text-sky-400">@<?php echo htmlspecialchars($activity['username']); ?> · ID <?php echo (int) $activity['user_id']; ?></span>
                                        <?php elseif ($activity['user_id']): ?>
                                            <span class="text-slate-500 dark:text-slate-400">Deleted account · User ID <?php echo (int) $activity['user_id']; ?></span>
                                        <?php else: ?>
                                            <span class="text-slate-400">System / account unavailable</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 px-4 text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($activity['role'] ?? '—'); ?></td>
                                    <td class="py-3 px-4 max-w-[32rem] break-words"><?php echo htmlspecialchars($activity['action']); ?></td>
                                    <td class="py-3 px-4 font-mono text-[0.65rem] text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($activity['ip_address'] ?? '—'); ?></td>
                                    <td class="py-3 px-4 max-w-[20rem] break-all text-[0.65rem] text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($activity['user_agent'] ?? '—'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            <?php if ($activity_count > 0): ?>
                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 px-4 py-4 border-t border-slate-200 dark:border-slate-700/60">
                    <p class="text-[0.65rem] font-bold uppercase tracking-wider text-slate-400">Showing <?php echo number_format($activity_offset + 1); ?>-<?php echo number_format($activity_offset + count($activity_logs)); ?> of <?php echo number_format($activity_count); ?> activities</p>
                    <?php if ($activity_total_pages > 1): ?>
                        <nav class="flex items-center gap-1" aria-label="System activity pagination">
                            <?php if ($activity_page > 1): ?><a href="<?php echo htmlspecialchars($activity_pagination_url($activity_page - 1)); ?>" class="px-3 h-8 inline-flex items-center border border-slate-300 dark:border-slate-700 rounded-lg text-xs">Previous</a><?php endif; ?>
                            <span class="px-3 text-xs font-bold text-slate-500">Page <?php echo $activity_page; ?> of <?php echo $activity_total_pages; ?></span>
                            <?php if ($activity_page < $activity_total_pages): ?><a href="<?php echo htmlspecialchars($activity_pagination_url($activity_page + 1)); ?>" class="px-3 h-8 inline-flex items-center border border-slate-300 dark:border-slate-700 rounded-lg text-xs">Next</a><?php endif; ?>
                        </nav>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </section>

       
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
    </style>

    <script>
        // Theme Toggle
        var themeToggleBtn = document.getElementById('themeToggleBtn');
        var themeToggleIcon = document.getElementById('themeToggleIcon');
        var htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
        } else {
            htmlElement.classList.remove('dark');
            themeToggleIcon.className = 'fas fa-moon text-base';
        }

        themeToggleBtn.addEventListener('click', function() {
            if (htmlElement.classList.contains('dark')) {
                htmlElement.classList.remove('dark');
                themeToggleIcon.className = 'fas fa-moon text-base';
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.classList.add('dark');
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                localStorage.setItem('theme', 'dark');
            }
        });

        // Profile Dropdown
        var profileMenuBtn = document.getElementById('profileMenuBtn');
        var profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', function() {
                profileDropdown.classList.add('hidden');
            });
        }

        // Live Clock
        function updateDateTime() {
            var now = new Date();
            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
            document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        var mobileMenuBtn = document.getElementById('mobileMenuBtn');
        var sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', function(e) {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // Auto Logout
        var INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        var inactivityTimer;
        var warningTimer;
        var warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(function(err) { console.log('Heartbeat failed:', err); });
        }

        function logoutUser() {
            var logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = '<div class="fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4"><div class="bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700"><i class="fas fa-clock text-5xl text-rose-500 mb-5"></i><h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">Session Expired</h3><p class="text-slate-500 dark:text-slate-400 text-sm mb-5">You have been logged out due to inactivity.</p><div class="w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden"><div class="bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full"></div></div></div></div>';
            document.body.appendChild(logoutMsg);
            setTimeout(function() { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            var modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = '<div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4"><div class="bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in"><i class="fas fa-hourglass-half text-5xl text-amber-500 mb-4"></i><h3 class="text-lg font-bold text-slate-900 dark:text-white mb-1">Session About to Expire</h3><p class="text-slate-500 dark:text-slate-400 text-sm mb-3">You will be logged out due to inactivity.</p><p id="countdownText" class="text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4">2:00</p><button onclick="keepSessionAlive()" class="w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm"><i class="fas fa-mouse-pointer mr-1.5"></i> Keep Session Active</button></div></div>';
            document.body.appendChild(modal);
            
            var secondsLeft = 120;
            var countdownElement = document.getElementById('countdownText');
            var countdownInterval = setInterval(function() {
                secondsLeft--;
                var minutes = Math.floor(secondsLeft / 60);
                var seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = minutes + ':' + (seconds.toString().padStart(2, '0'));
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(function() { resetInactivityTimer(); })
                .catch(function() { resetInactivityTimer(); });
        }

        function hideWarningModal() {
            var modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        var events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(function(event) {
            document.addEventListener(event, resetInactivityTimer, false);
        });

        resetInactivityTimer();
        setInterval(function() {
            if (!warningShown) sendHeartbeat();
        }, 5 * 60 * 1000);
    </script>

</body>
</html>