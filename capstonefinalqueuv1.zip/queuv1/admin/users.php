<?php
// admin/users.php - User Management
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/SessionManager.php';

session_start();
require_once __DIR__ . '/../includes/UnifiedSession.php';
require_once dirname(__DIR__, 2) . '/CESH/unified_auth.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    if (($_SESSION['role'] ?? '') === 'admin_dashboard') {
        header('Location: dashboard.php');
        exit();
    }
    header('Location: ../index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$sessionManager = new SessionManager($db);

// ============================================
// FIRST: Add missing columns if not exists
// ============================================
try {
    $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS `email` varchar(100) DEFAULT NULL");
    $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS `is_active` tinyint(1) DEFAULT 1");
} catch (PDOException $e) {
    // Columns might already exist, ignore error
}

// ============================================
// HANDLE USER ACTIONS
// ============================================
$valid_roles = ['admin', 'admin_dashboard', 'doctor', 'nurse', 'technician', 'staff'];
$validate_user_clinic = function ($role, $clinic_id) use ($db, $valid_roles) {
    if (!in_array($role, $valid_roles, true)) {
        return [false, null, 'Select a valid user role.'];
    }

    if ($role === 'admin_dashboard') {
        return $clinic_id === ''
            ? [true, null, null]
            : [false, null, 'Admin Dashboard Access users cannot be assigned to a clinic.'];
    }

    if ($role === 'admin' && $clinic_id === '') {
        return [true, null, null];
    }

    $clinic_id = filter_var($clinic_id, FILTER_VALIDATE_INT);
    if ($clinic_id === false || $clinic_id <= 0) {
        return [false, null, $role === 'admin'
            ? 'Select a valid clinic or choose All Clinics for an administrator.'
            : 'Select a clinic for non-administrator users.'];
    }

    $clinic_stmt = $db->prepare('SELECT id FROM clinics WHERE id = ? AND is_active = 1');
    $clinic_stmt->execute([$clinic_id]);
    if (!$clinic_stmt->fetchColumn()) {
        return [false, null, 'Select an active clinic.'];
    }

    return [true, $clinic_id, null];
};

// Handle user deletion
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($id != 1) {
        $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        if ($stmt->rowCount() > 0) {
            $sessionManager->logActivity('Deleted user account; target_user_id=' . $id);
            $message = "User deleted successfully!";
        }
    }
    header('Location: users.php');
    exit();
}

// Handle user activation
if (isset($_GET['activate'])) {
    $id = (int)$_GET['activate'];
    $stmt = $db->prepare("UPDATE users SET is_active = 1 WHERE id = ?");
    $stmt->execute([$id]);
    if ($stmt->rowCount() > 0) $sessionManager->logActivity('Activated user account; target_user_id=' . $id);
    $message = "User activated successfully!";
    header('Location: users.php');
    exit();
}

// Handle user deactivation
if (isset($_GET['deactivate'])) {
    $id = (int)$_GET['deactivate'];
    if ($id != 1) {
        $stmt = $db->prepare("UPDATE users SET is_active = 0 WHERE id = ?");
        $stmt->execute([$id]);
        if ($stmt->rowCount() > 0) $sessionManager->logActivity('Deactivated user account; target_user_id=' . $id);
        $message = "User deactivated successfully!";
    }
    header('Location: users.php');
    exit();
}

// Handle user addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['username'] ?? '');
    $plain_password = $_POST['password'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? '';
    $access = $_POST['access'] ?? '';
    if ($access === 'admin_dashboard') {
        $role = 'admin_dashboard';
        $access = '';
    }
    [$clinic_valid, $clinic_id, $clinic_error] = $validate_user_clinic($role, $access);

    if ($username === '' || $plain_password === '' || $full_name === '') {
        $error = 'Username, password, and full name are required.';
    } elseif (!$clinic_valid) {
        $error = $clinic_error;
    } else {
        $password = password_hash($plain_password, PASSWORD_DEFAULT);
        $query = "INSERT INTO users (username, password, full_name, email, role, clinic_id, is_active) 
                  VALUES (?, ?, ?, ?, ?, ?, 1)";
        $db->beginTransaction();
        try {
            $stmt = $db->prepare($query);
            $stmt->execute([$username, $password, $full_name, $email, $role, $clinic_id]);
            $newUserId = (int)$db->lastInsertId();
            UnifiedAuth::registerAccount($db, 'smart_queueing', $newUserId, $full_name);
            $db->commit();
            $sessionManager->logActivity('Created user account; target_user_id=' . $newUserId);
            header('Location: users.php');
            exit();
        } catch (Throwable $exception) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            error_log('Unable to provision unified queueing account: ' . $exception->getMessage());
            $error = 'Unable to create the account mapping. Please contact the administrator.';
        }
    }
}

// Handle user edit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_user'])) {
    $id = (int)$_POST['user_id'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? '';
    $access = $_POST['access'] ?? '';
    if ($access === 'admin_dashboard') {
        $role = 'admin_dashboard';
        $access = '';
    }
    [$clinic_valid, $clinic_id, $clinic_error] = $validate_user_clinic($role, $access);

    if ($id <= 0) {
        $error = 'Invalid user account.';
    } elseif (!$clinic_valid) {
        $error = $clinic_error;
    } else {
        $query = "UPDATE users SET full_name = ?, email = ?, role = ?, clinic_id = ? WHERE id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$full_name, $email, $role, $clinic_id, $id]);
        if ($stmt->rowCount() > 0) $sessionManager->logActivity('Updated user account; target_user_id=' . $id);

        $message = "User updated successfully!";
        header('Location: users.php');
        exit();
    }
}

// Handle password reset
if (isset($_GET['reset_password'])) {
    $id = (int)$_GET['reset_password'];
    if ($id != 1) {
        $new_password = password_hash('clinic123', PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$new_password, $id]);
        if ($stmt->rowCount() > 0) $sessionManager->logActivity('Reset user password; target_user_id=' . $id);
        $message = "Password reset to 'clinic123' for user ID: $id";
    }
    header('Location: users.php');
    exit();
}

// ============================================
// GET SEARCH/FILTER PARAMETERS
// ============================================
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$role_filter = isset($_GET['role_filter']) ? $_GET['role_filter'] : '';
$status_filter = isset($_GET['status_filter']) ? $_GET['status_filter'] : '';

// Build query with filters
$query = "SELECT u.*, c.name as clinic_name 
          FROM users u
          LEFT JOIN clinics c ON u.clinic_id = c.id
          WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (u.username LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)";
    $search_term = "%$search%";
    $params = array_merge($params, [$search_term, $search_term, $search_term]);
}

if (!empty($role_filter)) {
    $query .= " AND u.role = ?";
    $params[] = $role_filter;
}

if (!empty($status_filter)) {
    $is_active = ($status_filter == 'active') ? 1 : 0;
    $query .= " AND u.is_active = ?";
    $params[] = $is_active;
}

$query .= " ORDER BY u.id";
$stmt = $db->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all clinics for dropdowns
$clinics = $db->query("SELECT * FROM clinics WHERE is_active = 1 ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$total_users = count($users);
$total_active = 0;
$total_inactive = 0;
$admin_count = 0;
$admin_dashboard_count = 0;
$doctor_count = 0;
$nurse_count = 0;
$technician_count = 0;
$staff_count = 0;

foreach ($users as $user) {
    if ($user['is_active']) $total_active++;
    else $total_inactive++;
    
    switch ($user['role']) {
        case 'admin': $admin_count++; break;
        case 'admin_dashboard': $admin_dashboard_count++; break;
        case 'doctor': $doctor_count++; break;
        case 'nurse': $nurse_count++; break;
        case 'technician': $technician_count++; break;
        case 'staff': $staff_count++; break;
    }
}

// Get user for edit modal (if edit parameter is set)
$edit_user = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $edit_user = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $current_theme === 'dark' ? 'dark' : ''; ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management | 4ID Station Hospital | Camp Evangelista</title>
             <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
   
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="dashboard.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patients.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patients</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-line text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Monitor</span>
                        </a>
                    </li>
                    <li>
                        <a href="clinic-congestion.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-pie text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Clinic Congestion</span>
                        </a>
                    </li>
                    <li>
                        <a href="reports.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-bar text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Reports</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users-cog text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="login-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-history text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Login/Session Monitor</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5">User Management</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">Manage system users, roles, and account status</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate">System Administrator</p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5">HOSP-HQ COM</p>
                        </div>
                        <div class="p-1.5">
                            <a href="../logout.php" onclick="return confirm('Confirm Dashboard Exit?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Statistics Cards -->
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3 mb-6">
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-sky-50 dark:bg-sky-500/10 rounded-lg flex items-center justify-center text-sky-600 dark:text-sky-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-users"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $total_users; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-0.5">Total</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-emerald-50 dark:bg-emerald-500/10 rounded-lg flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $total_active; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-0.5">Active</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-slate-100 dark:bg-slate-700/50 rounded-lg flex items-center justify-center text-slate-500 dark:text-slate-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-ban"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $total_inactive; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-0.5">Inactive</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-rose-50 dark:bg-rose-500/10 rounded-lg flex items-center justify-center text-rose-600 dark:text-rose-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-crown"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $admin_count; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-0.5">Admin</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-violet-50 dark:bg-violet-500/10 rounded-lg flex items-center justify-center text-violet-600 dark:text-violet-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-tachometer-alt"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $admin_dashboard_count; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-0.5">Dashboard Access</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-sky-50 dark:bg-sky-500/10 rounded-lg flex items-center justify-center text-sky-600 dark:text-sky-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-stethoscope"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $doctor_count; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-0.5">Doctor</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-indigo-50 dark:bg-indigo-500/10 rounded-lg flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-heartbeat"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $nurse_count; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-0.5">Nurse</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-amber-50 dark:bg-amber-500/10 rounded-lg flex items-center justify-center text-amber-600 dark:text-amber-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-flask"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $technician_count + $staff_count; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-0.5">Tech/Staff</div>
            </div>
        </div>

        <!-- Alerts -->
        <?php if (isset($message)): ?>
            <div class="p-4 mb-6 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-between shadow-sm">
                <div class="flex items-center"><i class="fas fa-check-circle mr-3 text-base"></i> <span class="text-xs font-bold uppercase tracking-wide"><?php echo $message; ?></span></div>
                <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-emerald-500"><i class="fas fa-times text-base"></i></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="p-4 mb-6 bg-rose-50 dark:bg-rose-500/10 border border-rose-300 dark:border-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl flex items-center justify-between shadow-sm">
                <div class="flex items-center"><i class="fas fa-exclamation-triangle mr-3 text-base"></i> <span class="text-xs font-bold uppercase tracking-wide"><?php echo $error; ?></span></div>
                <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-rose-500"><i class="fas fa-times text-base"></i></button>
            </div>
        <?php endif; ?>

        <!-- Add User Panel -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-user-plus text-sky-500 text-sm"></i> Add New User
                </h3>
            </div>
            <div class="p-5">
                <form method="POST" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3 items-end">
                    <div class="flex flex-col gap-1.5 lg:col-span-1">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Username</label>
                        <input type="text" name="username" placeholder="Username" required class="w-full px-3 py-2 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-xs transition-all">
                    </div>
                    <div class="flex flex-col gap-1.5 lg:col-span-1">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Password</label>
                        <input type="password" name="password" placeholder="••••••••" required class="w-full px-3 py-2 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-xs transition-all">
                    </div>
                    <div class="flex flex-col gap-1.5 lg:col-span-1">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Full Name</label>
                        <input type="text" name="full_name" placeholder="Full name" required class="w-full px-3 py-2 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-xs transition-all">
                    </div>
                    <div class="flex flex-col gap-1.5 lg:col-span-1">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Email</label>
                        <input type="email" name="email" placeholder="Email (optional)" class="w-full px-3 py-2 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-xs transition-all">
                    </div>
                    <div class="flex flex-col gap-1.5 lg:col-span-1">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Role</label>
                        <select name="role" id="add_role" required class="w-full px-3 py-2 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-xs transition-all">
                            <option value="">Select Role</option>
                            <option value="admin">Administrator</option>
                            <option value="doctor">Doctor</option>
                            <option value="nurse">Nurse</option>
                            <option value="technician">Technician</option>
                            <option value="staff">Staff</option>
                        </select>
                    </div>
                    <div class="flex flex-col gap-1.5 lg:col-span-1">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Access</label>
                        <select name="access" id="add_access" class="w-full px-3 py-2 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-xs transition-all">
                            <option value="">All Clinics</option>
                            <?php foreach ($clinics as $clinic): ?>
                                <option value="<?php echo $clinic['id']; ?>"><?php echo htmlspecialchars($clinic['name']); ?></option>
                            <?php endforeach; ?>
                            <option value="admin_dashboard">Admin Dashboard Access</option>
                        </select>
                    </div>
                    <div class="lg:col-span-6 mt-2 flex justify-end">
                        <button type="submit" name="add_user" class="bg-sky-600 hover:bg-sky-700 text-white border-none px-5 py-2.5 rounded-xl font-bold text-[0.65rem] uppercase tracking-wider transition-all shadow-sm flex items-center gap-2">
                            <i class="fas fa-plus"></i> Add User
                        </button>
                    </div>
                </form>
                <p class="text-[0.65rem] text-slate-400 dark:text-slate-500 mt-3">Choose a clinic for clinic staff, or select Admin Dashboard Access to give the account admin-page access without clinic access. Non-admin users must answer the security question when signing in.</p>
            </div>
        </div>

        <!-- Filter Bar -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-filter text-sky-500 text-sm"></i> Filter Users
                </h3>
                <div class="flex flex-wrap items-center gap-3 w-full md:w-auto">
                    <div class="flex items-center bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-1.5 gap-2 flex-1 md:flex-none">
                        <i class="fas fa-search text-slate-400 text-xs"></i>
                        <input type="text" id="searchInput" placeholder="Search name, username, email..." class="bg-transparent border-none text-slate-900 dark:text-white text-xs outline-none w-full md:w-[180px] focus:ring-0">
                    </div>
                    <select id="roleFilter" class="bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white text-xs rounded-xl px-3 py-2 outline-none focus:border-sky-500">
                        <option value="">All Roles</option>
                        <option value="admin">Admin</option>
                        <option value="doctor">Doctor</option>
                        <option value="nurse">Nurse</option>
                        <option value="technician">Technician</option>
                        <option value="staff">Staff</option>
                    </select>
                    <select id="statusFilter" class="bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white text-xs rounded-xl px-3 py-2 outline-none focus:border-sky-500">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                    <button id="applyFilters" class="bg-sky-600 hover:bg-sky-700 text-white font-bold text-[0.6rem] uppercase tracking-wider px-4 py-2 rounded-xl transition-colors shadow-sm flex items-center gap-1.5">
                        <i class="fas fa-filter"></i> Apply
                    </button>
                    <a href="users.php" class="bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-[0.6rem] font-bold uppercase tracking-wider px-4 py-2 rounded-xl hover:bg-slate-200 transition-colors">
                        Clear
                    </a>
                </div>
            </div>
        </div>

        <!-- Users Table -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-list-ul text-sky-500 text-sm"></i> System Users
                </h3>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($users)): ?>
                    <div class="text-center py-12 text-slate-400 dark:text-slate-500">
                        <i class="fas fa-users-slash text-4xl mb-3 block opacity-50"></i>
                        <p class="text-sm font-medium">No users found</p>
                        <small class="text-xs">Click "Add User" to create a new system user</small>
                    </div>
                <?php else: ?>
                    <table class="w-full text-left border-collapse min-w-[900px]" id="usersTable">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider">
                                <th class="py-3 px-4">ID</th>
                                <th class="py-3 px-4">Username</th>
                                <th class="py-3 px-4">Full Name</th>
                                <th class="py-3 px-4">Email</th>
                                <th class="py-3 px-4">Role</th>
                                <th class="py-3 px-4">Clinic</th>
                                <th class="py-3 px-4">Status</th>
                                <th class="py-3 px-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="usersList">
                            <?php foreach ($users as $user): ?>
                            <?php
                                $role_class = 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300';
                                if ($user['role'] == 'admin') $role_class = 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400';
                                else if ($user['role'] == 'admin_dashboard') $role_class = 'bg-violet-50 dark:bg-violet-500/10 text-violet-600 dark:text-violet-400';
                                else if ($user['role'] == 'doctor') $role_class = 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400';
                                else if ($user['role'] == 'nurse') $role_class = 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400';
                                else if ($user['role'] == 'technician') $role_class = 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400';
                            ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
                                data-id="<?php echo $user['id']; ?>" 
                                data-username="<?php echo strtolower($user['username']); ?>" 
                                data-name="<?php echo strtolower($user['full_name']); ?>" 
                                data-email="<?php echo strtolower($user['email'] ?? ''); ?>" 
                                data-role="<?php echo $user['role']; ?>" 
                                data-clinic-id="<?php echo (int) ($user['clinic_id'] ?? 0); ?>"
                                data-status="<?php echo $user['is_active'] ? 'active' : 'inactive'; ?>">
                                <td class="py-3 px-4 text-xs font-mono text-slate-400 dark:text-slate-500"><?php echo $user['id']; ?></td>
                                <td class="py-3 px-4 text-xs font-mono font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($user['username']); ?></td>
                                <td class="py-3 px-4 text-xs font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td class="py-3 px-4 text-xs text-slate-500 dark:text-slate-400 font-mono"><?php echo htmlspecialchars($user['email'] ?? '—'); ?></td>
                                <td class="py-3 px-4">
                                    <span class="inline-block px-2.5 py-0.5 rounded-full text-[0.6rem] font-bold <?php echo $role_class; ?>">
                                        <?php echo $user['role'] === 'admin_dashboard' ? 'Admin Dashboard Access' : ucfirst($user['role']); ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4 text-xs text-slate-600 dark:text-slate-400">
                                    <?php if ($user['clinic_name']): ?>
                                        <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[0.6rem]">
                                            <i class="fas fa-clinic-medical text-slate-400"></i> <?php echo htmlspecialchars($user['clinic_name']); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[0.6rem] text-slate-500 dark:text-slate-400"><?php echo $user['role'] === 'admin_dashboard' ? 'No Clinic Access' : 'All Clinics'; ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4">
                                    <?php if ($user['is_active']): ?>
                                        <span class="inline-block px-2.5 py-0.5 rounded-full text-[0.6rem] font-bold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"><i class="fas fa-check-circle mr-1"></i> Active</span>
                                    <?php else: ?>
                                        <span class="inline-block px-2.5 py-0.5 rounded-full text-[0.6rem] font-bold bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400"><i class="fas fa-ban mr-1"></i> Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4 text-right">
                                    <div class="flex flex-wrap gap-1.5 justify-end">
                                    <?php if ($user['id'] != 1): ?>
                                        <button onclick="openEditModal(<?php echo $user['id']; ?>)" class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[0.6rem] font-bold bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 hover:bg-amber-500 hover:text-white transition-colors border-none cursor-pointer">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <?php if ($user['is_active']): ?>
                                            <a href="?deactivate=<?php echo $user['id']; ?>" class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[0.6rem] font-bold bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 hover:bg-rose-500 hover:text-white transition-colors" onclick="return confirm('Deactivate this user?')">
                                                <i class="fas fa-pause-circle"></i> Deactivate
                                            </a>
                                        <?php else: ?>
                                            <a href="?activate=<?php echo $user['id']; ?>" class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[0.6rem] font-bold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500 hover:text-white transition-colors" onclick="return confirm('Activate this user?')">
                                                <i class="fas fa-play-circle"></i> Activate
                                            </a>
                                        <?php endif; ?>
                                        <a href="?reset_password=<?php echo $user['id']; ?>" class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[0.6rem] font-bold bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 hover:bg-sky-500 hover:text-white transition-colors" onclick="return confirm('Reset password to \'clinic123\'?')">
                                            <i class="fas fa-key"></i> Reset
                                        </a>
                                        <a href="?delete=<?php echo $user['id']; ?>" class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[0.6rem] font-bold bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 hover:bg-rose-600 hover:text-white transition-colors" onclick="return confirm('Delete this user? Cannot be undone.')">
                                            <i class="fas fa-trash-alt"></i> Delete
                                        </a>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[0.6rem] text-slate-400 dark:text-slate-500 font-bold"><i class="fas fa-shield-alt"></i> Protected</span>
                                    <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Edit User Modal -->
    <div id="editModal" class="hidden fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[2000] items-center justify-center p-4">
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-2xl w-full max-w-[500px] shadow-2xl animate-[modalFadeIn_0.2s_ease] flex flex-col max-h-[90vh]">
            <div class="px-5 py-4 border-b border-slate-200 dark:border-slate-700/60 flex justify-between items-center">
                <h3 class="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
                    <i class="fas fa-user-edit text-sky-500"></i> Edit User
                </h3>
                <button class="text-2xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors cursor-pointer border-none bg-transparent" onclick="closeEditModal()">&times;</button>
            </div>
            <form method="POST" class="flex flex-col flex-1 overflow-hidden">
                <div class="p-5 overflow-y-auto flex flex-col gap-4">
                    <input type="hidden" name="user_id" id="edit_user_id">
                    <input type="hidden" name="edit_user" value="1">
                    
                    <div class="flex flex-col gap-1.5">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Full Name</label>
                        <input type="text" name="full_name" id="edit_full_name" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all">
                    </div>
                    <div class="flex flex-col gap-1.5">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Email</label>
                        <input type="email" name="email" id="edit_email" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all">
                    </div>
                    <div class="flex flex-col gap-1.5">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Role</label>
                        <select name="role" id="edit_role" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all">
                            <option value="admin">Administrator</option>
                            <option value="doctor">Doctor</option>
                            <option value="nurse">Nurse</option>
                            <option value="technician">Technician</option>
                            <option value="staff">Staff</option>
                        </select>
                    </div>
                    <div class="flex flex-col gap-1.5">
                        <label class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">Access</label>
                        <select name="access" id="edit_access" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all">
                            <option value="">All Clinics</option>
                            <?php foreach ($clinics as $clinic): ?>
                                <option value="<?php echo $clinic['id']; ?>"><?php echo htmlspecialchars($clinic['name']); ?></option>
                            <?php endforeach; ?>
                            <option value="admin_dashboard">Admin Dashboard Access</option>
                        </select>
                    </div>
                </div>
                <div class="px-5 py-4 border-t border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 rounded-b-2xl flex justify-end gap-3">
                    <button type="button" class="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-[0.6rem] font-bold uppercase tracking-wider px-5 py-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="bg-sky-600 hover:bg-sky-700 text-white text-[0.6rem] font-bold uppercase tracking-wider px-5 py-2.5 rounded-xl transition-colors shadow-sm">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
    </style>

    <script>
        // Theme Toggle
        var themeToggleBtn = document.getElementById('themeToggleBtn');
        var themeToggleIcon = document.getElementById('themeToggleIcon');
        var htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
        } else {
            htmlElement.classList.remove('dark');
            themeToggleIcon.className = 'fas fa-moon text-base';
        }

        themeToggleBtn.addEventListener('click', function() {
            if (htmlElement.classList.contains('dark')) {
                htmlElement.classList.remove('dark');
                themeToggleIcon.className = 'fas fa-moon text-base';
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.classList.add('dark');
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                localStorage.setItem('theme', 'dark');
            }
        });

        // Profile Dropdown
        var profileMenuBtn = document.getElementById('profileMenuBtn');
        var profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', function() {
                profileDropdown.classList.add('hidden');
            });
        }

        // Live Clock
        function updateDateTime() {
            var now = new Date();
            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
            document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        var mobileMenuBtn = document.getElementById('mobileMenuBtn');
        var sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', function(e) {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // Edit Modal Functions
        function openEditModal(userId) {
            var row = document.querySelector('tr[data-id="' + userId + '"]');
            if (!row) return;

            document.getElementById('edit_user_id').value = userId;
            document.getElementById('edit_full_name').value = row.cells[2]?.innerText.trim() || '';
            document.getElementById('edit_email').value = row.cells[3]?.innerText.trim() || '';
            var roleSelect = document.getElementById('edit_role');
            var accessSelect = document.getElementById('edit_access');
            roleSelect.value = row.dataset.role === 'admin_dashboard' ? 'staff' : (row.dataset.role || 'staff');
            accessSelect.value = row.dataset.role === 'admin_dashboard' ? 'admin_dashboard' : (row.dataset.clinicId || '');
            updateAccessRequirement(roleSelect, accessSelect);
            
            var modal = document.getElementById('editModal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function updateAccessRequirement(roleSelect, accessSelect) {
            var dashboardOnly = accessSelect.value === 'admin_dashboard';
            roleSelect.required = !dashboardOnly;
            accessSelect.required = roleSelect.value !== 'admin' && !dashboardOnly;
            accessSelect.options[0].textContent = roleSelect.value === 'admin' ? 'All Clinics' : 'Select Clinic or Access';
        }

        var addRoleSelect = document.getElementById('add_role');
        var addAccessSelect = document.getElementById('add_access');
        var editRoleSelect = document.getElementById('edit_role');
        var editAccessSelect = document.getElementById('edit_access');

        addRoleSelect.addEventListener('change', function() {
            updateAccessRequirement(addRoleSelect, addAccessSelect);
        });
        addAccessSelect.addEventListener('change', function() {
            updateAccessRequirement(addRoleSelect, addAccessSelect);
        });
        editRoleSelect.addEventListener('change', function() {
            updateAccessRequirement(editRoleSelect, editAccessSelect);
        });
        editAccessSelect.addEventListener('change', function() {
            updateAccessRequirement(editRoleSelect, editAccessSelect);
        });
        updateAccessRequirement(addRoleSelect, addAccessSelect);

        function closeEditModal() {
            var modal = document.getElementById('editModal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }

        window.onclick = function(event) {
            var modal = document.getElementById('editModal');
            if (event.target === modal) {
                closeEditModal();
            }
        }

        // Filters
        var searchInput = document.getElementById('searchInput');
        var roleFilter = document.getElementById('roleFilter');
        var statusFilter = document.getElementById('statusFilter');
        var applyFiltersBtn = document.getElementById('applyFilters');
        
        function applyFilters() {
            var searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
            var roleTerm = roleFilter ? roleFilter.value : '';
            var statusTerm = statusFilter ? statusFilter.value : '';
            
            var rows = document.querySelectorAll('#usersList tr');
            rows.forEach(function(row) {
                var username = row.dataset.username || '';
                var name = row.dataset.name || '';
                var email = row.dataset.email || '';
                var role = row.dataset.role || '';
                var status = row.dataset.status || '';
                
                var matchSearch = true;
                if (searchTerm) {
                    matchSearch = username.includes(searchTerm) || name.includes(searchTerm) || email.includes(searchTerm);
                }
                
                var matchRole = true;
                if (roleTerm) {
                    matchRole = (role === roleTerm);
                }
                
                var matchStatus = true;
                if (statusTerm) {
                    matchStatus = (status === statusTerm);
                }
                
                if (matchSearch && matchRole && matchStatus) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        if (applyFiltersBtn) {
            applyFiltersBtn.addEventListener('click', applyFilters);
        }
        if (searchInput) {
            searchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') applyFilters();
            });
        }

        // Auto Logout
        var INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        var inactivityTimer;
        var warningTimer;
        var warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(function(err) { console.log('Heartbeat failed:', err); });
        }

        function logoutUser() {
            var logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = '<div class="fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4"><div class="bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700"><i class="fas fa-clock text-5xl text-rose-500 mb-5"></i><h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">Session Expired</h3><p class="text-slate-500 dark:text-slate-400 text-sm mb-5">You have been logged out due to inactivity.</p><div class="w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden"><div class="bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full"></div></div></div></div>';
            document.body.appendChild(logoutMsg);
            setTimeout(function() { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            var modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = '<div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4"><div class="bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in"><i class="fas fa-hourglass-half text-5xl text-amber-500 mb-4"></i><h3 class="text-lg font-bold text-slate-900 dark:text-white mb-1">Session About to Expire</h3><p class="text-slate-500 dark:text-slate-400 text-sm mb-3">You will be logged out due to inactivity.</p><p id="countdownText" class="text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4">2:00</p><button onclick="keepSessionAlive()" class="w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm"><i class="fas fa-mouse-pointer mr-1.5"></i> Keep Session Active</button></div></div>';
            document.body.appendChild(modal);
            
            var secondsLeft = 120;
            var countdownElement = document.getElementById('countdownText');
            var countdownInterval = setInterval(function() {
                secondsLeft--;
                var minutes = Math.floor(secondsLeft / 60);
                var seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = minutes + ':' + (seconds.toString().padStart(2, '0'));
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(function() { resetInactivityTimer(); })
                .catch(function() { resetInactivityTimer(); });
        }

        function hideWarningModal() {
            var modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        var events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(function(event) {
            document.addEventListener(event, resetInactivityTimer, false);
        });

        resetInactivityTimer();
        setInterval(function() {
            if (!warningShown) sendHeartbeat();
        }, 5 * 60 * 1000);

        // Auto-dismiss alerts
        setTimeout(function() {
            document.querySelectorAll('.alert').forEach(function(alert) {
                alert.style.transition = 'all 0.4s ease-in-out';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-10px)';
                setTimeout(function() { alert.remove(); }, 400);
            });
        }, 5000);
    </script>

</body>
</html>