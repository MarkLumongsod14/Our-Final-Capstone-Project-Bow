<?php
// continue-journey.php - Continue patient journey

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';
require_once dirname(__DIR__) . '/includes/SessionManager.php';

session_start();

$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);
$sessionManager = new SessionManager($db);
$logClinicAssignment = function ($result, $patient_id) use ($sessionManager) {
    $action = 'Assigned Patient ID ' . (int) $patient_id . ' to Clinic ID ' . (int) $result['clinic_id'] . ' by continuing journey';
    if (isset($_SESSION['user_id'])) {
        $sessionManager->logActivity($action);
    } else {
        $sessionManager->logUnauthenticatedActivity($action);
    }
};

$token = isset($_GET['token']) ? $_GET['token'] : '';

if (empty($token)) {
    header('Location: track-queue.php?error=No token provided');
    exit();
}

// Get patient info by token
$query = "SELECT q.*, p.id as patient_id, p.first_name, p.last_name, p.patient_type
          FROM queue_entries q
          JOIN patients p ON q.patient_id = p.id
          WHERE q.transaction_token = :token
          ORDER BY q.registered_at ASC LIMIT 1";
$stmt = $db->prepare($query);
$stmt->bindParam(':token', $token);
$stmt->execute();
$queue_info = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$queue_info) {
    header('Location: track-queue.php?error=Invalid token');
    exit();
}

$patient_id = $queue_info['patient_id'];

// Serialize continuation requests for this patient so one click can create only one active clinic entry.
$db->beginTransaction();
$patient_lock = $db->prepare('SELECT id FROM patients WHERE id = ? FOR UPDATE');
$patient_lock->execute([$patient_id]);

$active_check = $db->prepare("SELECT id, clinic_id FROM queue_entries
                                                            WHERE patient_id = ?
                                                                AND DATE(registered_at) = CURDATE()
                                                                AND status IN ('waiting', 'called', 'in-progress')
                                                            LIMIT 1");
$active_check->execute([$patient_id]);
$active_entry = $active_check->fetch(PDO::FETCH_ASSOC);

if ($active_entry) {
        $db->commit();
        header('Location: track-queue.php?token=' . urlencode($token) . '&message=Already+queued+for+next+clinic');
        exit();
}

// Get journey
$journey_query = "SELECT * FROM patient_journey 
                  WHERE patient_id = :patient_id
                  AND DATE(created_at) = DATE(:registered_at)
                  AND status = 'pending'
                  ORDER BY id DESC LIMIT 1";
$journey_stmt = $db->prepare($journey_query);
$journey_stmt->bindParam(':patient_id', $patient_id);
$journey_stmt->bindParam(':registered_at', $queue_info['registered_at']);
$journey_stmt->execute();
$journey = $journey_stmt->fetch(PDO::FETCH_ASSOC);

if (!$journey) {
    $db->rollBack();
    header('Location: track-queue.php?token=' . urlencode($token) . '&error=No+pending+journey');
    exit();
}

// Military patients follow the clinic sequence saved for this visit.
if ($queue_info['patient_type'] === 'military') {
    $result = $queueManager->queueMilitaryForNextClinic(
        $patient_id,
        $queue_info['clinic_id'],
        $queue_info['transaction_token']
    );

    if ($result['success']) {
        $logClinicAssignment($result, $patient_id);
        $db->commit();
        header('Location: track-queue.php?token=' . urlencode($token) . '&message=Queued+for+next+clinic');
    } elseif (!empty($result['all_completed'])) {
        $db->commit();
        header('Location: track-queue.php?token=' . urlencode($token) . '&message=Journey+Complete');
    } else {
        $db->rollBack();
        header('Location: track-queue.php?token=' . urlencode($token) . '&error=' . urlencode($result['error']));
    }
    exit();
}

// Get next clinic for dependent patients.
$clinics = json_decode($journey['clinic_sequence'], true);
$current_index = $journey['current_index'];

if ($current_index >= count($clinics)) {
    // All clinics completed
    $update = "UPDATE patient_journey SET status = 'completed' WHERE id = :journey_id";
    $update_stmt = $db->prepare($update);
    $update_stmt->bindParam(':journey_id', $journey['id']);
    $update_stmt->execute();
    $db->commit();
    
    header('Location: track-queue.php?token=' . urlencode($token) . '&message=Journey+Complete');
    exit();
}

$next_clinic_id = $clinics[$current_index];

// Queue patient for next clinic
$result = $queueManager->addToNextClinic($patient_id, $next_clinic_id, $queue_info['transaction_token']);

if ($result['success']) {
    $logClinicAssignment($result, $patient_id);
    // Advance journey
    $update = "UPDATE patient_journey SET current_index = current_index + 1 WHERE id = :journey_id";
    $update_stmt = $db->prepare($update);
    $update_stmt->bindParam(':journey_id', $journey['id']);
    $update_stmt->execute();
    $db->commit();
    
    header('Location: track-queue.php?token=' . urlencode($token) . '&message=Queued+for+next+clinic');
} else {
    $db->rollBack();
    header('Location: track-queue.php?token=' . urlencode($token) . '&error=' . urlencode($result['error']));
}
exit();
?>