<?php
// patient-portal/print-ticket.php - Print Queue Ticket
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';

$database = new Database();
$db = $database->getConnection();

$transaction_token = isset($_GET['token']) ? $_GET['token'] : '';

// Get queue entry details
$query = "SELECT q.*, p.first_name, p.last_name, p.mrn, p.patient_type, p.is_pwd, p.is_senior, p.is_pregnant, c.name as clinic_name
          FROM queue_entries q
          JOIN patients p ON q.patient_id = p.id
          JOIN clinics c ON q.clinic_id = c.id
          WHERE q.transaction_token = :token";

$stmt = $db->prepare($query);
$stmt->bindParam(':token', $transaction_token);
$stmt->execute();
$queue = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$queue) {
    die("Invalid ticket request.");
}

// Generate QR code URL
$tracking_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/track-queue.php?token=" . urlencode($queue['transaction_token']);
$qr_code_url = "https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=" . urlencode($tracking_url);

// Determine priority display
$priority_display = [
    'PR1' => ['text' => 'MILITARY', 'bg' => '#FF6F61', 'color' => 'white'],
    'PR2' => ['text' => 'PRIORITY', 'bg' => '#FFB84D', 'color' => '#333'],
    'PR3' => ['text' => 'REGULAR', 'bg' => '#A4D1B1', 'color' => '#333']
];
$p_info = $priority_display[$queue['priority_level']] ?? $priority_display['PR3'];

// Check if dark mode is set
$is_dark = isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark';
if (!isset($_COOKIE['theme'])) {
    $is_dark = true; // Default to dark
}
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $is_dark ? 'dark' : ''; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Queue Ticket | Camp Evangelista Hospital</title>
              <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
  
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        /* Thermal Printer Optimized - 80mm width */
        @page {
            size: 80mm auto;
            margin: 0;
        }
        
        @media print {
            body { 
                margin: 0; 
                padding: 0;
                background: white !important;
            }
            .no-print { 
                display: none !important; 
            }
            .ticket {
                box-shadow: none;
                border: none;
                margin: 0;
                padding: 8px;
                width: 100%;
                background: white !important;
            }
            .ticket-header {
                padding: 8px 0 !important;
                background: #1a3a5c !important;
            }
            .queue-number {
                font-size: 28px !important;
                padding: 8px !important;
                color: #1a3a5c !important;
                background: white !important;
            }
            .qr-code img {
                width: 80px !important;
                height: 80px !important;
            }
            .ticket-section {
                border-bottom-color: #e0e0e0 !important;
            }
            .info-label { color: #666 !important; }
            .info-value { color: #333 !important; }
            .token-section { background: #f0f7ff !important; }
            .token-value { background: white !important; color: #333 !important; }
            .ticket-footer { background: #f5f5f5 !important; color: #999 !important; }
            .watermark { color: #ccc !important; }
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Plus Jakarta Sans', 'Segoe UI', sans-serif;
            background: #e0e0e0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
            transition: background-color 0.3s ease;
        }

        html.dark body {
            background: #0f172a;
        }
        
        .ticket {
            max-width: 350px;
            width: 100%;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow: hidden;
            font-size: 11px;
            transition: background 0.3s ease;
        }

        html.dark .ticket {
            background: #1e293b;
            box-shadow: 0 4px 20px rgba(0,0,0,0.4);
        }
        
        .ticket-section {
            padding: 10px 12px;
            border-bottom: 1px dashed #e0e0e0;
            transition: border-color 0.3s ease;
        }

        html.dark .ticket-section {
            border-bottom-color: #334155;
        }
        
        .ticket-section:last-child {
            border-bottom: none;
        }
        
        /* Header */
        .ticket-header {
            text-align: center;
            background: #0f172a;
            color: white;
            padding: 12px;
            transition: background 0.3s ease;
        }

        html.dark .ticket-header {
            background: #0f172a;
        }
        
        .hospital-name {
            font-size: 14px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        
        .hospital-address {
            font-size: 8px;
            opacity: 0.8;
            margin-top: 2px;
        }
        
        .ticket-type {
            background: rgba(255,255,255,0.2);
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 9px;
            margin-top: 6px;
            font-weight: 600;
        }
        
        /* Queue Number */
        .queue-section {
            text-align: center;
            padding: 16px 12px !important;
            background: #f8f9fa;
            transition: background 0.3s ease;
        }

        html.dark .queue-section {
            background: #1e293b;
        }
        
        .queue-label {
            font-size: 9px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #666;
            transition: color 0.3s ease;
        }

        html.dark .queue-label {
            color: #94a3b8;
        }
        
        .queue-number {
            font-size: 32px;
            font-weight: 800;
            font-family: 'JetBrains Mono', 'Courier New', monospace;
            letter-spacing: 2px;
            color: #1a3a5c;
            background: white;
            padding: 8px 16px;
            border-radius: 8px;
            display: inline-block;
            margin-top: 6px;
            border: 1px solid #e0e0e0;
            transition: all 0.3s ease;
        }

        html.dark .queue-number {
            color: #38bdf8;
            background: #0f172a;
            border-color: #334155;
        }
        
        /* Priority Badge */
        .priority-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 9px;
            font-weight: 700;
            margin-top: 8px;
        }
        
        /* Token Section */
        .token-section {
            background: #f0f7ff;
            text-align: center;
            transition: background 0.3s ease;
        }

        html.dark .token-section {
            background: #1a2744;
        }
        
        .token-label {
            font-size: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #4A90E2;
            transition: color 0.3s ease;
        }

        html.dark .token-label {
            color: #60a5fa;
        }
        
        .token-value {
            font-size: 11px;
            font-weight: 700;
            font-family: 'JetBrains Mono', 'Courier New', monospace;
            background: white;
            padding: 6px 10px;
            border-radius: 6px;
            display: inline-block;
            margin-top: 6px;
            border: 1px solid #d0e0f0;
            word-break: break-all;
            transition: all 0.3s ease;
        }

        html.dark .token-value {
            background: #0f172a;
            border-color: #334155;
            color: #e2e8f0;
        }
        
        /* Info Rows */
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 5px 0;
            border-bottom: 1px dotted #f0f0f0;
            transition: border-color 0.3s ease;
        }

        html.dark .info-row {
            border-bottom-color: #334155;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .info-label {
            color: #666;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        html.dark .info-label {
            color: #94a3b8;
        }
        
        .info-value {
            font-weight: 600;
            color: #333;
            text-align: right;
            transition: color 0.3s ease;
        }

        html.dark .info-value {
            color: #e2e8f0;
        }
        
        /* QR Section */
        .qr-section {
            text-align: center;
            background: white;
            transition: background 0.3s ease;
        }

        html.dark .qr-section {
            background: #1e293b;
        }
        
        .qr-code {
            display: inline-block;
            margin: 5px 0;
        }
        
        .qr-code img {
            width: 90px;
            height: 90px;
            border: 1px solid #e0e0e0;
            padding: 4px;
            background: white;
            transition: border-color 0.3s ease;
        }

        html.dark .qr-code img {
            border-color: #334155;
        }
        
        .tracking-note {
            font-size: 8px;
            color: #888;
            margin-top: 5px;
            transition: color 0.3s ease;
        }

        html.dark .tracking-note {
            color: #94a3b8;
        }
        
        /* Footer */
        .ticket-footer {
            text-align: center;
            background: #f5f5f5;
            font-size: 8px;
            color: #999;
            padding: 10px !important;
            transition: all 0.3s ease;
        }

        html.dark .ticket-footer {
            background: #1e293b;
            color: #64748b;
        }
        
        .watermark {
            font-size: 7px;
            color: #ccc;
            text-align: center;
            margin-top: 8px;
            transition: color 0.3s ease;
        }

        html.dark .watermark {
            color: #475569;
        }
        
        /* Buttons */
        .btn-print {
            flex: 1;
            background: #38bdf8;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 40px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
        }
        
        .btn-print:hover {
            background: #0ea5e9;
            transform: translateY(-1px);
        }
        
        .btn-close {
            flex: 1;
            background: #e2e8f0;
            color: #1e293b;
            border: none;
            padding: 12px;
            border-radius: 40px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
        }

        html.dark .btn-close {
            background: #334155;
            color: #e2e8f0;
        }
        
        .btn-close:hover {
            background: #cbd5e1;
        }

        html.dark .btn-close:hover {
            background: #475569;
        }
        
        .button-group {
            display: flex;
            gap: 12px;
            margin-top: 16px;
            max-width: 350px;
        }

        /* Dark mode toggle button */
        .theme-toggle {
            position: fixed;
            top: 16px;
            right: 16px;
            background: #1e293b;
            color: #e2e8f0;
            border: 1px solid #334155;
            border-radius: 50%;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 18px;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        html:not(.dark) .theme-toggle {
            background: #ffffff;
            color: #1e293b;
            border-color: #e2e8f0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .theme-toggle:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <!-- Theme Toggle -->
    <button class="theme-toggle no-print" onclick="toggleTheme()" title="Toggle Dark Mode">
        <i class="fas <?php echo $is_dark ? 'fa-sun' : 'fa-moon'; ?>"></i>
    </button>

    <div>
        <!-- Ticket -->
        <div class="ticket">
            <!-- Header -->
            <div class="ticket-header">
                <div class="hospital-name">4ID STATION HOSPITAL</div>
                <div class="hospital-address">Camp Evangelista, Cagayan de Oro City</div>
                <div class="ticket-type">OUTPATIENT QUEUE TICKET</div>
            </div>
            
            <!-- Queue Number -->
            <div class="ticket-section queue-section">
                <div class="queue-label">YOUR QUEUE NUMBER</div>
                <div class="queue-number"><?php echo htmlspecialchars($queue['queue_number']); ?></div>
                <div>
                    <span class="priority-badge" style="background: <?php echo $p_info['bg']; ?>; color: <?php echo $p_info['color']; ?>;">
                        <?php echo $p_info['text']; ?>
                    </span>
                </div>
            </div>
            
            <!-- Transaction Token -->
            <div class="ticket-section token-section">
                <div class="token-label">
                    <i class="fas fa-key"></i> PRIVATE TRACKING TOKEN
                </div>
                <div class="token-value"><?php echo htmlspecialchars($queue['transaction_token']); ?></div>
                <div style="font-size: 7px; margin-top: 4px; color: #666;">
                    Use this to track your queue - Do not share publicly
                </div>
            </div>
            
            <!-- Patient Information -->
            <div class="ticket-section">
                <div class="info-row">
                    <span class="info-label">Patient Name</span>
                    <span class="info-value"><?php echo htmlspecialchars($queue['last_name'] . ', ' . $queue['first_name']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">MRN</span>
                    <span class="info-value"><?php echo htmlspecialchars($queue['mrn']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Clinic</span>
                    <span class="info-value"><?php echo htmlspecialchars($queue['clinic_name']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Patient Type</span>
                    <span class="info-value"><?php echo ucfirst($queue['patient_type']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Date</span>
                    <span class="info-value"><?php echo date('M d, Y', strtotime($queue['registered_at'])); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Time</span>
                    <span class="info-value"><?php echo date('h:i A', strtotime($queue['registered_at'])); ?></span>
                </div>
            </div>
            
            <!-- QR Code Section -->
            <div class="ticket-section qr-section">
                <div class="qr-code">
                    <img src="<?php echo $qr_code_url; ?>" alt="QR Code">
                </div>
                <div class="tracking-note">
                    <i class="fas fa-qrcode"></i> Scan with your phone to track your queue status
                </div>
                <div style="font-size: 7px; margin-top: 4px; color: #888;">
                    or visit: patient-portal/track-queue.php
                </div>
            </div>
            
            <!-- Footer Instructions -->
            <div class="ticket-section ticket-footer">
                <div><i class="fas fa-bell"></i> Please wait for your number to be called</div>
                <div style="margin-top: 4px;"><i class="fas fa-phone-alt"></i> For concerns: (088) 123-4567</div>
                <div class="watermark">Ticket #: <?php echo date('YmdHis'); ?></div>
            </div>
        </div>
        
        <!-- Screen Buttons -->
        <div class="no-print">
            <div class="button-group">
                <button onclick="window.print()" class="btn-print">
                    <i class="fas fa-print"></i> Print Ticket
                </button>
                <button onclick="window.location.href='self-register.php'" class="btn-close">
                    <i class="fas fa-user-plus"></i> New Registration
                </button>
            </div>
        </div>
    </div>
    
    <script>
        // Theme toggle
        function toggleTheme() {
            var html = document.documentElement;
            var isDark = html.classList.contains('dark');
            
            if (isDark) {
                html.classList.remove('dark');
                document.cookie = "theme=light; path=/; max-age=31536000";
                document.querySelector('.theme-toggle i').className = 'fas fa-moon';
            } else {
                html.classList.add('dark');
                document.cookie = "theme=dark; path=/; max-age=31536000";
                document.querySelector('.theme-toggle i').className = 'fas fa-sun';
            }
        }

        // Auto open print dialog when page loads
        setTimeout(function() {
            window.print();
        }, 500);
    </script>
</body>
</html>