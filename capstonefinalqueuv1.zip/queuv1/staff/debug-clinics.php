<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

$database = new Database();
$db = $database->getConnection();

echo "<h2>Testing QueueManager</h2>";

try {
    $queueManager = new QueueManager($db);
    echo "<p style='color:green;'>✅ QueueManager loaded successfully!</p>";
    
    // Test if methods exist
    $methods = get_class_methods('QueueManager');
    echo "<h3>Methods:</h3>";
    echo "<ul>";
    foreach ($methods as $method) {
        echo "<li>$method</li>";
    }
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<pre>";
    echo $e->getTraceAsString();
    echo "</pre>";
}
?>