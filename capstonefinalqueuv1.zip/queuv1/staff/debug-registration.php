<?php
// staff/debug-register.php - Debug registration flow

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

echo "<h2>🔍 Debug - Registration Flow</h2>";

// Check patients in database
$query = "SELECT id, first_name, last_name, patient_type FROM patients LIMIT 5";
$stmt = $db->prepare($query);
$stmt->execute();
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Patients in database:</h3>";
echo "<table border='1' cellpadding='8'>";
echo "<tr><th>ID</th><th>Name</th><th>Type</th></tr>";
foreach ($patients as $p) {
    echo "<tr>";
    echo "<td>{$p['id']}</td>";
    echo "<td>{$p['first_name']} {$p['last_name']}</td>";
    echo "<td>{$p['patient_type']}</td>";
    echo "</tr>";
}
echo "</table>";

// Check queue entries for today
$query = "SELECT q.*, c.name as clinic_name 
          FROM queue_entries q
          JOIN clinics c ON q.clinic_id = c.id
          WHERE DATE(q.registered_at) = CURDATE()";
$stmt = $db->prepare($query);
$stmt->execute();
$entries = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Queue entries today:</h3>";
if (empty($entries)) {
    echo "<p style='color: orange;'>No queue entries found for today.</p>";
} else {
    echo "<table border='1' cellpadding='8'>";
    echo "<tr><th>ID</th><th>Queue #</th><th>Patient ID</th><th>Clinic</th><th>Status</th></tr>";
    foreach ($entries as $e) {
        echo "<tr>";
        echo "<td>{$e['id']}</td>";
        echo "<td>{$e['queue_number']}</td>";
        echo "<td>{$e['patient_id']}</td>";
        echo "<td>{$e['clinic_name']}</td>";
        echo "<td>{$e['status']}</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Check patient_journey table
$query = "SELECT * FROM patient_journey WHERE DATE(created_at) = CURDATE()";
$stmt = $db->prepare($query);
$stmt->execute();
$journeys = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Patient journeys today:</h3>";
if (empty($journeys)) {
    echo "<p style='color: orange;'>No patient journeys found for today.</p>";
} else {
    echo "<pre>";
    print_r($journeys);
    echo "</pre>";
}

// Simulate a new registration for a military patient
echo "<h3>Simulate Military Registration:</h3>";
$military = $patients[0] ?? null;
if ($military && $military['patient_type'] == 'military') {
    echo "<p>Using patient: <strong>{$military['first_name']} {$military['last_name']}</strong> (ID: {$military['id']})</p>";
    
    // Add to Registration (ID: 1)
    $result = $queueManager->addToQueue($military['id'], 1);
    echo "<pre>";
    print_r($result);
    echo "</pre>";
} else {
    echo "<p style='color: red;'>No military patient found. Please register a military patient first.</p>";
}