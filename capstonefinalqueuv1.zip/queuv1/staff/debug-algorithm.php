<?php
// staff/debug-algorithm.php - Deep debug of least congested algorithm

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

echo "<h2>🔍 Deep Debug - Least Congested Algorithm</h2>";

// Get all clinics with counts
echo "<h3>1. All Clinics with Current Load:</h3>";
$clinics = $queueManager->getClinicsWithPatientCount();
echo "<table border='1' cellpadding='8' style='border-collapse: collapse;'>";
echo "<tr><th>ID</th><th>Name</th><th>Active Patients</th><th>Waiting</th><th>In Progress</th><th>Called</th><th>Status</th></tr>";
foreach ($clinics as $c) {
    $is_full = $c['active_patients'] >= 5;
    echo "<tr>";
    echo "<td>{$c['id']}</td>";
    echo "<td><strong>{$c['name']}</strong></td>";
    echo "<td style='text-align:center;'><strong>{$c['active_patients']}</strong></td>";
    echo "<td style='text-align:center;'>{$c['waiting_count']}</td>";
    echo "<td style='text-align:center;'>{$c['in_progress_count']}</td>";
    echo "<td style='text-align:center;'>{$c['called_count']}</td>";
    echo "<td style='text-align:center;'>" . ($is_full ? '🔴 FULL' : '🟢 Available') . "</td>";
    echo "</tr>";
}
echo "</table>";

// Test getLeastCongestedAvailableClinic
echo "<h3>2. getLeastCongestedAvailableClinic() Result:</h3>";
$least = $queueManager->getLeastCongestedAvailableClinic();
if ($least) {
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 8px; border: 2px solid #28a745;'>";
    echo "<p style='font-size: 18px;'><strong>✅ SELECTED:</strong> <span style='color: #006400;'>{$least['name']}</span> (ID: {$least['id']})</p>";
    echo "<p><strong>Active Patients:</strong> {$least['active_patients']}</p>";
    echo "<p><strong>Waiting:</strong> {$least['waiting_count']}</p>";
    echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 4px;'>";
    print_r($least);
    echo "</pre>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 8px; border: 2px solid #dc3545;'>";
    echo "<p style='color: red;'><strong>❌ No clinic found!</strong></p>";
    echo "</div>";
}

// Test queueMilitaryForNextClinic simulation
echo "<h3>3. Simulate queueMilitaryForNextClinic() for a patient:</h3>";
// Get a military patient
$military_query = "SELECT id, first_name, last_name FROM patients WHERE patient_type = 'military' LIMIT 1";
$military_stmt = $db->prepare($military_query);
$military_stmt->execute();
$military = $military_stmt->fetch(PDO::FETCH_ASSOC);

if ($military) {
    echo "<p>Using patient: <strong>{$military['first_name']} {$military['last_name']}</strong> (ID: {$military['id']})</p>";
    
    // Get a clinic to simulate completion
    $clinic_query = "SELECT id FROM clinics WHERE id != 1 AND is_active = 1 LIMIT 1";
    $clinic_stmt = $db->prepare($clinic_query);
    $clinic_stmt->execute();
    $clinic = $clinic_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($clinic) {
        echo "<p>Simulating completion at clinic: <strong>ID {$clinic['id']}</strong></p>";
        $result = $queueManager->queueMilitaryForNextClinic($military['id'], $clinic['id']);
        echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 4px;'>";
        print_r($result);
        echo "</pre>";
    }
} else {
    echo "<p style='color: orange;'>No military patient found. Please register a military patient first.</p>";
}

// Test queueDependentForNextClinic simulation
echo "<h3>4. Simulate queueDependentForNextClinic() for a patient:</h3>";
$dependent_query = "SELECT id, first_name, last_name FROM patients WHERE patient_type = 'dependent' LIMIT 1";
$dependent_stmt = $db->prepare($dependent_query);
$dependent_stmt->execute();
$dependent = $dependent_stmt->fetch(PDO::FETCH_ASSOC);

if ($dependent) {
    echo "<p>Using patient: <strong>{$dependent['first_name']} {$dependent['last_name']}</strong> (ID: {$dependent['id']})</p>";
    
    $clinic_query = "SELECT id FROM clinics WHERE id != 1 AND is_active = 1 LIMIT 1";
    $clinic_stmt = $db->prepare($clinic_query);
    $clinic_stmt->execute();
    $clinic = $clinic_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($clinic) {
        echo "<p>Simulating completion at clinic: <strong>ID {$clinic['id']}</strong></p>";
        $result = $queueManager->queueDependentForNextClinic($dependent['id'], $clinic['id']);
        echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 4px;'>";
        print_r($result);
        echo "</pre>";
    }
} else {
    echo "<p style='color: orange;'>No dependent patient found. Please register a dependent patient first.</p>";
}

echo "<h3>5. QueueManager Settings:</h3>";
$reflection = new ReflectionClass($queueManager);
$properties = $reflection->getProperties(ReflectionProperty::IS_PRIVATE);
foreach ($properties as $prop) {
    $prop->setAccessible(true);
    $value = $prop->getValue($queueManager);
    echo "<p><strong>{$prop->getName()}:</strong> " . print_r($value, true) . "</p>";
}
?>