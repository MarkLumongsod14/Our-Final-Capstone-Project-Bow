<?php
// staff/submit-result.php - Submit Clinic Results
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

session_start();
require_once dirname(__DIR__) . '/includes/UnifiedSession.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

$allowed_staff_roles = ['admin', 'doctor', 'nurse', 'technician', 'staff'];
if (!in_array($_SESSION['role'], $allowed_staff_roles)) {
    header('Location: ../unauthorized.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

require_once dirname(__DIR__) . '/includes/SessionManager.php';
$sessionManager = new SessionManager($db);
if (!$sessionManager->checkTimeout()) {
    exit();
}

$access_stmt = $db->prepare("SELECT role, clinic_id FROM users WHERE id = ?");
$access_stmt->execute([$_SESSION['user_id']]);
$account_access = $access_stmt->fetch(PDO::FETCH_ASSOC);
if (!$account_access || !in_array($account_access['role'], $allowed_staff_roles, true)) {
    header('Location: ../unauthorized.php');
    exit();
}
$_SESSION['role'] = $account_access['role'];
$_SESSION['clinic_id'] = $account_access['clinic_id'];
$account_role = (string) $account_access['role'];
$assigned_clinic_id = (int) ($account_access['clinic_id'] ?? 0);

$clinic_id = isset($_GET['clinic_id']) ? (int)$_GET['clinic_id'] : ($_SESSION['clinic_id'] ?? 0);
$queue_entry_id = isset($_GET['queue_id']) ? (int)$_GET['queue_id'] : 0;
$message = '';
$error = '';

// Get patient and queue info
$queue_query = "SELECT q.*, p.first_name, p.last_name, p.mrn, p.date_of_birth, p.patient_type
                FROM queue_entries q
                JOIN patients p ON q.patient_id = p.id
                WHERE q.id = :queue_id";
$queue_stmt = $db->prepare($queue_query);
$queue_stmt->bindParam(':queue_id', $queue_entry_id);
$queue_stmt->execute();
$queue_entry = $queue_stmt->fetch(PDO::FETCH_ASSOC);

if (!$queue_entry) {
    die("Invalid queue entry");
}
$queue_clinic_id = (int) $queue_entry['clinic_id'];
if ($account_role !== 'admin' && $assigned_clinic_id !== $queue_clinic_id) {
    http_response_code(403);
    exit(
        'You do not have permission to access this clinic. '
        . 'Your account is assigned to clinic ID ' . ($assigned_clinic_id > 0 ? $assigned_clinic_id : 'none')
        . ', but this queue entry belongs to clinic ID ' . $queue_clinic_id . '.'
    );
}
// Get clinic info from the queue entry's verified clinic.
$clinic_query = "SELECT * FROM clinics WHERE id = :id";
$clinic_stmt = $db->prepare($clinic_query);
$clinic_stmt->bindParam(':id', $queue_clinic_id);
$clinic_stmt->execute();
$clinic = $clinic_stmt->fetch(PDO::FETCH_ASSOC);
if (!$clinic) {
    http_response_code(404);
    exit('Clinic not found.');
}
$clinic_id = $queue_clinic_id;
$was_already_completed = $queue_entry['status'] === 'completed';

// Get result templates for this clinic
$template_query = "SELECT * FROM result_templates WHERE clinic_id = :clinic_id ORDER BY sort_order";
$template_stmt = $db->prepare($template_query);
$template_stmt->bindParam(':clinic_id', $clinic_id);
$template_stmt->execute();
$templates = $template_stmt->fetchAll(PDO::FETCH_ASSOC);

// Check if result already exists
$existing_query = "SELECT * FROM clinic_results 
                   WHERE queue_entry_id = :queue_id AND clinic_id = :clinic_id";
$existing_stmt = $db->prepare($existing_query);
$existing_stmt->bindParam(':queue_id', $queue_entry_id);
$existing_stmt->bindParam(':clinic_id', $clinic_id);
$existing_stmt->execute();
$existing_result = $existing_stmt->fetch(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_result'])) {
    $result_data = [];
    $is_drug_test_clinic = $clinic && $clinic['name'] === 'Drug Test';
    $findings = $is_drug_test_clinic ? '' : ($_POST['findings'] ?? '');
    $recommendations = $is_drug_test_clinic ? '' : ($_POST['recommendations'] ?? '');
    
    foreach ($templates as $template) {
        $field_name = $template['field_name'];
        $result_data[$field_name] = $_POST[$field_name] ?? '';
    }
    
    $result_data_json = json_encode($result_data);
    $submitted_by = $_SESSION['user_id'];
    
    try {
        // Start transaction
        $db->beginTransaction();
        
        // Save or update result
        if ($existing_result) {
            $update_query = "UPDATE clinic_results 
                             SET result_data = :result_data, 
                                 findings = :findings, 
                                 recommendations = :recommendations,
                                 status = 'completed',
                                 submitted_by = :submitted_by,
                                 submitted_at = NOW()
                             WHERE id = :id";
            $update_stmt = $db->prepare($update_query);
            $update_stmt->bindParam(':result_data', $result_data_json);
            $update_stmt->bindParam(':findings', $findings);
            $update_stmt->bindParam(':recommendations', $recommendations);
            $update_stmt->bindParam(':submitted_by', $submitted_by);
            $update_stmt->bindParam(':id', $existing_result['id']);
            $update_stmt->execute();
        } else {
            $insert_query = "INSERT INTO clinic_results 
                             (queue_entry_id, patient_id, clinic_id, result_data, 
                              findings, recommendations, status, submitted_by) 
                             VALUES 
                             (:queue_id, :patient_id, :clinic_id, :result_data, 
                              :findings, :recommendations, 'completed', :submitted_by)";
            $insert_stmt = $db->prepare($insert_query);
            $insert_stmt->bindParam(':queue_id', $queue_entry_id);
            $insert_stmt->bindParam(':patient_id', $queue_entry['patient_id']);
            $insert_stmt->bindParam(':clinic_id', $clinic_id);
            $insert_stmt->bindParam(':result_data', $result_data_json);
            $insert_stmt->bindParam(':findings', $findings);
            $insert_stmt->bindParam(':recommendations', $recommendations);
            $insert_stmt->bindParam(':submitted_by', $submitted_by);
            $insert_stmt->execute();
        }
        
        // ============================================
        // STEP 2: COMPLETE THE PATIENT (same as Complete button)
        // ============================================
        $complete_query = "UPDATE queue_entries 
                           SET status = 'completed', completed_at = NOW() 
                           WHERE id = :id AND status <> 'completed'";
        $complete_stmt = $db->prepare($complete_query);
        $complete_stmt->bindParam(':id', $queue_entry_id);
        $complete_stmt->execute();
        
        // ============================================
        // STEP 3: QUEUE FOR NEXT CLINIC (same as Complete button logic)
        // ============================================
        $queue_query = "SELECT q.patient_id, p.patient_type, q.clinic_id, q.transaction_token
                        FROM queue_entries q
                        JOIN patients p ON q.patient_id = p.id
                        WHERE q.id = :queue_id";
        $queue_stmt = $db->prepare($queue_query);
        $queue_stmt->bindParam(':queue_id', $queue_entry_id);
        $queue_stmt->execute();
        $queue_data = $queue_stmt->fetch(PDO::FETCH_ASSOC);
        
        $next_message = '';
        if ($queue_data && $complete_stmt->rowCount() > 0) {
            if ($queue_data['patient_type'] == 'military') {
                $next_result = $queueManager->queueMilitaryForNextClinic($queue_data['patient_id'], $queue_data['clinic_id'], $queue_data['transaction_token']);
                
                if ($next_result['success']) {
                    $next_message = "Military patient queued for: " . $next_result['clinic'];
                } elseif (isset($next_result['all_completed']) && $next_result['all_completed']) {
                    $next_message = "Military patient has completed this clinic journey.";
                } else {
                    $next_message = "Error: " . ($next_result['error'] ?? 'Unknown error');
                }
            } else {
                $next_result = $queueManager->queueDependentForNextClinic($queue_data['patient_id'], $queue_data['clinic_id']);
                
                if ($next_result['success']) {
                    $next_message = "Patient queued for: " . $next_result['clinic'] . " (least congested)";
                } elseif (isset($next_result['all_completed']) && $next_result['all_completed']) {
                    $next_message = "Patient has completed all clinics!";
                } else {
                    $next_message = "Error: " . ($next_result['error'] ?? 'Unknown error');
                }
            }

            if (!empty($next_result['success'])) {
                $sessionManager->logActivity('Assigned Patient ID ' . (int) $queue_data['patient_id'] . ' to Clinic ID ' . (int) $next_result['clinic_id'] . ' after completion at Clinic ID ' . (int) $queue_data['clinic_id']);
            }
        }
        
        // Commit transaction
        $db->commit();
        $result_action = $existing_result ? 'Updated clinic result' : 'Submitted clinic result';
        $sessionManager->logActivity($result_action . '; queue_entry_id=' . $queue_entry_id . '; clinic_id=' . $clinic_id);
        
        // ============================================
        // STEP 4: Store notification in session
        // ============================================
        $_SESSION['result_notification'] = [
            'type' => 'success',
            'message' => $was_already_completed
                ? ($existing_result ? 'Clinic result updated successfully.' : 'Clinic result submitted successfully.')
                : 'Result submitted and patient completed successfully!',
            'next_message' => $next_message,
            'queue_number' => $queue_entry['queue_number']
        ];
        
        // Redirect back to dashboard
        header('Location: clinic-dashboard.php?clinic_id=' . $clinic_id);
        exit();
        
    } catch (Exception $e) {
        $db->rollBack();
        $error = "Error: " . $e->getMessage();
        error_log("Submit Result Error: " . $e->getMessage());
    }
}

// Load existing result data for display
$existing_data = [];
if ($existing_result) {
    $existing_data = json_decode($existing_result['result_data'], true) ?: [];
    $existing_findings = $existing_result['findings'] ?? '';
    $existing_recommendations = $existing_result['recommendations'] ?? '';
}

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $current_theme === 'dark' ? 'dark' : ''; ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Result - <?php echo htmlspecialchars($clinic['name']); ?> | Camp Evangelista</title>
            <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="clinic-dashboard.php?clinic_id=<?php echo $clinic_id; ?>" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="registration.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-plus text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Register Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient-queue.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-list text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">All Clinics</span>
                        </a>
                    </li>
                    <li>
                        <a href="submit-result.php?clinic_id=<?php echo $clinic_id; ?>&queue_id=<?php echo $queue_entry_id; ?>" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-file-alt text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Submit Result</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        
        <!-- Bottom Section -->
        <div class="p-3 border-t border-slate-300/90 dark:border-slate-700/60">
            <div class="px-3 py-3 bg-sky-50 dark:bg-sky-500/10 rounded-xl mb-3">
                <div class="text-[0.55rem] font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider">Logged in as</div>
                <div class="text-sm font-bold text-slate-800 dark:text-slate-200 truncate"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></div>
                <div class="text-[0.6rem] font-semibold text-sky-600 dark:text-sky-400">
                    <i class="fas fa-tag"></i> Role: <?php echo ucfirst(htmlspecialchars($_SESSION['role'])); ?>
                </div>
            </div>
            <a href="profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                <div class="w-6 h-6 flex items-center justify-center shrink-0">
                    <i class="fas fa-user-circle text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                </div>
                <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">My Profile</span>
            </a>
            <a href="../logout.php" onclick="return confirm('Are you sure you want to logout?')" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                <div class="w-6 h-6 flex items-center justify-center shrink-0">
                    <i class="fas fa-sign-out-alt text-base"></i>
                </div>
                <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5"><i class="fas fa-file-alt text-sky-500 mr-2"></i>Submit Result</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium"><?php echo htmlspecialchars($clinic['name']); ?> - Patient Examination Results</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5"><?php echo ucfirst(htmlspecialchars($_SESSION['role'])); ?></p>
                        </div>
                        <div class="p-1.5">
                            <a href="profile.php" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                                <i class="fas fa-user-circle text-sm"></i>
                                <span>My Profile</span>
                            </a>
                            <a href="../logout.php" onclick="return confirm('Confirm Logout?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Alerts -->
        <?php if ($message): ?>
            <div class="p-4 mb-6 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center gap-3 shadow-sm">
                <i class="fas fa-check-circle text-base"></i> <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="p-4 mb-6 bg-rose-50 dark:bg-rose-500/10 border border-rose-300 dark:border-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl flex items-center gap-3 shadow-sm">
                <i class="fas fa-exclamation-circle text-base"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <!-- Form -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center flex-wrap gap-3">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-notes-medical text-sky-500 text-sm"></i> Clinical Results
                </h3>
                <div class="flex items-center gap-2">
                    <span class="px-3 py-1 bg-sky-100 dark:bg-sky-500/10 text-sky-700 dark:text-sky-400 rounded-full text-xs font-bold font-mono">Queue #: <?php echo htmlspecialchars($queue_entry['queue_number']); ?></span>
                </div>
            </div>
            <div class="p-5">
                <!-- Patient Info -->
                <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-4 mb-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div>
                        <h4 class="text-base font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($queue_entry['first_name'] . ' ' . $queue_entry['last_name']); ?></h4>
                        <p class="text-xs text-slate-500 dark:text-slate-400">
                            <i class="fas fa-id-card mr-1"></i> MRN: <?php echo htmlspecialchars($queue_entry['mrn']); ?> | 
                            <i class="fas fa-calendar-alt mr-1 ml-2"></i> DOB: <?php echo date('M d, Y', strtotime($queue_entry['date_of_birth'])); ?>
                        </p>
                    </div>
                    <div class="text-xs font-bold text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-700 px-3 py-1.5 rounded-lg">
                        <i class="fas fa-calendar-check text-sky-500 mr-1"></i> <?php echo date('F d, Y'); ?>
                    </div>
                </div>

                <form method="POST">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php foreach ($templates as $template): ?>
                            <div class="<?php echo $template['field_type'] == 'textarea' ? 'md:col-span-2' : ''; ?>">
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5 <?php echo $template['is_required'] ? 'required' : ''; ?>">
                                    <i class="fas fa-stethoscope mr-1 text-sky-500"></i> <?php echo htmlspecialchars($template['field_label']); ?>
                                </label>
                                <?php 
                                $field_value = $existing_data[$template['field_name']] ?? '';
                                $field_name = $template['field_name'];
                                $field_type = $template['field_type'];
                                $field_options = json_decode($template['field_options'] ?? '', true);
                                ?>
                                <?php if ($field_type == 'textarea'): ?>
                                    <textarea name="<?php echo $field_name; ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" rows="3" <?php echo $template['is_required'] ? 'required' : ''; ?>><?php echo htmlspecialchars($field_value); ?></textarea>
                                <?php elseif ($field_type == 'number'): ?>
                                    <input type="number" name="<?php echo $field_name; ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" value="<?php echo htmlspecialchars($field_value); ?>" step="any" <?php echo $template['is_required'] ? 'required' : ''; ?>>
                                <?php elseif ($field_type == 'date'): ?>
                                    <input type="date" name="<?php echo $field_name; ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" value="<?php echo htmlspecialchars($field_value); ?>" <?php echo $template['is_required'] ? 'required' : ''; ?>>
                                <?php elseif ($field_type == 'select' && is_array($field_options)): ?>
                                    <select name="<?php echo $field_name; ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" <?php echo $template['is_required'] ? 'required' : ''; ?>>
                                        <option value="">Select <?php echo htmlspecialchars($template['field_label']); ?></option>
                                        <?php foreach ($field_options as $option): ?>
                                            <option value="<?php echo htmlspecialchars($option); ?>" <?php echo $field_value === $option ? 'selected' : ''; ?>><?php echo htmlspecialchars($option); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php else: ?>
                                    <input type="text" name="<?php echo $field_name; ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" value="<?php echo htmlspecialchars($field_value); ?>" <?php echo $template['is_required'] ? 'required' : ''; ?>>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if ($clinic['name'] !== 'Drug Test'): ?>
                        <div class="md:col-span-2">
                            <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5"><i class="fas fa-stethoscope mr-1 text-sky-500"></i> General Findings / Notes</label>
                            <textarea name="findings" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" rows="4" placeholder="Enter any additional findings or clinical notes..."><?php echo htmlspecialchars($existing_result['findings'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5"><i class="fas fa-clinic-medical mr-1 text-sky-500"></i> Recommendations / Follow-up</label>
                            <textarea name="recommendations" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" rows="3" placeholder="Enter recommendations for patient..."><?php echo htmlspecialchars($existing_result['recommendations'] ?? ''); ?></textarea>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="flex flex-col sm:flex-row justify-end gap-3 mt-5 pt-4 border-t border-slate-200 dark:border-slate-700/60">
                        <a href="clinic-dashboard.php?clinic_id=<?php echo $clinic_id; ?>" class="px-5 py-2.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                        <button type="submit" name="submit_result" class="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl transition-all shadow-sm flex items-center justify-center gap-2">
                            <i class="fas fa-save"></i> <?php echo $was_already_completed ? ($existing_result ? 'Update Result' : 'Submit Result') : 'Submit Result & Complete'; ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
        .required:after { content: " *"; color: #FF6F61; }
    </style>

    <script>
        // Theme Toggle
        var themeToggleBtn = document.getElementById('themeToggleBtn');
        var themeToggleIcon = document.getElementById('themeToggleIcon');
        var htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
        } else {
            htmlElement.classList.remove('dark');
            themeToggleIcon.className = 'fas fa-moon text-base';
        }

        themeToggleBtn.addEventListener('click', function() {
            if (htmlElement.classList.contains('dark')) {
                htmlElement.classList.remove('dark');
                themeToggleIcon.className = 'fas fa-moon text-base';
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.classList.add('dark');
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                localStorage.setItem('theme', 'dark');
            }
        });

        // Profile Dropdown
        var profileMenuBtn = document.getElementById('profileMenuBtn');
        var profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', function(e) {
                if (!profileDropdown.contains(e.target) && e.target !== profileMenuBtn && !profileMenuBtn.contains(e.target)) {
                    profileDropdown.classList.add('hidden');
                }
            });
        }

        // Live Clock
        function updateDateTime() {
            var now = new Date();
            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
            document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        var mobileMenuBtn = document.getElementById('mobileMenuBtn');
        var sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', function(e) {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // Auto-dismiss alerts
        setTimeout(function() {
            document.querySelectorAll('.alert').forEach(function(alert) {
                alert.style.transition = 'all 0.4s ease-in-out';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-10px)';
                setTimeout(function() { alert.remove(); }, 400);
            });
        }, 5000);

        // Auto Logout
        var INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        var inactivityTimer;
        var warningTimer;
        var warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(function(err) { console.log('Heartbeat failed:', err); });
        }

        function logoutUser() {
            var logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = "<div class=\"fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4\"><div class=\"bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700\"><i class=\"fas fa-clock text-5xl text-rose-500 mb-5\"></i><h3 class=\"text-xl font-bold text-slate-900 dark:text-white mb-2\">Session Expired</h3><p class=\"text-slate-500 dark:text-slate-400 text-sm mb-5\">You have been logged out due to inactivity.</p><div class=\"w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden\"><div class=\"bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full\"></div></div></div></div>";
            document.body.appendChild(logoutMsg);
            setTimeout(function() { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            var modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = "<div class=\"fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4\"><div class=\"bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in\"><i class=\"fas fa-hourglass-half text-5xl text-amber-500 mb-4\"></i><h3 class=\"text-lg font-bold text-slate-900 dark:text-white mb-1\">Session About to Expire</h3><p class=\"text-slate-500 dark:text-slate-400 text-sm mb-3\">You will be logged out due to inactivity.</p><p id=\"countdownText\" class=\"text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4\">2:00</p><button onclick=\"keepSessionAlive()\" class=\"w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm\"><i class=\"fas fa-mouse-pointer mr-1.5\"></i> Keep Session Active</button></div></div>";
            document.body.appendChild(modal);
            
            var secondsLeft = 120;
            var countdownElement = document.getElementById('countdownText');
            var countdownInterval = setInterval(function() {
                secondsLeft--;
                var minutes = Math.floor(secondsLeft / 60);
                var seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = minutes + ':' + (seconds.toString().padStart(2, '0'));
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(function() { resetInactivityTimer(); })
                .catch(function() { resetInactivityTimer(); });
        }

        function hideWarningModal() {
            var modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        var events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(function(event) {
            document.addEventListener(event, resetInactivityTimer, false);
        });

        resetInactivityTimer();
        setInterval(function() {
            if (!warningShown) sendHeartbeat();
        }, 5 * 60 * 1000);
    </script>

</body>
</html>