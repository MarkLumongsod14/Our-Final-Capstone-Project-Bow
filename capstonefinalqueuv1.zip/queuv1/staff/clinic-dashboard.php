<?php
// staff/clinic-dashboard.php - Clinic Staff Dashboard
// Camp Evangelista Station Hospital

date_default_timezone_set('Asia/Manila');

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

session_start();
require_once dirname(__DIR__) . '/includes/UnifiedSession.php';

// ============================================
// AUTHENTICATION & ROLE-BASED ACCESS CONTROL
// ============================================

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

// Allowed roles for staff pages
$allowed_staff_roles = ['admin', 'doctor', 'nurse', 'technician', 'staff'];

if (!in_array($_SESSION['role'], $allowed_staff_roles)) {
    header('Location: ../unauthorized.php');
    exit();
}

// ============================================
// DATABASE CONNECTION (Must be before SessionManager)
// ============================================
$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

$account_stmt = $db->prepare("SELECT role, clinic_id FROM users WHERE id = ?");
$account_stmt->execute([$_SESSION['user_id']]);
$account_access = $account_stmt->fetch(PDO::FETCH_ASSOC);
if (!$account_access || !in_array($account_access['role'], $allowed_staff_roles, true)) {
    header('Location: ../unauthorized.php');
    exit();
}
$_SESSION['role'] = $account_access['role'];
$_SESSION['clinic_id'] = $account_access['clinic_id'];

// ============================================
// SESSION TIMEOUT CHECK (Now $db exists!)
// ============================================
require_once dirname(__DIR__) . '/includes/SessionManager.php';
$sessionManager = new SessionManager($db);
if (!$sessionManager->checkTimeout()) {
    exit(); // Already redirected to login
}

// ============================================
// CLINIC SETUP
// ============================================

// Get clinic ID from URL (default to user's clinic if not specified)
$clinic_id = isset($_GET['clinic_id']) ? (int)$_GET['clinic_id'] : ($_SESSION['clinic_id'] ?? 1);

// Check if user has access to this clinic (for non-admin users)
if ($_SESSION['role'] != 'admin') {
    if (!isset($_SESSION['clinic_id']) || $_SESSION['clinic_id'] != $clinic_id) {
        $_SESSION['error'] = "You don't have permission to access this clinic.";
        header('Location: clinic-dashboard.php?clinic_id=' . $_SESSION['clinic_id']);
        exit();
    }
}

// Get clinic info
$query = "SELECT * FROM clinics WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $clinic_id);
$stmt->execute();
$clinic = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$clinic) {
    die("Clinic not found. Please check the clinic ID.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_clinic'])) {
    if ($_SESSION['role'] === 'admin' || (isset($_SESSION['clinic_id']) && (int) $_SESSION['clinic_id'] === $clinic_id)) {
        $toggle_stmt = $db->prepare("UPDATE clinics SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?");
        $toggle_stmt->execute([$clinic_id]);
        if ($toggle_stmt->rowCount() > 0) {
            $sessionManager->logActivity('Toggled clinic availability; clinic_id=' . $clinic_id);
        }
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            $status_stmt = $db->prepare("SELECT is_active FROM clinics WHERE id = ?");
            $status_stmt->execute([$clinic_id]);
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'is_active' => (int) $status_stmt->fetchColumn()]);
            exit();
        }
    }
    header('Location: clinic-dashboard.php?clinic_id=' . $clinic_id);
    exit();
}

// Handle calling next patient
if (isset($_POST['call_next'])) {
    $called_queue_id = $queueManager->callNextPatient($clinic_id);
    if ($called_queue_id) {
        $sessionManager->logActivity('Called next queue entry; queue_entry_id=' . (int) $called_queue_id . '; clinic_id=' . $clinic_id);
    }
    
    // Return JSON for AJAX requests
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Patient called']);
        exit();
    }
    
    header('Location: clinic-dashboard.php?clinic_id=' . $clinic_id);
    exit();
}

// Handle patient status update
if (isset($_POST['update_status'])) {
    $is_completion = $_POST['status'] == 'completed';
    $query = "UPDATE queue_entries SET status = :status";
    
    if ($_POST['status'] == 'completed') {
        $query .= ", completed_at = NOW()";
    } elseif ($_POST['status'] == 'called') {
        $query .= ", called_at = NOW()";
    }
    
    $query .= $is_completion ? " WHERE id = :id AND status <> 'completed'" : " WHERE id = :id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':status', $_POST['status']);
    $stmt->bindParam(':id', $_POST['queue_id']);
    
    $stmt->execute();
    $was_completed = $stmt->rowCount() > 0 && $is_completion;
    if ($stmt->rowCount() > 0) {
        $sessionManager->logActivity('Changed queue status to ' . preg_replace('/[^a-z-]/', '', $_POST['status']) . '; queue_entry_id=' . (int) $_POST['queue_id'] . '; clinic_id=' . $clinic_id);
    }

    if ($was_completed) {
        $queue_query = "SELECT q.patient_id, p.patient_type, q.clinic_id, q.transaction_token
                        FROM queue_entries q
                        JOIN patients p ON q.patient_id = p.id
                        WHERE q.id = :queue_id";
        $queue_stmt = $db->prepare($queue_query);
        $queue_stmt->bindParam(':queue_id', $_POST['queue_id']);
        $queue_stmt->execute();
        $queue_data = $queue_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($queue_data) {
            if ($queue_data['patient_type'] == 'military') {
                $next_result = $queueManager->queueMilitaryForNextClinic($queue_data['patient_id'], $queue_data['clinic_id'], $queue_data['transaction_token']);
                    
                    if ($next_result['success']) {
                        $_SESSION['next_queue'] = "Military patient queued for: " . $next_result['clinic'];
                    } elseif (isset($next_result['all_completed']) && $next_result['all_completed']) {
                        $_SESSION['next_queue'] = "Military patient has completed this clinic journey.";
                    } else {
                        $_SESSION['next_queue'] = "Error: " . ($next_result['error'] ?? 'Unknown error');
                    }
                } else {
                    // Dependent - uses journey or least congested
                    $next_result = $queueManager->queueDependentForNextClinic($queue_data['patient_id'], $queue_data['clinic_id']);
                    
                    if ($next_result['success']) {
                    $_SESSION['next_queue'] = "Patient queued for: " . $next_result['clinic'] . " (least congested)";
                } elseif (isset($next_result['all_completed']) && $next_result['all_completed']) {
                    $_SESSION['next_queue'] = "Patient has completed all clinics!";
                } else {
                    $_SESSION['next_queue'] = "Error: " . ($next_result['error'] ?? 'Unknown error');
                }
            }
        }
    }
    
    // Return JSON for AJAX requests
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Status updated']);
        exit();
    }
    
    header('Location: clinic-dashboard.php?clinic_id=' . $clinic_id);
    exit();
}

// Get current queue
$query = "SELECT q.*, p.first_name, p.last_name, p.date_of_birth,
                 p.patient_type, p.is_pwd, p.is_senior, p.is_pregnant,
                 TIMESTAMPDIFF(MINUTE, q.registered_at, NOW()) as waiting_minutes,
                 HOUR(q.batch_hour) as batch_number,
                 DATE_FORMAT(q.batch_hour, '%h:%i %p') as batch_time,
                 (SELECT COUNT(*) FROM queue_entries 
                  WHERE clinic_id = q.clinic_id 
                  AND status IN ('waiting', 'called') 
                  AND batch_hour = q.batch_hour
                  AND id < q.id) + 1 as position_in_batch
          FROM queue_entries q
          JOIN patients p ON q.patient_id = p.id
          WHERE q.clinic_id = :clinic_id 
          AND q.status IN ('waiting', 'called', 'in-progress')
          AND DATE(q.registered_at) = CURDATE()
          ORDER BY 
            q.batch_hour ASC,
            FIELD(q.priority_level, 'PR1', 'PR2', 'PR3'),
            FIELD(q.status, 'called', 'in-progress', 'waiting'),
            q.registered_at ASC";

$stmt = $db->prepare($query);
$stmt->bindParam(':clinic_id', $clinic_id);
$stmt->execute();
$queue = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get today's stats
$query = "SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'waiting' THEN 1 ELSE 0 END) as waiting,
            SUM(CASE WHEN status = 'called' THEN 1 ELSE 0 END) as called,
            SUM(CASE WHEN status = 'in-progress' THEN 1 ELSE 0 END) as in_progress,
            AVG(TIMESTAMPDIFF(MINUTE, registered_at, completed_at)) as avg_time
          FROM queue_entries 
          WHERE clinic_id = :clinic_id 
          AND DATE(registered_at) = CURDATE()";

$stmt = $db->prepare($query);
$stmt->bindParam(':clinic_id', $clinic_id);
$stmt->execute();
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Get batch information
$batch_info = $queueManager->getCurrentBatch();

// Get completed patients today
$query = "SELECT q.*, p.first_name, p.last_name, p.patient_type,
                 DATE_FORMAT(q.completed_at, '%h:%i %p') as completed_time
          FROM queue_entries q
          JOIN patients p ON q.patient_id = p.id
          WHERE q.clinic_id = :clinic_id 
          AND q.status = 'completed'
          AND DATE(q.registered_at) = CURDATE()
          ORDER BY q.completed_at DESC
          LIMIT 10";

$stmt = $db->prepare($query);
$stmt->bindParam(':clinic_id', $clinic_id);
$stmt->execute();
$completed_patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Keep recent visits available for updates and older visits visible while their result is pending.
$completed_results_query = "SELECT q.id, q.queue_number, q.completed_at,
                                   p.first_name, p.last_name, p.mrn,
                                   (SELECT cr.status
                                    FROM clinic_results cr
                                    WHERE cr.queue_entry_id = q.id AND cr.clinic_id = q.clinic_id
                                    ORDER BY cr.submitted_at DESC, cr.id DESC
                                    LIMIT 1) AS result_status
                            FROM queue_entries q
                            JOIN patients p ON q.patient_id = p.id
                            WHERE q.clinic_id = :clinic_id
                              AND q.status = 'completed'
                              AND (
                                  q.completed_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                                  OR NOT EXISTS (
                                      SELECT 1
                                      FROM clinic_results old_result
                                      WHERE old_result.queue_entry_id = q.id
                                        AND old_result.clinic_id = q.clinic_id
                                        AND old_result.status = 'completed'
                                  )
                              )
                            ORDER BY q.completed_at DESC, q.id DESC";
$completed_results_stmt = $db->prepare($completed_results_query);
$completed_results_stmt->bindParam(':clinic_id', $clinic_id);
$completed_results_stmt->execute();
$completed_result_patients = $completed_results_stmt->fetchAll(PDO::FETCH_ASSOC);

$completion_rate = 0;
if ($stats['total'] > 0) {
    $completion_rate = round(($stats['completed'] / $stats['total']) * 100, 1);
}

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
$html_class = ($current_theme === 'dark' ? 'dark ' : '') . 'h-full';
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo htmlspecialchars($html_class, ENT_QUOTES); ?>">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($clinic['name']); ?> | Staff Dashboard | Camp Evangelista</title>
<link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- <meta http-equiv="refresh" content="60"> -->
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="../assets/js/clinic-ajax.js?v=3"></script>
    <script>
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
        }
    </script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }

            if (!empty($next_result['success'])) {
                $sessionManager->logActivity('Assigned Patient ID ' . (int) $queue_data['patient_id'] . ' to Clinic ID ' . (int) $next_result['clinic_id'] . ' after completion at Clinic ID ' . (int) $queue_data['clinic_id']);
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="clinic-dashboard.php?clinic_id=<?php echo $clinic_id; ?>" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="registration.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-plus text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Register Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient-queue.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-list text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">All Clinics</span>
                        </a>
                    </li>
                    <li>
                        <a href="../patient-portal/track-queue.php" target="_blank" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-search text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Portal</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        
        <!-- Bottom Section -->
        <div class="p-3 border-t border-slate-300/90 dark:border-slate-700/60">
            <!-- Collapsed State (Icon only) -->
            <div class="flex items-center justify-center md:group-hover/sidebar:hidden py-2">
                <div class="w-10 h-10 bg-sky-50 dark:bg-sky-500/10 rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700">
                    <i class="fas fa-user text-base"></i>
                </div>
            </div>
            
            <!-- Expanded State (Full info) -->
            <div class="hidden md:group-hover/sidebar:flex flex-col px-3 py-3 bg-sky-50 dark:bg-sky-500/10 rounded-xl mb-3 transition-all duration-300">
                <div class="text-[0.55rem] font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider">Logged in as</div>
                <div class="text-sm font-bold text-slate-800 dark:text-slate-200 truncate"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></div>
                <div class="text-[0.6rem] font-semibold text-sky-600 dark:text-sky-400">
                    <i class="fas fa-tag"></i> Role: <?php echo ucfirst(htmlspecialchars($_SESSION['role'])); ?>
                </div>
            </div>
            
            <a href="profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                <div class="w-6 h-6 flex items-center justify-center shrink-0">
                    <i class="fas fa-user-circle text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                </div>
                <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">My Profile</span>
            </a>
            <a href="../logout.php" onclick="return confirm('Are you sure you want to logout?')" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                <div class="w-6 h-6 flex items-center justify-center shrink-0">
                    <i class="fas fa-sign-out-alt text-base"></i>
                </div>
                <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5"><?php echo htmlspecialchars($clinic['name']); ?></h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">Staff Dashboard • Manage patient queue and consultations</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <a href="../public/clinic-display-monitor.php?clinic_id=<?php echo urlencode($clinic_id); ?>" target="_blank" rel="noopener noreferrer" class="px-3 py-2 rounded-lg text-xs font-bold bg-sky-50 text-sky-600 dark:bg-sky-500/10 dark:text-sky-400 hover:bg-sky-100 dark:hover:bg-sky-500/20 transition-all flex items-center gap-1.5" title="Open <?php echo htmlspecialchars($clinic['name']); ?> display monitor">
                    <i class="fas fa-tv"></i><span class="hidden sm:inline">Open Display</span>
                </a>
                <form method="POST" class="clinic-toggle-form flex items-center" onsubmit="return toggleClinicAjax(this);">
                    <input type="hidden" name="clinic_id" value="<?php echo (int) $clinic_id; ?>">
                    <button type="submit" name="toggle_clinic" class="clinic-toggle-button px-3 py-2 rounded-lg text-xs font-bold <?php echo $clinic['is_active'] ? 'bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-400' : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400'; ?>" data-active="<?php echo (int) $clinic['is_active']; ?>">
                        <i class="fas <?php echo $clinic['is_active'] ? 'fa-pause' : 'fa-play'; ?> mr-1"></i><?php echo $clinic['is_active'] ? 'Close Clinic' : 'Open Clinic'; ?>
                    </button>
                </form>
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5"><?php echo ucfirst(htmlspecialchars($_SESSION['role'])); ?></p>
                        </div>
                        <div class="p-1.5">
                            <a href="../admin/setup-2fa.php" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                                <i class="fas fa-shield-alt text-sm text-sky-500"></i>
                                <span>Set Up Two-Factor Authentication</span>
                            </a>
                            <a href="profile.php" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                                <i class="fas fa-user-circle text-sm"></i>
                                <span>My Profile</span>
                            </a>
                            <a href="../logout.php" onclick="return confirm('Confirm Logout?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Alerts -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="p-4 mb-6 bg-rose-50 dark:bg-rose-500/10 border border-rose-300 dark:border-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl flex items-center gap-3 shadow-sm">
                <i class="fas fa-exclamation-circle text-base"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_SESSION['next_queue'])): ?>
            <div class="p-4 mb-6 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center gap-3 shadow-sm">
                <i class="fas fa-check-circle text-base"></i> <?php echo htmlspecialchars($_SESSION['next_queue']); unset($_SESSION['next_queue']); ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="grid grid-cols-3 md:grid-cols-6 gap-3 md:gap-4 mb-6">
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-sky-50 dark:bg-sky-500/10 rounded-lg flex items-center justify-center text-sky-600 dark:text-sky-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-users"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $stats['total'] ?? 0; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">Total</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-amber-50 dark:bg-amber-500/10 rounded-lg flex items-center justify-center text-amber-600 dark:text-amber-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $stats['waiting'] ?? 0; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">Waiting</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-sky-50 dark:bg-sky-500/10 rounded-lg flex items-center justify-center text-sky-600 dark:text-sky-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $stats['called'] ?? 0; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">Called</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-emerald-50 dark:bg-emerald-500/10 rounded-lg flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-play-circle"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $stats['in_progress'] ?? 0; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">In Progress</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-emerald-50 dark:bg-emerald-500/10 rounded-lg flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $stats['completed'] ?? 0; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">Completed</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-indigo-50 dark:bg-indigo-500/10 rounded-lg flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-hourglass-half"></i>
                </div>
                <div class="text-xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo round($stats['avg_time'] ?? 0); ?>m</div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">Avg Time</div>
            </div>
        </div>
            <!-- Alerts -->
<?php if (isset($_SESSION['error'])): ?>
    <div class="p-4 mb-6 bg-rose-50 dark:bg-rose-500/10 border border-rose-300 dark:border-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl flex items-center gap-3 shadow-sm">
        <i class="fas fa-exclamation-circle text-base"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['next_queue'])): ?>
    <div class="p-4 mb-6 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center gap-3 shadow-sm">
        <i class="fas fa-check-circle text-base"></i> <?php echo htmlspecialchars($_SESSION['next_queue']); unset($_SESSION['next_queue']); ?>
    </div>
<?php endif; ?>

<!-- Result Submission Notification -->
<?php if (isset($_SESSION['result_notification'])): ?>
    <?php 
    $notif = $_SESSION['result_notification'];
    ?>
    <div class="p-4 mb-6 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl shadow-sm alert-notification">
        <div class="flex items-start gap-3">
            <i class="fas fa-check-circle text-base mt-0.5"></i>
            <div>
                <div class="font-medium"><?php echo htmlspecialchars($notif['message']); ?></div>
                <?php if (!empty($notif['next_message'])): ?>
                    <div class="text-sm mt-1 text-emerald-700 dark:text-emerald-300">
                        <i class="fas fa-arrow-right mr-1"></i> <?php echo htmlspecialchars($notif['next_message']); ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($notif['queue_number'])): ?>
                    <div class="text-xs mt-1 font-mono text-emerald-700 dark:text-emerald-300">
                        Queue #: <?php echo htmlspecialchars($notif['queue_number']); ?>
                    </div>
                <?php endif; ?>
            </div>
            <button onclick="this.parentElement.parentElement.style.display='none'" class="ml-auto text-emerald-500 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>
    <?php unset($_SESSION['result_notification']); ?>
<?php endif; ?>
        <!-- Batch Bar -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 mb-6 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="flex flex-wrap gap-6">
                <div>
                    <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Current Batch</div>
                    <div class="text-lg font-bold text-sky-600 dark:text-sky-400"><?php echo date('h:00 A', strtotime($batch_info['current_hour'])); ?></div>
                </div>
                <div>
                    <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Patients</div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white"><?php echo $batch_info['current_count']; ?>/20</div>
                </div>
                <div>
                    <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Remaining</div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white"><?php echo $batch_info['remaining_slots']; ?></div>
                </div>
                <div>
                    <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Next Batch</div>
                    <div class="text-lg font-bold text-slate-900 dark:text-white"><?php echo date('h:00 A', strtotime($batch_info['next_hour'])); ?></div>
                </div>
            </div>
            <div class="flex items-center gap-3 w-full sm:w-auto">
                <div class="flex-1 sm:w-32 bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div class="bg-emerald-500 h-full rounded-full transition-all duration-500" style="width: <?php echo ($batch_info['current_count'] / 20) * 100; ?>%"></div>
                </div>
                <span class="text-xs font-bold text-slate-500 dark:text-slate-400"><?php echo round(($batch_info['current_count'] / 20) * 100); ?>%</span>
            </div>
        </div>

        <!-- Now Serving -->
        <?php 
        $current_patient = null;
        foreach ($queue as $patient) { 
            if ($patient['status'] == 'in-progress') { 
                $current_patient = $patient; 
                break; 
            } 
        } 
        ?>
        <?php if ($current_patient): ?>
            <div class="bg-gradient-to-r from-sky-500 to-teal-500 dark:from-sky-600 dark:to-teal-600 rounded-xl p-5 mb-6 text-white text-center">
                <div class="text-xs font-bold uppercase tracking-widest opacity-90"><i class="fas fa-bell mr-2"></i> NOW SERVING</div>
                <div class="text-4xl md:text-5xl font-black font-mono my-2 tracking-wider"><?php echo htmlspecialchars($current_patient['queue_number']); ?></div>
                <div class="text-lg font-semibold"><?php echo htmlspecialchars($current_patient['first_name'] . ' ' . $current_patient['last_name']); ?></div>
                <div class="mt-2 inline-block px-3 py-1 bg-white/20 rounded-full text-sm font-bold"><?php echo htmlspecialchars($current_patient['priority_level']); ?></div>
            </div>
        <?php endif; ?>

        <!-- Queue List and Sidebar -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Queue List -->
            <div class="lg:col-span-2 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
                <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center flex-wrap gap-3">
                    <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                        <i class="fas fa-list-ol text-sky-500 text-sm"></i> Current Queue
                    </h3>
                    <div class="flex gap-2">
                        <button type="button" onclick="callNextPatientAjax(<?php echo $clinic_id; ?>)" class="bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold px-4 py-2 rounded-lg transition-all flex items-center gap-1.5">
                            <i class="fas fa-bell"></i> Call Next
                        </button>
                        <a href="registration.php" class="bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold px-4 py-2 rounded-lg transition-all flex items-center gap-1.5">
                            <i class="fas fa-user-plus"></i> Register
                        </a>
                    </div>
                </div>
                <div class="p-4 space-y-3 max-h-[600px] overflow-y-auto">
                    <?php if (empty($queue)): ?>
                        <div class="text-center py-12 text-slate-400 dark:text-slate-500">
                            <i class="fas fa-check-circle text-3xl mb-3 block text-emerald-400"></i>
                            <p class="text-sm font-medium">No patients in queue</p>
                            <small class="text-xs">Queue is empty. New patients will appear here when registered.</small>
                        </div>
                    <?php else: ?>
                        <?php foreach ($queue as $patient): 
                            $priorityClass = 'border-l-4 ';
                            if ($patient['priority_level'] == 'PR1') $priorityClass .= 'border-l-rose-500';
                            elseif ($patient['priority_level'] == 'PR2') $priorityClass .= 'border-l-amber-500';
                            else $priorityClass .= 'border-l-emerald-500';
                            
                            $statusClass = '';
                            if ($patient['status'] == 'called') $statusClass = 'bg-sky-50 dark:bg-sky-500/5 border-sky-200 dark:border-sky-500/20';
                        ?>
                            <div class="<?php echo 'bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700/60 rounded-xl p-4 ' . $priorityClass . ' ' . $statusClass . ' transition-all hover:shadow-sm'; ?>">
                                <div class="flex flex-col md:flex-row md:items-center gap-3">
                                    <div class="flex items-center gap-3">
                                        <?php
                                            $badgeClass = '';
                                            if ($patient['priority_level'] == 'PR1') $badgeClass = 'bg-rose-500 text-white';
                                            elseif ($patient['priority_level'] == 'PR2') $badgeClass = 'bg-amber-500 text-white';
                                            else $badgeClass = 'bg-emerald-500 text-white';
                                        ?>
                                        <div class="w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm <?php echo $badgeClass; ?>">
                                            <?php echo htmlspecialchars($patient['priority_level']); ?>
                                        </div>
                                        <div>
                                            <div class="flex items-center gap-2">
                                                <span class="font-bold text-slate-900 dark:text-white font-mono"><?php echo htmlspecialchars($patient['queue_number']); ?></span>
                                                <span class="text-[0.55rem] font-bold bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded-full text-slate-500 dark:text-slate-400">Batch <?php echo htmlspecialchars($patient['batch_number']); ?>:00</span>
                                            </div>
                                            <div class="text-sm font-semibold text-slate-800 dark:text-slate-200">
                                                <?php echo htmlspecialchars($patient['last_name'] . ', ' . $patient['first_name']); ?>
                                                <?php if ($patient['patient_type'] == 'military'): ?>
                                                    <i class="fas fa-shield-alt text-rose-500 text-xs ml-1"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div class="text-xs text-slate-500 dark:text-slate-400">
                                                <?php $dob = new DateTime($patient['date_of_birth']); echo (new DateTime())->diff($dob)->y; ?> yrs | 
                                                Reg: <?php echo date('h:i A', strtotime($patient['registered_at'])); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex-1 flex flex-wrap items-center justify-end gap-2">
                                        <div class="text-xs text-slate-500 dark:text-slate-400 text-right">
                                            <span class="font-bold text-slate-700 dark:text-slate-300">Pos: <?php echo $patient['position_in_batch']; ?>/batch</span><br>
                                            Wait: <?php echo $patient['waiting_minutes']; ?> min
                                        </div>
                                        <div class="flex gap-1.5">
                                            <?php if ($patient['status'] == 'waiting'): ?>
                                                <button type="button" onclick="updatePatientStatusAjax(<?php echo $patient['id']; ?>, 'called', <?php echo $clinic_id; ?>)" class="bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1">
                                                    <i class="fas fa-bell"></i> Call
                                                </button>
                                            <?php elseif ($patient['status'] == 'called'): ?>
                                                <button type="button" onclick="updatePatientStatusAjax(<?php echo $patient['id']; ?>, 'in-progress', <?php echo $clinic_id; ?>)" class="bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1">
                                                    <i class="fas fa-play"></i> Start
                                                </button>
                                                <button type="button" onclick="if (confirm('Mark this patient as no-show? They can retry this clinic from the tracking portal.')) updatePatientStatusAjax(<?php echo $patient['id']; ?>, 'no-show', <?php echo $clinic_id; ?>)" class="bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1">
                                                    <i class="fas fa-user-slash"></i> No Show
                                                </button>
                                            <?php elseif ($patient['status'] == 'in-progress'): ?>
                                                <button type="button" onclick="updatePatientStatusAjax(<?php echo $patient['id']; ?>, 'completed', <?php echo $clinic_id; ?>)" class="bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1">
                                                    <i class="fas fa-check"></i> Complete
                                                </button>
                                                <a href="submit-result.php?clinic_id=<?php echo $clinic_id; ?>&queue_id=<?php echo $patient['id']; ?>" class="bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1">
                                                    <i class="fas fa-file-alt"></i> Result
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sidebar Info -->
            <div class="space-y-4">
                <!-- Quick Actions -->
                <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
                    <div class="px-4 py-3 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20">
                        <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                            <i class="fas fa-bolt text-amber-500 text-sm"></i> Quick Actions
                        </h3>
                    </div>
                    <div class="p-4 space-y-2">
                        <a href="registration.php" class="block w-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold text-center px-4 py-2.5 rounded-lg transition-all">
                            <i class="fas fa-user-plus mr-1.5"></i> Register New Patient
                        </a>
                        <a href="patient-queue.php" class="block w-full bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold text-center px-4 py-2.5 rounded-lg transition-all">
                            <i class="fas fa-list mr-1.5"></i> View All Clinics
                        </a>
                        <button onclick="location.reload()" class="block w-full bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold text-center px-4 py-2.5 rounded-lg transition-all">
                            <i class="fas fa-sync mr-1.5"></i> Refresh
                        </button>
                    </div>
                </div>

                <!-- Clinic Info -->
                <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
                    <div class="px-4 py-3 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20">
                        <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                            <i class="fas fa-info-circle text-sky-500 text-sm"></i> Clinic Info
                        </h3>
                    </div>
                    <div class="p-4 space-y-2 text-sm">
                        <div class="flex justify-between"><span class="text-slate-500 dark:text-slate-400">Capacity</span><span class="font-bold text-slate-900 dark:text-white"><?php echo $clinic['capacity_per_hour']; ?> patients/hr</span></div>
                        <div class="flex justify-between"><span class="text-slate-500 dark:text-slate-400">Current Load</span><span class="font-bold text-slate-900 dark:text-white"><?php echo ($stats['waiting'] + $stats['called'] + $stats['in_progress']); ?> patients</span></div>
                        <div class="flex justify-between"><span class="text-slate-500 dark:text-slate-400">Est. Wait Time</span><span class="font-bold text-amber-500"><?php echo ($stats['waiting'] + $stats['called']) * 10; ?> min</span></div>
                        <div class="flex justify-between"><span class="text-slate-500 dark:text-slate-400">Completion Rate</span><span class="font-bold text-emerald-500"><?php echo $completion_rate; ?>%</span></div>
                    </div>
                </div>

                <!-- Recently Completed -->
                <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
                    <div class="px-4 py-3 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex items-center justify-between gap-2">
                        <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                            <i class="fas fa-history text-sky-500 text-sm"></i> Recently Completed
                        </h3>
                        <button type="button" onclick="openCompletedResultsModal()" class="shrink-0 bg-sky-500 hover:bg-sky-600 text-white text-[0.65rem] font-bold px-2.5 py-1.5 rounded-lg transition-colors">
                            <i class="fas fa-file-medical mr-1"></i> Results (<?php echo count($completed_result_patients); ?>)
                        </button>
                    </div>
                    <div class="p-4 max-h-48 overflow-y-auto">
                        <?php if (empty($completed_patients)): ?>
                            <p class="text-center text-xs text-slate-400 dark:text-slate-500 py-4">No completed patients yet today</p>
                        <?php else: ?>
                            <?php foreach ($completed_patients as $completed): ?>
                                <div class="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-700/50 last:border-0">
                                    <div>
                                        <span class="font-bold text-sky-600 dark:text-sky-400 font-mono"><?php echo htmlspecialchars($completed['queue_number']); ?></span>
                                        <div class="text-xs text-slate-600 dark:text-slate-400"><?php echo htmlspecialchars($completed['first_name'] . ' ' . $completed['last_name']); ?></div>
                                    </div>
                                    <div class="text-xs text-slate-400 dark:text-slate-500"><?php echo htmlspecialchars($completed['completed_time']); ?></div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div id="completedResultsModal" class="fixed inset-0 z-[1200] hidden items-center justify-center bg-slate-950/60 p-4" role="dialog" aria-modal="true" aria-labelledby="completedResultsTitle">
                    <div class="w-full max-w-3xl max-h-[85vh] overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1f2937] shadow-2xl">
                        <div class="flex items-start justify-between gap-4 border-b border-slate-200 dark:border-slate-700 px-5 py-4">
                            <div>
                                <h2 id="completedResultsTitle" class="text-base font-extrabold text-slate-900 dark:text-white">Completed Patients &amp; Results</h2>
                                <p class="mt-1 text-xs text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($clinic['name']); ?> · last 30 days and older visits with pending results</p>
                            </div>
                            <button type="button" onclick="closeCompletedResultsModal()" aria-label="Close" class="rounded-lg px-2.5 py-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="p-5">
                            <label class="sr-only" for="completedResultsSearch">Search completed patients</label>
                            <input id="completedResultsSearch" type="search" oninput="filterCompletedResultPatients()" placeholder="Search by patient name, MRN, or queue number" class="mb-4 w-full rounded-xl border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-[#111827] px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:border-sky-500 focus:outline-none">
                            <div class="max-h-[55vh] overflow-auto">
                                <table class="w-full min-w-[600px] text-left text-sm">
                                    <thead class="sticky top-0 bg-slate-100 dark:bg-slate-800 text-[0.65rem] uppercase tracking-wide text-slate-500 dark:text-slate-400">
                                        <tr>
                                            <th class="px-3 py-2">Patient</th>
                                            <th class="px-3 py-2">Queue</th>
                                            <th class="px-3 py-2">Completed</th>
                                            <th class="px-3 py-2">Result</th>
                                            <th class="px-3 py-2 text-right">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="completedResultsRows" class="divide-y divide-slate-100 dark:divide-slate-700">
                                        <?php foreach ($completed_result_patients as $completed_result): ?>
                                            <?php
                                            $has_result = $completed_result['result_status'] !== null;
                                            $result_status_label = $has_result
                                                ? ($completed_result['result_status'] === 'completed' ? 'Submitted' : 'Draft')
                                                : 'Pending';
                                            ?>
                                            <tr class="completed-result-row">
                                                <td class="px-3 py-3">
                                                    <div class="font-semibold text-slate-800 dark:text-slate-100"><?php echo htmlspecialchars($completed_result['first_name'] . ' ' . $completed_result['last_name']); ?></div>
                                                    <div class="text-xs text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($completed_result['mrn'] ?? ''); ?></div>
                                                </td>
                                                <td class="px-3 py-3 font-mono text-sky-600 dark:text-sky-400"><?php echo htmlspecialchars($completed_result['queue_number']); ?></td>
                                                <td class="px-3 py-3 text-slate-600 dark:text-slate-300"><?php echo htmlspecialchars(date('M j, g:i A', strtotime($completed_result['completed_at']))); ?></td>
                                                <td class="px-3 py-3">
                                                    <span class="inline-flex rounded-full px-2.5 py-1 text-[0.65rem] font-bold <?php echo $result_status_label === 'Submitted' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400'; ?>">
                                                        <?php echo htmlspecialchars($result_status_label); ?>
                                                    </span>
                                                </td>
                                                <td class="px-3 py-3 text-right">
                                                    <a href="submit-result.php?clinic_id=<?php echo $clinic_id; ?>&amp;queue_id=<?php echo (int)$completed_result['id']; ?>" class="inline-flex items-center gap-1.5 rounded-lg bg-sky-500 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-sky-600">
                                                        <i class="fas <?php echo $has_result ? 'fa-pen' : 'fa-plus'; ?>"></i><?php echo $has_result ? 'Update' : 'Submit'; ?>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($completed_result_patients)): ?>
                                            <tr><td colspan="5" class="px-3 py-8 text-center text-sm text-slate-500 dark:text-slate-400">No patients have been completed at this clinic today.</td></tr>
                                        <?php endif; ?>
                                        <tr id="completedResultsNoMatch" class="hidden"><td colspan="5" class="px-3 py-8 text-center text-sm text-slate-500 dark:text-slate-400">No matching completed patients.</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
    </style>

    <script>
        function openCompletedResultsModal() {
            var modal = document.getElementById('completedResultsModal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
            document.body.classList.add('overflow-hidden');
            document.getElementById('completedResultsSearch').focus();
        }

        function closeCompletedResultsModal() {
            var modal = document.getElementById('completedResultsModal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
            document.body.classList.remove('overflow-hidden');
        }

        function filterCompletedResultPatients() {
            var term = document.getElementById('completedResultsSearch').value.trim().toLowerCase();
            var rows = document.querySelectorAll('.completed-result-row');
            var visibleCount = 0;
            rows.forEach(function(row) {
                var matches = row.textContent.toLowerCase().includes(term);
                row.classList.toggle('hidden', !matches);
                if (matches) visibleCount++;
            });
            var noMatch = document.getElementById('completedResultsNoMatch');
            if (noMatch) noMatch.classList.toggle('hidden', visibleCount > 0 || rows.length === 0);
        }

        document.getElementById('completedResultsModal').addEventListener('click', function(event) {
            if (event.target === this) closeCompletedResultsModal();
        });
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') closeCompletedResultsModal();
        });

        // Theme Toggle
        var themeToggleBtn = document.getElementById('themeToggleBtn');
        var themeToggleIcon = document.getElementById('themeToggleIcon');
        var htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
        } else {
            htmlElement.classList.remove('dark');
            themeToggleIcon.className = 'fas fa-moon text-base';
        }

        themeToggleBtn.addEventListener('click', function() {
            if (htmlElement.classList.contains('dark')) {
                htmlElement.classList.remove('dark');
                themeToggleIcon.className = 'fas fa-moon text-base';
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.classList.add('dark');
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                localStorage.setItem('theme', 'dark');
            }
        });

        // Profile Dropdown
        var profileMenuBtn = document.getElementById('profileMenuBtn');
        var profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', function(e) {
                if (!profileDropdown.contains(e.target) && e.target !== profileMenuBtn && !profileMenuBtn.contains(e.target)) {
                    profileDropdown.classList.add('hidden');
                }
            });
        }

        // Live Clock
        function updateDateTime() {
            var now = new Date();
            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
            document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        var mobileMenuBtn = document.getElementById('mobileMenuBtn');
        var sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', function(e) {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // Auto-dismiss alerts
        setTimeout(function() {
            document.querySelectorAll('.alert').forEach(function(alert) {
                alert.style.transition = 'all 0.4s ease-in-out';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-10px)';
                setTimeout(function() { alert.remove(); }, 400);
            });
        }, 5000);

        // Auto Logout
        var INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        var inactivityTimer;
        var warningTimer;
        var warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(function(err) { console.log('Heartbeat failed:', err); });
        }

        function logoutUser() {
            var logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = "<div class=\"fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4\"><div class=\"bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700\"><i class=\"fas fa-clock text-5xl text-rose-500 mb-5\"></i><h3 class=\"text-xl font-bold text-slate-900 dark:text-white mb-2\">Session Expired</h3><p class=\"text-slate-500 dark:text-slate-400 text-sm mb-5\">You have been logged out due to inactivity.</p><div class=\"w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden\"><div class=\"bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full\"></div></div></div></div>";
            document.body.appendChild(logoutMsg);
            setTimeout(function() { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            var modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = "<div class=\"fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4\"><div class=\"bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in\"><i class=\"fas fa-hourglass-half text-5xl text-amber-500 mb-4\"></i><h3 class=\"text-lg font-bold text-slate-900 dark:text-white mb-1\">Session About to Expire</h3><p class=\"text-slate-500 dark:text-slate-400 text-sm mb-3\">You will be logged out due to inactivity.</p><p id=\"countdownText\" class=\"text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4\">2:00</p><button onclick=\"keepSessionAlive()\" class=\"w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm\"><i class=\"fas fa-mouse-pointer mr-1.5\"></i> Keep Session Active</button></div></div>";
            document.body.appendChild(modal);
            
            var secondsLeft = 120;
            var countdownElement = document.getElementById('countdownText');
            var countdownInterval = setInterval(function() {
                secondsLeft--;
                var minutes = Math.floor(secondsLeft / 60);
                var seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = minutes + ':' + (seconds.toString().padStart(2, '0'));
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(function() { resetInactivityTimer(); })
                .catch(function() { resetInactivityTimer(); });
        }

        function hideWarningModal() {
            var modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        var events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(function(event) {
            document.addEventListener(event, resetInactivityTimer, false);
        });

        resetInactivityTimer();
        setInterval(function() {
            if (!warningShown) sendHeartbeat();
        }, 5 * 60 * 1000);
    </script>

</body>
</html>