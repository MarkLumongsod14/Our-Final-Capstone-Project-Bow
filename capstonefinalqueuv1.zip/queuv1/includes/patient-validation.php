<?php

function isValidPatientName($name, $allowEmpty = false) {
    if (!is_string($name)) {
        return false;
    }

    if ($name === '') {
        return $allowEmpty;
    }

    return preg_match('/^[\p{L} -]+$/u', $name) === 1;
}
