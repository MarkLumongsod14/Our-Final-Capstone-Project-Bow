<?php

$ceshAppPath = getenv('CESH_APP_PATH');
if (!$ceshAppPath) {
    $ceshAppPath = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'CESH';
}
require_once rtrim($ceshAppPath, '\\/') . DIRECTORY_SEPARATOR . 'unified_session.php';
UnifiedSession::activate('smart_queueing', true);
