<?php
// includes/SimpleEmailSender.php - Using Brevo SMTP

// Load PHPMailer autoloader
require_once dirname(__DIR__) . '/vendor/autoload.php';

// ============================================
// CONFIGURE THESE WITH YOUR BREVO CREDENTIALS
// ============================================
define('BREVO_SERVER', 'smtp-relay.brevo.com');
define('BREVO_PORT', 587);
define('BREVO_USERNAME', '87dc1d001@smtp-brevo.com'); // CHANGE THIS
define('BREVO_PASSWORD', 'bskFVA23yUGYU8i'); // CHANGE THIS
define('BREVO_FROM_EMAIL', 'mark.adrian.lumongsod@gmail.com');
define('BREVO_FROM_NAME', 'Camp Evangelista Station Hospital');

class SimpleEmailSender {
    
    public function sendNotification($to, $patient_name, $queue_number, $transaction_token, $clinic_name = null) {
        
        $subject = "Queue Registration Confirmation - Camp Evangelista Hospital";
        $message = $this->buildEmailMessage($patient_name, $queue_number, $transaction_token, $clinic_name);
        
        return $this->sendViaBrevo($to, $subject, $message);
    }
    
    private function sendViaBrevo($to, $subject, $message) {
        
        // Try PHPMailer if available
        if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            return $this->sendViaPHPMailer($to, $subject, $message);
        }
        
        // Fallback: Use cURL with Brevo's API
        return $this->sendViaBrevoAPI($to, $subject, $message);
    }
    
    private function sendViaPHPMailer($to, $subject, $message) {
        try {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            
            // Server settings
            $mail->isSMTP();
            $mail->Host       = BREVO_SERVER;
            $mail->SMTPAuth   = true;
            $mail->Username   = BREVO_USERNAME;
            $mail->Password   = BREVO_PASSWORD;
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = BREVO_PORT;
            
            // Recipients
            $mail->setFrom(BREVO_FROM_EMAIL, BREVO_FROM_NAME);
            $mail->addAddress($to);
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $message;
            
            $mail->send();
            return true;
            
        } catch (Exception $e) {
            error_log("Brevo SMTP Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Fallback: Send via Brevo's REST API (no PHPMailer required)
     */
    private function sendViaBrevoAPI($to, $subject, $message) {
        
        // Your Brevo API Key - Get from Settings → SMTP & API → API Keys
        $api_key = 'xkeysib-your-api-key-here'; // CHANGE THIS
        
        $data = [
            'sender' => [
                'email' => BREVO_FROM_EMAIL,
                'name' => BREVO_FROM_NAME
            ],
            'to' => [
                ['email' => $to]
            ],
            'subject' => $subject,
            'htmlContent' => $message
        ];
        
        $ch = curl_init('https://api.brevo.com/v3/smtp/email');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'api-key: ' . $api_key
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $http_code >= 200 && $http_code < 300;
    }
    
    private function buildEmailMessage($patient_name, $queue_number, $transaction_token, $clinic_name = null) {
        $tracking_url = "http://" . $_SERVER['HTTP_HOST'] . "/patient-portal/track-queue.php?token=" . urlencode($transaction_token);
        $clinic_text = $clinic_name ? "at <strong>" . htmlspecialchars($clinic_name) . "</strong>" : "";
        
        return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
</head>
<body style="font-family: Arial, sans-serif; background: #f5f7fa; padding: 20px;">
    <div style="max-width: 500px; margin: 0 auto; background: white; border-radius: 12px; padding: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
        
        <div style="text-align: center; border-bottom: 2px solid #1a3a5c; padding-bottom: 15px; margin-bottom: 20px;">
            <h2 style="color: #1a3a5c; margin: 0;">🏥 Camp Evangelista</h2>
            <p style="color: #666; margin: 5px 0 0 0; font-size: 13px;">Station Hospital</p>
        </div>
        
        <p style="font-size: 15px; color: #333;">Dear <strong>{$patient_name}</strong>,</p>
        
        <p style="font-size: 14px; color: #555; line-height: 1.6;">
            You have been successfully registered and queued {$clinic_text} at Camp Evangelista Station Hospital.
        </p>
        
        <div style="background: #f0f7ff; border: 2px dashed #4A90E2; border-radius: 10px; padding: 20px; text-align: center; margin: 20px 0;">
            <div style="font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 1px;">Your Queue Number</div>
            <div style="font-size: 32px; font-weight: 800; color: #1a3a5c; font-family: monospace; letter-spacing: 2px;">{$queue_number}</div>
        </div>
        
        <div style="background: #fff8e1; border: 1px solid #ffd54f; border-radius: 8px; padding: 12px 15px; margin: 15px 0;">
            <div style="font-size: 11px; color: #888; text-transform: uppercase; letter-spacing: 0.5px;">🔑 Your Private Tracking Token</div>
            <div style="font-family: monospace; font-size: 13px; font-weight: 700; color: #e65100; word-break: break-all; margin-top: 4px;">{$transaction_token}</div>
            <div style="font-size: 11px; color: #888; margin-top: 4px;">Keep this token private to track your queue status</div>
        </div>
        
        <div style="text-align: center; margin: 20px 0;">
            <a href="{$tracking_url}" style="display: inline-block; background: #4A90E2; color: white; padding: 10px 25px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 14px;">
                📍 Track Your Queue Status
            </a>
        </div>
        
        <div style="background: #fff3e0; border-left: 4px solid #ff9800; padding: 10px 15px; border-radius: 4px; margin: 15px 0;">
            <p style="margin: 0; font-size: 12px; color: #555;">
                <strong>📌 Please wait</strong> for your number to be called. You can check your queue position anytime using the link above.
            </p>
        </div>
        
        <div style="text-align: center; border-top: 1px solid #eee; padding-top: 15px; margin-top: 20px; font-size: 11px; color: #999;">
            Camp Evangelista Station Hospital<br>
            Camp Evangelista, Cagayan de Oro City<br>
            This is an automated message. Please do not reply.
        </div>
        
    </div>
</body>
</html>
HTML;
    }
}
?>