<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/SessionManager.php';

$ceshAppPath = getenv('CESH_APP_PATH') ?: dirname(__DIR__) . DIRECTORY_SEPARATOR . 'CESH';
require_once rtrim($ceshAppPath, '\\/') . DIRECTORY_SEPARATOR . 'unified_session.php';
header('Location: ' . UnifiedSession::logoutUrl());
exit;
session_start();

if (isset($_SESSION['user_id'])) {
	$database = new Database();
	$sessionManager = new SessionManager($database->getConnection());
	$sessionManager->logActivity('User logged out');
}

$_SESSION = [];
if (ini_get('session.use_cookies')) {
	$cookie = session_get_cookie_params();
	setcookie(session_name(), '', time() - 42000, $cookie['path'], $cookie['domain'], $cookie['secure'], $cookie['httponly']);
}
session_destroy();
header('Location: index.php');
exit();
?>