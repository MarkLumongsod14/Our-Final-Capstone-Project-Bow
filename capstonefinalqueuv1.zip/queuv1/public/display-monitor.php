<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
ini_set('log_errors', 1);

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';
require_once dirname(__DIR__) . '/includes/cache.php';

// Initialize database connection
$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

// Initialize cache
Cache::init();

// Cache clinic data for 60 seconds to reduce database hits
$cache_key = 'display_clinics';
$clinics = Cache::get($cache_key, 60);

if ($clinics === null) {
    // Run the actual database query (not "SELECT ...")
    $query = "SELECT c.*, 
              (SELECT COUNT(*) FROM queue_entries q 
               WHERE q.clinic_id = c.id 
               AND q.status IN ('waiting', 'called', 'in-progress') 
               AND DATE(q.registered_at) = CURDATE()) as active_patients
              FROM clinics c 
              ORDER BY c.clinic_order ASC, c.id ASC";
    
    $clinics = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
    Cache::set($cache_key, $clinics);
}

// Get current batch info
$batch_info = $queueManager->getCurrentBatch();
$batch_progress = ($batch_info['current_count'] / 20) * 100;

// Get all clinics - SIMPLE QUERY
$clinic_query = "SELECT * FROM clinics ORDER BY clinic_order ASC, id ASC";
$stmt = $db->prepare($clinic_query);
$stmt->execute();
$clinics_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

// DEBUG: Log what we got from the database
error_log("Raw clinics from DB: " . print_r(array_column($clinics_raw, 'id'), true));

// Build a clean array without any references
$clinics = [];
foreach ($clinics_raw as $row) {
    $clinics[] = $row;
}

// DEBUG: Log what we have after building
error_log("Clinics array after build: " . print_r(array_column($clinics, 'id'), true));

// Now add queue data to each clinic
$clinics_with_queue = [];
foreach ($clinics as $clinic) {
    $clinic_id = $clinic['id'];
    
    // Get current patient (in-progress)
    $current_query = "SELECT q.queue_number, p.first_name, p.last_name 
                      FROM queue_entries q
                      JOIN patients p ON q.patient_id = p.id
                      WHERE q.clinic_id = ? 
                      AND q.status = 'in-progress'
                      AND DATE(q.registered_at) = CURDATE()
                      LIMIT 1";
    $stmt = $db->prepare($current_query);
    $stmt->execute([$clinic_id]);
    $current = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $clinic['current_patient'] = $current['queue_number'] ?? null;
    $clinic['current_patient_name'] = $current ? ($current['first_name'] . ' ' . $current['last_name']) : null;
    
    // Get waiting count
    $waiting_query = "SELECT COUNT(*) as count 
                      FROM queue_entries 
                      WHERE clinic_id = ? 
                      AND status = 'waiting'
                      AND DATE(registered_at) = CURDATE()";
    $stmt = $db->prepare($waiting_query);
    $stmt->execute([$clinic_id]);
    $clinic['waiting_count'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Get in-progress count
    $progress_query = "SELECT COUNT(*) as count 
                       FROM queue_entries 
                       WHERE clinic_id = ? 
                       AND status = 'in-progress'
                       AND DATE(registered_at) = CURDATE()";
    $stmt = $db->prepare($progress_query);
    $stmt->execute([$clinic_id]);
    $clinic['in_progress'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
        // Get next 5 patients, keeping called patients visible until they are started.
    $next_query = "SELECT q.queue_number, q.status
                   FROM queue_entries q
                   WHERE q.clinic_id = ? 
                                     AND q.status IN ('called', 'waiting')
                   AND DATE(q.registered_at) = CURDATE()
                   ORDER BY 
                                         FIELD(q.status, 'called', 'waiting'),
                     FIELD(q.priority_level, 'PR1', 'PR2', 'PR3'),
                     q.registered_at ASC
                   LIMIT 5";
    $stmt = $db->prepare($next_query);
    $stmt->execute([$clinic_id]);
    $next_patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $clinic['next_patients_array'] = $next_patients;
    
    $clinics_with_queue[] = $clinic;
}

// DEBUG: Log final array
error_log("Final clinics: " . print_r(array_column($clinics_with_queue, 'id'), true));

// Use the new array
$clinics = $clinics_with_queue;

// Function to calculate wait time
function calculateWaitTime($position, $avg_service_time = 5) {
    return $position * $avg_service_time;
}

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $current_theme === 'dark' ? 'dark' : ''; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Queue Display - Camp Evangelista</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
            <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            min-height: 100vh;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #0A0F1E;
            color: #F3F4F6;
            padding: 20px;
            transition: background-color 0.3s ease, color 0.3s ease;
            overflow-y: auto !important;
            height: auto !important;
            min-height: 100vh;
        }

        body:not(.dark) {
            background: #F0F4F8;
            color: #1E293B;
        }

        .display-container {
            max-width: 1920px;
            margin: 0 auto;
            overflow: visible !important;
            height: auto !important;
            min-height: 100vh;
            padding-bottom: 80px;
        }

        /* Header Section */
        .hospital-header {
            background: linear-gradient(135deg, #0B1E33 0%, #1A2C40 100%);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid #2D3748;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        body:not(.dark) .hospital-header {
            background: linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%);
            border-color: #E2E8F0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }

        .hospital-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #2563EB, #38BDF8);
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .hospital-title h1 {
            font-size: 42px;
            font-weight: 800;
            color: #FFFFFF;
            letter-spacing: -0.5px;
            line-height: 1.2;
        }

        body:not(.dark) .hospital-title h1 {
            color: #0F172A;
        }

        .hospital-title h2 {
            font-size: 24px;
            font-weight: 500;
            color: #38BDF8;
            margin-top: 5px;
        }

        body:not(.dark) .hospital-title h2 {
            color: #2563EB;
        }

        .hospital-badge {
            background: rgba(56, 189, 248, 0.15);
            border: 1px solid #38BDF8;
            border-radius: 50px;
            padding: 12px 24px;
            font-size: 18px;
            font-weight: 600;
            color: #38BDF8;
        }

        body:not(.dark) .hospital-badge {
            background: rgba(37, 99, 235, 0.1);
            border-color: #2563EB;
            color: #2563EB;
        }

        /* Batch Info Cards */
        .batch-info-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 20px;
        }

        .batch-card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid #2D3748;
            border-radius: 20px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s ease;
        }

        body:not(.dark) .batch-card {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
        }

        .batch-card:hover {
            border-color: #38BDF8;
        }

        body:not(.dark) .batch-card:hover {
            border-color: #2563EB;
        }

        .batch-icon {
            width: 60px;
            height: 60px;
            background: rgba(56, 189, 248, 0.1);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        body:not(.dark) .batch-icon {
            background: #F1F5F9;
        }

        .batch-icon i {
            font-size: 30px;
            color: #38BDF8;
        }

        body:not(.dark) .batch-icon i {
            color: #2563EB;
        }

        .batch-info h3 {
            font-size: 14px;
            color: #94A3B8;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
            font-weight: 600;
        }

        body:not(.dark) .batch-info h3 {
            color: #64748B;
        }

        .batch-info .batch-number {
            font-size: 36px;
            font-weight: 700;
            color: #FFFFFF;
            line-height: 1;
        }

        body:not(.dark) .batch-info .batch-number {
            color: #0F172A;
        }

        .batch-progress {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid #2D3748;
            border-radius: 20px;
            padding: 20px;
            grid-column: span 2;
            transition: all 0.3s ease;
        }

        body:not(.dark) .batch-progress {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
        }

        .progress-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            color: #94A3B8;
        }

        body:not(.dark) .progress-header {
            color: #475569;
        }

        .progress-bar {
            height: 12px;
            background: #2D3748;
            border-radius: 6px;
            overflow: hidden;
            margin-bottom: 10px;
        }

        body:not(.dark) .progress-bar {
            background: #E2E8F0;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #2563EB, #38BDF8);
            border-radius: 6px;
            width: 0;
            transition: width 0.5s ease;
        }

        .wait-time {
            font-size: 18px;
            color: #38BDF8;
            font-weight: 600;
        }

        body:not(.dark) .wait-time {
            color: #2563EB;
        }

        /* Clinic Grid - 4 columns for 16 clinics */
        .clinic-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-top: 30px;
        }

        @media (max-width: 1400px) {
            .clinic-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 992px) {
            .clinic-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .clinic-grid {
                grid-template-columns: 1fr;
            }
        }

        .clinic-display-card {
            background: #141B2B;
            border: 1px solid #2D3748;
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
        }

        body:not(.dark) .clinic-display-card {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
        }

        .clinic-display-card:hover {
            transform: translateY(-4px);
            border-color: #38BDF8;
            box-shadow: 0 12px 24px -8px rgba(56, 189, 248, 0.15);
        }

        body:not(.dark) .clinic-display-card:hover {
            border-color: #2563EB;
            box-shadow: 0 12px 24px -8px rgba(37, 99, 235, 0.15);
        }

        .clinic-header {
            background: rgba(255, 255, 255, 0.03);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #2D3748;
            flex-shrink: 0;
        }

        body:not(.dark) .clinic-header {
            background: #F8FAFC;
            border-color: #E2E8F0;
        }

        .clinic-name {
            font-size: 18px;
            font-weight: 700;
            color: #FFFFFF;
            text-transform: uppercase;
        }

        body:not(.dark) .clinic-name {
            color: #0F172A;
        }

        .clinic-batch {
            background: #2563EB;
            color: #FFFFFF;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 700;
            box-shadow: 0 2px 4px rgba(37, 99, 235, 0.2);
        }

        .clinic-body {
            padding: 20px;
            flex: 1;
        }

        /* Current Patient Section */
        .current-patient {
            background: rgba(56, 189, 248, 0.08);
            border: 1px solid rgba(56, 189, 248, 0.2);
            border-radius: 15px;
            padding: 15px;
            margin-bottom: 20px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        body:not(.dark) .current-patient {
            background: #F0F9FF;
            border-color: #BAE6FD;
        }

        .current-patient::before {
            content: '● NOW SERVING';
            position: absolute;
            top: 8px;
            right: 12px;
            font-size: 11px;
            font-weight: 700;
            color: #38BDF8;
            opacity: 0.7;
        }

        body:not(.dark) .current-patient::before {
            color: #0369A1;
        }

        .current-label {
            font-size: 12px;
            color: #94A3B8;
            text-transform: uppercase;
            margin-bottom: 5px;
            font-weight: 600;
        }

        body:not(.dark) .current-label {
            color: #475569;
        }

        .current-number {
            font-size: 32px;
            font-weight: 800;
            color: #38BDF8;
            margin-bottom: 5px;
            letter-spacing: 1px;
            font-family: 'JetBrains Mono', monospace;
        }

        body:not(.dark) .current-number {
            color: #0369A1;
        }

        .current-name {
            font-size: 16px;
            color: #F3F4F6;
            font-weight: 500;
        }

        body:not(.dark) .current-name {
            color: #1E293B;
        }

        /* Next Patients List */
        .next-patients {
            margin-top: 15px;
        }

        .next-label {
            font-size: 12px;
            color: #94A3B8;
            text-transform: uppercase;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 5px;
            font-weight: 600;
        }

        body:not(.dark) .next-label {
            color: #475569;
        }

        .next-label i {
            color: #38BDF8;
        }

        body:not(.dark) .next-label i {
            color: #2563EB;
        }

        .next-list {
            list-style: none;
        }

        .next-item {
            display: flex;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #2D3748;
        }

        body:not(.dark) .next-item {
            border-bottom: 1px solid #F1F5F9;
        }

        .next-item:last-child {
            border-bottom: none;
        }

        .next-position {
            width: 28px;
            height: 28px;
            background: rgba(56, 189, 248, 0.1);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 600;
            color: #94A3B8;
            margin-right: 12px;
        }

        body:not(.dark) .next-position {
            background: #F1F5F9;
            color: #475569;
        }

        .next-number {
            flex: 1;
            font-size: 16px;
            font-weight: 600;
            color: #F3F4F6;
            font-family: 'JetBrains Mono', monospace;
        }

        body:not(.dark) .next-number {
            color: #0F172A;
        }

        /* Clinic Footer */
        .clinic-footer {
            background: rgba(255, 255, 255, 0.02);
            padding: 15px 20px;
            border-top: 1px solid #2D3748;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }

        body:not(.dark) .clinic-footer {
            background: #F8FAFC;
            border-color: #E2E8F0;
        }

        .wait-info {
            display: flex;
            align-items: center;
            gap: 6px;
            color: #38BDF8;
            font-size: 14px;
            font-weight: 600;
        }

        body:not(.dark) .wait-info {
            color: #2563EB;
        }

        .wait-info i {
            color: #F59E0B;
        }

        .queue-length {
            background: rgba(56, 189, 248, 0.1);
            color: #94A3B8;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        body:not(.dark) .queue-length {
            background: #E2E8F0;
            color: #475569;
        }

        .queue-length i {
            color: #38BDF8;
        }

        body:not(.dark) .queue-length i {
            color: #2563EB;
        }

        /* Refresh indicator */
        .refresh-indicator {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: rgba(20, 27, 43, 0.95);
            border: 1px solid #2D3748;
            border-radius: 50px;
            padding: 12px 24px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94A3B8;
            font-size: 14px;
            font-weight: 500;
            z-index: 1000;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }

        body:not(.dark) .refresh-indicator {
            background: #FFFFFF;
            border-color: #E2E8F0;
            color: #475569;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        .refresh-indicator i {
            color: #38BDF8;
            animation: spin 2s linear infinite;
        }

        body:not(.dark) .refresh-indicator i {
            color: #2563EB;
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /* No data state */
        .no-data {
            text-align: center;
            padding: 30px;
            color: #64748B;
            font-style: italic;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            font-size: 14px;
        }

        body:not(.dark) .no-data {
            background: #F8FAFC;
            color: #94A3B8;
        }

        /* Status Dot */
        .status-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #22C55E;
            animation: blink 1.5s infinite;
        }

        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0.4; }
            100% { opacity: 1; }
        }

        /* Debug footer */
        .debug-footer {
            margin-top: 30px;
            padding: 15px;
            background: #1E293B;
            border-radius: 12px;
            border: 1px solid #2D3748;
            text-align: center;
            font-size: 13px;
            color: #94A3B8;
        }

        body:not(.dark) .debug-footer {
            background: #F1F5F9;
            border-color: #E2E8F0;
        }

        .debug-footer strong {
            color: #38BDF8;
        }
    </style>
</head>
<body>
    <div class="display-container">
        <!-- Hospital Header -->
        <div class="hospital-header">
            <div class="header-top">
                <div class="hospital-title">
                    <h1>CAMP EVANGELISTA</h1>
                    <h2>STATION HOSPITAL</h2>
                </div>
                <div class="hospital-badge">
                    <i class="fas fa-shield-alt"></i> 4ID.P.A <span class="status-dot" style="margin-left: 10px;"></span>
                </div>
            </div>

            <!-- Batch Information -->
            <div class="batch-info-grid">
                <div class="batch-card">
                    <div class="batch-icon">
                        <i class="fas fa-layer-group"></i>
                    </div>
                    <div class="batch-info">
                        <h3>Current Batch</h3>
                        <div class="batch-number"><?php echo $batch_info['batch_number']; ?></div>
                    </div>
                </div>

                <div class="batch-progress">
                    <div class="progress-header">
                        <span>Progress to next batch</span>
                        <span class="wait-time"><?php echo round($batch_progress); ?>%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo $batch_progress; ?>%;"></div>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-top: 10px;">
                        <span style="color: #94A3B8;"><?php echo $batch_info['current_count']; ?>/20 patients</span>
                        <span class="wait-time">
                            <i class="fas fa-clock"></i> Est. wait: <?php echo $batch_info['current_count'] * 2; ?> mins
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Clinic Grid -->
        <div class="clinic-grid">
            <?php 
            $displayed_count = 0;
            $displayed_ids = [];
            foreach ($clinics as $clinic): 
                $displayed_count++;
                $displayed_ids[] = $clinic['id'];
            ?>
            <div class="clinic-display-card">
                <div class="clinic-header">
                    <span class="clinic-name">
                        <?php echo htmlspecialchars($clinic['name']); ?>
                        <span style="font-size: 10px; color: #64748B; font-weight: 400; margin-left: 8px;">
                            (ID: <?php echo $clinic['id']; ?>)
                        </span>
                    </span>
                    <?php if ((int) $clinic['is_active'] === 1): ?>
                        <span class="clinic-batch">BATCH <?php echo $batch_info['batch_number']; ?></span>
                    <?php else: ?>
                        <span class="clinic-batch" style="background: #475569; color: #E2E8F0;">CLOSED</span>
                    <?php endif; ?>
                </div>
                
                <div class="clinic-body">
                    <!-- Current Patient -->
                    <?php if ($clinic['current_patient']): ?>
                    <div class="current-patient">
                        <div class="current-label"><i class="fas fa-bell"></i> NOW SERVING</div>
                        <div class="current-number"><?php echo htmlspecialchars($clinic['current_patient']); ?></div>
                        <div class="current-name"><?php echo htmlspecialchars($clinic['current_patient_name'] ?? 'Patient'); ?></div>
                    </div>
                    <?php else: ?>
                    <div class="current-patient" style="border-color: #475569;">
                        <div class="current-label"><i class="fas fa-pause-circle"></i> NO ACTIVE PATIENT</div>
                        <div class="current-number">---</div>
                        <div class="current-name">Waiting for next</div>
                    </div>
                    <?php endif; ?>

                    <!-- Next 5 Patients -->
                    <div class="next-patients">
                        <div class="next-label">
                            <i class="fas fa-arrow-right"></i> NEXT 5 PATIENTS
                        </div>
                        <?php if (!empty($clinic['next_patients_array'])): ?>
                            <ul class="next-list">
                                <?php foreach ($clinic['next_patients_array'] as $index => $next): ?>
                                <li class="next-item">
                                    <span class="next-position"><?php echo $next['status'] === 'called' ? '!' : $index + 1; ?></span>
                                    <span class="next-number"><?php echo htmlspecialchars($next['queue_number']); ?></span>
                                    <?php if ($next['status'] === 'called'): ?>
                                        <span style="color: #2563EB; font-size: 11px; font-weight: 700;">UP NEXT</span>
                                    <?php endif; ?>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <div class="no-data">
                                <i class="fas fa-inbox" style="display: block; font-size: 24px; margin-bottom: 8px;"></i>
                                No patients in queue
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="clinic-footer">
                    <div class="wait-info">
                        <i class="fas fa-hourglass-half"></i>
                        WAIT TIME: <?php echo calculateWaitTime(count($clinic['next_patients_array']) + ($clinic['in_progress'] ? 1 : 0)); ?> MINS
                    </div>
                    <div class="queue-length">
                        <i class="fas fa-users"></i> <?php echo $clinic['waiting_count']; ?> in queue
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Debug Footer -->
        <div class="debug-footer">
            Total clinics displayed: <strong><?php echo $displayed_count; ?></strong> &nbsp;|&nbsp;
            IDs: <strong><?php echo implode(', ', $displayed_ids); ?></strong>
        </div>
        
        <!-- Check your PHP error log for the debug messages -->
        <div style="margin-top: 10px; text-align: center; font-size: 12px; color: #64748B;">
            Check your PHP error log for debug output
        </div>
    </div>

    <!-- Auto-refresh indicator
    <div class="refresh-indicator">
        <i class="fas fa-sync-alt"></i>
        <span>Updating in <span id="countdown">60</span>s</span>
    </div>

    <script>
        // Auto-refresh every 30 seconds
        var countdown = 60;
        var countdownEl = document.getElementById('countdown');
        
        setInterval(function() {
            countdown--;
            if (countdownEl) {
                countdownEl.textContent = countdown;
            }
            if (countdown <= 0) {
                location.reload();
            }
        }, 1000);
    </script> -->
        <!-- Refresh Button Only (No Auto-Refresh) -->
    <div class="refresh-controls" style="position: fixed; bottom: 20px; right: 20px; z-index: 999;">
        <button onclick="location.reload()" style="background: #2563EB; color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4);">
            <i class="fas fa-sync-alt"></i>  Refresh Display
        </button>
    </div>
</body>
</html>