<?php
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

// Get recent announcements
$since_time = date('Y-m-d H:i:s', strtotime('-5 minutes'));
$query = "SELECT q.queue_number, c.name AS clinic_name, q.called_at
          FROM queue_entries q
          JOIN clinics c ON q.clinic_id = c.id
          WHERE q.status = 'called' AND q.called_at >= :since_time
          ORDER BY q.called_at DESC
          LIMIT 10";
$stmt = $db->prepare($query);
$stmt->bindParam(':since_time', $since_time);
$stmt->execute();
$announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $current_theme === 'dark' ? 'dark' : ''; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - Camp Evangelista Hospital</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
               <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
 
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #0A0F1E;
            color: #F3F4F6;
            min-height: 100vh;
            padding: 20px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* Dark Mode Override */
        .dark body {
            background: #0A0F1E;
            color: #F3F4F6;
        }

        body:not(.dark) {
            background: #F0F4F8;
            color: #1E293B;
        }

        .announcement-container {
            max-width: 800px;
            margin: 50px auto;
        }

        .announcement-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .announcement-header h1 {
            font-size: 48px;
            font-weight: 800;
            color: #38BDF8;
            margin-bottom: 10px;
            letter-spacing: -0.5px;
        }

        body:not(.dark) .announcement-header h1 {
            color: #2563EB;
        }

        .announcement-header p {
            font-size: 18px;
            color: #64748B;
        }

        .audio-toggle {
            margin-top: 18px;
            padding: 10px 16px;
            border: 1px solid #0D9488;
            border-radius: 8px;
            background: #0D9488;
            color: #FFFFFF;
            font: inherit;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
        }

        .audio-toggle[aria-pressed="true"] { background: #0F766E; }

        .current-announcement {
            background: linear-gradient(135deg, #0B1E33 0%, #1A2C40 100%);
            border: 2px solid #38BDF8;
            border-radius: 30px;
            padding: 40px;
            text-align: center;
            margin-bottom: 40px;
            animation: pulse 2s infinite;
            transition: all 0.3s ease;
        }

        body:not(.dark) .current-announcement {
            background: linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%);
            border-color: #2563EB;
            box-shadow: 0 4px 20px rgba(37, 99, 235, 0.15);
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0.4); }
            70% { box-shadow: 0 0 0 20px rgba(56, 189, 248, 0); }
            100% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0); }
        }

        body:not(.dark) .current-announcement {
            animation: pulse-light 2s infinite;
        }

        @keyframes pulse-light {
            0% { box-shadow: 0 0 0 0 rgba(37, 99, 235, 0.3); }
            70% { box-shadow: 0 0 0 20px rgba(37, 99, 235, 0); }
            100% { box-shadow: 0 0 0 0 rgba(37, 99, 235, 0); }
        }

        .now-serving {
            font-size: 24px;
            color: #38BDF8;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 20px;
            font-weight: 700;
        }

        body:not(.dark) .now-serving {
            color: #2563EB;
        }

        .queue-number {
            font-size: 120px;
            font-weight: 800;
            color: #FFFFFF;
            margin-bottom: 20px;
            text-shadow: 0 0 20px rgba(56, 189, 248, 0.3);
            font-family: 'JetBrains Mono', monospace;
            line-height: 1;
        }

        body:not(.dark) .queue-number {
            color: #0F172A;
            text-shadow: 0 0 20px rgba(37, 99, 235, 0.15);
        }

        .clinic-name {
            font-size: 36px;
            color: #38BDF8;
            font-weight: 600;
        }

        body:not(.dark) .clinic-name {
            color: #2563EB;
        }

        .recent-announcements {
            background: #141B2B;
            border: 1px solid #2D3748;
            border-radius: 20px;
            padding: 30px;
            transition: all 0.3s ease;
        }

        body:not(.dark) .recent-announcements {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .recent-title {
            font-size: 24px;
            color: #F3F4F6;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
        }

        body:not(.dark) .recent-title {
            color: #0F172A;
        }

        .recent-title i {
            color: #38BDF8;
        }

        body:not(.dark) .recent-title i {
            color: #2563EB;
        }

        .announcement-list {
            list-style: none;
        }

        .announcement-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #2D3748;
            font-size: 18px;
            transition: background 0.2s;
            border-radius: 10px;
        }

        body:not(.dark) .announcement-item {
            border-bottom: 1px solid #F1F5F9;
        }

        .announcement-item:hover {
            background: rgba(56, 189, 248, 0.05);
        }

        body:not(.dark) .announcement-item:hover {
            background: #F8FAFC;
        }

        .announcement-item:last-child {
            border-bottom: none;
        }

        .announcement-time {
            width: 100px;
            color: #64748B;
            font-size: 14px;
            font-weight: 500;
        }

        .announcement-number {
            width: 150px;
            font-weight: 700;
            color: #38BDF8;
            font-size: 20px;
            font-family: 'JetBrains Mono', monospace;
        }

        body:not(.dark) .announcement-number {
            color: #2563EB;
        }

        .announcement-clinic {
            flex: 1;
            color: #F3F4F6;
            font-weight: 500;
        }

        body:not(.dark) .announcement-clinic {
            color: #1E293B;
        }

        .speaker-icon {
            width: 40px;
            height: 40px;
            background: #1E2639;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-left: 15px;
            transition: all 0.3s ease;
        }

        body:not(.dark) .speaker-icon {
            background: #F1F5F9;
        }

        .speaker-icon i {
            color: #38BDF8;
            font-size: 18px;
        }

        body:not(.dark) .speaker-icon i {
            color: #2563EB;
        }

        .speaker-icon.speaking {
            animation: speaking 0.8s infinite;
            background: #38BDF8;
        }

        body:not(.dark) .speaker-icon.speaking {
            background: #2563EB;
        }

        .speaker-icon.speaking i {
            color: #FFFFFF;
        }

        @keyframes speaking {
            0% { transform: scale(1); }
            50% { transform: scale(1.15); }
            100% { transform: scale(1); }
        }

        .no-announcements {
            text-align: center;
            padding: 40px;
            color: #64748B;
            font-style: italic;
            font-size: 16px;
        }

        /* Status Dot */
        .status-dot {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #22C55E;
            margin-right: 10px;
            animation: blink 1.5s infinite;
        }

        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0.4; }
            100% { opacity: 1; }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .announcement-header h1 {
                font-size: 32px;
            }
            
            .queue-number {
                font-size: 72px;
            }
            
            .clinic-name {
                font-size: 24px;
            }
            
            .announcement-item {
                flex-wrap: wrap;
                gap: 8px;
                font-size: 14px;
            }
            
            .announcement-time {
                width: 80px;
                font-size: 12px;
            }
            
            .announcement-number {
                width: 100px;
                font-size: 16px;
            }
            
            .current-announcement {
                padding: 30px 20px;
            }
        }

        @media (max-width: 480px) {
            .announcement-header h1 {
                font-size: 24px;
            }
            
            .queue-number {
                font-size: 56px;
            }
            
            .clinic-name {
                font-size: 20px;
            }
            
            .announcement-item {
                padding: 12px;
                flex-direction: column;
                align-items: flex-start;
            }
            
            .announcement-time {
                width: auto;
            }
            
            .announcement-number {
                width: auto;
            }
            
            .speaker-icon {
                width: 32px;
                height: 32px;
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="announcement-container">
        <div class="announcement-header">
            <h1>🏥 CAMP EVANGELISTA</h1>
            <p><span class="status-dot"></span> Patient Announcement System • Live</p>
            <button class="audio-toggle" id="audioToggle" type="button" aria-pressed="false">
                <i class="fas fa-volume-up"></i> Enable voice announcements
            </button>
        </div>

        <!-- Current Announcement Area -->
        <div class="current-announcement" id="currentAnnouncement">
            <div class="now-serving"><i class="fas fa-bell"></i> NOW SERVING</div>
            <div class="queue-number" id="currentQueueNumber">---</div>
            <div class="clinic-name" id="currentClinicName">Waiting for next patient</div>
        </div>

        <!-- Recent Announcements -->
        <div class="recent-announcements">
            <div class="recent-title">
                <i class="fas fa-history"></i>
                Recent Announcements
                <span style="margin-left: auto; font-size: 12px; color: #64748B; font-weight: 400;">
                    <i class="fas fa-volume-up"></i> Last 5 minutes
                </span>
            </div>
            
            <ul class="announcement-list" id="announcementList">
                <?php if (empty($announcements)): ?>
                    <li class="no-announcements">
                        <i class="fas fa-inbox" style="display: block; font-size: 36px; margin-bottom: 10px; color: #475569;"></i>
                        No recent announcements
                    </li>
                <?php else: ?>
                    <?php foreach ($announcements as $ann): ?>
                    <li class="announcement-item">
                        <span class="announcement-time"><i class="far fa-clock"></i> <?php echo date('h:i A', strtotime($ann['called_at'])); ?></span>
                        <span class="announcement-number"><?php echo $ann['queue_number']; ?></span>
                        <span class="announcement-clinic"><i class="fas fa-clinic-medical"></i> <?php echo $ann['clinic_name']; ?></span>
                        <div class="speaker-icon">
                            <i class="fas fa-volume-up"></i>
                        </div>
                    </li>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ul>
        </div>
        
        <div style="text-align: center; margin-top: 30px; color: #475569; font-size: 13px;">
            <i class="fas fa-sync-alt fa-spin"></i> Auto-updates every 5 seconds
        </div>
    </div>

    <script>
        var lastAnnouncementTime = '<?php echo date('Y-m-d H:i:s', strtotime('-1 minute')); ?>';
        var announcementQueue = [];
        var audioEnabled = false;
        var isSpeaking = false;
        var isCheckingAnnouncements = false;
        var audioToggle = document.getElementById('audioToggle');
        var speechSupported = 'speechSynthesis' in window;

        // Text-to-speech function
        function speak(text) {
            if (!('speechSynthesis' in window)) return;
            announcementQueue.push(text);
            speakNext();
        }

        function speakNext() {
            if (!audioEnabled || isSpeaking || !announcementQueue.length || !('speechSynthesis' in window)) return;

            isSpeaking = true;
            var utterance = new SpeechSynthesisUtterance(announcementQueue.shift());
            utterance.lang = 'en-US';
            utterance.rate = 0.9;
            utterance.pitch = 1;
            utterance.volume = 1;
            utterance.onstart = function() {
                document.querySelectorAll('.speaker-icon').forEach(function(icon) {
                    icon.classList.add('speaking');
                });
            };
            utterance.onend = finishSpeech;
            utterance.onerror = finishSpeech;
            window.speechSynthesis.speak(utterance);
        }

        function finishSpeech() {
            isSpeaking = false;
            document.querySelectorAll('.speaker-icon').forEach(function(icon) {
                icon.classList.remove('speaking');
            });
            speakNext();
        }

        audioToggle.addEventListener('click', function() {
            if (!speechSupported) return;
            audioEnabled = !audioEnabled;
            audioToggle.setAttribute('aria-pressed', String(audioEnabled));
            audioToggle.innerHTML = audioEnabled
                ? '<i class="fas fa-volume-up"></i> Voice announcements enabled'
                : '<i class="fas fa-volume-mute"></i> Enable voice announcements';
            if (audioEnabled) {
                window.speechSynthesis.resume();
                speak('Voice announcements enabled.');
            } else {
                announcementQueue = [];
                window.speechSynthesis.cancel();
                isSpeaking = false;
            }
        });

        if (!speechSupported) {
            audioToggle.disabled = true;
            audioToggle.textContent = 'Voice announcements unavailable in this browser';
        }

        // Check for new announcements
        function checkAnnouncements() {
            if (isCheckingAnnouncements) return;
            isCheckingAnnouncements = true;
            fetch('../api/announce.php?action=get_announcements&since=' + encodeURIComponent(lastAnnouncementTime))
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    if (data.success && data.announcements.length > 0) {
                        lastAnnouncementTime = data.announcements[0].called_at;
                        data.announcements.slice().reverse().forEach(function(ann) {
                            document.getElementById('currentQueueNumber').textContent = ann.queue_number;
                            document.getElementById('currentClinicName').textContent = ann.clinic_name;
                            speak('Attention please. Patient number ' + ann.queue_number + ', please proceed to ' + ann.clinic_name + '.');
                            addToRecentList(ann);
                        });
                    }
                })
                .catch(function(error) { console.error('Error checking announcements:', error); })
                .finally(function() { isCheckingAnnouncements = false; });
        }

        // Add announcement to recent list
        function addToRecentList(announcement) {
            var list = document.getElementById('announcementList');
            var time = new Date(announcement.called_at).toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            
            var newItem = document.createElement('li');
            newItem.className = 'announcement-item';
            newItem.innerHTML = '<span class="announcement-time"><i class="far fa-clock"></i> ' + time + '</span><span class="announcement-number">' + announcement.queue_number + '</span><span class="announcement-clinic"><i class="fas fa-clinic-medical"></i> ' + announcement.clinic_name + '</span><div class="speaker-icon"><i class="fas fa-volume-up"></i></div>';
            
            // Remove "no announcements" if present
            if (list.children.length === 1 && list.children[0].classList.contains('no-announcements')) {
                list.innerHTML = '';
            }
            
            list.insertBefore(newItem, list.firstChild);
            
            // Keep only last 10 announcements
            while (list.children.length > 10) {
                list.removeChild(list.lastChild);
            }
        }

        // Check for new announcements every 5 seconds
        setInterval(checkAnnouncements, 5000);

        // Initial check
        setTimeout(checkAnnouncements, 1000);
    </script>
</body>
</html>