<?php
require_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

$test_users = ['pedia_dr', 'cardio_dr', 'neuro_dr', 'ortho_dr', 'derma_dr', 'optha_dr', 'ent_dr', 'pt_staff'];

echo "<h2>Testing Clinic Accounts (9-16)</h2>";
echo "<table border='1' cellpadding='8'>";
echo "<tr><th>Username</th><th>Clinic ID</th><th>Role</th><th>is_active</th><th>locked_until</th><th>Password Test</th></tr>";

foreach ($test_users as $username) {
    $query = "SELECT * FROM users WHERE username = :username";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        $valid = password_verify('clinic123', $user['password']);
        $status = $valid ? "✅ VALID" : "❌ INVALID";
        $locked = $user['locked_until'] ?? 'NULL';
        $active = $user['is_active'] ? 'Yes' : 'No';
        
        echo "<tr>";
        echo "<td><strong>$username</strong></td>";
        echo "<td>{$user['clinic_id']}</td>";
        echo "<td>{$user['role']}</td>";
        echo "<td>$active</td>";
        echo "<td>$locked</td>";
        echo "<td style='color: " . ($valid ? 'green' : 'red') . ";'>$status</td>";
        echo "</tr>";
    } else {
        echo "<tr><td>$username</td><td colspan='5' style='color:red;'>❌ USER NOT FOUND</td></tr>";
    }
}
echo "</table>";
?>