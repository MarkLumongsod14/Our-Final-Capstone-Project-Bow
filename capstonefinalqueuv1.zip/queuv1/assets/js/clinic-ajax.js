// ========================================
// CLINIC QUEUE AJAX FUNCTIONS
// ========================================

/**
 * Show toast notification
 */
function showClinicToast(message, type = 'info') {
    const toast = document.createElement('div');
    const bgColor = type === 'success' ? 'bg-emerald-500' : 
                    type === 'error' ? 'bg-rose-500' : 
                    type === 'warning' ? 'bg-amber-500' : 'bg-sky-500';
    
    toast.className = `fixed top-4 right-4 px-6 py-3 rounded-lg font-bold text-white z-50 transition-all ${bgColor}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('opacity-0');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

/**
 * Call next patient via AJAX
 */
function callNextPatientAjax(clinicId) {
    console.log('Calling next patient for clinic:', clinicId);
    
    const formData = new FormData();
    formData.append('action', 'call_next');
    formData.append('clinic_id', clinicId);
    
    const apiUrl = new URL('../api/clinic-queue-action.php', window.location.href);
    console.log('API URL:', apiUrl);
    
    fetch(apiUrl, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
    })
    .then(response => {
        console.log('Response status:', response.status);
        return response.text();
    })
    .then(text => {
        console.log('Response text:', text);
        const data = JSON.parse(text);
        
        if (data.success) {
            showClinicToast('Next patient called!', 'success');
            setTimeout(() => location.reload(), 500);
        } else {
            showClinicToast('Error: ' + (data.error || 'Failed to call next patient'), 'error');
        }
    })
    .catch(error => {
        console.error('AJAX Error:', error);
        showClinicToast('Error: ' + error.message, 'error');
    });
    
    return false;
}

/**
 * Update patient status via AJAX
 */
function updatePatientStatusAjax(queueId, newStatus, clinicId) {
    console.log('Updating patient status:', queueId, newStatus, clinicId);
    
    const formData = new FormData();
    formData.append('action', 'update_status');
    formData.append('queue_id', queueId);
    formData.append('status', newStatus);
    formData.append('clinic_id', clinicId);
    
    const apiUrl = new URL('../api/clinic-queue-action.php', window.location.href);
    console.log('API URL:', apiUrl);
    
    fetch(apiUrl, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
    })
    .then(response => {
        console.log('Response status:', response.status);
        return response.text();
    })
    .then(text => {
        console.log('Response text:', text);
        const data = JSON.parse(text);
        
        if (data.success) {
            const statusText = newStatus === 'called' ? 'Called' :
                              newStatus === 'in-progress' ? 'Started' :
                              newStatus === 'no-show' ? 'Marked as no-show' : 'Completed';
            showClinicToast(`Patient ${statusText}!`, 'success');
            if (data.next_message) {
                setTimeout(() => showClinicToast(data.next_message, 'info'), 350);
            }
            setTimeout(() => location.reload(), 500);
        } else {
            showClinicToast('Error: ' + (data.error || 'Failed to update status'), 'error');
        }
    })
    .catch(error => {
        console.error('AJAX Error:', error);
        showClinicToast('Error: ' + error.message, 'error');
    });
    
    return false;
}

/**
 * Toggle clinic availability via AJAX
 */
function toggleClinicAjax(form) {
    const button = form.querySelector('.clinic-toggle-button');
    const wasActive = button.dataset.active === '1';

    if (!confirm((wasActive ? 'Close' : 'Open') + ' this clinic?')) return false;

    button.disabled = true;
    const formData = new FormData(form);
    formData.append('action', 'toggle_clinic');

    fetch('../api/clinic-queue-action.php', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
    })
        .then(response => response.json())
        .then(data => {
            if (!data.success) throw new Error(data.error || 'Clinic update failed');

            const active = Number(data.is_active) === 1;
            button.dataset.active = active ? '1' : '0';
            button.innerHTML = '<i class="fas ' + (active ? 'fa-pause' : 'fa-play') + ' mr-1"></i>' + (active ? 'Close Clinic' : 'Open Clinic');
            button.className = 'clinic-toggle-button px-3 py-2 rounded-lg text-xs font-bold ' + (active ? 'bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-400' : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400');
            showClinicToast(active ? 'Clinic opened.' : 'Clinic closed.', 'success');
        })
        .catch(error => showClinicToast(error.message, 'error'))
        .finally(() => { button.disabled = false; });

    return false;
}
