<?php
// get_patient_count.php - Get patient statistics
require_once 'db.php';
require_once 'auth.php';

$auth->requireLogin();
header('Content-Type: application/json');

$totalRes = $conn->query("SELECT COUNT(*) as total FROM patients WHERE status = 'Active'");
$total = $totalRes ? $totalRes->fetch_assoc()['total'] : 0;

// Get today's registrations
$todayRes = $conn->query("SELECT COUNT(*) as today FROM patients WHERE DATE(created_at) = CURDATE()");
$today = $todayRes ? $todayRes->fetch_assoc()['today'] : 0;

echo json_encode(['total' => $total, 'today' => $today]);
?>