<?php

require_once __DIR__ . '/unified_session.php';

class UnifiedAuth
{
    private mysqli $db;

    public function __construct()
    {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $this->db = new mysqli(
            getenv('AUTH_DB_HOST') ?: '127.0.0.1',
            getenv('AUTH_DB_USERNAME') ?: 'root',
            getenv('AUTH_DB_PASSWORD') ?: '',
            getenv('AUTH_DB_NAME') ?: 'hospital_identity'
        );
        $this->db->set_charset('utf8mb4');
    }

    public function login(
        string $username,
        string $password,
        int $captchaAnswer,
        ?string $selectedAccount = null
    ): array
    {
        $username = trim($username);
        if ($username === '' || $password === '') {
            return ['success' => false, 'message' => 'Enter your username and password.'];
        }

        if ($this->isLocked($username)) {
            return ['success' => false, 'message' => 'Too many failed attempts. Try again in 15 minutes.'];
        }

        $expectedCaptcha = (int)($_SESSION['unified_captcha_a'] ?? -1)
            + (int)($_SESSION['unified_captcha_b'] ?? -1);
        if ($captchaAnswer !== $expectedCaptcha) {
            $this->recordAttempt($username, false);
            $this->resetCaptcha();
            return ['success' => false, 'message' => 'Incorrect security check.'];
        }

        $matches = [];
        $outpatient = $this->db->prepare(
            "SELECT u.id, u.username, u.password, u.full_name, u.email, u.role,
                    u.status AS account_status, u.assigned_department, u.can_access_all_depts,
                    u.two_factor_secret AS twofa_secret, u.two_factor_enabled AS twofa_enabled,
                    NULL AS clinic_id, NULL AS clinic_name, NULL AS locked_until,
                    'outpatient' AS system_key
             FROM cesh_crm.users AS u
             WHERE u.username = ?"
        );
        $outpatient->bind_param('s', $username);
        $outpatient->execute();
        $result = $outpatient->get_result();
        while ($account = $result->fetch_assoc()) {
            if ($account['account_status'] !== 'Active' || !password_verify($password, $account['password'])) {
                continue;
            }
            $identityId = $this->getIdentityForAccount('outpatient', (int)$account['id']);
            if ($identityId !== null) {
                $matches[$identityId]['accounts']['outpatient'] = $account;
            }
        }
        $outpatient->close();

        $queue = $this->db->prepare(
            "SELECT u.id, u.username, u.password, u.full_name, u.email, u.role,
                    u.is_active AS account_status, NULL AS assigned_department,
                    0 AS can_access_all_depts, u.twofa_secret AS twofa_secret,
                    u.twofa_enabled AS twofa_enabled, u.clinic_id, c.name AS clinic_name,
                    u.locked_until, 'smart_queueing' AS system_key
             FROM hospital_queue_system.users AS u
             LEFT JOIN hospital_queue_system.clinics AS c ON c.id = u.clinic_id
             WHERE u.username = ?"
        );
        $queue->bind_param('s', $username);
        $queue->execute();
        $result = $queue->get_result();
        while ($account = $result->fetch_assoc()) {
            if (
                (isset($account['account_status']) && (int)$account['account_status'] !== 1)
                || (!empty($account['locked_until']) && strtotime($account['locked_until']) > time())
                || !password_verify($password, $account['password'])
            ) {
                continue;
            }
            $identityId = $this->getIdentityForAccount('smart_queueing', (int)$account['id']);
            if ($identityId !== null) {
                $matches[$identityId]['accounts']['smart_queueing'] = $account;
            }
        }
        $queue->close();

        $candidates = [];
        foreach ($matches as $candidateId => $match) {
            foreach ($match['accounts'] as $candidateSystem => $account) {
                $candidates[] = [
                    'identity_id' => (int)$candidateId,
                    'system' => $candidateSystem,
                    'role' => $account['role'],
                    'full_name' => $account['full_name'],
                ];
            }
        }

        if (count($candidates) > 1 && $selectedAccount === null) {
            return [
                'success' => false,
                'requires_account_selection' => true,
                'candidates' => $candidates,
            ];
        }

        $candidate = null;
        if ($selectedAccount !== null) {
            [$selectedSystem, $selectedIdentity] = array_pad(explode(':', $selectedAccount, 2), 2, '');
            $selectedIdentityId = filter_var($selectedIdentity, FILTER_VALIDATE_INT);
            foreach ($candidates as $availableCandidate) {
                if (
                    $availableCandidate['system'] === $selectedSystem
                    && $availableCandidate['identity_id'] === $selectedIdentityId
                ) {
                    $candidate = $availableCandidate;
                    break;
                }
            }
        } elseif (count($candidates) === 1) {
            $candidate = $candidates[0];
        }

        if ($candidate === null) {
            $this->recordAttempt($username, false);
            return [
                'success' => false,
                'message' => $selectedAccount === null
                    ? 'Invalid username or password.'
                    : 'The selected application account did not match those credentials.',
            ];
        }

        $identityId = $candidate['identity_id'];
        $system = $candidate['system'];
        if (!isset($this->loadActiveContexts($identityId)[$system])) {
            $this->recordAttempt($username, false);
            return ['success' => false, 'message' => 'No active application access is assigned to this account.'];
        }

        session_regenerate_id(true);
        $_SESSION['sso_identity_id'] = $identityId;
        $_SESSION['sso_login_username'] = $username;
        $_SESSION['sso_authenticated_at'] = time();
        $_SESSION['sso_contexts'] = [];
        unset($_SESSION['pending_2fa_user'], $_SESSION['2fa_user_id'], $_SESSION['2fa_username']);
        $this->recordAttempt($username, true);

        $entry = $this->enterSystem($identityId, $system);
        if (!empty($entry['requires_2fa'])) {
            $_SESSION['sso_pending_system'] = $system;
            return ['success' => false, 'requires_2fa' => true];
        }
        if (empty($entry['success'])) {
            return ['success' => false, 'message' => $entry['message'] ?? 'Unable to enter the selected application.'];
        }
        $_SESSION['sso_dashboard_url'] = $entry['url'];
        return ['success' => true, 'url' => $entry['url']];
    }

    public function getAvailableSystems(int $identityId): array
    {
        return $this->loadActiveContexts($identityId);
    }

    public function enterSystem(int $identityId, string $system, ?string $code = null): array
    {
        if (!in_array($system, ['outpatient', 'smart_queueing'], true)) {
            return ['success' => false, 'message' => 'Invalid application selection.'];
        }

        $contexts = $this->loadActiveContexts($identityId);
        if (!isset($contexts[$system])) {
            return ['success' => false, 'message' => 'This account does not have access to that application.'];
        }
        $account = $contexts[$system];

        if ((int)($account['twofa_enabled'] ?? 0) === 1) {
            if ($code === null) {
                return ['success' => false, 'requires_2fa' => true];
            }
            if ($this->isTwoFactorLocked($identityId, $system)) {
                return [
                    'success' => false,
                    'requires_2fa' => true,
                    'message' => 'Too many incorrect authenticator codes. Try again in 15 minutes.',
                ];
            }
            require_once __DIR__ . '/../queuv1/includes/GoogleAuthenticator.php';
            $authenticator = new GoogleAuthenticator();
            if (!$authenticator->verifyCode((string)($account['twofa_secret'] ?? ''), $code, 1)) {
                $this->recordTwoFactorAttempt($identityId, $system, false);
                return ['success' => false, 'requires_2fa' => true, 'message' => 'The authenticator code is invalid.'];
            }
            $this->recordTwoFactorAttempt($identityId, $system, true);
        }

        $_SESSION['sso_contexts'][$system] = $this->toSessionContext($account, $system);
        $_SESSION['sso_verified_systems'][$system] = time();
        unset($_SESSION['sso_pending_system']);

        return ['success' => true, 'url' => $this->dashboardUrl($account, $system)];
    }

    public function mergeIdentities(int $sourceIdentityId, int $targetIdentityId): void
    {
        if ($sourceIdentityId === $targetIdentityId) {
            throw new InvalidArgumentException('Select two different identities.');
        }

        $this->db->begin_transaction();
        try {
            $stmt = $this->db->prepare(
                'SELECT id FROM unified_identities WHERE id IN (?, ?) AND merged_into_id IS NULL FOR UPDATE'
            );
            $stmt->bind_param('ii', $sourceIdentityId, $targetIdentityId);
            $stmt->execute();
            $rows = $stmt->get_result()->num_rows;
            $stmt->close();
            if ($rows !== 2) {
                throw new RuntimeException('One or both identities are no longer available.');
            }

            $systemsStmt = $this->db->prepare(
                'SELECT system_key
                 FROM unified_accounts
                 WHERE identity_id IN (?, ?)
                 FOR UPDATE'
            );
            $systemsStmt->bind_param('ii', $sourceIdentityId, $targetIdentityId);
            $systemsStmt->execute();
            $systemRows = $systemsStmt->get_result();
            $existingSystems = [];
            while ($systemRow = $systemRows->fetch_assoc()) {
                if (isset($existingSystems[$systemRow['system_key']])) {
                    throw new RuntimeException('These identities already contain accounts from the same application.');
                }
                $existingSystems[$systemRow['system_key']] = true;
            }
            $systemsStmt->close();
            if (count($existingSystems) !== 2) {
                throw new RuntimeException('Each identity must contain a different application account.');
            }

            $move = $this->db->prepare('UPDATE unified_accounts SET identity_id = ? WHERE identity_id = ?');
            $move->bind_param('ii', $targetIdentityId, $sourceIdentityId);
            $move->execute();
            $move->close();

            $mark = $this->db->prepare('UPDATE unified_identities SET merged_into_id = ? WHERE id = ?');
            $mark->bind_param('ii', $targetIdentityId, $sourceIdentityId);
            $mark->execute();
            $mark->close();
            $this->db->commit();
        } catch (Throwable $exception) {
            $this->db->rollback();
            throw $exception;
        }
    }

    public function isSystemAdmin(int $identityId, string $system): bool
    {
        $contexts = $this->loadActiveContexts($identityId);
        return isset($contexts[$system]) && $contexts[$system]['role'] === 'admin';
    }

    public function verifyAdminPassword(int $identityId, string $system, string $password): bool
    {
        if (!in_array($system, ['outpatient', 'smart_queueing'], true) || !$this->isSystemAdmin($identityId, $system)) {
            return false;
        }
        $stmt = $this->db->prepare(
            'SELECT local_user_id FROM unified_accounts WHERE identity_id = ? AND system_key = ?'
        );
        $stmt->bind_param('is', $identityId, $system);
        $stmt->execute();
        $mapping = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$mapping) {
            return false;
        }

        $table = $system === 'outpatient' ? 'cesh_crm.users' : 'hospital_queue_system.users';
        $query = $this->db->prepare("SELECT password FROM $table WHERE id = ?");
        $query->bind_param('i', $mapping['local_user_id']);
        $query->execute();
        $row = $query->get_result()->fetch_assoc();
        $query->close();
        return $row && password_verify($password, $row['password']);
    }

    public static function registerAccount($connection, string $system, int $localUserId, string $displayName): void
    {
        if (!in_array($system, ['outpatient', 'smart_queueing'], true) || $localUserId <= 0) {
            throw new InvalidArgumentException('Invalid account mapping.');
        }
        if ($connection instanceof PDO) {
            $identity = $connection->prepare(
                'INSERT INTO hospital_identity.unified_identities (seed_system, seed_user_id, display_name)
                 VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE display_name = VALUES(display_name)'
            );
            $identity->execute([$system, $localUserId, $displayName]);
            $lookup = $connection->prepare(
                'SELECT id FROM hospital_identity.unified_identities
                 WHERE seed_system = ? AND seed_user_id = ?'
            );
            $lookup->execute([$system, $localUserId]);
            $identityId = (int)$lookup->fetchColumn();
            $account = $connection->prepare(
                'INSERT IGNORE INTO hospital_identity.unified_accounts (identity_id, system_key, local_user_id)
                 VALUES (?, ?, ?)'
            );
            $account->execute([$identityId, $system, $localUserId]);
            return;
        }
        if (!$connection instanceof mysqli) {
            throw new InvalidArgumentException('Unsupported account database connection.');
        }
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        $identity = $connection->prepare(
            'INSERT INTO hospital_identity.unified_identities (seed_system, seed_user_id, display_name)
             VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE display_name = VALUES(display_name)'
        );
        $identity->bind_param('sis', $system, $localUserId, $displayName);
        $identity->execute();
        $identity->close();

        $lookup = $connection->prepare(
            'SELECT id FROM hospital_identity.unified_identities
             WHERE seed_system = ? AND seed_user_id = ?'
        );
        $lookup->bind_param('si', $system, $localUserId);
        $lookup->execute();
        $identityId = (int)$lookup->get_result()->fetch_assoc()['id'];
        $lookup->close();

        $account = $connection->prepare(
            'INSERT IGNORE INTO hospital_identity.unified_accounts (identity_id, system_key, local_user_id)
             VALUES (?, ?, ?)'
        );
        $account->bind_param('isi', $identityId, $system, $localUserId);
        $account->execute();
        $account->close();
    }

    public function listIdentities(): array
    {
        $sql = "SELECT i.id, i.display_name, i.merged_into_id,
                       GROUP_CONCAT(DISTINCT a.system_key ORDER BY a.system_key SEPARATOR ',') AS systems,
                       GROUP_CONCAT(CONCAT(a.system_key, ':', COALESCE(c.username, q.username),
                                           ' [', a.local_user_id, ']')
                                    ORDER BY a.system_key SEPARATOR ', ') AS accounts
                FROM unified_identities AS i
                LEFT JOIN unified_accounts AS a ON a.identity_id = i.id
                LEFT JOIN cesh_crm.users AS c ON a.system_key = 'outpatient' AND c.id = a.local_user_id
                LEFT JOIN hospital_queue_system.users AS q ON a.system_key = 'smart_queueing' AND q.id = a.local_user_id
                WHERE i.merged_into_id IS NULL
                GROUP BY i.id, i.display_name, i.merged_into_id
                ORDER BY i.display_name, i.id";
        $result = $this->db->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }
        session_destroy();
    }

    private function getIdentityForAccount(string $system, int $localUserId): ?int
    {
        $stmt = $this->db->prepare(
            'SELECT a.identity_id
             FROM unified_accounts AS a
             JOIN unified_identities AS i ON i.id = a.identity_id
             WHERE a.system_key = ? AND a.local_user_id = ? AND i.merged_into_id IS NULL'
        );
        $stmt->bind_param('si', $system, $localUserId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ? (int)$row['identity_id'] : null;
    }

    private function loadActiveContexts(int $identityId): array
    {
        $contexts = [];
        $stmt = $this->db->prepare(
            'SELECT system_key, local_user_id
             FROM unified_accounts
             WHERE identity_id = ?
             ORDER BY system_key'
        );
        $stmt->bind_param('i', $identityId);
        $stmt->execute();
        $accounts = $stmt->get_result();
        while ($mapped = $accounts->fetch_assoc()) {
            if ($mapped['system_key'] === 'outpatient') {
                $query = $this->db->prepare(
                    "SELECT id, username, full_name, email, role, status, assigned_department,
                            can_access_all_depts, two_factor_secret AS twofa_secret,
                            two_factor_enabled AS twofa_enabled
                     FROM cesh_crm.users WHERE id = ?"
                );
                $query->bind_param('i', $mapped['local_user_id']);
                $query->execute();
                $account = $query->get_result()->fetch_assoc();
                $query->close();
                if ($account && $account['status'] === 'Active') {
                    $account['system_key'] = 'outpatient';
                    $contexts['outpatient'] = $account;
                }
            } else {
                $query = $this->db->prepare(
                    "SELECT u.id, u.username, u.full_name, u.email, u.role, u.is_active,
                            u.clinic_id, u.twofa_secret, u.twofa_enabled, u.locked_until,
                            c.name AS clinic_name
                     FROM hospital_queue_system.users AS u
                     LEFT JOIN hospital_queue_system.clinics AS c ON c.id = u.clinic_id
                     WHERE u.id = ?"
                );
                $query->bind_param('i', $mapped['local_user_id']);
                $query->execute();
                $account = $query->get_result()->fetch_assoc();
                $query->close();
                if (
                    $account
                    && (!isset($account['is_active']) || (int)$account['is_active'] === 1)
                    && (empty($account['locked_until']) || strtotime($account['locked_until']) <= time())
                ) {
                    $account['system_key'] = 'smart_queueing';
                    $contexts['smart_queueing'] = $account;
                }
            }
        }
        $stmt->close();
        return $contexts;
    }

    private function toSessionContext(array $account, string $system): array
    {
        $context = [
            'user_id' => (int)$account['id'],
            'username' => $account['username'],
            'full_name' => $account['full_name'],
            'email' => $account['email'] ?? '',
            'role' => $account['role'],
            'logged_in' => true,
            'login_time' => time(),
        ];
        if ($system === 'outpatient') {
            $context['assigned_department'] = $account['assigned_department'] ?? 'General';
            $context['can_access_all_depts'] = (int)($account['can_access_all_depts'] ?? 0);
        } else {
            $context['clinic_id'] = $account['clinic_id'] ?? null;
            $context['clinic_name'] = $account['clinic_name'] ?? null;
            $context['last_activity'] = time();
        }
        return $context;
    }

    private function dashboardUrl(array $account, string $system): string
    {
        if ($system === 'outpatient') {
            if ($account['role'] === 'admin') {
                return 'index.php';
            }
            if ($account['role'] === 'doctor') {
                return 'queue_doctor.php?dept=' . urlencode($account['assigned_department'] ?? 'General');
            }
            if ($account['role'] === 'nurse') {
                return 'registration.php';
            }
            return 'frontdesk_dashboard.php?dept=' . urlencode($account['assigned_department'] ?? 'General');
        }
        if (in_array($account['role'], ['admin', 'admin_dashboard'], true)) {
            return '../queuv1/admin/dashboard.php';
        }
        return '../queuv1/staff/clinic-dashboard.php?clinic_id=' . urlencode((string)($account['clinic_id'] ?? ''));
    }

    private function isLocked(string $username): bool
    {
        $username = strtolower($username);
        $stmt = $this->db->prepare(
            'SELECT COUNT(*) AS failed_count, MIN(attempted_at) AS first_failure
             FROM unified_login_attempts
             WHERE username = ? AND succeeded = 0
               AND attempted_at > COALESCE(
                   (SELECT MAX(attempted_at) FROM unified_login_attempts
                    WHERE username = ? AND succeeded = 1),
                   DATE_SUB(NOW(), INTERVAL 15 MINUTE)
               )
               AND attempted_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)'
        );
        $stmt->bind_param('ss', $username, $username);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return (int)$row['failed_count'] >= 5;
    }

    private function recordAttempt(string $username, bool $succeeded): void
    {
        $username = strtolower($username);
        $ip = substr((string)($_SERVER['REMOTE_ADDR'] ?? 'Unknown'), 0, 45);
        $success = $succeeded ? 1 : 0;
        $stmt = $this->db->prepare(
            'INSERT INTO unified_login_attempts (username, ip_address, succeeded) VALUES (?, ?, ?)'
        );
        $stmt->bind_param('ssi', $username, $ip, $success);
        $stmt->execute();
        $stmt->close();
    }

    private function resetCaptcha(): void
    {
        $_SESSION['unified_captcha_a'] = random_int(1, 9);
        $_SESSION['unified_captcha_b'] = random_int(1, 9);
    }

    private function isTwoFactorLocked(int $identityId, string $system): bool
    {
        $stmt = $this->db->prepare(
            'SELECT COUNT(*) AS failed_count
             FROM unified_two_factor_attempts
             WHERE identity_id = ? AND system_key = ? AND succeeded = 0
               AND attempted_at > COALESCE(
                   (SELECT MAX(attempted_at) FROM unified_two_factor_attempts
                    WHERE identity_id = ? AND system_key = ? AND succeeded = 1),
                   DATE_SUB(NOW(), INTERVAL 15 MINUTE)
               )
               AND attempted_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)'
        );
        $stmt->bind_param('isis', $identityId, $system, $identityId, $system);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return (int)$row['failed_count'] >= 5;
    }

    private function recordTwoFactorAttempt(int $identityId, string $system, bool $succeeded): void
    {
        $success = $succeeded ? 1 : 0;
        $stmt = $this->db->prepare(
            'INSERT INTO unified_two_factor_attempts (identity_id, system_key, succeeded)
             VALUES (?, ?, ?)'
        );
        $stmt->bind_param('isi', $identityId, $system, $success);
        $stmt->execute();
        $stmt->close();
    }
}

function unified_csrf_token(): string
{
    if (empty($_SESSION['unified_csrf'])) {
        $_SESSION['unified_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['unified_csrf'];
}

function unified_csrf_valid(): bool
{
    return isset($_SESSION['unified_csrf'], $_POST['csrf_token'])
        && hash_equals($_SESSION['unified_csrf'], (string)$_POST['csrf_token']);
}
