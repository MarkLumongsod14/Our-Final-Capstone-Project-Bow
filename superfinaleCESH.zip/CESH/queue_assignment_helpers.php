<?php
function getLeastLoadedAvailableDoctorId(mysqli $conn, string $department): ?int
{
    $stmt = $conn->prepare("
        SELECT u.id,
               (
                   SELECT COUNT(*)
                   FROM queue active_queue
                   WHERE active_queue.doctor_id = u.id
                     AND active_queue.status IN ('Waiting', 'In Consultation')
                     AND (
                         active_queue.department = ?
                         OR (? = 'General Medicine' AND active_queue.department = 'General')
                     )
               ) AS active_load,
               (
                   SELECT MAX(assigned_queue.id)
                   FROM queue assigned_queue
                   WHERE assigned_queue.doctor_id = u.id
                     AND (
                         assigned_queue.department = ?
                         OR (? = 'General Medicine' AND assigned_queue.department = 'General')
                     )
               ) AS last_assigned_id
        FROM users u
        WHERE u.role = 'doctor'
          AND u.status = 'Active'
          AND u.is_available = 1
          AND (
              u.assigned_department = ?
              OR (? = 'General Medicine' AND u.assigned_department = 'General')
          )
        ORDER BY active_load ASC, last_assigned_id IS NOT NULL ASC, last_assigned_id ASC, u.id ASC
        LIMIT 1
        FOR UPDATE
    ");
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare automatic doctor assignment: ' . $conn->error);
    }

    $stmt->bind_param(
        'ssssss',
        $department,
        $department,
        $department,
        $department,
        $department,
        $department
    );
    if (!$stmt->execute()) {
        $error = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Unable to select an available doctor: ' . $error);
    }

    $doctor = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $doctor ? (int)$doctor['id'] : null;
}
