<?php

define('BREVO_SERVER', getenv('BREVO_SERVER') ?: 'smtp-relay.brevo.com');
define('BREVO_PORT', (int)(getenv('BREVO_PORT') ?: 587));
define('BREVO_USERNAME', getenv('BREVO_USERNAME') ?: '87dc1d001@smtp-brevo.com');
define('BREVO_PASSWORD', getenv('BREVO_PASSWORD') ?: 'bskFVA23yUGYU8i');
define('BREVO_FROM_EMAIL', getenv('BREVO_FROM_EMAIL') ?: 'mark.adrian.lumongsod@gmail.com');
define('BREVO_FROM_NAME', getenv('BREVO_FROM_NAME') ?: 'Camp Evangelista Station Hospital');
define('BREVO_CRON_TOKEN', getenv('BREVO_CRON_TOKEN') ?: '');
