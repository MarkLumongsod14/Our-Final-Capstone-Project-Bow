<?php

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/brevo_mailer.php';

date_default_timezone_set('Asia/Manila');
header('Content-Type: application/json');

$providedToken = PHP_SAPI === 'cli' ? '' : ($_GET['token'] ?? $_SERVER['HTTP_X_CRON_TOKEN'] ?? '');
if (PHP_SAPI !== 'cli' && (!BREVO_CRON_TOKEN || !hash_equals(BREVO_CRON_TOKEN, $providedToken))) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid reminder worker token.']);
    exit;
}

$now = date('Y-m-d H:i:s');
$nextDay = date('Y-m-d H:i:s', strtotime('+24 hours'));
$stmt = $conn->prepare("SELECT a.id, a.date, a.time, a.provider, a.type, a.notes,
                               p.first_name, p.last_name, p.email
                        FROM appointments a
                        JOIN patients p ON a.patient_mrn = p.mrn
                        LEFT JOIN appointment_email_log l
                                                    ON l.appointment_id = a.id AND l.email_type = '24_hour_reminder'
                                                WHERE TIMESTAMP(a.date, a.time) > ?
                                                    AND TIMESTAMP(a.date, a.time) <= ?
                          AND a.status NOT IN ('Cancelled', 'Completed')
                          AND p.email IS NOT NULL AND p.email != ''
                          AND l.id IS NULL
                        ORDER BY a.time ASC");

if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Could not prepare reminder query. Run the database migration first.']);
    exit;
}

$stmt->bind_param('ss', $now, $nextDay);
$stmt->execute();
$appointments = $stmt->get_result();
$sent = 0;
$failed = [];

while ($appointment = $appointments->fetch_assoc()) {
    $patientName = trim($appointment['first_name'] . ' ' . $appointment['last_name']);
    $dateText = date('F j, Y', strtotime($appointment['date']));

    $email = sendBrevoEmail(
        $appointment['email'],
        $patientName,
        'Appointment reminder - ' . $dateText,
        buildAppointmentEmailHtml($patientName, $appointment['date'], $appointment['time'], $appointment['type'], $appointment['provider'], $appointment['notes'], true)
    );

    if ($email['success']) {
        $log = $conn->prepare("INSERT INTO appointment_email_log (appointment_id, email_type, recipient_email, sent_at) VALUES (?, '24_hour_reminder', ?, NOW())");
        $log->bind_param('is', $appointment['id'], $appointment['email']);
        $log->execute();
        $log->close();
        $sent++;
    } else {
        $failed[] = ['appointment_id' => $appointment['id'], 'error' => $email['error']];
    }
}

$stmt->close();
echo json_encode(['success' => count($failed) === 0, 'from' => $now, 'until' => $nextDay, 'sent' => $sent, 'failed' => $failed]);
