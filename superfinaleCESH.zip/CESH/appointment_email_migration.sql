ALTER TABLE patients ADD COLUMN email VARCHAR(255) NULL AFTER contact;

CREATE TABLE IF NOT EXISTS appointment_email_log (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    appointment_id INT NOT NULL,
    email_type VARCHAR(50) NOT NULL,
    recipient_email VARCHAR(255) NOT NULL,
    sent_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY unique_appointment_email (appointment_id, email_type),
    KEY idx_email_log_appointment (appointment_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;