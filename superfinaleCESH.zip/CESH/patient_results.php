<?php
// Patient Results for CESH doctors, backed by linked QUEUV1 outpatient records.
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once dirname(__DIR__) . '/queuv1/config/database.php';

$auth->requireRole(['doctor']);
$current_user = $auth->currentUser();

function patientResultsEscape($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function patientResultsMrn($mrn) {
    return str_pad((string)$mrn, 6, '0', STR_PAD_LEFT);
}

$search = isset($_GET['search']) && is_string($_GET['search']) ? trim($_GET['search']) : '';
$pageSize = 10;
$page = max(1, (int)($_GET['page'] ?? 1));
$error = '';
$patients = [];
$total = 0;
$totalPages = 1;
$resultsByPatient = [];

try {
    $queueDatabase = new Database();
    $queueDb = $queueDatabase->getConnection();
    if (!$queueDb) {
        throw new RuntimeException('Could not connect to Smart Queueing.');
    }

    // Outpatient registrations sourced from CESH use MRN followed by six digits.
    $outpatientStmt = $queueDb->query("
        SELECT id, mrn, first_name, middle_name, last_name, suffix
        FROM patients
        WHERE mrn REGEXP '^MRN[0-9]{6}$'
        ORDER BY created_at DESC, id DESC
    ");
    $queuePatients = $outpatientStmt->fetchAll(PDO::FETCH_ASSOC);
    $mrnNumbers = [];
    foreach ($queuePatients as $queuePatient) {
        $mrnNumbers[] = (int)substr($queuePatient['mrn'], 3);
    }
    $mrnNumbers = array_values(array_unique($mrnNumbers));

    $ceshPatientsByMrn = [];
    if ($mrnNumbers) {
        // Values are digit-only integers derived from the strict QUEUV1 MRN pattern above.
        $mrnList = implode(',', $mrnNumbers);
        $ceshResult = $conn->query("
            SELECT mrn, first_name, middle_name, last_name, suffix, dob, gender
            FROM patients
            WHERE mrn IN ($mrnList)
        ");
        if (!$ceshResult) {
            throw new RuntimeException('Could not load CESH patient records.');
        }
        foreach ($ceshResult->fetch_all(MYSQLI_ASSOC) as $ceshPatient) {
            $ceshPatientsByMrn['MRN' . patientResultsMrn($ceshPatient['mrn'])] = $ceshPatient;
        }
    }

    $outpatients = [];
    foreach ($queuePatients as $queuePatient) {
        $matchedCeshPatient = $ceshPatientsByMrn[$queuePatient['mrn']] ?? null;
        if (!$matchedCeshPatient) {
            continue;
        }

        $patientName = trim(
            $matchedCeshPatient['last_name'] . ', ' .
            $matchedCeshPatient['first_name'] . ' ' .
            ($matchedCeshPatient['middle_name'] ?? '') . ' ' .
            ($matchedCeshPatient['suffix'] ?? '')
        );
        $searchHaystack = $patientName . ' ' . $queuePatient['mrn'];
        if ($search !== '' && stripos($searchHaystack, $search) === false) {
            continue;
        }

        $outpatients[] = [
            'queue_id' => (int)$queuePatient['id'],
            'mrn' => $queuePatient['mrn'],
            'name' => $patientName,
            'dob' => $matchedCeshPatient['dob'] ?? '',
            'gender' => $matchedCeshPatient['gender'] ?? ''
        ];
    }

    $total = count($outpatients);
    $totalPages = max(1, (int)ceil($total / $pageSize));
    $page = min($page, $totalPages);
    $patients = array_slice($outpatients, ($page - 1) * $pageSize, $pageSize);

    if ($patients) {
        $queuePatientIds = array_column($patients, 'queue_id');
        $placeholders = implode(',', array_fill(0, count($queuePatientIds), '?'));
        $resultsStmt = $queueDb->prepare("
            SELECT cr.id, cr.patient_id, cr.result_data, cr.findings, cr.recommendations,
                   cr.status AS result_status, cr.submitted_at,
                   c.name AS clinic_name, q.queue_number, u.full_name AS submitted_by
            FROM clinic_results cr
            JOIN clinics c ON c.id = cr.clinic_id
            LEFT JOIN queue_entries q ON q.id = cr.queue_entry_id
            LEFT JOIN users u ON u.id = cr.submitted_by
            WHERE cr.patient_id IN ($placeholders)
            ORDER BY cr.submitted_at DESC, cr.id DESC
        ");
        $resultsStmt->execute($queuePatientIds);
        foreach ($resultsStmt->fetchAll(PDO::FETCH_ASSOC) as $result) {
            $resultsByPatient[(int)$result['patient_id']][] = $result;
        }
    }
} catch (Throwable $exception) {
    error_log('Patient results draft: ' . $exception->getMessage());
    $error = 'Patient results could not be loaded. Please try again or contact support.';
}

$pageUrl = static function ($targetPage) use ($search) {
    $params = ['page' => $targetPage];
    if ($search !== '') {
        $params['search'] = $search;
    }
    return 'patient_results.php?' . http_build_query($params);
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Results | 4ID Station Hospital</title>
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>tailwind.config = { darkMode: 'class' };</script>
    <style>
        summary::-webkit-details-marker { display: none; }
        details[open] > summary .patient-folder-chevron,
        details[open] > summary .clinic-folder-chevron { transform: rotate(180deg); }
    </style>
</head>
<body class="min-h-screen bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased transition-colors duration-200">
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div class="overflow-y-auto">
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none"><span>C</span><span>E</span><span>S</span><span>H</span></div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="assets/images/logo.png" alt="4ID Station Hospital logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li><a href="queue_doctor.php?dept=<?= urlencode($current_user['assigned_department'] ?? 'General') ?>" class="flex items-center rounded-xl font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link"><div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-stethoscope text-base text-slate-400 group-hover/link:text-sky-500"></i></div><span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity">Queue Management</span></a></li>
                    <li><a href="https://localhost/queuv1/staff/registration.php" target="_blank" rel="noopener noreferrer" class="flex items-center rounded-xl font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link"><div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-plus text-base text-slate-400 group-hover/link:text-sky-500"></i></div><span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity">Smart Queuing Registration</span></a></li>
                    <li><a href="patient_results.php" aria-current="page" class="flex items-center rounded-xl font-semibold bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3"><div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-file-medical text-base"></i></div><span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity">Patient Results</span></a></li>
                    <li><a href="queue_display.php" class="flex items-center rounded-xl font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link"><div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-tv text-base text-slate-400 group-hover/link:text-sky-500"></i></div><span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity">Queue Display</span></a></li>
                    <?php if (($current_user['role'] ?? '') === 'admin'): ?>
                    <li><a href="admin/users.php" class="flex items-center rounded-xl font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link"><div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-shield text-base text-slate-400 group-hover/link:text-sky-500"></i></div><span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity">User Management</span></a></li>
                    <?php endif; ?>
                </ul>
                <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
                    <a href="logout.php" class="flex items-center rounded-xl font-medium text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link"><div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-sign-out-alt text-base"></i></div><span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity">Logout</span></a>
                </div>
            </nav>
        </div>
    </aside>

    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" type="button" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl" aria-label="Open navigation menu"><i class="fas fa-bars text-xl"></i></button>
                <div>
                    <p class="text-xs font-bold uppercase tracking-widest text-sky-600 dark:text-sky-400">Doctor Portal</p>
                    <h1 class="mt-1 text-2xl font-extrabold">Patient Results</h1>
                    <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Outpatients registered in Smart Queueing and their submitted clinic results.</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300"><?= patientResultsEscape($current_user['full_name'] ?? '') ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400">Doctor</div>
                </div>
                <button id="themeToggle" type="button" class="w-10 h-10 rounded-xl bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-300" aria-label="Toggle dark mode"><i class="fas fa-moon dark:hidden"></i><i class="fas fa-sun hidden dark:inline"></i></button>
            </div>
        </header>

        <?php if ($error !== ''): ?>
            <div class="mb-5 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300" role="alert">
                <?= patientResultsEscape($error) ?>
            </div>
        <?php else: ?>
            <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-700 dark:bg-[#1f2937]">
                <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 p-5 dark:border-slate-700">
                    <div>
                        <h2 class="font-bold">Outpatient records</h2>
                        <p class="mt-1 text-xs text-slate-500 dark:text-slate-400"><?= number_format($total) ?> matching patient(s)</p>
                    </div>
                    <form method="get" class="flex items-center gap-2 rounded-xl border border-slate-300 px-3 py-2 dark:border-slate-600">
                        <i class="fas fa-search text-slate-400" aria-hidden="true"></i>
                        <input type="search" name="search" value="<?= patientResultsEscape($search) ?>" placeholder="Search name or MRN" aria-label="Search outpatient patients" class="w-44 bg-transparent text-sm outline-none md:w-60">
                        <button type="submit" class="text-sm font-bold text-sky-600 dark:text-sky-400">Search</button>
                    </form>
                </div>

                <?php if (!$patients): ?>
                    <div class="p-12 text-center text-sm text-slate-500 dark:text-slate-400">
                        <?= $search !== '' ? 'No outpatient records match your search.' : 'No linked outpatient registrations were found.' ?>
                    </div>
                <?php else: ?>
                    <div class="space-y-4 p-4 md:p-5">
                        <?php foreach ($patients as $patient): ?>
                            <?php
                                $patientResults = $resultsByPatient[$patient['queue_id']] ?? [];
                                $resultsByClinic = [];
                                foreach ($patientResults as $patientResult) {
                                    $resultsByClinic[$patientResult['clinic_name']][] = $patientResult;
                                }
                                $patientFolderId = 'patient-folder-' . (int)$patient['queue_id'];
                                $initials = strtoupper(substr($patient['name'], 0, 1));
                            ?>
                            <details class="patient-folder overflow-hidden rounded-xl border border-slate-300 bg-white shadow-sm dark:border-slate-700 dark:bg-[#1f2937]">
                                <summary class="flex cursor-pointer list-none items-center justify-between gap-4 p-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 [&::-webkit-details-marker]:hidden">
                                    <span class="flex min-w-0 items-center gap-3">
                                        <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-sky-50 font-bold text-sky-600 dark:bg-sky-500/10 dark:text-sky-400"><?= patientResultsEscape($initials) ?></span>
                                        <span class="min-w-0">
                                            <span class="block truncate text-sm font-extrabold text-slate-900 dark:text-white"><?= patientResultsEscape($patient['name']) ?></span>
                                            <span class="mt-1 block text-xs text-slate-500 dark:text-slate-400">
                                                <?php if ($patient['dob'] !== ''): ?><i class="fas fa-calendar-alt mr-1"></i>DOB: <?= patientResultsEscape(date('M j, Y', strtotime($patient['dob']))) ?><?php endif; ?>
                                                <?php if ($patient['gender'] !== ''): ?><span class="ml-2"><i class="fas fa-venus-mars mr-1"></i><?= patientResultsEscape($patient['gender']) ?></span><?php endif; ?>
                                            </span>
                                        </span>
                                    </span>
                                    <span class="flex shrink-0 items-center gap-3">
                                        <span class="hidden rounded-full bg-sky-50 px-3 py-1 font-mono text-[0.65rem] font-bold tracking-wider text-sky-600 dark:bg-sky-500/10 dark:text-sky-400 sm:inline-flex"><i class="fas fa-id-card mr-1.5"></i>MRN: <?= patientResultsEscape(substr($patient['mrn'], 3)) ?></span>
                                        <span class="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-300"><?= count($patientResults) ?> result(s)</span>
                                        <i class="patient-folder-chevron fas fa-chevron-down text-slate-400 transition-transform"></i>
                                    </span>
                                </summary>
                                <div id="<?= patientResultsEscape($patientFolderId) ?>" class="space-y-3 border-t border-slate-200 bg-slate-50/60 p-4 dark:border-slate-700 dark:bg-slate-800/20">
                                    <div class="mb-3 flex items-center justify-between gap-3">
                                        <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400"><i class="fas fa-folder-open mr-1.5 text-sky-500"></i>Patient clinical results</h3>
                                        <span class="rounded-full bg-sky-50 px-3 py-1 font-mono text-[0.65rem] font-bold text-sky-600 dark:bg-sky-500/10 dark:text-sky-400 sm:hidden">MRN: <?= patientResultsEscape(substr($patient['mrn'], 3)) ?></span>
                                    </div>
                                    <?php if (!$patientResults): ?>
                                        <p class="rounded-lg border border-dashed border-slate-300 bg-white p-4 text-xs text-slate-500 dark:border-slate-700 dark:bg-[#1f2937] dark:text-slate-400">No results submitted for this patient yet.</p>
                                    <?php else: ?>
                                        <?php foreach ($resultsByClinic as $clinicName => $clinicResults): ?>
                                            <?php $clinicFolderId = 'clinic-folder-' . (int)$patient['queue_id'] . '-' . substr(sha1($clinicName), 0, 8); ?>
                                            <details class="clinic-folder overflow-hidden rounded-xl border border-slate-300 bg-white dark:border-slate-700 dark:bg-[#1f2937]">
                                                <summary class="flex cursor-pointer list-none items-center justify-between gap-3 bg-slate-50 p-3 hover:bg-slate-100 dark:bg-slate-800/40 dark:hover:bg-slate-800/70 [&::-webkit-details-marker]:hidden">
                                                    <span class="flex min-w-0 items-center gap-3">
                                                        <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-500 dark:bg-amber-500/10"><i class="fas fa-folder"></i></span>
                                                        <span class="min-w-0">
                                                            <span class="block truncate text-xs font-extrabold"><?= patientResultsEscape($clinicName) ?></span>
                                                            <span class="block text-[0.65rem] text-slate-500 dark:text-slate-400"><?= count($clinicResults) ?> result<?= count($clinicResults) === 1 ? '' : 's' ?></span>
                                                        </span>
                                                    </span>
                                                    <i class="clinic-folder-chevron fas fa-chevron-down text-slate-400 transition-transform"></i>
                                                </summary>
                                                <div id="<?= patientResultsEscape($clinicFolderId) ?>" class="space-y-3 border-t border-slate-200 p-3 dark:border-slate-700">
                                                    <?php foreach ($clinicResults as $result): ?>
                                                        <?php $resultData = json_decode($result['result_data'] ?? '', true); ?>
                                                        <section class="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-700 dark:bg-[#1f2937]">
                                                            <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 bg-slate-50/70 p-3 dark:border-slate-700 dark:bg-slate-800/40">
                                                                <div class="flex flex-wrap items-center gap-2">
                                                                    <span class="text-xs font-bold"><?= patientResultsEscape($clinicName) ?></span>
                                                                    <span class="rounded bg-sky-50 px-2 py-1 font-mono text-[0.6rem] font-bold text-sky-600 dark:bg-sky-500/10 dark:text-sky-400">Queue: <?= patientResultsEscape($result['queue_number'] ?? '—') ?></span>
                                                                </div>
                                                                <div class="flex flex-wrap items-center gap-2">
                                                                    <span class="text-[0.65rem] text-slate-500 dark:text-slate-400"><i class="fas fa-calendar-alt mr-1"></i><?= patientResultsEscape($result['submitted_at'] ? date('M j, Y g:i A', strtotime($result['submitted_at'])) : 'Date unavailable') ?></span>
                                                                    <?php if (!empty($result['submitted_by'])): ?><span class="text-[0.65rem] font-semibold text-slate-600 dark:text-slate-300"><i class="fas fa-user-md mr-1 text-sky-500"></i><?= patientResultsEscape($result['submitted_by']) ?></span><?php endif; ?>
                                                                    <a href="<?= patientResultsEscape('patient_result_export.php?' . http_build_query(['id' => (int)$result['id'], 'mode' => 'pdf'])) ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1 rounded-lg bg-rose-500 px-3 py-1.5 text-[0.65rem] font-bold text-white hover:bg-rose-600" title="Print or save this result as PDF"><i class="fas fa-file-pdf"></i> PDF</a>
                                                                    <a href="<?= patientResultsEscape('patient_result_export.php?' . http_build_query(['id' => (int)$result['id'], 'mode' => 'print'])) ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1 rounded-lg bg-sky-600 px-3 py-1.5 text-[0.65rem] font-bold text-white hover:bg-sky-500"><i class="fas fa-print"></i> Print</a>
                                                                </div>
                                                            </div>
                                                            <div class="space-y-3 p-3">
                                                                <p class="text-[0.65rem] text-slate-500 dark:text-slate-400">Status: <span class="font-bold"><?= patientResultsEscape(ucfirst($result['result_status'] ?? 'unknown')) ?></span></p>
                                                                <?php if (is_array($resultData) && $resultData): ?>
                                                                    <dl class="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                                                                        <?php foreach ($resultData as $key => $value): ?>
                                                                            <?php if ($value === '' || $value === null || $value === []) continue; ?>
                                                                            <div class="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800/40">
                                                                                <dt class="text-[0.6rem] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400"><?= patientResultsEscape(ucwords(str_replace('_', ' ', (string)$key))) ?></dt>
                                                                                <dd class="mt-1 whitespace-pre-wrap text-xs font-semibold"><?= patientResultsEscape(is_scalar($value) ? $value : json_encode($value, JSON_UNESCAPED_UNICODE)) ?></dd>
                                                                            </div>
                                                                        <?php endforeach; ?>
                                                                    </dl>
                                                                <?php endif; ?>
                                                                <?php if (!empty($result['findings'])): ?>
                                                                    <div><p class="mb-1 text-[0.6rem] font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400"><i class="fas fa-stethoscope mr-1"></i>Clinical Findings</p><p class="whitespace-pre-wrap rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs dark:border-slate-700 dark:bg-slate-800/40"><?= patientResultsEscape($result['findings']) ?></p></div>
                                                                <?php endif; ?>
                                                                <?php if (!empty($result['recommendations'])): ?>
                                                                    <div><p class="mb-1 text-[0.6rem] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400"><i class="fas fa-comment-medical mr-1"></i>Recommendations</p><p class="whitespace-pre-wrap rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs dark:border-slate-700 dark:bg-slate-800/40"><?= patientResultsEscape($result['recommendations']) ?></p></div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </section>
                                                    <?php endforeach; ?>
                                                </div>
                                            </details>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            </details>
                        <?php endforeach; ?>
                    </div>
                    <?php if ($totalPages > 1): ?>
                        <nav class="flex items-center justify-between border-t border-slate-200 p-4 dark:border-slate-700" aria-label="Outpatient patient pagination">
                            <span class="text-xs text-slate-500 dark:text-slate-400">Page <?= $page ?> of <?= $totalPages ?></span>
                            <div class="flex gap-2">
                                <?php if ($page > 1): ?><a class="rounded-lg bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-slate-700" href="<?= patientResultsEscape($pageUrl($page - 1)) ?>">Previous</a><?php endif; ?>
                                <?php if ($page < $totalPages): ?><a class="rounded-lg bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-slate-700" href="<?= patientResultsEscape($pageUrl($page + 1)) ?>">Next</a><?php endif; ?>
                            </div>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        <?php endif; ?>
    </main>
    <script>
        const themeToggle = document.getElementById('themeToggle');
        themeToggle.addEventListener('click', function() {
            const isDark = document.documentElement.classList.toggle('dark');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
        });

        const sidebar = document.getElementById('sidebar');
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        mobileMenuBtn.addEventListener('click', function(event) {
            event.stopPropagation();
            sidebar.classList.toggle('-translate-x-full');
        });
        document.addEventListener('click', function(event) {
            if (window.innerWidth < 768 && !sidebar.contains(event.target) && !mobileMenuBtn.contains(event.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
    </script>
</body>
</html>
