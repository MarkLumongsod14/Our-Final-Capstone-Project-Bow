# Brevo appointment reminders

The scheduling page sends an immediate confirmation for new appointments. The reminder worker sends one additional email during the 24 hours before each non-cancelled, non-completed appointment whose patient has an email address.

## One-time setup

1. Run `appointment_email_migration.sql` in the `cesh_crm` database.
2. Set these environment variables for the Apache/PHP process:

   - `BREVO_SERVER`: `smtp-relay.brevo.com`
   - `BREVO_PORT`: `587`
   - `BREVO_USERNAME`: your Brevo SMTP login
   - `BREVO_PASSWORD`: your Brevo SMTP master password
   - `BREVO_FROM_EMAIL`: a sender email verified in Brevo
   - `BREVO_FROM_NAME`: optional sender name
   - `BREVO_CRON_TOKEN`: a long random value used to protect the worker URL

3. Configure Windows Task Scheduler to run this hourly:

   `C:\xampp\php\php.exe C:\xampp\htdocs\CESH\send_appointment_reminders.php`

The worker may also be called over HTTPS by a scheduler using:

`https://your-host/send_appointment_reminders.php?token=BREVO_CRON_TOKEN`

Run it hourly using the hospital's local timezone. The endpoint returns `sent` and `failed` counts. A reminder is recorded only after Brevo accepts it, so failed sends can be retried on the next run.
