<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

header('Content-Type: text/html; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !unified_csrf_valid()) {
    http_response_code(400);
    exit('Invalid Smart Queueing transfer request.');
}

$auth->requireRole(['doctor']);
$currentUser = $auth->currentUser();
$identityId = (int)($_SESSION['sso_identity_id'] ?? 0);
$queueId = filter_var($_POST['queue_id'] ?? null, FILTER_VALIDATE_INT);
$patientMrn = filter_var($_POST['patient_mrn'] ?? null, FILTER_VALIDATE_INT);

if (
    $identityId <= 0
    || !$queueId
    || !$patientMrn
    || $queueId <= 0
    || $patientMrn <= 0
) {
    http_response_code(400);
    exit('The active patient information is invalid. Return to the doctor queue and try again.');
}

$outpatientContext = $_SESSION['sso_contexts']['outpatient'] ?? null;
if (
    !is_array($outpatientContext)
    || empty($outpatientContext['logged_in'])
    || ($outpatientContext['role'] ?? '') !== 'doctor'
    || (int)($outpatientContext['user_id'] ?? 0) !== (int)$currentUser['id']
) {
    http_response_code(403);
    exit('A verified Outpatient doctor session is required for this transfer.');
}

$queueStmt = $conn->prepare(
    "SELECT patient_mrn, department, doctor_id, priority
     FROM queue
     WHERE id = ? AND status = 'In Consultation'
     LIMIT 1"
);
$queueStmt->bind_param('i', $queueId);
$queueStmt->execute();
$activeQueue = $queueStmt->get_result()->fetch_assoc();
$queueStmt->close();

$normalizeDepartment = static function (string $department): string {
    return $department === 'General' ? 'General Medicine' : $department;
};
$assignedDepartment = $normalizeDepartment((string)($currentUser['assigned_department'] ?? 'General'));
$activeDepartment = $normalizeDepartment((string)($activeQueue['department'] ?? ''));
if (
    !$activeQueue
    || (int)$activeQueue['patient_mrn'] !== $patientMrn
    || (int)$activeQueue['doctor_id'] !== (int)$currentUser['id']
    || $activeDepartment !== $assignedDepartment
    || !in_array($activeQueue['priority'], ['Normal', 'Senior', 'PWD'], true)
) {
    http_response_code(403);
    exit('You are not authorized to transfer this active consultation.');
}

$_SESSION['sso_contexts']['smart_queueing'] = [
    'user_id' => (int)$currentUser['id'],
    'username' => (string)$currentUser['username'],
    'full_name' => (string)$currentUser['full_name'],
    'email' => (string)($currentUser['email'] ?? ''),
    'role' => 'doctor',
    'logged_in' => true,
    'login_time' => time(),
    'clinic_id' => null,
    'clinic_name' => 'Outpatient referral',
    'last_activity' => time(),
];
$_SESSION['sso_smart_queue_registration_only'] = true;
$_SESSION['sso_smart_queue_registration_mrn'] = $patientMrn;
$_SESSION['sso_smart_queue_registration_priority'] = $activeQueue['priority'];
$_SESSION['sso_smart_queue_registration_expires_at'] = time() + 1800;
$_SESSION['sso_smart_queue_return_department'] = $activeDepartment;

header('Location: ../queuv1/staff/registration.php?crm_mrn=' . urlencode((string)$patientMrn));
exit;
