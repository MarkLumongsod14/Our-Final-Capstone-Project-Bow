<?php
require_once 'db.php';

// Reset admin password
$new_password = 'admin123';
$hashed = password_hash($new_password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = 'admin'");
$stmt->bind_param("s", $hashed);

if ($stmt->execute()) {
    echo "✅ Admin password reset successfully!<br>";
    echo "New hash: " . $hashed . "<br>";
    echo "Password: admin123<br>";
    echo "<a href='login.php'>Go to Login Page</a>";
} else {
    echo "❌ Error: " . $conn->error;
}
$stmt->close();
?>