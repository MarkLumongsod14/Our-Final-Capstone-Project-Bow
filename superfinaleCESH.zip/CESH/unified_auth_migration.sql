-- Run once from the MySQL account configured for both existing applications.
-- This creates a separate identity database and links existing local accounts
-- by system plus user ID; matching usernames are deliberately not merged.

CREATE DATABASE IF NOT EXISTS hospital_identity
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE hospital_identity;

CREATE TABLE IF NOT EXISTS unified_identities (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    seed_system ENUM('outpatient', 'smart_queueing') NOT NULL,
    seed_user_id BIGINT UNSIGNED NOT NULL,
    display_name VARCHAR(150) NOT NULL,
    merged_into_id BIGINT UNSIGNED DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_unified_identity_seed (seed_system, seed_user_id),
    KEY idx_unified_identity_merged_into (merged_into_id),
    CONSTRAINT fk_unified_identity_merged_into
        FOREIGN KEY (merged_into_id) REFERENCES unified_identities(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS unified_accounts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    identity_id BIGINT UNSIGNED NOT NULL,
    system_key ENUM('outpatient', 'smart_queueing') NOT NULL,
    local_user_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_unified_account_local (system_key, local_user_id),
    KEY idx_unified_account_identity (identity_id),
    CONSTRAINT fk_unified_account_identity
        FOREIGN KEY (identity_id) REFERENCES unified_identities(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS unified_login_attempts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    succeeded TINYINT(1) NOT NULL DEFAULT 0,
    attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_unified_login_attempts_username_time (username, attempted_at),
    KEY idx_unified_login_attempts_ip_time (ip_address, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS unified_two_factor_attempts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    identity_id BIGINT UNSIGNED NOT NULL,
    system_key ENUM('outpatient', 'smart_queueing') NOT NULL,
    succeeded TINYINT(1) NOT NULL DEFAULT 0,
    attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_unified_2fa_identity_system_time (identity_id, system_key, attempted_at),
    CONSTRAINT fk_unified_2fa_identity
        FOREIGN KEY (identity_id) REFERENCES unified_identities(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO unified_identities (seed_system, seed_user_id, display_name)
SELECT 'outpatient', id, full_name
FROM cesh_crm.users;

INSERT IGNORE INTO unified_identities (seed_system, seed_user_id, display_name)
SELECT 'smart_queueing', id, full_name
FROM hospital_queue_system.users;

INSERT IGNORE INTO unified_accounts (identity_id, system_key, local_user_id)
SELECT i.id, 'outpatient', u.id
FROM cesh_crm.users AS u
JOIN unified_identities AS i
  ON i.seed_system = 'outpatient' AND i.seed_user_id = u.id;

INSERT IGNORE INTO unified_accounts (identity_id, system_key, local_user_id)
SELECT i.id, 'smart_queueing', u.id
FROM hospital_queue_system.users AS u
JOIN unified_identities AS i
  ON i.seed_system = 'smart_queueing' AND i.seed_user_id = u.id;
