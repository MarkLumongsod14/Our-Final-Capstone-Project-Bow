<?php
// queue_frontdesk.php - Front desk queue management
// Camp Evangelista Station Hospital
require_once 'db.php';
require_once 'auth.php';
require_once 'queue_tracking_helpers.php';
require_once 'queue_assignment_helpers.php';

$auth->requireRole(['admin', 'staff']);
ensureQueueTrackingTokens($conn);

$current_user = $auth->currentUser();
$user_department = $current_user['assigned_department'] ?? 'General';
$is_admin = ($current_user['role'] === 'admin');
$is_general_frontdesk = $current_user['role'] === 'staff'
    && in_array($user_department, ['General', 'General Medicine'], true);
$can_manage_all_queue_departments = $is_admin || $is_general_frontdesk;

$department = $_GET['dept'] ?? $user_department;

if ($department === 'General Medicine') {
    $department = 'General';
}

if (!$auth->canAccessDepartment($department) && !$is_general_frontdesk) {
    die("Access denied. You are not authorized for this department.");
}

$registeredQueueTicket = $_SESSION['registration_queue_ticket'] ?? null;
unset($_SESSION['registration_queue_ticket']);
if (
    !is_array($registeredQueueTicket)
    || !isset($registeredQueueTicket['department'])
    || !in_array($registeredQueueTicket['department'], [$department, $department === 'General' ? 'General Medicine' : $department], true)
) {
    $registeredQueueTicket = null;
}

$accessible_depts = $can_manage_all_queue_departments
    ? ['General', 'Pediatrics', 'OB-Gyne', 'Internal Medicine']
    : $auth->getAccessibleDepartments();

// Get patients that are NOT currently in queue
$patientsQuery = "
    SELECT p.mrn, p.first_name, p.last_name, p.created_at
    FROM patients p
    WHERE p.status = 'Active' 
    AND p.mrn NOT IN (
        SELECT DISTINCT patient_mrn 
        FROM queue 
        WHERE status IN ('Waiting', 'In Consultation')
    )
    ORDER BY p.mrn DESC
";

$patientsResult = $conn->query($patientsQuery);

if (!$patientsResult) {
    die("Database error: " . $conn->error);
}
$patients = $patientsResult->fetch_all(MYSQLI_ASSOC);

// Available doctors are used to show department availability; assignment happens server-side.
$doctorsQuery = "SELECT id, full_name, assigned_department FROM users WHERE role = 'doctor' AND status = 'Active' AND is_available = 1";
$doctorsResult = $conn->query($doctorsQuery);
$doctors = $doctorsResult ? $doctorsResult->fetch_all(MYSQLI_ASSOC) : [];

function formatMRN($mrn) {
    return str_pad($mrn, 6, '0', STR_PAD_LEFT);
}

// Get today's completed count
$completedStmt = $conn->prepare("SELECT COUNT(*) as count FROM queue WHERE (department = ? OR (? = 'General' AND department = 'General Medicine')) AND status = 'Completed' AND DATE(completed_at) = CURDATE()");
$completedStmt->bind_param('ss', $department, $department);
$completedStmt->execute();
$completedToday = $completedStmt->get_result();
$completedCount = $completedToday ? $completedToday->fetch_assoc()['count'] : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Queue Management | 4ID Station Hospital</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes modalFadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        #sidebar::-webkit-scrollbar {
            width: 4px;
        }
        #sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        #sidebar::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 2px;
        }
        .dark #sidebar::-webkit-scrollbar-thumb {
            background: #475569;
        }
        .main-content {
            transition: margin-left 0.3s ease;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        
        .theme-switch {
            position: relative;
            width: 48px;
            height: 26px;
            background: #e2e8f0;
            border-radius: 13px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(22px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 11px; }
        
        /* User Dropdown */
        .user-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            min-width: 200px;
            z-index: 1000;
            overflow: hidden;
        }
        .dark .user-dropdown {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .user-dropdown.show {
            display: block;
        }
        .user-dropdown .dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        .dark .user-dropdown .dropdown-header {
            border-bottom-color: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-header strong {
            color: #1f2937;
            display: block;
            font-size: 0.85rem;
        }
        .dark .user-dropdown .dropdown-header strong {
            color: #f1f5f9;
        }
        .user-dropdown .dropdown-header small {
            color: #6b7280;
            font-size: 0.7rem;
        }
        .dark .user-dropdown .dropdown-header small {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            color: #374151;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
        }
        .dark .user-dropdown .dropdown-item {
            color: #e5e7eb;
        }
        .user-dropdown .dropdown-item:hover {
            background: #f3f4f6;
        }
        .dark .user-dropdown .dropdown-item:hover {
            background: rgba(255,255,255,0.04);
        }
        .user-dropdown .dropdown-item i {
            width: 18px;
            color: #6b7280;
        }
        .dark .user-dropdown .dropdown-item i {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-divider {
            height: 1px;
            background: #e5e7eb;
            margin: 4px 0;
        }
        .dark .user-dropdown .dropdown-divider {
            background: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-item.logout {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout i {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout:hover {
            background: rgba(239, 68, 68, 0.08);
        }

        /* Ticket Modal */
        .ticket-modal {
            animation: modalFadeIn 0.2s ease;
        }
        .queue-flow-step {
            color: #94a3b8;
        }
        .queue-flow-step .step-indicator {
            border: 2px solid #cbd5e1;
            color: #64748b;
        }
        .queue-flow-step.is-active,
        .queue-flow-step.is-complete {
            color: #0284c7;
        }
        .queue-flow-step.is-active .step-indicator,
        .queue-flow-step.is-complete .step-indicator {
            border-color: #0284c7;
            background: #0284c7;
            color: #fff;
        }
        .queue-flow-connector.is-complete {
            background: #0284c7;
        }
        @media print {
            body * {
                visibility: hidden !important;
            }
            #ticketModal,
            #ticketModal * {
                visibility: visible !important;
            }
            #ticketModal {
                display: flex !important;
                position: absolute !important;
                inset: 0 !important;
                padding: 0 !important;
                background: #fff !important;
            }
            #ticketModal .ticket-modal {
                width: 100% !important;
                max-width: 420px !important;
                margin: auto !important;
                border: 1px solid #cbd5e1 !important;
                box-shadow: none !important;
                animation: none !important;
            }
            #ticketModal .ticket-modal > div:last-child {
                display: none !important;
            }
        }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- SIDEBAR -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span>
                    <span>E</span>
                    <span>S</span>
                    <span>H</span>
                </div>

                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <?php if ($is_admin): ?>
                    <!-- ADMIN SIDEBAR -->
                    <li>
                        <a href="index.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-gauge-high text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="medical_history.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-notes-medical text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Medical History</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_documents.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-file-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Documents</span>
                        </a>
                    </li>
                    <li>
                        <a href="scheduled_patient.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-calendar-check text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Scheduled Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_frontdesk.php?dept=<?php echo urlencode($department); ?>" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-ticket text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_display.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tv text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Display</span>
                        </a>
                    </li>
                    <?php else: ?>
                    <!-- FRONT DESK SIDEBAR -->
                    <li>
                        <a href="frontdesk_dashboard.php?dept=<?php echo urlencode($department); ?>" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-gauge-high text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="frontdesk_patient.php?dept=<?php echo urlencode($department); ?>" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-plus text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Register Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_frontdesk.php?dept=<?php echo urlencode($department); ?>" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-ticket text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_display.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tv text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Display</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (($current_user['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="admin/users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-shield text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i></div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                
                <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
                    <a href="logout.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                        <div class="w-6 h-6 flex items-center justify-center shrink-0">
                            <i class="fas fa-sign-out-alt text-base text-rose-400 group-hover/link:text-rose-500 transition-colors"></i>
                        </div>
                        <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
                    </a>
                </div>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 main-content">
        
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">Queue Management</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">Enroll patients to the waiting queue</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($current_user['full_name']); ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400 font-medium"><?php echo $is_admin ? 'Administrator' : 'Front Desk Staff'; ?></div>
                </div>
                
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 dark:text-slate-500">
                        <i class="fas fa-sun"></i>
                    </span>
                    <div class="theme-switch" id="themeToggle">
                        <div class="slider">
                            <span class="sun"><i class="fas fa-sun"></i></span>
                            <span class="moon"><i class="fas fa-moon"></i></span>
                        </div>
                    </div>
                    <span class="text-xs text-slate-400 dark:text-slate-500">
                        <i class="fas fa-moon"></i>
                    </span>
                </div>

                <!-- User Avatar with Click Dropdown -->
                <div class="relative">
                    <div class="w-10 h-10 rounded-full bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors" id="userAvatar">
                        <i class="fas fa-user text-slate-400 dark:text-slate-500 text-sm"></i>
                    </div>
                    <div class="user-dropdown" id="userDropdown">
                        <div class="dropdown-header">
                            <strong><?php echo htmlspecialchars($current_user['full_name']); ?></strong>
                            <small><?php echo $is_admin ? 'Administrator' : 'Front Desk Staff'; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a href="logout.php" class="dropdown-item logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Department Tabs -->
        <div class="flex flex-wrap gap-2 mb-6 border-b border-slate-200 dark:border-slate-700/50 pb-3">
            <?php foreach ($accessible_depts as $dept): 
                $icon = 'fa-stethoscope';
                if ($dept === 'Pediatrics') $icon = 'fa-child';
                elseif ($dept === 'OB-Gyne') $icon = 'fa-female';
                elseif ($dept === 'Internal Medicine') $icon = 'fa-heart-pulse';
            ?>
                <a href="?dept=<?php echo urlencode($dept); ?>" class="px-4 py-2 rounded-full text-sm font-semibold transition-all duration-150 <?php echo $dept === $department ? 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50 border border-transparent'; ?>">
                    <i class="fas <?php echo $icon; ?> mr-2"></i> <?php echo htmlspecialchars($dept); ?>
                </a>
            <?php endforeach; ?>
        </div>
        
        <!-- Stats Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
                <div class="flex justify-between items-center mb-4">
                    <div class="w-11 h-11 bg-sky-50 dark:bg-sky-500/10 rounded-xl flex items-center justify-center text-sky-600 dark:text-sky-400 text-lg">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono" id="waitingCount">0</div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Waiting</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
                <div class="flex justify-between items-center mb-4">
                    <div class="w-11 h-11 bg-amber-50 dark:bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-600 dark:text-amber-400 text-lg">
                        <i class="fas fa-user-plus"></i>
                    </div>
                </div>
                <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono" id="seniorCount">0</div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Senior/PWD</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
                <div class="flex justify-between items-center mb-4">
                    <div class="w-11 h-11 bg-emerald-50 dark:bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-lg">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
                <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono" id="completedCount"><?php echo $completedCount; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Completed Today</div>
            </div>
        </div>
        
        <!-- Queueing Steps -->
        <div class="flex items-center justify-center gap-4 mb-6" aria-label="Queueing progress">
            <div id="queueStepEnroll" class="queue-flow-step is-active flex items-center gap-2 text-xs sm:text-sm font-bold" aria-current="step">
                <span class="step-indicator flex h-8 w-8 items-center justify-center rounded-full text-sm">1</span>
                <span>Enroll Patient</span>
            </div>
            <div id="queueStepConnector" class="queue-flow-connector h-px w-10 sm:w-16 bg-slate-300 dark:bg-slate-600 transition-colors"></div>
            <div id="queueStepTicket" class="queue-flow-step flex items-center gap-2 text-xs sm:text-sm font-bold">
                <span class="step-indicator flex h-8 w-8 items-center justify-center rounded-full text-sm">2</span>
                <span>Get Ticket</span>
            </div>
        </div>

        <!-- Enroll Form -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm mb-8">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80">
                <div class="flex items-center gap-3">
                    <i class="fas fa-user-plus text-sky-500 dark:text-sky-400"></i>
                    <div>
                        <span class="block text-sm font-bold text-slate-800 dark:text-slate-200">Enroll Patient to Queue</span>
                        <span class="text-xs text-slate-500 dark:text-slate-400">Select a registered patient and confirm their queue details.</span>
                    </div>
                </div>
            </div>
            <div class="p-6">
                <form id="enqueueForm">
                    <div class="mb-6">
                        <h3 class="mb-3 flex items-center gap-2 border-b border-slate-200 pb-2 text-xs font-bold uppercase tracking-wider text-slate-500 dark:border-slate-700 dark:text-slate-400">
                            <i class="fas fa-user-circle text-sky-500"></i> Patient Information
                        </h3>
                        <label for="patient_id" class="mb-1.5 block text-xs font-bold text-slate-500 dark:text-slate-400">Registered Patient</label>
                        <select name="patient_mrn" id="patient_id" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                            <option value="">-- Select Patient --</option>
                            <?php foreach ($patients as $patient): ?>
                                <option value="<?= $patient['mrn'] ?>">
                                    <?= htmlspecialchars($patient['last_name']) ?>, <?= htmlspecialchars($patient['first_name']) ?> (MRN: <?= formatMRN($patient['mrn']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <h3 class="mb-3 flex items-center gap-2 border-b border-slate-200 pb-2 text-xs font-bold uppercase tracking-wider text-slate-500 dark:border-slate-700 dark:text-slate-400">
                            <i class="fas fa-clipboard-list text-sky-500"></i> Queue Details
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div>
                                <label for="department" class="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5">Department</label>
                                <select name="department" id="department" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                                    <option value="General Medicine" <?php echo in_array($department, ['General', 'General Medicine'], true) ? 'selected' : ''; ?>>General Medicine</option>
                                    <option value="Pediatrics" <?php echo $department === 'Pediatrics' ? 'selected' : ''; ?>>Pediatrics</option>
                                    <option value="OB-Gyne" <?php echo $department === 'OB-Gyne' ? 'selected' : ''; ?>>OB-Gyne</option>
                                    <option value="Internal Medicine" <?php echo $department === 'Internal Medicine' ? 'selected' : ''; ?>>Internal Medicine</option>
                                </select>
                            </div>
                            <div>
                                <label for="priority" class="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5">Priority</label>
                                <select name="priority" id="priority" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                                    <option value="Normal">Normal</option>
                                    <option value="Senior">Senior Citizen (60+)</option>
                                    <option value="PWD">Person with Disability</option>
                                </select>
                            </div>
                            <div>
                                <span class="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5">Doctor Assignment</span>
                                <div class="flex min-h-[42px] items-center rounded-xl border border-slate-300 bg-slate-50 px-4 py-2.5 text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-800/60 dark:text-slate-300">
                                    <i class="fas fa-shuffle mr-2 text-sky-500"></i> Automatically balanced
                                </div>
                            </div>
                        </div>
                    </div>
                    <p id="doctorAvailabilityMessage" class="mt-3 text-xs font-semibold text-slate-500 dark:text-slate-400" aria-live="polite"></p>
                    <button type="submit" id="enqueueSubmit" class="mt-4 px-6 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-2">
                        <i class="fas fa-plus-circle"></i> Enroll Patient
                    </button>
                </form>
            </div>
        </div>

        <script>
            const departmentSelect = document.getElementById('department');
            const enqueueSubmit = document.getElementById('enqueueSubmit');
            const doctorAvailabilityMessage = document.getElementById('doctorAvailabilityMessage');
            const availableDoctors = <?php
                echo json_encode(
                    array_map(
                        static fn($doctor) => ['department' => $doctor['assigned_department']],
                        $doctors
                    ),
                    JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
                );
            ?>;

            function refreshAvailableDoctors() {
                const selectedDepartment = departmentSelect.value;
                const departmentName = selectedDepartment === 'General' ? 'General Medicine' : selectedDepartment;
                const doctorCount = availableDoctors.filter(doctor =>
                    doctor.department === departmentName || (departmentName === 'General Medicine' && doctor.department === 'General')
                ).length;
                if (doctorCount === 0) {
                    enqueueSubmit.disabled = true;
                    enqueueSubmit.classList.add('opacity-50', 'cursor-not-allowed');
                    doctorAvailabilityMessage.classList.add('text-rose-600', 'dark:text-rose-400');
                    doctorAvailabilityMessage.textContent = 'Patient cannot be enrolled because no doctor is available for this department.';
                    return;
                }
                enqueueSubmit.disabled = false;
                enqueueSubmit.classList.remove('opacity-50', 'cursor-not-allowed');
                doctorAvailabilityMessage.classList.remove('text-rose-600', 'dark:text-rose-400');
                doctorAvailabilityMessage.textContent = `${doctorCount} available doctor${doctorCount === 1 ? '' : 's'}; patients are automatically assigned to balance active workloads.`;
            }

            departmentSelect.addEventListener('change', refreshAvailableDoctors);
            refreshAvailableDoctors();
        </script>
        
        <!-- Queue List -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex justify-between items-center flex-wrap gap-3">
                <div class="flex items-center gap-3">
                    <i class="fas fa-list-ol text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200">Current Waiting Queue</span>
                    <span class="text-xs text-slate-400 dark:text-slate-400 font-medium"><?php echo htmlspecialchars($department); ?></span>
                </div>
                <button class="text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 bg-white dark:bg-slate-700/50 px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-600 transition-colors" onclick="loadQueue()">
                    <i class="fas fa-sync-alt mr-1.5"></i> Refresh
                </button>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse min-w-[700px]">
                    <thead>
                        <tr class="bg-slate-50/50 dark:bg-slate-800/40 text-left border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.65rem] uppercase tracking-wider font-bold">
                            <th class="px-5 py-3.5">Queue #</th>
                            <th class="px-5 py-3.5">Patient Name</th>
                            <th class="px-5 py-3.5">MRN</th>
                            <th class="px-5 py-3.5">Priority</th>
                            <th class="px-5 py-3.5">Doctor</th>
                            <th class="px-5 py-3.5">Enrolled</th>
                            <th class="px-5 py-3.5">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-300/80 dark:divide-slate-700/50 text-xs md:text-sm text-slate-700 dark:text-slate-200" id="queueList">
                        <tr>
                            <td colspan="7" class="text-center py-12 text-slate-400 dark:text-slate-400">
                                <i class="fas fa-spinner fa-pulse text-2xl mb-2 block text-slate-300 dark:text-slate-600"></i> Loading...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Ticket Modal -->
    <div id="ticketModal" class="fixed inset-0 bg-slate-900/60 dark:bg-black/70 z-[2000] hidden items-center justify-center p-4 backdrop-blur-sm">
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-2xl w-full max-w-[420px] overflow-hidden shadow-2xl ticket-modal">
            <div class="px-6 py-5 bg-slate-50 dark:bg-slate-800 text-center border-b border-slate-300 dark:border-slate-700">
                <i class="fas fa-ticket text-3xl text-sky-500 dark:text-sky-400 mb-2 block"></i>
                <h2 class="text-lg font-bold text-slate-900 dark:text-white">Queue Ticket</h2>
                <p class="text-xs text-slate-400 dark:text-slate-400 font-medium">4ID Station Hospital • Camp Evangelista</p>
            </div>
            <div class="p-6 text-center">
                <div class="text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider">Your Queue Number</div>
                <div class="text-5xl font-black text-sky-600 dark:text-sky-400 font-mono my-3" id="ticketNumber">Q001</div>
                <div id="ticketPriority" class="inline-block px-3 py-1 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">Normal</div>
                
                <div class="mt-4 p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl text-left space-y-1.5">
                    <div class="flex justify-between text-sm">
                        <span class="text-slate-400 dark:text-slate-400">Patient:</span>
                        <span class="font-semibold text-slate-700 dark:text-slate-200" id="ticketName">---</span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-slate-400 dark:text-slate-400">MRN:</span>
                        <span class="font-mono text-slate-600 dark:text-slate-300" id="ticketMRN">---</span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-slate-400 dark:text-slate-400">Department:</span>
                        <span class="font-semibold text-slate-700 dark:text-slate-200" id="ticketDept">General</span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-slate-400 dark:text-slate-400">Date:</span>
                        <span class="text-slate-600 dark:text-slate-300" id="ticketDate">---</span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-slate-400 dark:text-slate-400">Time:</span>
                        <span class="text-slate-600 dark:text-slate-300" id="ticketTime">---</span>
                    </div>
                </div>
                <div class="mt-4 rounded-xl border border-sky-200 bg-sky-50 p-3 text-left dark:border-sky-500/20 dark:bg-sky-500/10">
                    <div class="flex flex-col items-center text-center">
                        <img id="ticketTrackingQr" alt="QR code for the queue tracking page" class="hidden h-32 w-32 rounded-lg border border-sky-200 bg-white p-1">
                        <p id="ticketTrackingQrUnavailable" class="hidden text-xs text-slate-500 dark:text-slate-400">QR code is unavailable. Open the queue tracking page and enter the transaction token below.</p>
                    </div>
                    <p class="mt-2 break-all text-xs font-bold text-slate-700 dark:text-slate-200">
                        Transaction Token: <span id="ticketTrackingCode" class="font-mono font-normal"></span>
                    </p>
                    <p class="mt-1 text-[0.65rem] text-slate-500 dark:text-slate-400">Scan the QR code, then enter this private transaction token to check queue status.</p>
                </div>
                <div class="mt-4 text-xs text-slate-400 dark:text-slate-400">
                    <i class="fas fa-info-circle mr-1"></i> Please wait for your number to be called
                </div>
            </div>
            <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-700 flex gap-3">
                <button onclick="printTicket()" class="flex-1 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-xl transition-all">
                    <i class="fas fa-print mr-2"></i> Print
                </button>
                <button onclick="closeTicketModal()" class="flex-1 py-2.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-sm font-bold rounded-xl transition-all">
                    <i class="fas fa-times mr-2"></i> Close
                </button>
            </div>
        </div>
    </div>

    <script>
        const department = '<?php echo $department; ?>';
        const isAdmin = <?php echo $is_admin ? 'true' : 'false'; ?>;
        const registrationQueueTicket = <?php echo json_encode($registeredQueueTicket, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?: 'null'; ?>;
        const basePath = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);
        
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            if (htmlElement.classList.contains('dark')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });
        
        // ============================================
        // User Dropdown - Click to toggle
        // ============================================
        const userAvatar = document.getElementById('userAvatar');
        const userDropdown = document.getElementById('userDropdown');
        
        userAvatar.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });
        
        document.addEventListener('click', function(e) {
            if (!userAvatar.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('show');
            }
        });
        
        // ============================================
        // Mobile Menu
        // ============================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        });

        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('mobileMenuBtn');
            if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
        
        // ============================================
        // Functions
        // ============================================
        function closeTicketModal() {
            document.getElementById('ticketModal').style.display = 'none';
            setQueueFlowStep(1);
        }
        
        function printTicket() {
            window.print();
        }
        
        function formatMRN(mrn) {
            if (!mrn) return '---';
            return String(mrn).padStart(6, '0');
        }

        function setQueueFlowStep(step) {
            const enrollStep = document.getElementById('queueStepEnroll');
            const ticketStep = document.getElementById('queueStepTicket');
            const connector = document.getElementById('queueStepConnector');
            enrollStep.classList.toggle('is-active', step === 1);
            enrollStep.classList.toggle('is-complete', step === 2);
            ticketStep.classList.toggle('is-active', step === 2);
            connector.classList.toggle('is-complete', step === 2);
            enrollStep.setAttribute('aria-current', step === 1 ? 'step' : 'false');
            ticketStep.setAttribute('aria-current', step === 2 ? 'step' : 'false');
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function getPriorityBadge(priority) {
            const badges = {
                'Emergency': '<span class="inline-block px-2.5 py-0.5 rounded-full text-[0.65rem] font-bold bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-300 dark:border-rose-400/20">Emergency</span>',
                'Senior': '<span class="inline-block px-2.5 py-0.5 rounded-full text-[0.65rem] font-bold bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-300 dark:border-amber-400/20">Senior</span>',
                'PWD': '<span class="inline-block px-2.5 py-0.5 rounded-full text-[0.65rem] font-bold bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-300 dark:border-sky-400/20">PWD</span>',
                'Normal': '<span class="inline-block px-2.5 py-0.5 rounded-full text-[0.65rem] font-bold bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700">Normal</span>'
            };
            return badges[priority] || badges['Normal'];
        }
        
        async function loadStats() {
            try {
                const res = await fetch(`${basePath}queue_api.php?action=get_waiting_count&department=${encodeURIComponent(department)}`);
                const stats = await res.json();
                document.getElementById('waitingCount').textContent = stats.waiting || 0;
                document.getElementById('seniorCount').textContent = Number(stats.seniors || 0) + Number(stats.pwd || 0);
            } catch (error) {
                console.error('Error loading stats:', error);
            }
        }
        
        async function loadQueue() {
            try {
                const res = await fetch(`${basePath}queue_api.php?action=get_queue&department=${encodeURIComponent(department)}&status=Waiting`);
                const queue = await res.json();
                const tbody = document.getElementById('queueList');
                
                if (queue.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="7" class="text-center py-12 text-slate-400 dark:text-slate-400"><i class="fas fa-inbox text-2xl mb-2 block text-slate-300 dark:text-slate-600"></i> No patients in queue</td></tr>';
                    return;
                }
                
                tbody.innerHTML = queue.map(q => `
                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors duration-150">
                        <td class="px-5 py-3.5"><span class="font-bold text-sky-600 dark:text-sky-400 font-mono text-sm">${escapeHtml(q.display_number)}</span></td>
                        <td class="px-5 py-3.5 font-semibold text-slate-800 dark:text-slate-100">${escapeHtml(q.full_name)}</td>
                        <td class="px-5 py-3.5"><span class="font-mono text-xs bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded-md text-slate-500 dark:text-slate-400">${formatMRN(q.mrn)}</span></td>
                        <td class="px-5 py-3.5">${getPriorityBadge(q.priority)}</td>
                        <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400">${q.doctor_name ? 'Dr. ' + escapeHtml(q.doctor_name) : '—'}</td>
                        <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400 font-mono text-sm">${new Date(q.created_at).toLocaleTimeString()}</td>
                        <td class="px-5 py-3.5">
                            <div class="flex flex-wrap items-center gap-2">
                            <button type="button" data-queue-id="${Number(q.id)}" class="viewTicketBtn px-3 py-1.5 bg-sky-50 dark:bg-sky-500/10 hover:bg-sky-100 dark:hover:bg-sky-500/20 text-sky-600 dark:text-sky-400 text-xs font-bold rounded-lg transition-colors">
                                <i class="fas fa-ticket-alt mr-1"></i> View / Print Ticket
                            </button>
                            <button type="button" onclick="cancelQueue(${Number(q.id)})" class="px-3 py-1.5 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-bold rounded-lg transition-colors">
                                <i class="fas fa-times mr-1"></i> Cancel
                            </button>
                            </div>
                        </td>
                    </tr>
                `).join('');

                tbody.querySelectorAll('.viewTicketBtn').forEach(button => {
                    button.addEventListener('click', () => {
                        const queueItem = queue.find(item => Number(item.id) === Number(button.dataset.queueId));
                        if (queueItem) showTicket({
                            formatted_number: queueItem.display_number,
                            patient_name: queueItem.full_name,
                            patient_mrn: queueItem.mrn,
                            department: queueItem.department,
                            priority: queueItem.priority,
                            created_at: queueItem.created_at,
                            tracking_token: queueItem.tracking_token
                        });
                    });
                });
                
                loadStats();
            } catch (error) {
                console.error('Error loading queue:', error);
                document.getElementById('queueList').innerHTML = '<tr><td colspan="7" class="text-center py-12 text-slate-400 dark:text-slate-400"><i class="fas fa-triangle-exclamation text-2xl mb-2 block text-rose-500"></i> Error loading queue</td></tr>';
            }
        }
        
        async function cancelQueue(queueId) {
            if (!confirm('Cancel this patient\'s queue? This action cannot be undone.')) return;
            
            const formData = new FormData();
            formData.append('action', 'cancel');
            formData.append('queue_id', queueId);
            formData.append('status', 'Cancelled');
            
            try {
                const res = await fetch(`${basePath}queue_api.php`, { method: 'POST', body: formData });
                const data = await res.json();
                if (data.success) {
                    alert('Queue cancelled successfully');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    alert('Error cancelling queue');
                }
            } catch (error) {
                alert('Network error');
            }
        }
        
        // Enqueue form submission
        document.getElementById('enqueueForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'enqueue');
            
            const submitBtn = e.target.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            
            try {
                const res = await fetch(`${basePath}queue_api.php`, { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.success) {
                    showTicket(data);
                    e.target.reset();
                    refreshAvailableDoctors();
                    await loadQueue();
                    await loadStats();
                } else {
                    alert(data.error || 'Error enrolling patient');
                }
            } catch (error) {
                alert('Network error: ' + error.message);
            } finally {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-plus-circle"></i> Enroll Patient';
            }
        });
        
        function showTicket(data) {
            setQueueFlowStep(2);
            document.getElementById('ticketNumber').textContent = data.formatted_number;
            document.getElementById('ticketName').textContent = data.patient_name;
            document.getElementById('ticketMRN').textContent = formatMRN(data.patient_mrn);
            const trackingCode = document.getElementById('ticketTrackingCode');
            const trackingQr = document.getElementById('ticketTrackingQr');
            const trackingQrUnavailable = document.getElementById('ticketTrackingQrUnavailable');
            if (data.tracking_token) {
                trackingCode.textContent = data.tracking_token;
                const trackingPageUrl = new URL(`${basePath}queue_tracking.php`, window.location.href).href;
                trackingQr.src = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(trackingPageUrl)}`;
                trackingQr.classList.remove('hidden');
                trackingQrUnavailable.classList.add('hidden');
                trackingQr.onerror = () => {
                    trackingQr.classList.add('hidden');
                    trackingQrUnavailable.classList.remove('hidden');
                };
            } else {
                trackingCode.textContent = '';
                trackingQr.removeAttribute('src');
                trackingQr.classList.add('hidden');
                trackingQrUnavailable.classList.add('hidden');
            }
            const departmentOption = Array.from(document.getElementById('department').options).find(option =>
                option.value === data.department || (data.department === 'General Medicine' && option.value === 'General')
            );
            document.getElementById('ticketDept').textContent = departmentOption?.text || data.department || 'General';

            const priority = data.priority || document.getElementById('priority').value;
            const priorityElem = document.getElementById('ticketPriority');
            priorityElem.textContent = priority;

            const priorityClassMap = {
                Emergency: 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-300',
                Senior: 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-300',
                PWD: 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-300'
            };
            priorityElem.className = `inline-block px-3 py-1 rounded-full text-xs font-bold ${priorityClassMap[priority] || 'bg-slate-50 dark:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-300'}`;
            
            const ticketDate = data.created_at ? new Date(String(data.created_at).replace(' ', 'T')) : new Date();
            document.getElementById('ticketDate').textContent = ticketDate.toLocaleDateString();
            document.getElementById('ticketTime').textContent = ticketDate.toLocaleTimeString();
            
            document.getElementById('ticketModal').style.display = 'flex';
        }
        
        // Initial load
        loadQueue();
        loadStats();
        if (registrationQueueTicket) showTicket(registrationQueueTicket);
        
        setInterval(() => { loadQueue(); loadStats(); }, 10000);
    </script>
</body>
</html>