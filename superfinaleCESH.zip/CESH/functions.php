<?php
header('Content-Type: application/json');
require 'db.php';
$action = $_GET['action'] ?? '';

// ---------------- Appointments ----------------
if($action === 'getAppointments'){
    $year = intval($_GET['year']);
    $month = intval($_GET['month']);
    $start = "$year-$month-01";
    $end = date("Y-m-t", strtotime($start));

    $stmt = $conn->prepare("SELECT date,time,patient_name FROM appointments WHERE date BETWEEN ? AND ? ORDER BY date,time");
    $stmt->bind_param("ss",$start,$end);
    $stmt->execute();
    $res = $stmt->get_result();
    $data = [];
    while($row = $res->fetch_assoc()){
        $d = $row['date'];
        if(!isset($data[$d])) $data[$d] = [];
        $data[$d][] = ['time'=>$row['time'],'name'=>$row['patient_name']];
    }
    echo json_encode($data);
    exit;
}

// ---------------- Scheduled Patients ----------------
if($action === 'getSchedules'){
    $res = $conn->query("SELECT * FROM schedules ORDER BY date,time");
    $data = [];
    while($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
    exit;
}

if($action === 'addSchedule'){
    $body = json_decode(file_get_contents('php://input'),true);
    $stmt = $conn->prepare("INSERT INTO schedules (patient_name,mrn,provider,type,date,time,status) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssss", $body['patient'],$body['mrn'],$body['provider'],$body['type'],$body['date'],$body['time'],$body['status']);
    $stmt->execute();
    echo json_encode(['success'=>true,'id'=>$stmt->insert_id]);
    exit;
}

if($action === 'updateSchedule'){
    $body = json_decode(file_get_contents('php://input'),true);
    $stmt = $conn->prepare("UPDATE schedules SET patient_name=?,mrn=?,provider=?,type=?,date=?,time=?,status=? WHERE id=?");
    $stmt->bind_param("sssssssi", $body['patient'],$body['mrn'],$body['provider'],$body['type'],$body['date'],$body['time'],$body['status'],$body['id']);
    $stmt->execute();
    echo json_encode(['success'=>true]);
    exit;
}

// ---------------- Documents ----------------
if($action === 'getDocuments'){
    $res = $conn->query("SELECT * FROM documents ORDER BY upload_date DESC");
    $data = [];
    while($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
    exit;
}

if($action === 'uploadDocument'){
    $targetDir = "uploads/";
    if(!file_exists($targetDir)) mkdir($targetDir,0777,true);
    $file = $_FILES['file'] ?? null;
    if($file){
        $filename = time().'_'.$file['name'];
        move_uploaded_file($file['tmp_name'],$targetDir.$filename);
        $stmt = $conn->prepare("INSERT INTO documents (file_name,patient_name,mrn,type) VALUES (?,?,?,?)");
        $stmt->bind_param("ssss", $_POST['patient'] ?? 'Unknown', $_POST['mrn'] ?? '', $_POST['type'] ?? 'Document', $filename);
        $stmt->execute();
        echo json_encode(['success'=>true,'file'=>$filename]);
    } else {
        echo json_encode(['error'=>"No file uploaded"]);
    }
    exit;
}
?>
