<?php
// patient_profile.php - Patient Management with Auto-increment MRN and Validations
// Camp Evangelista Station Hospital

require_once 'db.php';
require_once 'auth.php';

$auth->requireLogin();
$current_user = $auth->currentUser();

// Check if columns exist, if not, add them
$check_middle = $conn->query("SHOW COLUMNS FROM patients LIKE 'middle_name'");
if ($check_middle && $check_middle->num_rows == 0) {
    $conn->query("ALTER TABLE patients ADD COLUMN middle_name VARCHAR(100) DEFAULT NULL AFTER first_name");
}

$check_suffix = $conn->query("SHOW COLUMNS FROM patients LIKE 'suffix'");
if ($check_suffix && $check_suffix->num_rows == 0) {
    $conn->query("ALTER TABLE patients ADD COLUMN suffix VARCHAR(10) DEFAULT NULL AFTER last_name");
}

$profile_schema_ready = true;
$profile_columns = [
    'serial_no' => 'VARCHAR(50) DEFAULT NULL',
    'patient_type' => 'VARCHAR(20) DEFAULT NULL',
    'military_rank' => 'VARCHAR(60) DEFAULT NULL'
];
foreach ($profile_columns as $column => $definition) {
    $column_check = $conn->query("SHOW COLUMNS FROM patients LIKE '" . $conn->real_escape_string($column) . "'");
    if (!$column_check) {
        $profile_schema_ready = false;
        error_log('Patient profile schema check failed: ' . $conn->error);
        break;
    }
    if ($column_check->num_rows === 0 && !$conn->query("ALTER TABLE patients ADD COLUMN `$column` $definition")) {
        $profile_schema_ready = false;
        error_log('Patient profile schema update failed for ' . $column . ': ' . $conn->error);
        break;
    }
}

// Suffix options
$suffixes = ['', 'Jr.', 'Sr.', 'II', 'III', 'IV', 'V'];
$militaryRanks = [
    'Enlisted Officers' => [
        'Private',
        'Private First Class',
        'Corporal',
        'Sergeant',
        'Staff Sergeant',
        'Technical Sergeant',
        'Master Sergeant',
        'Senior Master Sergeant',
        'Chief Master Sergeant',
        'First Chief Master Sergeant'
    ],
    'Commissioned Officers' => [
        'Second Lieutenant',
        'First Lieutenant',
        'Captain',
        'Major',
        'Lieutenant Colonel',
        'Colonel',
        'Brigadier General',
        'Major General',
        'Lieutenant General',
        'General'
    ]
];
$allowedMilitaryRanks = array_merge(...array_values($militaryRanks));

// Error messages array
$errors = [];
$success_msg = '';
if (!$profile_schema_ready) {
    $errors[] = 'Patient serial number and military fields could not be initialized. Please contact the system administrator.';
}

function isValidPatientName($name) {
    return $name !== '' && preg_match('/^[\p{L}\p{M} -]+$/u', $name) === 1;
}

// ---------------- ADD PATIENT WITH VALIDATIONS ----------------
if ($profile_schema_ready && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_patient'])) {
    $first_name = trim($_POST['first_name'] ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $suffix = $_POST['suffix'] ?? '';
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $contact = trim($_POST['contact'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $primary_physician = trim($_POST['primary_physician'] ?? '');
    $serial_no = trim($_POST['serial_no'] ?? '');
    $patient_type = $_POST['patient_type'] ?? '';
    $military_rank = trim($_POST['military_rank'] ?? '');
    
    if (empty($first_name)) $errors[] = "First name is required";
    elseif (!isValidPatientName($first_name)) $errors[] = "First name can contain letters, spaces, and hyphens only";
    if ($middle_name !== '' && !isValidPatientName($middle_name)) $errors[] = "Middle name can contain letters, spaces, and hyphens only";
    if (empty($last_name)) $errors[] = "Last name is required";
    elseif (!isValidPatientName($last_name)) $errors[] = "Last name can contain letters, spaces, and hyphens only";
    if (empty($dob)) $errors[] = "Date of birth is required";
    if (empty($gender)) $errors[] = "Gender is required";
    if (empty($contact)) $errors[] = "Contact number is required";
    if (empty($address)) $errors[] = "Address is required";
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Please enter a valid email address";
    if ($serial_no === '') $errors[] = "Serial number is required";
    elseif (strlen($serial_no) > 50) $errors[] = "Serial number cannot exceed 50 characters";
    if (!in_array($patient_type, ['Military', 'Dependent'], true)) $errors[] = "Please select Military or Dependent as the patient type";
    if ($patient_type === 'Military' && !in_array($military_rank, $allowedMilitaryRanks, true)) $errors[] = "Please select a valid military rank";
    if ($patient_type !== 'Military') $military_rank = '';
    
    if (!empty($dob)) {
        date_default_timezone_set('Asia/Manila');
        $dob_date = new DateTime($dob);
        $today = new DateTime();
        $today->setTime(0, 0, 0);
        $dob_date->setTime(0, 0, 0);
        $today_str = $today->format('Y-m-d');
        $dob_str = $dob_date->format('Y-m-d');
        $age = $today->diff($dob_date)->y;
        if ($dob_str > $today_str) $errors[] = "Date of birth cannot be in the future";
        if ($age > 120) $errors[] = "Age cannot exceed 120 years";
    }
    
    if (!empty($contact)) {
        $contact_clean = preg_replace('/[^0-9]/', '', $contact);
        if (strlen($contact_clean) != 11) $errors[] = "Contact number must be exactly 11 digits";
        elseif (!preg_match('/^09[0-9]{9}$/', $contact_clean)) $errors[] = "Contact number must start with 09 (e.g., 09123456789)";
        else $contact = $contact_clean;
    }
    
    if (empty($errors)) {
        $check_stmt = $conn->prepare("SELECT mrn FROM patients WHERE first_name = ? AND last_name = ? AND dob = ?");
        if ($check_stmt) {
            $check_stmt->bind_param("sss", $first_name, $last_name, $dob);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            if ($check_result->num_rows > 0) $errors[] = "A patient with the same name and date of birth already exists.";
            $check_stmt->close();
        }
    }
    
    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO patients (first_name, middle_name, last_name, suffix, dob, gender, contact, email, address, primary_physician, serial_no, patient_type, military_rank, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')");
        if ($stmt) {
            $stmt->bind_param("sssssssssssss", $first_name, $middle_name, $last_name, $suffix, $dob, $gender, $contact, $email, $address, $primary_physician, $serial_no, $patient_type, $military_rank);
            if ($stmt->execute()) {
                $new_mrn = $stmt->insert_id;
                $success_msg = "Patient added successfully! MRN: " . str_pad($new_mrn, 6, '0', STR_PAD_LEFT);
                header("Location: patient_profile.php?success=1&mrn=" . $new_mrn);
                exit();
            } else {
                $errors[] = "Error adding patient: " . $conn->error;
            }
            $stmt->close();
        }
    }
}

// ---------------- EDIT PATIENT ----------------
if ($profile_schema_ready && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_patient'])) {
    $error_msg = '';
    $mrn = intval($_POST['mrn'] ?? 0);
    $first_name = trim($_POST['first_name'] ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $suffix = $_POST['suffix'] ?? '';
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $contact = trim($_POST['contact'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $primary_physician = trim($_POST['primary_physician'] ?? '');
    $serial_no = trim($_POST['serial_no'] ?? '');
    $patient_type = $_POST['patient_type'] ?? '';
    $military_rank = trim($_POST['military_rank'] ?? '');

    if ($serial_no === '') $error_msg = "Serial number is required";
    elseif (strlen($serial_no) > 50) $error_msg = "Serial number cannot exceed 50 characters";
    elseif (!in_array($patient_type, ['Military', 'Dependent'], true)) $error_msg = "Please select Military or Dependent as the patient type";
    elseif ($patient_type === 'Military' && !in_array($military_rank, $allowedMilitaryRanks, true)) $error_msg = "Please select a valid military rank";
    if ($patient_type !== 'Military') $military_rank = '';
    
    if ($mrn > 0 && !empty($first_name) && !empty($last_name)) {
        if (!isValidPatientName($first_name)) $error_msg = "First name can contain letters, spaces, and hyphens only";
        elseif ($middle_name !== '' && !isValidPatientName($middle_name)) $error_msg = "Middle name can contain letters, spaces, and hyphens only";
        elseif (!isValidPatientName($last_name)) $error_msg = "Last name can contain letters, spaces, and hyphens only";
        if (!empty($contact) && empty($error_msg)) {
            $contact_clean = preg_replace('/[^0-9]/', '', $contact);
            if (strlen($contact_clean) != 11) $error_msg = "Contact number must be exactly 11 digits";
            elseif (!preg_match('/^09[0-9]{9}$/', $contact_clean)) $error_msg = "Contact number must start with 09 and contain 11 digits";
            else $contact = $contact_clean;
        }
        if (!empty($dob) && empty($error_msg)) {
            $dob_date = new DateTime($dob);
            $today = new DateTime();
            $today->setTime(0, 0, 0);
            $dob_date->setTime(0, 0, 0);
            $age = $today->diff($dob_date)->y;
            if ($dob_date > $today) $error_msg = "Date of birth cannot be in the future";
            elseif ($age > 120) $error_msg = "Age cannot exceed 120 years";
        }
        if (empty($error_msg)) {
            $stmt = $conn->prepare("UPDATE patients SET first_name=?, middle_name=?, last_name=?, suffix=?, dob=?, gender=?, contact=?, address=?, primary_physician=?, serial_no=?, patient_type=?, military_rank=? WHERE mrn=?");
            $stmt->bind_param("ssssssssssssi", $first_name, $middle_name, $last_name, $suffix, $dob, $gender, $contact, $address, $primary_physician, $serial_no, $patient_type, $military_rank, $mrn);
            if ($stmt->execute()) {
                $success_msg = "Patient updated successfully!";
                header("Location: patient_profile.php?success=1");
                exit();
            } else {
                $error_msg = "Error updating patient: " . $conn->error;
            }
            $stmt->close();
        }
    } else {
        $error_msg = "Invalid patient data";
    }
}

// ---------------- ARCHIVE ----------------
if (isset($_GET['archive'])) {
    $mrn = (int)$_GET['archive'];
    $stmt = $conn->prepare("UPDATE patients SET status='Archived' WHERE mrn=? AND status='Active'");
    $stmt->bind_param("i", $mrn);
    $stmt->execute();
    $stmt->close();
    header("Location: patient_profile.php?view=archived");
    exit();
}

if (isset($_GET['restore'])) {
    $mrn = (int)$_GET['restore'];
    $stmt = $conn->prepare("UPDATE patients SET status='Active' WHERE mrn=? AND status='Archived'");
    $stmt->bind_param("i", $mrn);
    $stmt->execute();
    $stmt->close();
    header("Location: patient_profile.php?view=archived");
    exit();
}

// ---------------- DELETE ----------------
if (isset($_GET['delete'])) {
    $mrn = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM patients WHERE mrn=?");
    $stmt->bind_param("i", $mrn);
    $stmt->execute();
    $stmt->close();
    header("Location: patient_profile.php");
    exit();
}

// ---------------- FETCH PAGINATED PATIENT DIRECTORY ----------------
$directory_view = ($_GET['view'] ?? 'active') === 'archived' ? 'archived' : 'active';
$directory_status = $directory_view === 'archived' ? 'Archived' : 'Active';
$page_size = 10;
$page = max(1, (int)($_GET['page'] ?? 1));
$search = trim($_GET['search'] ?? '');
$search_pattern = '%' . $search . '%';

$count_stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM patients
    WHERE status = ?
      AND (? = '' OR first_name LIKE ? OR middle_name LIKE ? OR last_name LIKE ?
           OR CAST(mrn AS CHAR) LIKE ? OR contact LIKE ? OR serial_no LIKE ?)
");
$count_stmt->bind_param('ssssssss', $directory_status, $search, $search_pattern, $search_pattern, $search_pattern, $search_pattern, $search_pattern, $search_pattern);
$count_stmt->execute();
$directory_total = (int)$count_stmt->get_result()->fetch_assoc()['total'];
$count_stmt->close();

$total_pages = max(1, (int)ceil($directory_total / $page_size));
$page = min($page, $total_pages);
$offset = ($page - 1) * $page_size;

$patients_stmt = $conn->prepare("
    SELECT *
    FROM patients
    WHERE status = ?
      AND (? = '' OR first_name LIKE ? OR middle_name LIKE ? OR last_name LIKE ?
           OR CAST(mrn AS CHAR) LIKE ? OR contact LIKE ? OR serial_no LIKE ?)
    ORDER BY last_name, first_name
    LIMIT ? OFFSET ?
");
$patients_stmt->bind_param('ssssssssii', $directory_status, $search, $search_pattern, $search_pattern, $search_pattern, $search_pattern, $search_pattern, $search_pattern, $page_size, $offset);
$patients_stmt->execute();
$patients = $patients_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$patients_stmt->close();

// Get next MRN (for display)
$next_mrn_result = $conn->query("SHOW TABLE STATUS LIKE 'patients'");
$next_mrn = $next_mrn_result ? $next_mrn_result->fetch_assoc()['Auto_increment'] : 1000;

function calculateAge($dob) {
    if (!$dob || $dob == '0000-00-00') return '—';
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    $age = $today->diff($birthDate)->y;
    return $age;
}

function formatMRN($mrn) {
    return str_pad($mrn, 6, '0', STR_PAD_LEFT);
}

function patientDirectoryPageUrl($page, $view, $search) {
    return '?' . http_build_query(array_filter([
        'view' => $view,
        'search' => $search,
        'page' => $page > 1 ? $page : null
    ], static function ($value) {
        return $value !== null && $value !== '';
    }));
}

$show_success = isset($_GET['success']) ? true : false;
$new_mrn = isset($_GET['mrn']) ? $_GET['mrn'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Profile | 4ID Station Hospital</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes modalFadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-6px); }
            20%, 40%, 60%, 80% { transform: translateX(6px); }
        }
        
        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        #sidebar::-webkit-scrollbar {
            width: 4px;
        }
        #sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        #sidebar::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 2px;
        }
        .dark #sidebar::-webkit-scrollbar-thumb {
            background: #475569;
        }
        .main-content {
            transition: margin-left 0.3s ease;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        
        /* Theme toggle switch */
        .theme-switch {
            position: relative;
            width: 48px;
            height: 26px;
            background: #e2e8f0;
            border-radius: 13px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(22px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 11px; }
        
        /* User Dropdown */
        .user-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            min-width: 200px;
            z-index: 1000;
            overflow: hidden;
        }
        .dark .user-dropdown {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .user-dropdown.show {
            display: block;
        }
        .user-dropdown .dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        .dark .user-dropdown .dropdown-header {
            border-bottom-color: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-header strong {
            color: #1f2937;
            display: block;
            font-size: 0.85rem;
        }
        .dark .user-dropdown .dropdown-header strong {
            color: #f1f5f9;
        }
        .user-dropdown .dropdown-header small {
            color: #6b7280;
            font-size: 0.7rem;
        }
        .dark .user-dropdown .dropdown-header small {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            color: #374151;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
        }
        .dark .user-dropdown .dropdown-item {
            color: #e5e7eb;
        }
        .user-dropdown .dropdown-item:hover {
            background: #f3f4f6;
        }
        .dark .user-dropdown .dropdown-item:hover {
            background: rgba(255,255,255,0.04);
        }
        .user-dropdown .dropdown-item i {
            width: 18px;
            color: #6b7280;
        }
        .dark .user-dropdown .dropdown-item i {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-divider {
            height: 1px;
            background: #e5e7eb;
            margin: 4px 0;
        }
        .dark .user-dropdown .dropdown-divider {
            background: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-item.logout {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout i {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout:hover {
            background: rgba(239, 68, 68, 0.08);
        }
        
        /* Modal styles */
        .modal-backdrop {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(4px);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            padding: 16px;
        }
        .modal-backdrop.show { display: flex; }
        .modal {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 20px;
            width: 100%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalFadeIn 0.2s ease;
        }
        .dark .modal {
            background: #1f2937;
            border-color: rgba(255,255,255,0.08);
        }
        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .dark .modal-header { border-bottom-color: rgba(255,255,255,0.06); }
        .modal-header h3 {
            font-size: 1.1rem;
            font-weight: 700;
            color: #1f2937;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .dark .modal-header h3 { color: #f1f5f9; }
        .modal-header h3 i { color: #0284c7; }
        .dark .modal-header h3 i { color: #38bdf8; }
        .modal-close {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            border: 1px solid #e5e7eb;
            background: transparent;
            color: #6b7280;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }
        .dark .modal-close { border-color: rgba(255,255,255,0.06); color: #9ca3af; }
        .modal-close:hover { background: #f3f4f6; }
        .dark .modal-close:hover { background: rgba(255,255,255,0.04); }
        .modal-body { padding: 24px; }
        .modal-actions {
            display: flex;
            gap: 12px;
            padding: 16px 24px 24px;
            border-top: 1px solid #e5e7eb;
        }
        .dark .modal-actions { border-top-color: rgba(255,255,255,0.06); }
        
        /* Form elements in modal */
        .form-group { margin-bottom: 16px; }
        .form-group label {
            display: block;
            font-size: 0.7rem;
            font-weight: 700;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }
        .dark .form-group label { color: #9ca3af; }
        .form-group label i { color: #9ca3af; margin-right: 4px; }
        .dark .form-group label i { color: #6b7280; }
        .form-group label .required { color: #ef4444; margin-left: 2px; }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px 14px;
            background: #f8fafc;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            color: #1f2937;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s ease;
            outline: none;
        }
        .dark .form-group input, .dark .form-group select {
            background: #111827;
            border-color: rgba(255,255,255,0.06);
            color: #f1f5f9;
        }
        .form-group input:focus, .form-group select:focus {
            border-color: #0284c7;
            box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.08);
        }
        .dark .form-group input:focus, .dark .form-group select:focus {
            border-color: #38bdf8;
        }
        .form-group select option {
            background: #ffffff;
            color: #1f2937;
        }
        .dark .form-group select option {
            background: #1f2937;
            color: #f1f5f9;
        }
        .form-group .help-text {
            font-size: 0.6rem;
            color: #6b7280;
            margin-top: 4px;
        }
        .dark .form-group .help-text { color: #9ca3af; }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }
        @media (max-width: 640px) { .form-row { grid-template-columns: 1fr; } }
        
        .mrn-preview {
            background: rgba(2, 132, 199, 0.06);
            border: 1px solid rgba(2, 132, 199, 0.1);
            border-radius: 12px;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        .dark .mrn-preview {
            background: rgba(56, 189, 248, 0.06);
            border-color: rgba(56, 189, 248, 0.1);
        }
        .mrn-preview i {
            color: #0284c7;
        }
        .dark .mrn-preview i {
            color: #38bdf8;
        }
        .mrn-preview span {
            color: #6b7280;
            font-size: 0.8rem;
        }
        .dark .mrn-preview span {
            color: #9ca3af;
        }
        .mrn-preview strong {
            color: #0284c7;
            font-family: 'JetBrains Mono', monospace;
            font-size: 1rem;
        }
        .dark .mrn-preview strong {
            color: #38bdf8;
        }
        
        /* Alert */
        .alert-success {
            background: rgba(16, 185, 129, 0.06);
            border: 1px solid rgba(16, 185, 129, 0.15);
            border-radius: 12px;
            padding: 14px 18px;
            margin-bottom: 20px;
            color: #10b981;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .dark .alert-success {
            color: #6ee7b7;
        }
        .alert-success i {
            color: #10b981;
            font-size: 1.1rem;
        }
        .dark .alert-success i {
            color: #34d399;
        }
        
        .error-box {
            background: rgba(239, 68, 68, 0.06);
            border: 1px solid rgba(239, 68, 68, 0.15);
            border-radius: 12px;
            padding: 14px 18px;
            margin-bottom: 20px;
            animation: shake 0.4s ease;
        }
        .dark .error-box {
            background: rgba(239, 68, 68, 0.08);
        }
        .error-box .error-title {
            color: #ef4444;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .dark .error-box .error-title {
            color: #f87171;
        }
        .error-box ul {
            list-style: none;
            margin-top: 6px;
            padding-left: 24px;
        }
        .error-box ul li {
            color: #dc2626;
            font-size: 0.75rem;
            padding: 2px 0;
            position: relative;
        }
        .dark .error-box ul li {
            color: #fca5a5;
        }
        .error-box ul li::before {
            content: '•';
            position: absolute;
            left: -14px;
            color: #ef4444;
        }
        .dark .error-box ul li::before {
            color: #f87171;
        }
        
        /* Menu toggle for mobile */
        .menu-toggle {
            display: none;
        }
        @media (max-width: 768px) {
            .menu-toggle {
                display: block;
            }
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            .sidebar.open {
                transform: translateX(0);
            }
        }
        
        /* Search box - consistent with index */
        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 30px;
            padding: 6px 14px;
            transition: all 0.2s ease;
        }
        .dark .search-box {
            background: rgba(255,255,255,0.04);
            border-color: rgba(255,255,255,0.06);
        }
        .search-box:focus-within {
            border-color: rgba(2, 132, 199, 0.3);
        }
        .search-box i {
            color: #6b7280;
            font-size: 0.8rem;
        }
        .dark .search-box i {
            color: #9ca3af;
        }
        .search-box input {
            background: transparent;
            border: none;
            outline: none;
            color: #1f2937;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 0.8rem;
            width: 180px;
        }
        .dark .search-box input {
            color: #f1f5f9;
        }
        .search-box input::placeholder {
            color: #9ca3af;
        }
        .dark .search-box input::placeholder {
            color: #6b7280;
        }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- SIDEBAR -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span>
                    <span>E</span>
                    <span>S</span>
                    <span>H</span>
                </div>

                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="index.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-gauge-high text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_profile.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="medical_history.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-notes-medical text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Medical History</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_documents.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-file-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Documents</span>
                        </a>
                    </li>
                    <li>
                        <a href="scheduled_patient.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-calendar-check text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Scheduled Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_frontdesk.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-ticket text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue System</span>
                        </a>
                    </li>
                    
                    <!-- Profile Link -->
                    <li>
                        <a href="profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-circle text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">My Profile</span>
                        </a>
                    </li>
                    <?php if (($current_user['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="admin/users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-shield text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i></div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                
                <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
                    <a href="logout.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                        <div class="w-6 h-6 flex items-center justify-center shrink-0">
                            <i class="fas fa-sign-out-alt text-base text-rose-400 group-hover/link:text-rose-500 transition-colors"></i>
                        </div>
                        <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
                    </a>
                </div>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 main-content">
        
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">Patient Profile</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">Manage patient records and demographics</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($current_user['full_name']); ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400 font-medium"><?php echo ucfirst($current_user['role']); ?></div>
                </div>
                
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-sun"></i></span>
                    <div class="theme-switch" id="themeToggle">
                        <div class="slider">
                            <span class="sun"><i class="fas fa-sun"></i></span>
                            <span class="moon"><i class="fas fa-moon"></i></span>
                        </div>
                    </div>
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-moon"></i></span>
                </div>

                <!-- User Avatar with Click Dropdown -->
                <div class="relative">
                    <div class="w-10 h-10 rounded-full bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors" id="userAvatar">
                        <i class="fas fa-user text-slate-400 dark:text-slate-500 text-sm"></i>
                    </div>
                    <div class="user-dropdown" id="userDropdown">
                        <div class="dropdown-header">
                            <strong><?php echo htmlspecialchars($current_user['full_name']); ?></strong>
                            <small><?php echo ucfirst($current_user['role']); ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user-circle"></i> My Profile
                        </a>
                        <a href="logout.php" class="dropdown-item logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Success Message -->
        <?php if ($show_success): ?>
            <div class="alert-success">
                <i class="fas fa-check-circle"></i>
                Patient record saved successfully! <?php if ($new_mrn): ?><strong>MRN: <?php echo formatMRN($new_mrn); ?></strong><?php endif; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_msg)): ?>
            <div class="error-box">
                <div class="error-title"><i class="fas fa-triangle-exclamation"></i> Error</div>
                <ul><li><?php echo htmlspecialchars($error_msg); ?></li></ul>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <div class="error-title"><i class="fas fa-triangle-exclamation"></i> Please fix the following errors:</div>
                <ul><?php foreach ($errors as $err): ?><li><?php echo htmlspecialchars($err); ?></li><?php endforeach; ?></ul>
            </div>
        <?php endif; ?>
        
        <!-- Patient Directory -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <i class="fas fa-list-ul text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200"><?php echo $directory_view === 'archived' ? 'Archived Patients' : 'Patient Directory'; ?></span>
                </div>
                <div class="flex flex-wrap items-center gap-3">
                    <?php if ($directory_view === 'active'): ?>
                        <button id="addBtn" class="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-2">
                            <i class="fas fa-plus"></i> Add Patient
                        </button>
                    <?php endif; ?>
                    <nav class="flex gap-2" aria-label="Patient directory">
                        <a href="?view=active" class="px-3 py-2 rounded-lg text-xs font-bold <?php echo $directory_view === 'active' ? 'bg-sky-600 text-white' : 'bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-200'; ?>">Active</a>
                        <a href="?view=archived" class="px-3 py-2 rounded-lg text-xs font-bold <?php echo $directory_view === 'archived' ? 'bg-sky-600 text-white' : 'bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-200'; ?>">Archive</a>
                    </nav>
                    <form method="GET" class="search-box">
                        <input type="hidden" name="view" value="<?php echo htmlspecialchars($directory_view); ?>">
                        <i class="fas fa-search"></i>
                        <input type="search" name="search" id="searchInput" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search name, MRN, serial...">
                        <button type="submit" class="text-sky-600 dark:text-sky-400 text-xs font-bold" aria-label="Search patients">Search</button>
                    </form>
                </div>
            </div>
            <div class="overflow-x-auto">
                <?php if(empty($patients)): ?>
                    <div class="text-center py-12 text-slate-400 dark:text-slate-400">
                        <i class="fas fa-user-friends text-3xl mb-3 block text-slate-300 dark:text-slate-600"></i>
                        <p class="font-medium"><?php echo $search !== '' ? 'No matching patients found' : ($directory_view === 'archived' ? 'No archived patients' : 'No patients found'); ?></p>
                        <?php if ($directory_view === 'active' && $search === ''): ?>
                            <p class="text-sm text-slate-400 dark:text-slate-500 mt-1">Click "Add Patient" to register a new patient</p>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <table class="w-full border-collapse min-w-[1100px]">
                        <thead>
                            <tr class="bg-slate-50/50 dark:bg-slate-800/40 text-left border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.65rem] uppercase tracking-wider font-bold">
                                <th class="px-5 py-3.5">MRN</th>
                                <th class="px-5 py-3.5">Last Name</th>
                                <th class="px-5 py-3.5">First Name</th>
                                <th class="px-5 py-3.5">Age / DOB</th>
                                <th class="px-5 py-3.5">Gender</th>
                                <th class="px-5 py-3.5">Serial No.</th>
                                <th class="px-5 py-3.5">Patient Type / Rank</th>
                                <th class="px-5 py-3.5">Contact</th>
                                <th class="px-5 py-3.5">Status</th>
                                <th class="px-5 py-3.5">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-300/80 dark:divide-slate-700/50 text-xs md:text-sm text-slate-700 dark:text-slate-200" id="patientsList">
                            <?php foreach($patients as $p): $age = calculateAge($p['dob']); ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors duration-150" 
                                data-mrn="<?= $p['mrn'] ?>"
                                data-first_name="<?= htmlspecialchars($p['first_name']) ?>"
                                data-middle_name="<?= htmlspecialchars($p['middle_name'] ?? '') ?>"
                                data-last_name="<?= htmlspecialchars($p['last_name']) ?>"
                                data-suffix="<?= htmlspecialchars($p['suffix'] ?? '') ?>"
                                data-dob="<?= $p['dob'] ?>"
                                data-gender="<?= $p['gender'] ?>"
                                data-contact="<?= htmlspecialchars($p['contact'] ?? '') ?>"
                                data-address="<?= htmlspecialchars($p['address'] ?? '') ?>"
                                data-physician="<?= htmlspecialchars($p['primary_physician'] ?? '') ?>"
                                data-serial_no="<?= htmlspecialchars($p['serial_no'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                                data-patient_type="<?= htmlspecialchars($p['patient_type'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                                data-military_rank="<?= htmlspecialchars($p['military_rank'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                <td class="px-5 py-3.5"><span class="font-mono text-xs bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded-md text-sky-600 dark:text-sky-400"><?= formatMRN($p['mrn']) ?></span></td>
                                <td class="px-5 py-3.5 font-semibold text-slate-800 dark:text-slate-100"><?= htmlspecialchars($p['last_name']) ?><?php if(!empty($p['suffix'])): ?> <?= htmlspecialchars($p['suffix']) ?><?php endif; ?></td>
                                <td class="px-5 py-3.5"><?= htmlspecialchars($p['first_name']) ?> <?php if(!empty($p['middle_name'])): ?><?= htmlspecialchars($p['middle_name']) ?><?php endif; ?></td>
                                <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400 text-sm">
                                    <?= date('M d, Y', strtotime($p['dob'])) ?>
                                    <?php if ($age > 0 && $age != '—'): ?>
                                        <span class="text-xs text-slate-400 dark:text-slate-500 ml-1">(<?= $age ?> yrs)</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-5 py-3.5"><?= $p['gender'] ?></td>
                                <td class="px-5 py-3.5 font-mono text-xs"><?= htmlspecialchars($p['serial_no'] ?? '—') ?></td>
                                <td class="px-5 py-3.5">
                                    <?= htmlspecialchars($p['patient_type'] ?? '—') ?>
                                    <?php if (!empty($p['military_rank'])): ?><span class="block mt-1 text-xs text-slate-500 dark:text-slate-400"><?= htmlspecialchars($p['military_rank']) ?></span><?php endif; ?>
                                </td>
                                <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400"><?= htmlspecialchars($p['contact'] ?: '—') ?></td>
                                <td class="px-5 py-3.5"><span class="inline-block px-3 py-1 rounded-full text-[0.65rem] font-bold tracking-wide uppercase <?php echo $directory_view === 'archived' ? 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-300 dark:border-slate-600' : 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-400/20'; ?>"><?php echo htmlspecialchars($directory_status); ?></span></td>
                                <td class="px-5 py-3.5">
                                    <?php if ($directory_view === 'archived'): ?>
                                        <a href="?restore=<?= (int)$p['mrn'] ?>" onclick="return confirm('Restore this patient to the active directory?')" class="px-3 py-1.5 bg-emerald-50 dark:bg-emerald-500/10 hover:bg-emerald-100 dark:hover:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold rounded-lg transition-colors inline-flex items-center gap-1"><i class="fas fa-rotate-left"></i> Restore</a>
                                    <?php else: ?>
                                        <button class="px-3 py-1.5 bg-amber-50 dark:bg-amber-500/10 hover:bg-amber-100 dark:hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 text-xs font-bold rounded-lg transition-colors editBtn"><i class="fas fa-edit"></i> Edit</button>
                                        <a href="?archive=<?= (int)$p['mrn'] ?>" onclick="return confirm('Archive this patient?')" class="px-3 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-500 dark:text-slate-400 text-xs font-bold rounded-lg transition-colors inline-flex items-center gap-1" aria-label="Archive patient"><i class="fas fa-archive"></i></a>
                                    <?php endif; ?>
                                    <a href="?delete=<?= (int)$p['mrn'] ?>" onclick="return confirm('WARNING: This will permanently delete. Are you sure?')" class="px-3 py-1.5 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-bold rounded-lg transition-colors inline-flex items-center gap-1" aria-label="Permanently delete patient"><i class="fas fa-trash-alt"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-700/70 flex flex-wrap items-center justify-between gap-3">
                <span class="text-xs text-slate-500 dark:text-slate-400">
                    Showing <?php echo $directory_total === 0 ? 0 : $offset + 1; ?>–<?php echo min($offset + count($patients), $directory_total); ?> of <?php echo number_format($directory_total); ?>
                </span>
                <?php if ($total_pages > 1): ?>
                    <nav class="flex items-center gap-2" aria-label="Patient directory pagination">
                        <?php if ($page > 1): ?>
                            <a href="<?php echo htmlspecialchars(patientDirectoryPageUrl($page - 1, $directory_view, $search)); ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Previous</a>
                        <?php endif; ?>
                        <span class="text-xs font-semibold text-slate-600 dark:text-slate-300">Page <?php echo $page; ?> of <?php echo $total_pages; ?></span>
                        <?php if ($page < $total_pages): ?>
                            <a href="<?php echo htmlspecialchars(patientDirectoryPageUrl($page + 1, $directory_view, $search)); ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Next</a>
                        <?php endif; ?>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Add/Edit Modal -->
    <div id="patientModal" class="modal-backdrop">
        <div class="modal">
            <div class="modal-header">
                <h3 id="modalTitle"><i class="fas fa-user-plus"></i> Add New Patient</h3>
                <button class="modal-close" id="closeModal">&times;</button>
            </div>
            <form method="POST" id="patientForm">
                <div class="modal-body">
                    <input type="hidden" name="mrn" id="patientMrn">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> First Name <span class="required">*</span></label>
                            <input type="text" name="first_name" id="firstName" placeholder="Enter first name" required title="Use letters, spaces, and hyphens only">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> Middle Name <span style="color:#6b7280;font-weight:400;">(Optional)</span></label>
                            <input type="text" name="middle_name" id="middleName" placeholder="Enter middle name" title="Use letters, spaces, and hyphens only">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> Last Name <span class="required">*</span></label>
                            <input type="text" name="last_name" id="lastName" placeholder="Enter last name" required title="Use letters, spaces, and hyphens only">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Suffix</label>
                            <select name="suffix" id="suffix">
                                <option value="">-- None --</option>
                                <option value="Jr.">Jr.</option>
                                <option value="Sr.">Sr.</option>
                                <option value="II">II</option>
                                <option value="III">III</option>
                                <option value="IV">IV</option>
                                <option value="V">V</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mrn-preview">
                        <i class="fas fa-id-card"></i>
                        <span>MRN will be auto-generated:</span>
                        <strong id="mrnPreview"><?php echo formatMRN($next_mrn); ?></strong>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-calendar-alt"></i> Date of Birth <span class="required">*</span></label>
                            <input type="date" name="dob" id="dob" required max="<?php echo date('Y-m-d'); ?>">
                            <div class="help-text">Cannot be future. Today is allowed. Max age 120 years.</div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-venus-mars"></i> Gender <span class="required">*</span></label>
                            <select name="gender" id="gender" required>
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-id-badge"></i> Serial No. <span class="required">*</span></label>
                            <input type="text" name="serial_no" id="serialNo" maxlength="50" placeholder="Enter serial number" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-users"></i> Patient Type <span class="required">*</span></label>
                            <select name="patient_type" id="patientType" required>
                                <option value="">-- Select Patient Type --</option>
                                <option value="Military">Military</option>
                                <option value="Dependent">Dependent</option>
                            </select>
                            <div class="help-text">For dependents, enter the sponsor's serial number.</div>
                        </div>
                    </div>

                    <div class="form-group" id="militaryRankGroup" hidden>
                        <label><i class="fas fa-medal"></i> Military Rank <span class="required">*</span></label>
                        <select name="military_rank" id="militaryRank">
                            <option value="">-- Select Military Rank --</option>
                            <?php foreach ($militaryRanks as $rankGroup => $ranks): ?>
                                <optgroup label="<?= htmlspecialchars($rankGroup, ENT_QUOTES, 'UTF-8') ?>">
                                    <?php foreach ($ranks as $rank): ?>
                                        <option value="<?= htmlspecialchars($rank, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($rank) ?></option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Contact Number <span class="required">*</span></label>
                        <input type="tel" name="contact" id="contact" placeholder="09123456789" required>
                        <div class="help-text">Must be 11 digits and start with 09 (e.g., 09123456789)</div>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email Address <span style="color:#6b7280;font-weight:400;">(Optional)</span></label>
                        <input type="email" name="email" id="email" placeholder="patient@example.com">
                        <div class="help-text">Appointment reminders will be sent to this address.</div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Address <span class="required">*</span></label>
                        <input type="text" name="address" id="address" placeholder="Complete address" required>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-user-md"></i> Primary Physician <span style="color:#6b7280;font-weight:400;">(Optional)</span></label>
                        <input type="text" name="primary_physician" id="physician" placeholder="Doctor's name">
                    </div>
                </div>
                <div class="modal-actions">
                    <button type="button" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-sm font-bold rounded-xl transition-colors" id="cancelBtn">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-2" name="add_patient" id="submitBtn"><i class="fas fa-save"></i> Save Patient</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            localStorage.setItem('theme', htmlElement.classList.contains('dark') ? 'dark' : 'light');
        });
        
        // ============================================
        // User Dropdown - Click to toggle
        // ============================================
        const userAvatar = document.getElementById('userAvatar');
        const userDropdown = document.getElementById('userDropdown');
        
        userAvatar.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });
        
        document.addEventListener('click', function(e) {
            if (!userAvatar.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('show');
            }
        });
        
        // ============================================
        // Mobile Menu
        // ============================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        });

        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('mobileMenuBtn');
            if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
        
        // ============================================
        // Modal Controls
        // ============================================
        const modal = document.getElementById('patientModal');
        const modalTitle = document.getElementById('modalTitle');
        const form = document.getElementById('patientForm');
        const addBtn = document.getElementById('addBtn');
        const closeBtn = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');
        const submitBtn = document.getElementById('submitBtn');
        
        const patientMrn = document.getElementById('patientMrn');
        const firstName = document.getElementById('firstName');
        const middleName = document.getElementById('middleName');
        const lastName = document.getElementById('lastName');
        const suffix = document.getElementById('suffix');
        const dob = document.getElementById('dob');
        const gender = document.getElementById('gender');
        const contact = document.getElementById('contact');
        const address = document.getElementById('address');
        const physician = document.getElementById('physician');
        const serialNo = document.getElementById('serialNo');
        const patientType = document.getElementById('patientType');
        const militaryRankGroup = document.getElementById('militaryRankGroup');
        const militaryRank = document.getElementById('militaryRank');

        function updateMilitaryRankVisibility() {
            const isMilitary = patientType.value === 'Military';
            militaryRankGroup.hidden = !isMilitary;
            militaryRank.required = isMilitary;
            if (!isMilitary) militaryRank.value = '';
        }

        patientType.addEventListener('change', updateMilitaryRankVisibility);
        
        function closeModal() {
            modal.classList.remove('show');
            form.reset();
        }
        
        if (addBtn) addBtn.addEventListener('click', function() {
            modalTitle.innerHTML = '<i class="fas fa-user-plus"></i> Add New Patient';
            patientMrn.value = '';
            form.reset();
            updateMilitaryRankVisibility();
            submitBtn.name = 'add_patient';
            modal.classList.add('show');
            const today = new Date();
            const yyyy = today.getFullYear();
            const mm = String(today.getMonth() + 1).padStart(2, '0');
            const dd = String(today.getDate()).padStart(2, '0');
            dob.setAttribute('max', yyyy + '-' + mm + '-' + dd);
        });
        
        closeBtn.addEventListener('click', closeModal);
        cancelBtn.addEventListener('click', closeModal);
        window.addEventListener('click', function(e) {
            if (e.target === modal) closeModal();
        });
        
        // ============================================
        // Edit Button Handler
        // ============================================
        function attachEditHandlers() {
            document.querySelectorAll('.editBtn').forEach(function(btn) {
                btn.removeEventListener('click', handleEditClick);
                btn.addEventListener('click', handleEditClick);
            });
        }
        
        function handleEditClick(e) {
            const btn = e.currentTarget;
            const tr = btn.closest('tr');
            modalTitle.innerHTML = '<i class="fas fa-user-edit"></i> Edit Patient';
            patientMrn.value = tr.dataset.mrn;
            firstName.value = tr.dataset.first_name;
            middleName.value = tr.dataset.middle_name || '';
            lastName.value = tr.dataset.last_name;
            suffix.value = tr.dataset.suffix || '';
            dob.value = tr.dataset.dob;
            gender.value = tr.dataset.gender;
            contact.value = tr.dataset.contact;
            address.value = tr.dataset.address;
            physician.value = tr.dataset.physician;
            serialNo.value = tr.dataset.serial_no || '';
            patientType.value = tr.dataset.patient_type || '';
            militaryRank.value = tr.dataset.military_rank || '';
            updateMilitaryRankVisibility();
            submitBtn.name = 'edit_patient';
            modal.classList.add('show');
            const today = new Date();
            const yyyy = today.getFullYear();
            const mm = String(today.getMonth() + 1).padStart(2, '0');
            const dd = String(today.getDate()).padStart(2, '0');
            dob.setAttribute('max', yyyy + '-' + mm + '-' + dd);
        }
        
        attachEditHandlers();
        
        // ============================================
        // Contact Number Validation
        // ============================================
        if (contact) {
            contact.addEventListener('input', function(e) {
                let value = this.value.replace(/[^0-9]/g, '');
                if (value.length > 11) value = value.slice(0, 11);
                this.value = value;
            });
        }
        
        // ============================================
        // DOB Validation
        // ============================================
        if (dob) {
            dob.addEventListener('change', function(e) {
                const dobDate = new Date(this.value);
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                dobDate.setHours(0, 0, 0, 0);
                
                if (dobDate > today) {
                    alert('Date of birth cannot be in the future!\n\nPlease select a date that is today or earlier.');
                    this.value = '';
                    return;
                }
                
                if (this.value) {
                    let age = today.getFullYear() - dobDate.getFullYear();
                    const monthDiff = today.getMonth() - dobDate.getMonth();
                    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dobDate.getDate())) {
                        age--;
                    }
                    if (age > 100) {
                        alert('Note: Patient age is ' + age + ' years. Please verify the date of birth is correct.');
                    }
                    if (age > 120) {
                        alert('Age cannot exceed 120 years! Please correct the date of birth.');
                        this.value = '';
                    }
                }
            });
        }
        
        // ============================================
        // Form Validation
        // ============================================
        form.addEventListener('submit', function(e) {
            if (!firstName.value.trim()) {
                e.preventDefault();
                alert('Please enter first name');
                firstName.focus();
                return;
            }
            if (!/^[\p{L}\p{M} -]+$/u.test(firstName.value.trim())) {
                e.preventDefault();
                alert('First name can contain letters, spaces, and hyphens only');
                firstName.focus();
                return;
            }
            if (middleName.value.trim() && !/^[\p{L}\p{M} -]+$/u.test(middleName.value.trim())) {
                e.preventDefault();
                alert('Middle name can contain letters, spaces, and hyphens only');
                middleName.focus();
                return;
            }
            if (!lastName.value.trim()) {
                e.preventDefault();
                alert('Please enter last name');
                lastName.focus();
                return;
            }
            if (!/^[\p{L}\p{M} -]+$/u.test(lastName.value.trim())) {
                e.preventDefault();
                alert('Last name can contain letters, spaces, and hyphens only');
                lastName.focus();
                return;
            }
            if (!dob.value) {
                e.preventDefault();
                alert('Please enter date of birth');
                dob.focus();
                return;
            }
            if (!gender.value) {
                e.preventDefault();
                alert('Please select gender');
                gender.focus();
                return;
            }
            if (!contact.value.trim()) {
                e.preventDefault();
                alert('Please enter contact number');
                contact.focus();
                return;
            }
            if (contact.value.length != 11) {
                e.preventDefault();
                alert('Contact number must be exactly 11 digits');
                contact.focus();
                return;
            }
            if (!contact.value.match(/^09[0-9]{9}$/)) {
                e.preventDefault();
                alert('Contact number must start with 09');
                contact.focus();
                return;
            }
            if (!address.value.trim()) {
                e.preventDefault();
                alert('Please enter address');
                address.focus();
                return;
            }
        });
    </script>
</body>
</html>