<?php
// appointment_api.php - API for appointment management
require_once 'db.php';
require_once 'auth.php';
header('Content-Type: application/json');

$auth->requireRole(['admin', 'doctor', 'staff']);
$current_user = $auth->currentUser();
$user_id = $current_user['id'];
$user_role = $current_user['role'];

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'get_today':
        getTodayAppointments();
        break;
    case 'get_all':
        getAllAppointments();
        break;
    case 'get_calendar_events':
        getCalendarEvents();
        break;
    case 'start_appointment':
        startAppointment();
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

function getTodayAppointments() {
    global $conn, $current_user, $user_role;
    
    $doctor_id = $_GET['doctor_id'] ?? ($user_role === 'doctor' ? $current_user['id'] : 0);
    $department = $_GET['department'] ?? '';
    $today = date('Y-m-d');
    
    $sql = "SELECT a.*, p.full_name, p.phone 
            FROM appointments a 
            JOIN patients p ON a.patient_id = p.id 
            WHERE a.appointment_date = ? AND a.status IN ('scheduled', 'confirmed')
            AND a.doctor_id = ?";
    $params = [$today, $doctor_id];
    
    if ($department && $user_role === 'admin') {
        $sql .= " AND a.department = ?";
        $params[] = $department;
    }
    
    $sql .= " ORDER BY a.appointment_time ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(str_repeat('s', count($params)), ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $appointments = [];
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
    
    echo json_encode($appointments);
}

function getAllAppointments() {
    global $conn, $current_user, $user_role;
    
    $doctor_id = $_GET['doctor_id'] ?? ($user_role === 'doctor' ? $current_user['id'] : 0);
    $department = $_GET['department'] ?? '';
    $date = $_GET['date'] ?? date('Y-m-d');
    
    $sql = "SELECT a.*, p.full_name, p.phone, p.email 
            FROM appointments a 
            JOIN patients p ON a.patient_id = p.id 
            WHERE DATE(a.appointment_date) = ? AND a.doctor_id = ?";
    $params = [$date, $doctor_id];
    
    if ($department && $user_role === 'admin') {
        $sql .= " AND a.department = ?";
        $params[] = $department;
    }
    
    $sql .= " ORDER BY a.appointment_date DESC, a.appointment_time ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(str_repeat('s', count($params)), ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $appointments = [];
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
    
    echo json_encode($appointments);
}

function getCalendarEvents() {
    global $conn, $current_user, $user_role;
    
    $doctor_id = $_GET['doctor_id'] ?? ($user_role === 'doctor' ? $current_user['id'] : 0);
    $department = $_GET['department'] ?? '';
    $start = $_GET['start'] ?? '';
    $end = $_GET['end'] ?? '';
    
    $sql = "SELECT a.*, p.full_name 
            FROM appointments a 
            JOIN patients p ON a.patient_id = p.id 
            WHERE a.doctor_id = ?";
    $params = [$doctor_id];
    
    if ($start && $end) {
        $sql .= " AND a.appointment_date BETWEEN ? AND ?";
        $params[] = $start;
        $params[] = $end;
    }
    
    if ($department && $user_role === 'admin') {
        $sql .= " AND a.department = ?";
        $params[] = $department;
    }
    
    $sql .= " ORDER BY a.appointment_date ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(str_repeat('s', count($params)), ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $events = [];
    $statusColors = [
        'scheduled' => '#9C27B0',
        'confirmed' => '#4A90E2',
        'in_progress' => '#FFB84D',
        'completed' => '#A4D1B1',
        'cancelled' => '#FF6F61'
    ];
    
    while ($row = $result->fetch_assoc()) {
        $datetime = $row['appointment_date'] . 'T' . $row['appointment_time'];
        $events[] = [
            'id' => $row['id'],
            'title' => $row['full_name'] . ' - ' . ($row['appointment_type'] ?? 'Consultation'),
            'start' => $datetime,
            'end' => date('Y-m-d\TH:i:s', strtotime($datetime . ' +30 minutes')),
            'backgroundColor' => $statusColors[$row['status']] ?? '#888',
            'borderColor' => $statusColors[$row['status']] ?? '#888',
            'extendedProps' => [
                'status' => $row['status'],
                'type' => $row['appointment_type'],
                'id' => $row['id']
            ]
        ];
    }
    
    echo json_encode($events);
}

function startAppointment() {
    global $conn;
    
    $appointment_id = $_POST['appointment_id'] ?? 0;
    $doctor_id = $_POST['doctor_id'] ?? 0;
    
    if (!$appointment_id) {
        echo json_encode(['success' => false, 'message' => 'Appointment ID required']);
        return;
    }
    
    // Update appointment status
    $stmt = $conn->prepare("UPDATE appointments SET status = 'in_progress', updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $appointment_id);
    
    if ($stmt->execute()) {
        // Get appointment details to add to queue
        $stmt2 = $conn->prepare("SELECT a.*, p.full_name, p.id as patient_id FROM appointments a JOIN patients p ON a.patient_id = p.id WHERE a.id = ?");
        $stmt2->bind_param("i", $appointment_id);
        $stmt2->execute();
        $result = $stmt2->get_result();
        $appointment = $result->fetch_assoc();
        
        if ($appointment) {
            // Check if already in queue
            $checkStmt = $conn->prepare("SELECT id FROM queue WHERE patient_id = ? AND status IN ('Waiting', 'Called', 'In Consultation')");
            $checkStmt->bind_param("i", $appointment['patient_id']);
            $checkStmt->execute();
            if ($checkStmt->get_result()->num_rows === 0) {
                // Add to queue as high priority
                $insertStmt = $conn->prepare("INSERT INTO queue (patient_id, department, status, priority, display_number, created_at) 
                    VALUES (?, ?, 'Waiting', 'Appointment', CONCAT(?, '-', LPAD((SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(display_number, '-', -1) AS UNSIGNED)), 0) + 1 FROM queue q WHERE q.department = ?), 3, '0')), NOW())");
                $dept = $appointment['department'];
                $prefix = substr($dept, 0, 2);
                $insertStmt->bind_param("issss", $appointment['patient_id'], $dept, $prefix, $dept);
                $insertStmt->execute();
            }
        }
        
        echo json_encode(['success' => true, 'message' => 'Appointment started successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to start appointment']);
    }
}
?>