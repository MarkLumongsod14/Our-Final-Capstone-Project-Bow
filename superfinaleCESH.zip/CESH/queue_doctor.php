<?php
// queue_doctor.php - Doctor's panel for managing queue
// Camp Evangelista Station Hospital
require_once 'db.php';
require_once 'auth.php';

$auth->requireRole(['admin', 'doctor']);

$current_user = $auth->currentUser();
$user_department = $current_user['assigned_department'] ?? 'General';
$is_admin = ($current_user['role'] === 'admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_availability']) && !$is_admin) {
    $availability = !empty($_POST['is_available']) ? 1 : 0;
    $availabilityStmt = $conn->prepare("UPDATE users SET is_available = ? WHERE id = ? AND role = 'doctor'");
    $availabilityStmt->bind_param('ii', $availability, $current_user['id']);
    $availabilityStmt->execute();
    $availabilityStmt->close();
    header('Location: queue_doctor.php?dept=' . urlencode($_GET['dept'] ?? $user_department));
    exit();
}

$availabilityStmt = $conn->prepare("SELECT is_available FROM users WHERE id = ? LIMIT 1");
$availabilityStmt->bind_param('i', $current_user['id']);
$availabilityStmt->execute();
$availabilityRow = $availabilityStmt->get_result()->fetch_assoc();
$availabilityStmt->close();
$is_available = (int)($availabilityRow['is_available'] ?? 1) === 1;

$department = $_GET['dept'] ?? $user_department;

if (!$auth->canAccessDepartment($department)) {
    die("Access denied. You are not authorized for this department.");
}

$accessible_depts = $auth->getAccessibleDepartments();
$smartQueueTransferCsrf = unified_csrf_token();

// Fix: Remove duplicate "Dr." prefix if it exists in the stored name
$doctor_name = $current_user['full_name'];
$doctor_name = preg_replace('/^Dr\.?\s*/i', '', $doctor_name);
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Physician Queue | 4ID Station Hospital</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        @keyframes glowPulse {
            0%, 100% { box-shadow: 0 0 30px rgba(2, 132, 199, 0.15); }
            50% { box-shadow: 0 0 60px rgba(2, 132, 199, 0.3); }
        }
        #sidebar::-webkit-scrollbar {
            width: 4px;
        }
        #sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        #sidebar::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 2px;
        }
        .dark #sidebar::-webkit-scrollbar-thumb {
            background: #475569;
        }
        .main-content {
            transition: margin-left 0.3s ease;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        
        /* Theme toggle switch */
        .theme-switch {
            position: relative;
            width: 48px;
            height: 26px;
            background: #e2e8f0;
            border-radius: 13px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(22px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 11px; }
        
        /* User Dropdown */
        .user-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            min-width: 200px;
            z-index: 1000;
            overflow: hidden;
        }
        .dark .user-dropdown {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .user-dropdown.show {
            display: block;
        }
        .user-dropdown .dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        .dark .user-dropdown .dropdown-header {
            border-bottom-color: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-header strong {
            color: #1f2937;
            display: block;
            font-size: 0.85rem;
        }
        .dark .user-dropdown .dropdown-header strong {
            color: #f1f5f9;
        }
        .user-dropdown .dropdown-header small {
            color: #6b7280;
            font-size: 0.7rem;
        }
        .dark .user-dropdown .dropdown-header small {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            color: #374151;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
        }
        .dark .user-dropdown .dropdown-item {
            color: #e5e7eb;
        }
        .user-dropdown .dropdown-item:hover {
            background: #f3f4f6;
        }
        .dark .user-dropdown .dropdown-item:hover {
            background: rgba(255,255,255,0.04);
        }
        .user-dropdown .dropdown-item i {
            width: 18px;
            color: #6b7280;
        }
        .dark .user-dropdown .dropdown-item i {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-divider {
            height: 1px;
            background: #e5e7eb;
            margin: 4px 0;
        }
        .dark .user-dropdown .dropdown-divider {
            background: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-item.logout {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout i {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout:hover {
            background: rgba(239, 68, 68, 0.08);
        }
        
        /* Current Patient Card */
        .current-patient {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 20px;
            padding: 32px;
            text-align: center;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        .dark .current-patient {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .current-patient::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #0284c7, #38bdf8, #0284c7);
            background-size: 200% 100%;
            animation: shimmer 3s ease-in-out infinite;
        }
        @keyframes shimmer {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        .current-patient.has-patient {
            border-color: rgba(2, 132, 199, 0.3);
            animation: glowPulse 3s ease-in-out infinite;
        }
        .current-label {
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: #6b7280;
            margin-bottom: 12px;
        }
        .dark .current-label {
            color: #9ca3af;
        }
        .current-number {
            font-size: 4rem;
            font-weight: 900;
            color: #0284c7;
            font-family: 'JetBrains Mono', monospace;
            letter-spacing: 2px;
            margin-bottom: 8px;
        }
        .dark .current-number {
            color: #38bdf8;
        }
        .current-name {
            font-size: 1.2rem;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 20px;
        }
        .dark .current-name {
            color: #f1f5f9;
        }
        
        /* Toast */
        .toast {
            position: fixed;
            bottom: 24px;
            right: 24px;
            padding: 12px 20px;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 500;
            z-index: 3000;
            display: none;
            box-shadow: 0 8px 30px rgba(0,0,0,0.3);
            animation: fadeIn 0.3s ease;
        }
        .toast.success {
            background: #065f46;
            color: #6ee7b7;
            border: 1px solid rgba(6, 95, 70, 0.3);
        }
        .toast.error {
            background: #7f1d1d;
            color: #fca5a5;
            border: 1px solid rgba(127, 29, 29, 0.3);
        }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

        <!-- SIDEBAR -->
        <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
            
            <div>
                <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                    
                    <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                        <span>C</span>
                        <span>E</span>
                        <span>S</span>
                        <span>H</span>
                    </div>

                    <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                        <img src="assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                        <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                        <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                    </div>
                </div>
                
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
        <ul class="list-none p-0 space-y-1">
            <li>
                <a href="queue_doctor.php?dept=<?php echo urlencode($department); ?>" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                    <div class="w-6 h-6 flex items-center justify-center shrink-0">
                        <i class="fas fa-stethoscope text-base"></i>
                    </div>
                    <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Management</span>
                </a>
            </li>
    <li>
        <a href="https://localhost/queuv1/staff/registration.php" target="_blank" rel="noopener noreferrer"
        class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                <i class="fas fa-user-plus text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
            </div>
            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Smart Queuing Registration</span>
        </a>
    </li>
    <?php if (($current_user['role'] ?? '') === 'doctor'): ?>
    <li>
        <a href="patient_results.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                <i class="fas fa-file-medical text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
            </div>
            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Results</span>
        </a>
    </li>
    <?php endif; ?>
            <li>    
                <a href="queue_display.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                    <div class="w-6 h-6 flex items-center justify-center shrink-0">
                        <i class="fas fa-tv text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                    </div>
                    <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Display</span>
                </a>
            </li>
            <?php if (($current_user['role'] ?? '') === 'admin'): ?>
            <li>
                <a href="admin/users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                    <div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-shield text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i></div>
                    <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
        
        <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
            <a href="logout.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                <div class="w-6 h-6 flex items-center justify-center shrink-0">
                    <i class="fas fa-sign-out-alt text-base text-rose-400 group-hover/link:text-rose-500 transition-colors"></i>
                </div>
                <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
            </a>
        </div>
    </nav>  
            </div>
        </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 main-content">
        
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">Physician Queue</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-medium"><?php echo htmlspecialchars($department); ?> Department • Manage patient queue and consultations</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <?php if (!$is_admin): ?>
                <form method="POST" class="flex items-center gap-2">
                    <input type="hidden" name="toggle_availability" value="1">
                    <input type="hidden" name="is_available" value="<?php echo $is_available ? '0' : '1'; ?>">
                    <button type="submit" class="px-3 py-2 rounded-xl text-xs font-bold <?php echo $is_available ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400'; ?>">
                        <i class="fas fa-circle mr-1"></i> Doctor is <?php echo $is_available ? 'Available' : 'Unavailable'; ?>
                    </button>
                </form>
                <?php endif; ?>
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300">Dr. <?php echo htmlspecialchars($doctor_name); ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400 font-medium">Physician • <?php echo htmlspecialchars($department); ?> Dept</div>
                </div>
                
                <!-- Dark Mode Toggle Switch -->
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 dark:text-slate-500">
                        <i class="fas fa-sun"></i>
                    </span>
                    <div class="theme-switch" id="themeToggle">
                        <div class="slider">
                            <span class="sun"><i class="fas fa-sun"></i></span>
                            <span class="moon"><i class="fas fa-moon"></i></span>
                        </div>
                    </div>
                    <span class="text-xs text-slate-400 dark:text-slate-500">
                        <i class="fas fa-moon"></i>
                    </span>
                </div>

                <!-- User Avatar with Click Dropdown -->
                <div class="relative">
                    <div class="w-10 h-10 rounded-full bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors" id="userAvatar">
                        <i class="fas fa-user-md text-slate-400 dark:text-slate-500 text-sm"></i>
                    </div>
                    <div class="user-dropdown" id="userDropdown">
                        <div class="dropdown-header">
                            <strong>Dr. <?php echo htmlspecialchars($doctor_name); ?></strong>
                            <small>Physician • <?php echo htmlspecialchars($department); ?> Dept</small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a href="logout.php" class="dropdown-item logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Department Tabs -->
        <div class="flex flex-wrap gap-2 mb-6 border-b border-slate-200 dark:border-slate-700/50 pb-3">
            <?php foreach ($accessible_depts as $dept): 
                $icon = 'fa-stethoscope';
                if ($dept === 'Pediatrics') $icon = 'fa-baby-carriage';
                elseif ($dept === 'OB-Gyne') $icon = 'fa-female';
                elseif ($dept === 'Internal Medicine') $icon = 'fa-heartbeat';
            ?>
                <a href="?dept=<?php echo urlencode($dept); ?>" class="px-4 py-2 rounded-full text-sm font-semibold transition-all duration-150 <?php echo $dept === $department ? 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50 border border-transparent'; ?>">
                    <i class="fas <?php echo $icon; ?> mr-2"></i> <?php echo htmlspecialchars($dept); ?>
                </a>
            <?php endforeach; ?>
        </div>
        
        <!-- Current Patient -->
        <div class="current-patient mb-6" id="currentPatient">
            <div class="current-label">Currently Consulting</div>
            <div class="current-number" id="currentNumber">—</div>
            <div class="current-name" id="currentName">No patient assigned</div>
            <div class="flex flex-wrap justify-center gap-3" id="actionButtons">
                <button class="px-6 py-3 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-full transition-all shadow-sm hover:shadow-md flex items-center gap-2" onclick="callNext()">
                    <i class="fas fa-bell"></i> Call Next Patient
                </button>
            </div>
        </div>
        
        <!-- Queue List -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex justify-between items-center flex-wrap gap-3">
                <div class="flex items-center gap-3">
                    <i class="fas fa-list-ol text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200">Waiting Queue</span>
                    <span class="text-xs text-slate-400 dark:text-slate-400 font-medium"><?php echo htmlspecialchars($department); ?></span>
                </div>
                <button class="text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 bg-white dark:bg-slate-700/50 px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-600 transition-colors" onclick="loadQueue()">
                    <i class="fas fa-sync-alt mr-1.5"></i> Refresh
                </button>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse min-w-[700px]">
                    <thead>
                        <tr class="bg-slate-50/50 dark:bg-slate-800/40 text-left border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.65rem] uppercase tracking-wider font-bold">
                            <th class="px-5 py-3.5">Queue #</th>
                            <th class="px-5 py-3.5">Patient Name</th>
                            <th class="px-5 py-3.5">Priority</th>
                            <th class="px-5 py-3.5">Waiting Time</th>
                            <th class="px-5 py-3.5">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-300/80 dark:divide-slate-700/50 text-xs md:text-sm text-slate-700 dark:text-slate-200" id="queueList">
                        <tr>
                            <td colspan="5" class="text-center py-12 text-slate-400 dark:text-slate-400">
                                <i class="fas fa-spinner fa-pulse text-2xl mb-2 block text-slate-300 dark:text-slate-600"></i> Loading...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Toast -->
    <div id="toast" class="toast"></div>
    <form id="smartQueueTransferForm" method="post" action="unified_switch.php" class="hidden">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($smartQueueTransferCsrf, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="queue_id" id="smartQueueTransferQueueId">
        <input type="hidden" name="patient_mrn" id="smartQueueTransferPatientMrn">
    </form>

    <script>
        const department = '<?php echo $department; ?>';
        const basePath = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);
        
        let currentQueueId = null;
        let currentPatientMrn = null;
        
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            if (htmlElement.classList.contains('dark')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });
        
        // ============================================
        // User Dropdown - Click to toggle
        // ============================================
        const userAvatar = document.getElementById('userAvatar');
        const userDropdown = document.getElementById('userDropdown');
        
        userAvatar.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });
        
        document.addEventListener('click', function(e) {
            if (!userAvatar.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('show');
            }
        });
        
        // ============================================
        // Mobile Menu
        // ============================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        });

        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('mobileMenuBtn');
            if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
        
        // ============================================
        // Toast
        // ============================================
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            toast.textContent = message;
            toast.className = `toast ${type}`;
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 3000);
        }
        
        // ============================================
        // Helper Functions
        // ============================================
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function getPriorityBadge(priority) {
            const badges = {
                'Emergency': '<span class="inline-block px-2.5 py-0.5 rounded-full text-[0.65rem] font-bold bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-300 dark:border-rose-400/20"><i class="fas fa-triangle-exclamation mr-1"></i>Emergency</span>',
                'Senior': '<span class="inline-block px-2.5 py-0.5 rounded-full text-[0.65rem] font-bold bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-300 dark:border-amber-400/20"><i class="fas fa-user-plus mr-1"></i>Senior</span>',
                'PWD': '<span class="inline-block px-2.5 py-0.5 rounded-full text-[0.65rem] font-bold bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-300 dark:border-sky-400/20"><i class="fas fa-wheelchair mr-1"></i>PWD</span>',
                'Normal': '<span class="inline-block px-2.5 py-0.5 rounded-full text-[0.65rem] font-bold bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700">Normal</span>'
            };
            return badges[priority] || badges['Normal'];
        }
        
        function playBellSound() {
            try {
                const audio = new Audio('https://www.soundjay.com/misc/sounds/bell-ringing-05.mp3');
                audio.play().catch(() => {});
            } catch(e) {}
        }
        
        // ============================================
        // Load Current Patient
        // ============================================
        async function loadCurrentPatient() {
            try {
                const res = await fetch(`${basePath}queue_api.php?action=get_stats&department=${encodeURIComponent(department)}`);
                const stats = await res.json();
                const card = document.getElementById('currentPatient');
                
                if (stats.currently_serving) {
                    document.getElementById('currentNumber').textContent = stats.currently_serving.display_number || '—';
                    document.getElementById('currentName').textContent = stats.currently_serving.full_name || 'No patient';
                    currentQueueId = stats.currently_serving.id;
                    currentPatientMrn = stats.currently_serving.patient_mrn;
                    card.classList.add('has-patient');
                    
                    document.getElementById('actionButtons').innerHTML = `
                        <button class="px-6 py-3 bg-violet-600 hover:bg-violet-500 text-white text-sm font-bold rounded-full transition-all shadow-sm hover:shadow-md flex items-center gap-2" onclick="assignCurrentPatientToSmartQueue()">
                            <i class="fas fa-arrow-right-to-bracket"></i> Assign to Smart Queue
                        </button>
                        <button class="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold rounded-full transition-all shadow-sm hover:shadow-md flex items-center gap-2" onclick="completeConsultation()">
                            <i class="fas fa-check-circle"></i> Complete Consultation
                        </button>
                        <button class="px-6 py-3 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-full transition-all shadow-sm hover:shadow-md flex items-center gap-2" onclick="callNext()">
                            <i class="fas fa-bell"></i> Call Next
                        </button>
                    `;
                } else {
                    document.getElementById('currentNumber').textContent = '—';
                    document.getElementById('currentName').textContent = 'No patient assigned';
                    currentQueueId = null;
                    currentPatientMrn = null;
                    card.classList.remove('has-patient');
                    
                    document.getElementById('actionButtons').innerHTML = `
                        <button class="px-6 py-3 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-full transition-all shadow-sm hover:shadow-md flex items-center gap-2" onclick="callNext()">
                            <i class="fas fa-bell"></i> Call Next Patient
                        </button>
                    `;
                }
            } catch (error) {
                console.error('Error loading current patient:', error);
            }
        }
        
        // ============================================
        // Load Queue
        // ============================================
        async function loadQueue() {
            try {
                const res = await fetch(`${basePath}queue_api.php?action=get_queue&department=${encodeURIComponent(department)}&status=Waiting`);
                const queue = await res.json();
                const tbody = document.getElementById('queueList');
                
                if (!queue || queue.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="5" class="text-center py-12 text-slate-400 dark:text-slate-400"><i class="fas fa-inbox text-2xl mb-2 block text-slate-300 dark:text-slate-600"></i> No patients waiting</td></tr>';
                    return;
                }
                
                tbody.innerHTML = queue.map(q => {
                    const waitMinutes = Math.floor((Date.now() - new Date(q.created_at).getTime()) / 60000);
                    return `
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors duration-150">
                            <td class="px-5 py-3.5"><span class="font-bold text-sky-600 dark:text-sky-400 font-mono text-sm">${escapeHtml(q.display_number)}</span></td>
                            <td class="px-5 py-3.5 font-semibold text-slate-800 dark:text-slate-100">${escapeHtml(q.full_name)}</td>
                            <td class="px-5 py-3.5">${getPriorityBadge(q.priority)}</td>
                            <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400 text-sm">${waitMinutes} min</td>
                            <td class="px-5 py-3.5">
                                <button class="px-3 py-1.5 bg-sky-50 dark:bg-sky-500/10 hover:bg-sky-100 dark:hover:bg-sky-500/20 text-sky-600 dark:text-sky-400 text-xs font-bold rounded-lg transition-colors" onclick="callSpecific(${q.id})">
                                    <i class="fas fa-bell"></i> Call
                                </button>
                            </td>
                        </tr>
                    `;
                }).join('');
            } catch (error) {
                console.error('Error loading queue:', error);
                document.getElementById('queueList').innerHTML = '<tr><td colspan="5" class="text-center py-12 text-slate-400 dark:text-slate-400"><i class="fas fa-triangle-exclamation text-2xl mb-2 block text-rose-500"></i> Error loading queue</td></tr>';
            }
        }
        
        // ============================================
        // Call Next Patient
        // ============================================
        async function callNext() {
            const formData = new FormData();
            formData.append('action', 'call_next');
            formData.append('department', department);
            
            try {
                const res = await fetch(`${basePath}queue_api.php`, { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.success) {
                    playBellSound();
                    showToast(data.message || 'Patient called successfully');
                    loadCurrentPatient();
                    loadQueue();
                } else {
                    showToast(data.message || 'Unable to call next patient', 'error');
                }
            } catch (error) {
                showToast('Network error. Please try again.', 'error');
            }
        }
        
        // ============================================
        // Call Specific Patient
        // ============================================
        async function callSpecific(queueId) {
            if (!confirm('Call this patient now?')) return;
            
            const formData = new FormData();
            formData.append('action', 'call_next');
            formData.append('department', department);
            formData.append('queue_id', queueId);
            
            try {
                const res = await fetch(`${basePath}queue_api.php`, { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.success) {
                    playBellSound();
                    showToast(data.message || 'Patient called successfully');
                    loadCurrentPatient();
                    loadQueue();
                } else {
                    showToast(data.message || 'Unable to call patient', 'error');
                }
            } catch (error) {
                showToast('Network error. Please try again.', 'error');
            }
        }
        
        // ============================================
        // Assign Current Patient to Smart Queue
        // ============================================
        function assignCurrentPatientToSmartQueue() {
            if (!currentQueueId || !currentPatientMrn) {
                showToast('The active patient record is missing its outpatient MRN.', 'error');
                return;
            }

            document.getElementById('smartQueueTransferQueueId').value = currentQueueId;
            document.getElementById('smartQueueTransferPatientMrn').value = currentPatientMrn;
            document.getElementById('smartQueueTransferForm').submit();
        }

        // ============================================
        // Complete Consultation
        // ============================================
        async function completeConsultation() {
            if (!currentQueueId) {
                showToast('No active consultation to complete', 'error');
                return;
            }
            
            if (!confirm('Mark this consultation as completed?')) return;
            
            const formData = new FormData();
            formData.append('action', 'complete');
            formData.append('queue_id', currentQueueId);
            
            try {
                const res = await fetch(`${basePath}queue_api.php`, { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.success) {
                    showToast('Consultation completed successfully');
                    loadCurrentPatient();
                    loadQueue();
                } else {
                    showToast('Unable to complete consultation', 'error');
                }
            } catch (error) {
                showToast('Network error. Please try again.', 'error');
            }
        }
        
        // ============================================
        // Initialize
        // ============================================
        loadCurrentPatient();
        loadQueue();
        
        setInterval(() => {
            loadCurrentPatient();
            loadQueue();
        }, 10000);
    </script>
</body>
</html>