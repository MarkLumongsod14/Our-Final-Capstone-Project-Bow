<?php
// patient_documents.php - Patient Document Management
// Camp Evangelista Station Hospital

require_once 'db.php';
require_once 'auth.php';

$auth->requireLogin();
$current_user = $auth->currentUser();

// Create uploads directory if not exists
$uploadDir = 'uploads/';
if(!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

// ---------------- UPLOAD DOCUMENT ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_document'])) {
    $patient_mrn = $_POST['patient_mrn'] ?? 0;

    if(isset($_FILES['document']) && $_FILES['document']['error'] === UPLOAD_ERR_OK){
        $originalName = basename($_FILES['document']['name']);
        $fileType = $_FILES['document']['type'];
        $fileExt = pathinfo($originalName, PATHINFO_EXTENSION);
        $safeName = time() . "_" . preg_replace("/[^a-zA-Z0-9]/", "_", pathinfo($originalName, PATHINFO_FILENAME)) . "." . $fileExt;
        $targetPath = $uploadDir . $safeName;

        if(move_uploaded_file($_FILES['document']['tmp_name'], $targetPath)){
            $uploadedDate = date('Y-m-d');
            $stmt = $conn->prepare("INSERT INTO documents (patient_mrn, file_name, type, uploaded) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $patient_mrn, $targetPath, $fileType, $uploadedDate);
            $stmt->execute();
            $stmt->close();
            $success_msg = "Document uploaded successfully!";
        } else {
            $error_msg = "Failed to move uploaded file.";
        }
    } else {
        $error_msg = "No file uploaded or upload error.";
    }
}

// ---------------- DELETE DOCUMENT ----------------
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $selected_patient_mrn = (int)($_GET['patient_mrn'] ?? 0);
    $patient_page = max(1, (int)($_GET['patient_page'] ?? 1));
    $patient_search = trim($_GET['patient_search'] ?? '');
    $file_stmt = $conn->prepare("SELECT file_name FROM documents WHERE id = ? AND (? = 0 OR patient_mrn = ?)");
    $file_stmt->bind_param('iii', $id, $selected_patient_mrn, $selected_patient_mrn);
    $file_stmt->execute();
    $file = $file_stmt->get_result()->fetch_assoc();
    $file_stmt->close();
    if ($file) {
        if (file_exists($file['file_name'])) unlink($file['file_name']);
        $delete_stmt = $conn->prepare("DELETE FROM documents WHERE id = ?");
        $delete_stmt->bind_param('i', $id);
        $delete_stmt->execute();
        $delete_stmt->close();
    }
    header("Location: patient_documents.php?" . http_build_query([
        'patient_page' => $patient_page,
        'patient_search' => $patient_search,
        'patient_mrn' => $selected_patient_mrn ?: null
    ]));
    exit;
}

// ---------------- FETCH PATIENTS & DOCUMENTS ----------------
$selected_patient_mrn = (int)($_GET['patient_mrn'] ?? 0);
$page_size = 10;
$patient_page = max(1, (int)($_GET['patient_page'] ?? 1));
$patient_search = trim($_GET['patient_search'] ?? '');
$patient_search_pattern = '%' . $patient_search . '%';
$patient_count_stmt = $conn->prepare("
    SELECT COUNT(*) AS total FROM patients
    WHERE status = 'Active'
      AND (? = '' OR first_name LIKE ? OR last_name LIKE ? OR CAST(mrn AS CHAR) LIKE ? OR email LIKE ? OR contact LIKE ?)
");
$patient_count_stmt->bind_param('ssssss', $patient_search, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern);
$patient_count_stmt->execute();
$patient_directory_total = (int)$patient_count_stmt->get_result()->fetch_assoc()['total'];
$patient_count_stmt->close();
$patient_total_pages = max(1, (int)ceil($patient_directory_total / $page_size));
$patient_page = min($patient_page, $patient_total_pages);
$patient_offset = ($patient_page - 1) * $page_size;
$patient_directory_stmt = $conn->prepare("
    SELECT p.mrn, p.first_name, p.last_name, p.dob, p.gender, p.contact, p.email, COUNT(d.id) AS document_count
    FROM patients p LEFT JOIN documents d ON d.patient_mrn = p.mrn
    WHERE p.status = 'Active'
      AND (? = '' OR p.first_name LIKE ? OR p.last_name LIKE ? OR CAST(p.mrn AS CHAR) LIKE ? OR p.email LIKE ? OR p.contact LIKE ?)
    GROUP BY p.mrn, p.first_name, p.last_name, p.dob, p.gender, p.contact, p.email
    ORDER BY p.last_name, p.first_name
    LIMIT ? OFFSET ?
");
$patient_directory_stmt->bind_param('ssssssii', $patient_search, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern, $page_size, $patient_offset);
$patient_directory_stmt->execute();
$patient_directory = $patient_directory_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$patient_directory_stmt->close();

$patientsRes = $conn->query("SELECT p.mrn, p.first_name, p.last_name, p.dob, p.gender, p.contact, p.email, COUNT(d.id) AS document_count
                             FROM patients p LEFT JOIN documents d ON d.patient_mrn = p.mrn
                             WHERE p.status = 'Active'
                             GROUP BY p.mrn, p.first_name, p.last_name, p.dob, p.gender, p.contact, p.email
                             ORDER BY p.last_name, p.first_name");
$patients = $patientsRes ? $patientsRes->fetch_all(MYSQLI_ASSOC) : [];

$selected_patient = null;
$patient_documents = [];
$patient_document_total = 0;
$patient_document_page = max(1, (int)($_GET['document_page'] ?? 1));
$patient_document_total_pages = 1;
$patient_document_offset = 0;
if ($selected_patient_mrn > 0) {
    $selected_patient_stmt = $conn->prepare("SELECT mrn, first_name, last_name FROM patients WHERE mrn = ? LIMIT 1");
    $selected_patient_stmt->bind_param('i', $selected_patient_mrn);
    $selected_patient_stmt->execute();
    $selected_patient = $selected_patient_stmt->get_result()->fetch_assoc();
    $selected_patient_stmt->close();

    if ($selected_patient) {
        $document_count_stmt = $conn->prepare("SELECT COUNT(*) AS total FROM documents WHERE patient_mrn = ?");
        $document_count_stmt->bind_param('i', $selected_patient_mrn);
        $document_count_stmt->execute();
        $patient_document_total = (int)$document_count_stmt->get_result()->fetch_assoc()['total'];
        $document_count_stmt->close();

        $patient_document_total_pages = max(1, (int)ceil($patient_document_total / $page_size));
        $patient_document_page = min($patient_document_page, $patient_document_total_pages);
        $patient_document_offset = ($patient_document_page - 1) * $page_size;
        $patient_documents_stmt = $conn->prepare("
            SELECT id, file_name, type, uploaded
            FROM documents
            WHERE patient_mrn = ?
            ORDER BY uploaded DESC, id DESC
            LIMIT ? OFFSET ?
        ");
        $patient_documents_stmt->bind_param('iii', $selected_patient_mrn, $page_size, $patient_document_offset);
        $patient_documents_stmt->execute();
        $patient_documents = $patient_documents_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $patient_documents_stmt->close();
    }
}

// Format MRN function
function formatMRN($mrn) {
    return str_pad($mrn, 6, '0', STR_PAD_LEFT);
}

function patientDirectoryPageUrl($page, $search, $selectedPatientMrn = 0) {
    $params = ['patient_page' => $page];
    if ($search !== '') $params['patient_search'] = $search;
    if ($selectedPatientMrn) $params['patient_mrn'] = $selectedPatientMrn;
    return 'patient_documents.php?' . http_build_query($params) . '#patient-directory';
}

function patientDocumentsPageUrl($page, $selectedPatientMrn, $patientPage, $patientSearch) {
    return 'patient_documents.php?' . http_build_query([
        'patient_mrn' => $selectedPatientMrn,
        'patient_page' => $patientPage,
        'patient_search' => $patientSearch,
        'document_page' => $page
    ]) . '#patient-documents';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Documents | 4ID Station Hospital</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        #sidebar::-webkit-scrollbar {
            width: 4px;
        }
        #sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        #sidebar::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 2px;
        }
        .dark #sidebar::-webkit-scrollbar-thumb {
            background: #475569;
        }
        .main-content {
            transition: margin-left 0.3s ease;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        
        /* Theme toggle switch */
        .theme-switch {
            position: relative;
            width: 48px;
            height: 26px;
            background: #e2e8f0;
            border-radius: 13px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(22px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 11px; }
        .modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,.5); backdrop-filter: blur(4px); display: flex; justify-content: center; align-items: center; z-index: 2000; padding: 16px; }
        .modal { width: 100%; max-width: 1000px; max-height: 90vh; overflow-y: auto; }
        .modal-backdrop:not(.show) { display: none; }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- SIDEBAR -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span>
                    <span>E</span>
                    <span>S</span>
                    <span>H</span>
                </div>

                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="index.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-gauge-high text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="medical_history.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-notes-medical text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Medical History</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_documents.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-file-alt text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Documents</span>
                        </a>
                    </li>
                    <li>
                        <a href="scheduled_patient.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-calendar-check text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Scheduled Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_frontdesk.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-ticket text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue System</span>
                        </a>
                    </li>
                    <?php if (($current_user['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="admin/users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-shield text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i></div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                
                <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
                    <a href="logout.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                        <div class="w-6 h-6 flex items-center justify-center shrink-0">
                            <i class="fas fa-sign-out-alt text-base text-rose-400 group-hover/link:text-rose-500 transition-colors"></i>
                        </div>
                        <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
                    </a>
                </div>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 main-content">
        
        <!-- Header -->
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">Patient Documents</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">Manage medical records, lab results, and patient documents</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($current_user['full_name']); ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400 font-medium"><?php echo ucfirst($current_user['role']); ?></div>
                </div>
                
                <!-- Dark Mode Toggle Switch -->
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-sun"></i></span>
                    <div class="theme-switch" id="themeToggle">
                        <div class="slider">
                            <span class="sun"><i class="fas fa-sun"></i></span>
                            <span class="moon"><i class="fas fa-moon"></i></span>
                        </div>
                    </div>
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-moon"></i></span>
                </div>

                <div class="w-10 h-10 rounded-full bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 flex items-center justify-center">
                    <i class="fas fa-user text-slate-400 dark:text-slate-500 text-sm"></i>
                </div>
            </div>
        </header>
        
        <!-- Upload Panel -->
        <div id="patient-directory" class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm mb-8">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80">
                <div class="flex items-center gap-3">
                    <i class="fas fa-cloud-upload-alt text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200">Upload Document</span>
                </div>
            </div>
            <div class="p-6">
                <?php if(isset($success_msg)): ?>
                    <div class="mb-4 p-3 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-400/20 rounded-xl flex items-center gap-3">
                        <i class="fas fa-check-circle text-emerald-500 dark:text-emerald-400"></i>
                        <span class="text-sm text-emerald-700 dark:text-emerald-300"><?php echo $success_msg; ?></span>
                    </div>
                <?php endif; ?>
                <?php if(isset($error_msg)): ?>
                    <div class="mb-4 p-3 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-400/20 rounded-xl flex items-center gap-3">
                        <i class="fas fa-exclamation-triangle text-rose-500 dark:text-rose-400"></i>
                        <span class="text-sm text-rose-700 dark:text-rose-300"><?php echo $error_msg; ?></span>
                    </div>
                <?php endif; ?>
                
                <form method="POST" enctype="multipart/form-data">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                        <div>
                            <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-user mr-1"></i> Select Patient
                            </label>
                            <input type="search" id="patientSelectSearch" autocomplete="off" placeholder="Search by name or MRN..." aria-label="Search patients by name or MRN" class="w-full mb-2 px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                            <select name="patient_mrn" id="uploadPatientSelect" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                                <option value="">-- Select Patient --</option>
                                <?php foreach($patients as $p): ?>
                                    <option value="<?= (int)$p['mrn'] ?>" data-search="<?= htmlspecialchars($p['last_name'] . ', ' . $p['first_name'] . ' ' . formatMRN($p['mrn']) . ' ' . ($p['email'] ?? '') . ' ' . ($p['contact'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
                                        <?= htmlspecialchars($p['last_name']) ?>, <?= htmlspecialchars($p['first_name']) ?> (MRN: <?= formatMRN($p['mrn']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p id="patientSelectNoResults" class="hidden mt-1 text-xs text-rose-500" role="status">No patients match your search.</p>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-file mr-1"></i> Choose File
                            </label>
                            <input type="file" name="document" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-sky-50 dark:file:bg-sky-500/10 file:text-sky-600 dark:file:text-sky-400 hover:file:bg-sky-100 dark:hover:file:bg-sky-500/20">
                        </div>
                        <div>
                            <button type="submit" name="upload_document" class="w-full px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center justify-center gap-2">
                                <i class="fas fa-upload"></i> Upload
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Patient Directory -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm mb-8">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3"><i class="fas fa-folder-user text-sky-500 dark:text-sky-400"></i><span class="text-sm font-bold text-slate-800 dark:text-slate-200">Patient Documents</span></div>
                <form method="GET" class="flex items-center gap-2 bg-white dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-full px-3 py-1.5">
                    <input type="hidden" name="patient_page" value="1">
                    <i class="fas fa-search text-slate-400 dark:text-slate-500 text-sm"></i>
                    <input type="search" name="patient_search" value="<?= htmlspecialchars($patient_search) ?>" placeholder="Search patient..." class="bg-transparent border-none outline-none text-sm text-slate-700 dark:text-slate-200 w-36 md:w-48">
                    <button type="submit" class="text-sky-600 dark:text-sky-400 text-xs font-bold">Search</button>
                </form>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse min-w-[850px]"><thead><tr class="bg-slate-50/50 dark:bg-slate-800/40 text-left border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.65rem] uppercase tracking-wider font-bold"><th class="px-5 py-3.5">Patient</th><th class="px-5 py-3.5">MRN</th><th class="px-5 py-3.5">DOB / Gender</th><th class="px-5 py-3.5">Contact</th><th class="px-5 py-3.5">Documents</th><th class="px-5 py-3.5">Action</th></tr></thead>
                    <tbody id="patientDocumentDirectory" class="divide-y divide-slate-300/80 dark:divide-slate-700/50 text-xs md:text-sm text-slate-700 dark:text-slate-200">
                    <?php foreach($patient_directory as $p): ?><tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"><td class="px-5 py-3.5 font-semibold text-slate-800 dark:text-slate-100"><?= htmlspecialchars($p['last_name'].', '.$p['first_name']) ?></td><td class="px-5 py-3.5"><span class="font-mono text-xs bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded-md text-slate-500 dark:text-slate-400"><?= formatMRN($p['mrn']) ?></span></td><td class="px-5 py-3.5 text-slate-500 dark:text-slate-400"><?= $p['dob'] ? date('M d, Y', strtotime($p['dob'])) : '—' ?> / <?= htmlspecialchars($p['gender'] ?: '—') ?></td><td class="px-5 py-3.5 text-slate-500 dark:text-slate-400"><?= htmlspecialchars($p['email'] ?: ($p['contact'] ?: '—')) ?></td><td class="px-5 py-3.5 text-sky-600 dark:text-sky-400 font-bold"><?= (int)$p['document_count'] ?></td><td class="px-5 py-3.5"><a href="<?= htmlspecialchars(patientDocumentsPageUrl(1, (int)$p['mrn'], $patient_page, $patient_search)) ?>" class="px-3 py-1.5 bg-sky-50 dark:bg-sky-500/10 hover:bg-sky-100 dark:hover:bg-sky-500/20 text-sky-600 dark:text-sky-400 text-xs font-bold rounded-lg inline-flex items-center gap-1"><i class="fas fa-eye"></i> View Documents</a></td></tr><?php endforeach; ?></tbody></table>
            </div>
            <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-700/70 flex flex-wrap items-center justify-between gap-3">
                <span class="text-xs text-slate-500 dark:text-slate-400">Showing <?= $patient_directory_total === 0 ? 0 : $patient_offset + 1 ?>–<?= min($patient_offset + count($patient_directory), $patient_directory_total) ?> of <?= number_format($patient_directory_total) ?></span>
                <?php if ($patient_total_pages > 1): ?>
                    <nav class="flex items-center gap-2" aria-label="Patient directory pagination">
                        <?php if ($patient_page > 1): ?><a href="<?= htmlspecialchars(patientDirectoryPageUrl($patient_page - 1, $patient_search, $selected_patient_mrn)) ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Previous</a><?php endif; ?>
                        <span class="text-xs font-semibold text-slate-600 dark:text-slate-300">Page <?= $patient_page ?> of <?= $patient_total_pages ?></span>
                        <?php if ($patient_page < $patient_total_pages): ?><a href="<?= htmlspecialchars(patientDirectoryPageUrl($patient_page + 1, $patient_search, $selected_patient_mrn)) ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Next</a><?php endif; ?>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($selected_patient): ?>
            <div class="modal-backdrop show" role="dialog" aria-modal="true" aria-labelledby="patientDocumentsTitle">
                <section id="patient-documents" class="modal bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl shadow-xl">
                    <div class="relative px-6 py-4 pr-24 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-3">
                        <div>
                            <h2 id="patientDocumentsTitle" class="text-sm font-bold text-slate-800 dark:text-slate-200">Documents for <?= htmlspecialchars($selected_patient['last_name'] . ', ' . $selected_patient['first_name']) ?></h2>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">MRN: <?= formatMRN($selected_patient['mrn']) ?> · <?= number_format($patient_document_total) ?> document(s)</p>
                        </div>
                        <a href="<?= htmlspecialchars(patientDirectoryPageUrl($patient_page, $patient_search)) ?>" class="absolute top-4 right-4 px-3 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-xs font-bold rounded-lg inline-flex items-center gap-1"><i class="fas fa-times"></i> Close</a>
                    </div>
                    <div class="p-6">
                        <?php if (!$patient_documents): ?>
                            <div class="text-center py-10 text-slate-400 dark:text-slate-400">
                                <i class="fas fa-folder-open text-3xl mb-3 block text-slate-300 dark:text-slate-600"></i>
                                <p class="font-medium">No documents uploaded for this patient.</p>
                            </div>
                        <?php else: ?>
                            <div class="overflow-x-auto">
                                <table class="w-full border-collapse min-w-[650px]">
                                    <thead><tr class="bg-slate-50/50 dark:bg-slate-800/40 text-left border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.65rem] uppercase tracking-wider font-bold"><th class="px-5 py-3.5">File</th><th class="px-5 py-3.5">Type</th><th class="px-5 py-3.5">Uploaded</th><th class="px-5 py-3.5">Actions</th></tr></thead>
                                    <tbody class="divide-y divide-slate-300/80 dark:divide-slate-700/50 text-xs md:text-sm text-slate-700 dark:text-slate-200">
                                        <?php foreach ($patient_documents as $document): ?>
                                            <tr>
                                                <td class="px-5 py-3.5"><a href="<?= htmlspecialchars($document['file_name']) ?>" target="_blank" rel="noopener" class="text-sky-600 dark:text-sky-400 hover:underline inline-flex items-center gap-2"><i class="fas fa-file"></i><?= htmlspecialchars(basename($document['file_name'])) ?></a></td>
                                                <td class="px-5 py-3.5"><?= htmlspecialchars($document['type']) ?></td>
                                                <td class="px-5 py-3.5"><?= $document['uploaded'] ? date('M d, Y', strtotime($document['uploaded'])) : '—' ?></td>
                                                <td class="px-5 py-3.5"><a href="<?= htmlspecialchars('patient_documents.php?' . http_build_query(['delete' => (int)$document['id'], 'patient_mrn' => $selected_patient_mrn, 'patient_page' => $patient_page, 'patient_search' => $patient_search, 'document_page' => $patient_document_page])) ?>" onclick="return confirm('Are you sure you want to delete this document?')" class="px-3 py-1.5 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-bold rounded-lg inline-flex items-center gap-1"><i class="fas fa-trash-alt"></i> Delete</a></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                        <?php if ($patient_document_total_pages > 1): ?>
                            <div class="mt-4 flex items-center justify-between gap-3">
                                <span class="text-xs text-slate-500 dark:text-slate-400">Showing <?= $patient_document_offset + 1 ?>–<?= min($patient_document_offset + count($patient_documents), $patient_document_total) ?> of <?= number_format($patient_document_total) ?></span>
                                <nav class="flex items-center gap-2" aria-label="Patient documents pagination">
                                    <?php if ($patient_document_page > 1): ?><a href="<?= htmlspecialchars(patientDocumentsPageUrl($patient_document_page - 1, $selected_patient_mrn, $patient_page, $patient_search)) ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Previous</a><?php endif; ?>
                                    <span class="text-xs font-semibold text-slate-600 dark:text-slate-300">Page <?= $patient_document_page ?> of <?= $patient_document_total_pages ?></span>
                                    <?php if ($patient_document_page < $patient_document_total_pages): ?><a href="<?= htmlspecialchars(patientDocumentsPageUrl($patient_document_page + 1, $selected_patient_mrn, $patient_page, $patient_search)) ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Next</a><?php endif; ?>
                                </nav>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>
            </div>
        <?php elseif ($selected_patient_mrn > 0): ?>
            <div class="fixed inset-0 z-[2000] flex items-center justify-center bg-black/50 p-4">
                <section class="bg-white dark:bg-[#1f2937] rounded-2xl p-6 shadow-xl max-w-md">
                    <h2 class="font-bold text-slate-800 dark:text-slate-200">Patient not found</h2>
                    <a href="<?= htmlspecialchars(patientDirectoryPageUrl($patient_page, $patient_search)) ?>" class="mt-4 inline-flex px-3 py-2 bg-sky-600 text-white text-sm font-bold rounded-lg">Back to directory</a>
                </section>
            </div>
        <?php endif; ?>
    </main>

    <script>
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            localStorage.setItem('theme', htmlElement.classList.contains('dark') ? 'dark' : 'light');
        });
        
        // ============================================
        // Mobile Menu
        // ============================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        });

        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('mobileMenuBtn');
            if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });

        const patientSelectSearch = document.getElementById('patientSelectSearch');
        const uploadPatientSelect = document.getElementById('uploadPatientSelect');
        const patientSelectNoResults = document.getElementById('patientSelectNoResults');
        patientSelectSearch.addEventListener('input', function() {
            const query = this.value.trim().toLocaleLowerCase();
            let visiblePatients = 0;

            Array.from(uploadPatientSelect.options).slice(1).forEach(function(option) {
                const matches = option.dataset.search.toLocaleLowerCase().includes(query);
                option.hidden = !matches;
                if (matches) visiblePatients++;
            });

            uploadPatientSelect.value = '';
            patientSelectNoResults.classList.toggle('hidden', query === '' || visiblePatients > 0);
        });
        
        // ============================================
        // Search Filter
        // ============================================
    </script>
</body>
</html>