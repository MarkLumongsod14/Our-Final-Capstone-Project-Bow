<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    echo "<h3>Debug Results:</h3>";
    
    if ($result->num_rows === 0) {
        echo "❌ User '$username' not found in database<br>";
    } else {
        $user = $result->fetch_assoc();
        echo "✅ User found: " . $user['username'] . "<br>";
        echo "Status: " . $user['status'] . "<br>";
        echo "Stored hash: " . $user['password'] . "<br>";
        
        if (password_verify($password, $user['password'])) {
            echo "✅✅✅ PASSWORD MATCHES! Login would succeed. ✅✅✅<br>";
        } else {
            echo "❌ Password does NOT match<br>";
            echo "Try this: Create a new hash with: password_hash('your_password', PASSWORD_DEFAULT)<br>";
        }
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <title>Simple Login Test</title>
</head>
<body>
    <h2>Simple Login Test</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required><br><br>
        <input type="password" name="password" placeholder="Password" required><br><br>
        <button type="submit">Test Login</button>
    </form>
    
    <hr>
    <h3>Fix password if needed:</h3>
    <form method="POST" action="fix_password.php">
        <input type="text" name="username" placeholder="Username" value="admin" required>
        <input type="password" name="new_password" placeholder="New Password" value="admin123" required>
        <button type="submit">Reset Password</button>
    </form>
</body>
</html>