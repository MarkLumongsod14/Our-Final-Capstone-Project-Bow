<?php
// auth.php - Authentication and Session Management
session_start();

require_once 'db.php';
require_once __DIR__ . '/unified_auth.php';
UnifiedSession::activate('outpatient', false);

class Auth {
    private $conn;
    
    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }
    
    // Login user
    public function login($username, $password) {
        $lockout = $this->getLoginLockout($username);
        if ($lockout['locked']) {
            return $this->loginLockoutResponse($lockout);
        }

        // First, check if columns exist, if not, use default values
        $columns = $this->getUserColumns();
        
        $stmt = $this->conn->prepare("SELECT id, username, password, full_name, email, role, status, two_factor_secret, two_factor_enabled $columns FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            if ($user['status'] !== 'Active') {
                $this->recordLoginAttempt($username, $user['full_name'], null, 'Failed', 'Account is inactive');
                $stmt->close();
                $lockout = $this->getLoginLockout($username);
                if ($lockout['locked']) {
                    return $this->loginLockoutResponse($lockout);
                }
                return $this->failedLoginResponse($username, 'This account is inactive.');
            }

            if (password_verify($password, $user['password'])) {
                if ($user['role'] === 'admin' && (int)($user['two_factor_enabled'] ?? 0) === 1) {
                    $_SESSION['pending_2fa_user'] = $user;
                    $stmt->close();
                    return ['success' => false, 'requires_2fa' => true, 'message' => 'Enter the 6-digit code from Google Authenticator.'];
                }
                $this->completeLogin($user);
                $this->recordLoginAttempt($username, $user['full_name'], $user['id'], 'Success', 'Login successful');
                $stmt->close();
                return ['success' => true, 'role' => $user['role']];
            }
        }
        
        $this->recordLoginAttempt($username, null, null, 'Failed', 'Invalid username or password');
        $stmt->close();
        return $this->failedLoginResponse($username, 'Invalid username or password.');
    }

    public function recordFailedLogin($username, $reason) {
        $lockout = $this->getLoginLockout($username);
        if ($lockout['locked']) {
            return $this->loginLockoutResponse($lockout);
        }
        $this->recordLoginAttempt($username, null, null, 'Failed', $reason);
        return $this->failedLoginResponse($username, 'Incorrect security check.');
    }

    public function verifyTwoFactor($code) {
        $user = $_SESSION['pending_2fa_user'] ?? null;
        if (!$user || $user['role'] !== 'admin') return ['success' => false, 'message' => 'Two-factor session expired.'];
        $lockout = $this->getLoginLockout($user['username']);
        if ($lockout['locked']) {
            unset($_SESSION['pending_2fa_user']);
            return $this->loginLockoutResponse($lockout);
        }
        if (!$this->verifyTotp($user['two_factor_secret'] ?? '', $code)) {
            $this->recordLoginAttempt($user['username'], $user['full_name'], $user['id'], 'Failed', 'Invalid authenticator code');
            $lockout = $this->getLoginLockout($user['username']);
            if ($lockout['locked']) {
                unset($_SESSION['pending_2fa_user']);
                return $this->loginLockoutResponse($lockout);
            }
            return $this->failedLoginResponse($user['username'], 'Invalid authenticator code.');
        }
        unset($_SESSION['pending_2fa_user']);
        $this->completeLogin($user);
        $this->recordLoginAttempt($user['username'], $user['full_name'], $user['id'], 'Success', 'Login successful with 2FA');
        return ['success' => true, 'role' => 'admin'];
    }

    private function getLoginLockout($username) {
        $stmt = $this->conn->prepare("
            SELECT status, UNIX_TIMESTAMP(attempted_at) AS attempted_timestamp
            FROM login_activity
            WHERE username = ? AND attempted_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)
            ORDER BY id DESC
        ");
        if (!$stmt) {
            throw new RuntimeException('Unable to check login lockout status: ' . $this->conn->error);
        }
        $stmt->bind_param('s', $username);
        if (!$stmt->execute()) {
            $error = $stmt->error;
            $stmt->close();
            throw new RuntimeException('Unable to check login lockout status: ' . $error);
        }

        $result = $stmt->get_result();
        $failedAttempts = 0;
        $lockUntil = 0;
        while ($attempt = $result->fetch_assoc()) {
            if ($attempt['status'] === 'Success') {
                break;
            }
            $failedAttempts++;
            if ($failedAttempts === 5) {
                $lockUntil = (int)$attempt['attempted_timestamp'] + (15 * 60);
                break;
            }
        }
        $stmt->close();

        $remainingSeconds = max(0, $lockUntil - time());
        return [
            'locked' => $remainingSeconds > 0,
            'remaining_seconds' => $remainingSeconds,
            'failed_attempts' => $failedAttempts
        ];
    }

    private function failedLoginResponse($username, $message) {
        $lockout = $this->getLoginLockout($username);
        if ($lockout['locked']) {
            return $this->loginLockoutResponse($lockout);
        }
        $attempt = min(5, $lockout['failed_attempts']);
        return [
            'success' => false,
            'failed_attempts' => $attempt,
            'message' => $message . " Login attempt {$attempt} of 5."
        ];
    }

    private function loginLockoutResponse($lockout) {
        return [
            'success' => false,
            'failed_attempts' => 5,
            'message' => 'Login attempt 5 of 5. ' . $this->loginLockoutMessage($lockout['remaining_seconds'])
        ];
    }

    private function loginLockoutMessage($remainingSeconds) {
        $remainingMinutes = max(1, (int)ceil($remainingSeconds / 60));
        return "Too many failed login attempts. Please try again in {$remainingMinutes} minute(s).";
    }

    private function completeLogin($user) {
        $updateStmt = $this->conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $updateStmt->bind_param("i", $user['id']);
        $updateStmt->execute();
        $updateStmt->close();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['assigned_department'] = $user['assigned_department'] ?? 'General';
        $_SESSION['can_access_all_depts'] = $user['can_access_all_depts'] ?? 0;
        $_SESSION['logged_in'] = true;
        $_SESSION['login_time'] = time();
    }

    private function verifyTotp($secret, $code) {
        if (!$secret || !preg_match('/^[0-9]{6}$/', trim($code))) return false;
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $secret = strtoupper($secret);
        $bits = '';
        for ($i = 0; $i < strlen($secret); $i++) {
            $value = strpos($alphabet, $secret[$i]);
            if ($value === false) return false;
            $bits .= str_pad(decbin($value), 5, '0', STR_PAD_LEFT);
        }
        $binaryKey = '';
        for ($i = 0; $i + 8 <= strlen($bits); $i += 8) $binaryKey .= chr(bindec(substr($bits, $i, 8)));
        $counter = (int)floor(time() / 30);
        for ($offset = -1; $offset <= 1; $offset++) {
            $counterBytes = pack('N*', 0, $counter + $offset);
            $hash = hash_hmac('sha1', $counterBytes, $binaryKey, true);
            $index = ord($hash[19]) & 0x0f;
            $value = ((ord($hash[$index]) & 0x7f) << 24) | ((ord($hash[$index + 1]) & 0xff) << 16) | ((ord($hash[$index + 2]) & 0xff) << 8) | (ord($hash[$index + 3]) & 0xff);
            if (hash_equals(str_pad((string)($value % 1000000), 6, '0', STR_PAD_LEFT), trim($code))) return true;
        }
        return false;
    }

    public function enableAdminTwoFactor($id) {
        $secret = '';
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        for ($i = 0; $i < 16; $i++) $secret .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        $stmt = $this->conn->prepare("UPDATE users SET two_factor_secret = ?, two_factor_enabled = 1 WHERE id = ? AND role = 'admin'");
        $stmt->bind_param('si', $secret, $id);
        $success = $stmt->execute() && $stmt->affected_rows >= 0;
        $stmt->close();
        return ['success' => $success, 'secret' => $success ? $secret : ''];
    }

    private function recordLoginAttempt($username, $fullName, $userId, $status, $reason) {
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        $stmt = $this->conn->prepare("INSERT INTO login_activity (user_id, username, full_name, ip_address, status, reason) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param('isssss', $userId, $username, $fullName, $ipAddress, $status, $reason);
            $stmt->execute();
            $stmt->close();
        }
    }
    
    // Helper function to check if columns exist
    private function getUserColumns() {
        $columns = "";
        
        // Check if assigned_department column exists
        $result = $this->conn->query("SHOW COLUMNS FROM users LIKE 'assigned_department'");
        if ($result && $result->num_rows > 0) {
            $columns .= ", assigned_department";
        } else {
            $columns .= ", 'General' as assigned_department";
        }
        
        // Check if can_access_all_depts column exists
        $result = $this->conn->query("SHOW COLUMNS FROM users LIKE 'can_access_all_depts'");
        if ($result && $result->num_rows > 0) {
            $columns .= ", can_access_all_depts";
        } else {
            $columns .= ", 0 as can_access_all_depts";
        }
        
        return $columns;
    }
    
    // Logout user
    public function logout() {
        $_SESSION = array();
        
        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time()-3600, '/');
        }
        
        session_destroy();
        return true;
    }
    
    // Check if user is logged in
    public function isLoggedIn() {
        return ($_SESSION['sso_current_system'] ?? null) === 'outpatient'
            && !empty($_SESSION['sso_identity_id'])
            && isset($_SESSION['logged_in'])
            && $_SESSION['logged_in'] === true;
    }
    
    // Get current user info
    public function currentUser() {
        if ($this->isLoggedIn()) {
            return [
                'id' => $_SESSION['user_id'],
                'username' => $_SESSION['username'],
                'full_name' => $_SESSION['full_name'],
                'email' => $_SESSION['email'],
                'role' => $_SESSION['role'],
                'assigned_department' => $_SESSION['assigned_department'] ?? 'General',
                'can_access_all_depts' => $_SESSION['can_access_all_depts'] ?? 0
            ];
        }
        return null;
    }
    
    // Get user's assigned department
    public function getDepartment() {
        if (!$this->isLoggedIn()) return null;
        
        if (($_SESSION['role'] === 'admin') || ($_SESSION['can_access_all_depts'] ?? 0)) {
            return $_GET['dept'] ?? $_SESSION['assigned_department'] ?? 'General';
        }
        return $_SESSION['assigned_department'] ?? 'General';
    }
    
    // Check if user can access a specific department
    public function canAccessDepartment($department) {
        if (!$this->isLoggedIn()) return false;
        
        if (($_SESSION['role'] === 'admin') || ($_SESSION['can_access_all_depts'] ?? 0)) {
            return true;
        }
        
        return ($_SESSION['assigned_department'] === $department);
    }
    
    // Get all departments user can access
    public function getAccessibleDepartments() {
        if (!$this->isLoggedIn()) return [];
        
        if (($_SESSION['role'] === 'admin') || ($_SESSION['can_access_all_depts'] ?? 0)) {
            return ['General', 'Pediatrics', 'OB-Gyne', 'Internal Medicine'];
        }
        return [$_SESSION['assigned_department'] ?? 'General'];
    }
    
    // Check if user has specific role
    public function hasRole($roles) {
        if (!$this->isLoggedIn()) return false;
        
        if (is_array($roles)) {
            return in_array($_SESSION['role'], $roles);
        }
        return $_SESSION['role'] === $roles;
    }
    
    // Require login (redirect if not logged in)
    public function requireLogin() {
        if (!$this->isLoggedIn()) {
            header('Location: ' . UnifiedSession::loginUrl());
            exit();
        }
    }
    
    // Require specific role(s)
    public function requireRole($roles) {
        $this->requireLogin();
        
        if (!$this->hasRole($roles)) {
            http_response_code(403);
            exit('You are not authorized to access this page.');
        }
    }
    
    // Change password
    public function changePassword($user_id, $old_password, $new_password) {
        $policyError = $this->passwordPolicyError($new_password);
        if ($policyError !== null) {
            return ['success' => false, 'message' => $policyError];
        }

        $stmt = $this->conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        
        if (password_verify($old_password, $user['password'])) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $updateStmt = $this->conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $updateStmt->bind_param("si", $hashed_password, $user_id);
            $success = $updateStmt->execute();
            $updateStmt->close();
            
            return ['success' => $success, 'message' => $success ? 'Password changed successfully' : 'Error changing password'];
        }
        
        return ['success' => false, 'message' => 'Current password is incorrect'];
    }
    
    // Get all users (admin only)
    public function getAllUsers() {
        $result = $this->conn->query("SELECT id, username, full_name, email, role, assigned_department, status, last_login, created_at FROM users ORDER BY full_name");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getUserById($id) {
        $stmt = $this->conn->prepare("SELECT id, username, role FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $user ?: [];
    }

    public function getRecentLoginActivity($limit = 100) {
        $limit = max(1, min(500, (int)$limit));
        $result = $this->conn->query("SELECT attempted_at, username, full_name, ip_address, status, reason FROM login_activity ORDER BY attempted_at DESC LIMIT $limit");
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }
    
    // Add new user (admin only)
    public function addUser($username, $password, $full_name, $email, $role, $assigned_department = 'General') {
        $policyError = $this->passwordPolicyError($password);
        if ($policyError !== null) {
            return ['success' => false, 'id' => 0, 'message' => $policyError];
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Check if assigned_department column exists
        $result = $this->conn->query("SHOW COLUMNS FROM users LIKE 'assigned_department'");
        $this->conn->begin_transaction();
        try {
            if ($result && $result->num_rows > 0) {
                $stmt = $this->conn->prepare("INSERT INTO users (username, password, full_name, email, role, assigned_department) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssssss", $username, $hashed_password, $full_name, $email, $role, $assigned_department);
            } else {
                $stmt = $this->conn->prepare("INSERT INTO users (username, password, full_name, email, role) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $username, $hashed_password, $full_name, $email, $role);
            }

            $stmt->execute();
            $id = (int)$stmt->insert_id;
            $stmt->close();
            UnifiedAuth::registerAccount($this->conn, 'outpatient', $id, $full_name);
            $this->conn->commit();
            return ['success' => true, 'id' => $id];
        } catch (Throwable $exception) {
            $this->conn->rollback();
            error_log('Unable to provision unified outpatient account: ' . $exception->getMessage());
            return ['success' => false, 'id' => 0, 'message' => 'Unable to create the account mapping. Please contact the administrator.'];
        }
    }

    public function updateUser($id, $full_name, $email, $role, $status, $assigned_department, $password = '') {
        if ($password !== '') {
            $policyError = $this->passwordPolicyError($password);
            if ($policyError !== null) {
                return ['success' => false, 'message' => $policyError];
            }
        }

        $fields = "full_name = ?, email = ?, role = ?, status = ?, assigned_department = ?";
        $params = [$full_name, $email, $role, $status, $assigned_department];
        $types = 'sssss';

        if ($password !== '') {
            $fields .= ', password = ?';
            $params[] = password_hash($password, PASSWORD_DEFAULT);
            $types .= 's';
        }

        $params[] = (int)$id;
        $types .= 'i';
        $stmt = $this->conn->prepare("UPDATE users SET $fields WHERE id = ?");
        $stmt->bind_param($types, ...$params);
        $success = $stmt->execute();
        $error = $stmt->error;
        $stmt->close();

        return ['success' => $success, 'message' => $success ? '' : $error];
    }

    private function passwordPolicyError($password) {
        if (strlen($password) < 6) {
            return 'Password must be at least 6 characters and include an uppercase letter, a lowercase letter, a number, and a special character.';
        }
        if (!preg_match('/[A-Z]/', $password)
            || !preg_match('/[a-z]/', $password)
            || !preg_match('/[0-9]/', $password)
            || !preg_match('/[^A-Za-z0-9]/', $password)) {
            return 'Password must include at least one uppercase letter, one lowercase letter, one number, and one special character.';
        }
        return null;
    }
    
    // Delete user (admin only)
    public function deleteUser($id) {
        if ($id == $_SESSION['user_id']) {
            return ['success' => false, 'message' => 'Cannot delete your own account'];
        }
        
        $stmt = $this->conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $success = $stmt->execute();
        $stmt->close();
        
        return ['success' => $success];
    }
    // Add this method to the Auth class in auth.php

public function getRedirectUrl() {
    if (!$this->isLoggedIn()) {
        return 'login.php';
    }
    
    $role = $_SESSION['role'];
    $dept = $_SESSION['assigned_department'] ?? 'General';
    
    if ($role === 'admin') {
        return 'index.php';
    } elseif ($role === 'doctor') {
        return 'queue_doctor.php?dept=' . urlencode($dept);
    } else {
        return 'frontdesk_dashboard.php?dept=' . urlencode($dept);
    }
}
}

// Initialize Auth object
$auth = new Auth($conn);
?>