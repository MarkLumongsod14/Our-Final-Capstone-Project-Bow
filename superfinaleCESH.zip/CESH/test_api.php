<?php
// test_api.php - Test the queue API
echo "<h2>Testing Queue API</h2>";

// Test the API endpoint
$url = "queue_api.php?action=get_waiting_count&department=General";
echo "Calling: $url<br>";

// Use file_get_contents to get the response
$response = @file_get_contents($url);
if ($response === false) {
    echo "❌ Failed to get response<br>";
} else {
    echo "Response received:<br>";
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
}

// Also check if queue_api.php has syntax errors
echo "<hr>";
echo "<h3>Checking queue_api.php syntax:</h3>";

// Try to include the file to see errors
ob_start();
include 'queue_api.php';
$output = ob_get_clean();
if (!empty($output)) {
    echo "Output from queue_api.php:<br>";
    echo "<pre style='color:red;'>" . htmlspecialchars($output) . "</pre>";
}
?>