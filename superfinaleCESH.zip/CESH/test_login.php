<?php
// test_path.php - Check file paths

echo "<h2>File Path Test</h2>";

echo "<h3>Current file:</h3>";
echo "Full path: " . __FILE__ . "<br>";
echo "Directory: " . __DIR__ . "<br><br>";

echo "<h3>Looking for db.php:</h3>";

// Check different possible locations
$paths = [
    '../db.php',
    '../../db.php',
    './db.php',
    'db.php',
    '../config/db.php',
    '../../config/db.php',
    './config/db.php',
    '../includes/db.php',
    '../../includes/db.php',
];

foreach ($paths as $path) {
    if (file_exists($path)) {
        echo "✅ Found at: <strong>$path</strong><br>";
        echo "   Full path: " . realpath($path) . "<br>";
    } else {
        echo "❌ Not found: $path<br>";
    }
}

echo "<br><h3>Files in current directory:</h3>";
$files = scandir(__DIR__);
foreach ($files as $file) {
    if ($file != '.' && $file != '..') {
        echo "- " . $file . "<br>";
    }
}

echo "<br><h3>Files in parent directory:</h3>";
$parent_dir = dirname(__DIR__);
if (is_dir($parent_dir)) {
    $files = scandir($parent_dir);
    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            echo "- " . $file . "<br>";
        }
    }
}
?>