<?php
session_start();
require_once __DIR__ . '/unified_auth.php';

if (
    $_SERVER['REQUEST_METHOD'] !== 'GET'
    && ($_SERVER['REQUEST_METHOD'] !== 'POST' || !unified_csrf_valid())
) {
    http_response_code(400);
    exit('Invalid sign-out request.');
}

$auth = new UnifiedAuth();
$auth->logout();
header('Location: unified_login.php');
exit;
