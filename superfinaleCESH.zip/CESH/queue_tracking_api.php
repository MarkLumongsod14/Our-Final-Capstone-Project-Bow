<?php
require_once 'db.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');

$token = $_GET['token'] ?? '';
if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/i', $token)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Enter the tracking code from your queue ticket.']);
    exit();
}

$stmt = $conn->prepare("
    SELECT q.id, q.queue_number, q.priority, q.status, q.department, q.created_at,
           q.called_at, q.completed_at,
           CONCAT(COALESCE(qs.prefix, 'Q'), LPAD(q.queue_number, 3, '0')) AS display_number
    FROM queue q
    LEFT JOIN queue_settings qs ON qs.department = q.department
    WHERE q.tracking_token = ?
    LIMIT 1
");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Queue tracking is temporarily unavailable.']);
    exit();
}
$stmt->bind_param('s', $token);
if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Queue tracking is temporarily unavailable.']);
    exit();
}

$queue = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$queue) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'No queue record matches this tracking code. Check the code on your ticket and try again.']);
    exit();
}

$position = null;
if ($queue['status'] === 'Waiting') {
    $positionStmt = $conn->prepare("
        SELECT COUNT(*) AS position
        FROM queue waiting
        WHERE (waiting.department = ? OR (? = 'General Medicine' AND waiting.department = 'General'))
          AND waiting.status = 'Waiting'
          AND (
              CASE waiting.priority
                  WHEN 'Emergency' THEN 1
                  WHEN 'Senior' THEN 2
                  WHEN 'PWD' THEN 3
                  ELSE 4
              END < CASE ?
                  WHEN 'Emergency' THEN 1
                  WHEN 'Senior' THEN 2
                  WHEN 'PWD' THEN 3
                  ELSE 4
              END
              OR (
                  CASE waiting.priority
                      WHEN 'Emergency' THEN 1
                      WHEN 'Senior' THEN 2
                      WHEN 'PWD' THEN 3
                      ELSE 4
                  END = CASE ?
                      WHEN 'Emergency' THEN 1
                      WHEN 'Senior' THEN 2
                      WHEN 'PWD' THEN 3
                      ELSE 4
                  END
                  AND (waiting.queue_number < ? OR (waiting.queue_number = ? AND waiting.id < ?))
              )
          )
    ");
    if (!$positionStmt) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Queue tracking is temporarily unavailable.']);
        exit();
    }
    $positionStmt->bind_param(
        'ssssiii',
        $queue['department'],
        $queue['department'],
        $queue['priority'],
        $queue['priority'],
        $queue['queue_number'],
        $queue['queue_number'],
        $queue['id']
    );
    if (!$positionStmt->execute()) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Queue tracking is temporarily unavailable.']);
        exit();
    }
    $position = (int)$positionStmt->get_result()->fetch_assoc()['position'] + 1;
    $positionStmt->close();
}

$currentlyServing = null;
if (in_array($queue['status'], ['Waiting', 'In Consultation'], true)) {
    $servingStmt = $conn->prepare("
        SELECT CONCAT(COALESCE(qs.prefix, 'Q'), LPAD(q.queue_number, 3, '0')) AS display_number
        FROM queue q
        LEFT JOIN queue_settings qs ON qs.department = q.department
        WHERE (q.department = ? OR (? = 'General Medicine' AND q.department = 'General'))
          AND q.status = 'In Consultation'
        ORDER BY q.called_at DESC
        LIMIT 1
    ");
    if (!$servingStmt) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Queue tracking is temporarily unavailable.']);
        exit();
    }
    $servingStmt->bind_param('ss', $queue['department'], $queue['department']);
    if (!$servingStmt->execute()) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Queue tracking is temporarily unavailable.']);
        exit();
    }
    $servingRow = $servingStmt->get_result()->fetch_assoc();
    $currentlyServing = $servingRow['display_number'] ?? null;
    $servingStmt->close();
}

echo json_encode([
    'success' => true,
    'queue_number' => $queue['display_number'],
    'department' => $queue['department'],
    'priority' => $queue['priority'],
    'status' => $queue['status'],
    'position' => $position,
    'currently_serving' => $currentlyServing,
    'created_at' => $queue['created_at'],
    'called_at' => $queue['called_at'],
    'completed_at' => $queue['completed_at']
]);
