<?php
// queue_api.php - Queue Management API (Fixed Version)
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db.php';
require_once 'auth.php';
require_once 'queue_assignment_helpers.php';

header('Content-Type: application/json');

if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit();
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if (empty($action)) {
    echo json_encode(['success' => false, 'error' => 'No action specified']);
    exit();
}

function getPrefix($conn, $department) {
    $result = $conn->query("SELECT prefix FROM queue_settings WHERE department = '$department'");
    if ($result && $row = $result->fetch_assoc()) {
        return $row['prefix'];
    }
    return 'Q';
}

function normalizeDepartment($department) {
    return $department === 'General' ? 'General Medicine' : $department;
}

function getQueuePosition($conn, $queue_id, $department) {
    $stmt = $conn->prepare("SELECT COUNT(*) as position FROM queue WHERE (department = ? OR (? = 'General Medicine' AND department = 'General')) AND status = 'Waiting' AND id < ?");
    $stmt->bind_param("ssi", $department, $department, $queue_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $row = $result->fetch_assoc()) {
        $stmt->close();
        return $row['position'] + 1;
    }
    $stmt->close();
    return 1;
}

// ============ ENROLL PATIENT ============
if ($action === 'enqueue') {
    require_once 'queue_tracking_helpers.php';
    ensureQueueTrackingTokens($conn);

    $patient_mrn = intval($_POST['patient_mrn'] ?? 0);
    $requested_department = $_POST['department'] ?? 'General';
    if (!is_string($requested_department)) {
        echo json_encode(['success' => false, 'error' => 'Invalid department.']);
        exit();
    }
    $department = normalizeDepartment($requested_department);
    $priority = $_POST['priority'] ?? 'Normal';

    if (!in_array($department, ['General Medicine', 'Pediatrics', 'OB-Gyne', 'Internal Medicine'], true)) {
        echo json_encode(['success' => false, 'error' => 'Invalid department.']);
        exit();
    }

    if (!in_array($priority, ['Normal', 'Senior', 'PWD'], true)) {
        echo json_encode(['success' => false, 'error' => 'Emergency and unsupported priority cases cannot be enrolled in this queue.']);
        exit();
    }

    // Validate patient exists
    $patient_check = $conn->prepare("SELECT mrn, first_name, last_name FROM patients WHERE mrn = ?");
    $patient_check->bind_param("i", $patient_mrn);
    $patient_check->execute();
    $patient_result = $patient_check->get_result();
    
    if ($patient_result->num_rows === 0) {
        echo json_encode(['success' => false, 'error' => 'Patient not found']);
        exit();
    }
    $patient = $patient_result->fetch_assoc();
    $patient_check->close();
    
    // START TRANSACTION
    $conn->begin_transaction();
    
    // Get or create queue settings with lock
    $settings_result = $conn->query("SELECT current_number FROM queue_settings WHERE department = '$department' FOR UPDATE");
    
    if ($settings_result && $settings_result->num_rows > 0) {
        $settings = $settings_result->fetch_assoc();
        $new_number = $settings['current_number'] + 1;
        $conn->query("UPDATE queue_settings SET current_number = $new_number, last_reset_date = CURDATE() WHERE department = '$department'");
    } else {
        $new_number = 1;
        $conn->query("INSERT INTO queue_settings (department, current_number, last_reset_date, prefix) VALUES ('$department', 1, CURDATE(), 'Q')");
    }

    try {
        $doctor_id = getLeastLoadedAvailableDoctorId($conn, $department);
    } catch (Throwable $error) {
        $conn->rollback();
        error_log($error->getMessage());
        echo json_encode(['success' => false, 'error' => 'Unable to assign a doctor right now. Please try again.']);
        exit();
    }
    if ($doctor_id === null) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => 'Patient cannot be enrolled because no doctor is available for this department.']);
        exit();
    }
    
    // Insert into queue
    $tracking_token = bin2hex(random_bytes(32));
    $insert = $conn->prepare("INSERT INTO queue (patient_mrn, queue_number, priority, status, department, doctor_id, tracking_token, created_at) VALUES (?, ?, ?, 'Waiting', ?, ?, ?, NOW())");
    $insert->bind_param("iissis", $patient_mrn, $new_number, $priority, $department, $doctor_id, $tracking_token);
    
    if ($insert->execute()) {
        $queue_id = $insert->insert_id;
        $insert->close();
        $conn->commit();
        
        $prefix = getPrefix($conn, $department);
        $formatted_number = $prefix . str_pad($new_number, 3, '0', STR_PAD_LEFT);
        $position = getQueuePosition($conn, $queue_id, $department);
        
        echo json_encode([
            'success' => true,
            'queue_id' => $queue_id,
            'queue_number' => $new_number,
            'formatted_number' => $formatted_number,
            'patient_name' => $patient['first_name'] . ' ' . $patient['last_name'],
            'patient_mrn' => $patient_mrn,
            'department' => $department,
            'priority' => $priority,
            'tracking_token' => $tracking_token,
            'position' => $position
        ]);
    } else {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $conn->error]);
    }
    exit();
}

// ============ GET QUEUE ============
if ($action === 'get_queue') {
    $department = normalizeDepartment($_GET['department'] ?? 'General');
    $status = $_GET['status'] ?? 'Waiting';
    $current_user = $auth->currentUser();
    $doctor_id = $current_user['role'] === 'doctor' ? (int)$current_user['id'] : null;
    
    $query = "
        SELECT q.*, p.first_name, p.last_name, p.mrn,
               CONCAT(p.first_name, ' ', p.last_name) as full_name,
               CONCAT(COALESCE(qs.prefix, 'Q'), LPAD(q.queue_number, 3, '0')) as display_number,
               u.full_name as doctor_name
        FROM queue q
        JOIN patients p ON q.patient_mrn = p.mrn
        LEFT JOIN users u ON q.doctor_id = u.id
        LEFT JOIN queue_settings qs ON qs.department = q.department
        WHERE (q.department = ? OR (? = 'General Medicine' AND q.department = 'General')) AND q.status = ?
        " . ($doctor_id !== null ? "AND q.doctor_id = ? " : "") . "
        ORDER BY 
            CASE q.priority 
                WHEN 'Emergency' THEN 1
                WHEN 'Senior' THEN 2
                WHEN 'PWD' THEN 3
                ELSE 4
            END,
            q.queue_number ASC
    ";
    
    $stmt = $conn->prepare($query);
    if ($doctor_id !== null) {
        $stmt->bind_param("sssi", $department, $department, $status, $doctor_id);
    } else {
        $stmt->bind_param("sss", $department, $department, $status);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $queue = $result->fetch_all(MYSQLI_ASSOC);
    
    echo json_encode($queue);
    exit();
}

// ============ GET WAITING COUNT ============
if ($action === 'get_waiting_count') {
    $department = normalizeDepartment($_GET['department'] ?? 'General');
    
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as waiting,
            SUM(CASE WHEN priority = 'Emergency' THEN 1 ELSE 0 END) as emergencies,
            SUM(CASE WHEN priority = 'Senior' THEN 1 ELSE 0 END) as seniors,
            SUM(CASE WHEN priority = 'PWD' THEN 1 ELSE 0 END) as pwd
        FROM queue 
        WHERE (department = ? OR (? = 'General Medicine' AND department = 'General')) AND status = 'Waiting'
    ");
    $stmt->bind_param("ss", $department, $department);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $data = $result ? $result->fetch_assoc() : ['waiting' => 0, 'emergencies' => 0, 'seniors' => 0, 'pwd' => 0];
    echo json_encode($data);
    exit();
}

// ============ GET STATS ============
if ($action === 'get_stats') {
    $department = normalizeDepartment($_GET['department'] ?? 'General');
    $current_user = $auth->currentUser();
    $doctor_id = $current_user['role'] === 'doctor' ? (int)$current_user['id'] : null;
    
    $today_stmt = $conn->prepare("SELECT COUNT(*) as completed FROM queue WHERE (department = ? OR (? = 'General Medicine' AND department = 'General')) AND status = 'Completed' AND DATE(completed_at) = CURDATE()");
    $today_stmt->bind_param("ss", $department, $department);
    $today_stmt->execute();
    $today = $today_stmt->get_result();
    $today_data = $today ? $today->fetch_assoc() : ['completed' => 0];
    
    $serving_stmt = $conn->prepare("
        SELECT q.id, q.queue_number, q.patient_mrn, qs.prefix, p.first_name, p.last_name,
               CONCAT(p.first_name, ' ', p.last_name) as full_name,
               CONCAT(COALESCE(qs.prefix, 'Q'), LPAD(q.queue_number, 3, '0')) as display_number
        FROM queue q
        JOIN patients p ON q.patient_mrn = p.mrn
        LEFT JOIN queue_settings qs ON qs.department = q.department
        WHERE (q.department = ? OR (? = 'General Medicine' AND q.department = 'General')) AND q.status = 'In Consultation'
        " . ($doctor_id !== null ? "AND q.doctor_id = ? " : "") . "
        LIMIT 1
    ");
    if ($doctor_id !== null) {
        $serving_stmt->bind_param("ssi", $department, $department, $doctor_id);
    } else {
        $serving_stmt->bind_param("ss", $department, $department);
    }
    $serving_stmt->execute();
    $serving = $serving_stmt->get_result();

    $currently_serving = ($serving && $serving->num_rows > 0) ? $serving->fetch_assoc() : null;
    
    echo json_encode(['today' => $today_data, 'currently_serving' => $currently_serving]);
    exit();
}

// ============ CALL NEXT ============
if ($action === 'call_next') {
    $department = normalizeDepartment($_POST['department'] ?? 'General');
    $current_user = $auth->currentUser();
    if ($current_user['role'] !== 'doctor') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Only assigned doctors can call queue patients.']);
        exit();
    }
    $doctor_id = (int)$current_user['id'];
    $doctor_department = normalizeDepartment($current_user['assigned_department']);
    if ($doctor_department !== $department) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You cannot call patients from another department.']);
        exit();
    }
    $requested_queue_id = !empty($_POST['queue_id']) ? (int)$_POST['queue_id'] : null;
    
    $next_stmt = $conn->prepare("
        SELECT q.*, p.first_name, p.last_name, qs.prefix
        FROM queue q
        JOIN patients p ON q.patient_mrn = p.mrn
        LEFT JOIN queue_settings qs ON qs.department = q.department
        WHERE (q.department = ? OR (? = 'General Medicine' AND q.department = 'General'))
          AND q.status = 'Waiting'
          AND q.doctor_id = ?
          " . ($requested_queue_id !== null ? "AND q.id = ? " : "") . "
        ORDER BY 
            CASE q.priority 
                WHEN 'Emergency' THEN 1
                WHEN 'Senior' THEN 2
                WHEN 'PWD' THEN 3
                ELSE 4
            END,
            q.queue_number ASC
        LIMIT 1
    ");
    if ($requested_queue_id !== null) {
        $next_stmt->bind_param("ssii", $department, $department, $doctor_id, $requested_queue_id);
    } else {
        $next_stmt->bind_param("ssi", $department, $department, $doctor_id);
    }
    $next_stmt->execute();
    $next = $next_stmt->get_result();
    
    if ($next && $next->num_rows > 0) {
        $patient = $next->fetch_assoc();
        
        $update = $conn->prepare("UPDATE queue SET status = 'In Consultation', called_at = NOW() WHERE id = ? AND status = 'Waiting' AND doctor_id = ?");
        $update->bind_param("ii", $patient['id'], $doctor_id);
        $update->execute();
        $update->close();
        
        $conn->query("DELETE FROM queue_display WHERE department = '$department'");
        $conn->query("INSERT INTO queue_display (currently_serving, last_called, department) VALUES ({$patient['queue_number']}, NOW(), '$department')");
        
        $prefix = $patient['prefix'] ?? 'Q';
        $display_number = $prefix . str_pad($patient['queue_number'], 3, '0', STR_PAD_LEFT);
        
        echo json_encode([
            'success' => true,
            'display_number' => $display_number,
            'patient' => $patient,
            'message' => 'Now serving: ' . $patient['first_name'] . ' ' . $patient['last_name']
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No patients in queue']);
    }
    exit();
}

// ============ COMPLETE CONSULTATION ============
if ($action === 'complete') {
    $queue_id = intval($_POST['queue_id']);
    $get_info = $conn->query("SELECT department FROM queue WHERE id = $queue_id");
    $info = $get_info ? $get_info->fetch_assoc() : null;
    
    $stmt = $conn->prepare("UPDATE queue SET status = 'Completed', completed_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $queue_id);
    $success = $stmt->execute();
    $stmt->close();
    
    if ($success && $info) {
        $conn->query("DELETE FROM queue_display WHERE department = '{$info['department']}'");
    }
    
    echo json_encode(['success' => $success]);
    exit();
}

// ============ CANCEL ============
if ($action === 'cancel') {
    $queue_id = intval($_POST['queue_id']);
    $status = $_POST['status'] ?? 'Cancelled';
    
    $get_info = $conn->query("SELECT department FROM queue WHERE id = $queue_id");
    $info = $get_info ? $get_info->fetch_assoc() : null;
    
    $stmt = $conn->prepare("UPDATE queue SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $queue_id);
    $success = $stmt->execute();
    $stmt->close();
    
    if ($success && $info && $status === 'Cancelled') {
        $conn->query("DELETE FROM queue_display WHERE department = '{$info['department']}'");
    }
    
    echo json_encode(['success' => $success]);
    exit();
}

echo json_encode(['success' => false, 'error' => 'Invalid action: ' . $action]);
?>