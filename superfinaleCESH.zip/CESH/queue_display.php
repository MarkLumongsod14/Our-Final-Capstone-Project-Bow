<?php
// queue_display.php - Public Display for Waiting Area
// Camp Evangelista Station Hospital
require_once 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Queue Display | 4ID Station Hospital</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: { 
                        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'] 
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        @keyframes glowPulse {
            0%, 100% { box-shadow: 0 0 30px rgba(2, 132, 199, 0.15); }
            50% { box-shadow: 0 0 60px rgba(2, 132, 199, 0.3); }
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .live-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #22c55e;
            display: inline-block;
            animation: pulse 1.5s ease-in-out infinite;
        }
        
        .theme-switch {
            position: relative;
            width: 40px;
            height: 22px;
            background: #e2e8f0;
            border-radius: 11px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 2px;
            left: 2px;
            width: 18px;
            height: 18px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 10px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(18px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 10px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 9px; }
        
        .serving-card {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 20px;
            padding: 28px 24px;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .dark .serving-card {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .serving-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #0284c7, #38bdf8, #0284c7);
            background-size: 200% 100%;
            animation: shimmer 3s ease-in-out infinite;
        }
        @keyframes shimmer {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        .serving-card.has-patient {
            border-color: rgba(2, 132, 199, 0.3);
            animation: glowPulse 3s ease-in-out infinite;
        }
        
        .back-bar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 100;
            padding: 10px 24px;
            background: rgba(255,255,255,0.92);
            backdrop-filter: blur(16px);
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .dark .back-bar {
            background: rgba(15, 15, 26, 0.92);
            border-bottom-color: rgba(255,255,255,0.06);
        }
        .back-bar .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 16px;
            border-radius: 20px;
            background: rgba(2, 132, 199, 0.08);
            border: 1px solid rgba(2, 132, 199, 0.2);
            color: #0284c7;
            font-size: 0.75rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.25s ease;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .dark .back-bar .back-btn {
            background: rgba(2, 132, 199, 0.12);
            border-color: rgba(2, 132, 199, 0.25);
            color: #7dd3fc;
        }
        .back-bar .back-btn:hover {
            background: rgba(2, 132, 199, 0.15);
            transform: translateX(-2px);
        }
        .dark .back-bar .back-btn:hover {
            background: rgba(2, 132, 199, 0.2);
        }
        .back-bar .back-btn i {
            font-size: 0.8rem;
        }
        .back-bar .back-location {
            font-size: 0.7rem;
            color: #6b7280;
            font-weight: 400;
        }
        .dark .back-bar .back-location {
            color: #9ca3af;
        }
        
        .main-content {
            padding-top: 72px;
            padding-bottom: 40px;
        }
        
        .queue-card {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 16px;
            overflow: hidden;
            transition: all 0.2s ease;
        }
        .dark .queue-card {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .queue-header {
            padding: 14px 18px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .dark .queue-header {
            border-bottom-color: rgba(255,255,255,0.06);
        }
        .queue-list {
            max-height: 300px;
            overflow-y: auto;
            padding: 4px 0;
        }
        .queue-list li {
            padding: 10px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e5e7eb;
            transition: background 0.2s;
        }
        .dark .queue-list li {
            border-bottom-color: rgba(255,255,255,0.04);
        }
        .queue-list li:hover {
            background: rgba(0,0,0,0.02);
        }
        .dark .queue-list li:hover {
            background: rgba(255,255,255,0.02);
        }
        .queue-list li:last-child {
            border-bottom: none;
        }
        
        .priority-badge {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .priority-Emergency {
            background: rgba(239, 68, 68, 0.15);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.1);
        }
        .priority-Senior {
            background: rgba(251, 191, 36, 0.15);
            color: #f59e0b;
            border: 1px solid rgba(251, 191, 36, 0.1);
        }
        .priority-PWD {
            background: rgba(56, 189, 248, 0.15);
            color: #0ea5e9;
            border: 1px solid rgba(56, 189, 248, 0.1);
        }
        
        .empty-queue {
            text-align: center;
            padding: 32px 16px;
            color: #6b7280;
        }
        .dark .empty-queue {
            color: #9ca3af;
        }
        .empty-queue i {
            font-size: 2rem;
            margin-bottom: 8px;
            display: block;
            color: #d1d5db;
        }
        .dark .empty-queue i {
            color: #4b5563;
        }
        
        .footer {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 16px;
            padding: 16px 24px;
            text-align: center;
        }
        .dark .footer {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        
        @media (max-width: 1024px) {
            .serving-grid { grid-template-columns: repeat(2, 1fr) !important; }
            .queue-grid { grid-template-columns: repeat(2, 1fr) !important; }
        }
        @media (max-width: 640px) {
            .serving-grid { grid-template-columns: 1fr !important; }
            .queue-grid { grid-template-columns: 1fr !important; }
            .serving-card { padding: 20px 16px; }
            .serving-number { font-size: 2.5rem !important; }
            .back-bar { padding: 8px 12px; flex-wrap: wrap; gap: 8px; justify-content: center; }
            .back-bar .back-location { display: none; }
            .back-bar .back-btn { padding: 4px 12px; font-size: 0.65rem; gap: 4px; }
            .main-content { padding-top: 64px; padding-left: 12px; padding-right: 12px; }
            .theme-switch { width: 36px; height: 20px; }
            .theme-switch .slider { width: 16px; height: 16px; top: 2px; left: 2px; }
            .dark .theme-switch .slider { transform: translateX(16px); }
        }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Back Bar with Dark Mode Toggle -->
    <div class="back-bar">
        <div class="flex items-center gap-3">
            <a href="javascript:history.back()" class="back-btn" title="Go back">
                <i class="fas fa-arrow-left"></i>
                <span>Back</span>
            </a>
            <span class="text-xs text-slate-400 dark:text-slate-500 font-medium uppercase tracking-wider hidden sm:inline">← Navigation</span>
            <span class="w-px h-4 bg-slate-300 dark:bg-slate-700 hidden sm:block"></span>
            <span class="back-location hidden sm:inline">
                <i class="fas fa-tv mr-1.5"></i> Queue Display
            </span>
        </div>
        
        <!-- Dark Mode Toggle -->
        <div class="flex items-center gap-1.5">
            <span class="text-xs text-slate-400 dark:text-slate-500">
                <i class="fas fa-sun"></i>
            </span>
            <div class="theme-switch" id="themeToggle">
                <div class="slider">
                    <span class="sun"><i class="fas fa-sun"></i></span>
                    <span class="moon"><i class="fas fa-moon"></i></span>
                </div>
            </div>
            <span class="text-xs text-slate-400 dark:text-slate-500">
                <i class="fas fa-moon"></i>
            </span>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content w-full max-w-7xl mx-auto px-6">
        
<!-- Hospital Header -->
<div class="text-center mb-8">
    <div class="flex flex-col items-center justify-center">
        <div class="w-24 h-24 flex items-center justify-center mb-3">
            <img src="assets/images/logo.png" alt="4ID Station Hospital Logo" class="w-full h-full object-contain" style="filter: drop-shadow(0 0 25px rgba(56, 189, 248, 0.35));">
        </div>
        <h1 class="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">4ID Station Hospital</h1>
        <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">Camp Evangelista • Outpatient Queue Management</p>
    </div>
    <div class="flex items-center justify-center gap-3 text-xs text-slate-500 dark:text-slate-400 mt-4">
        <span class="flex items-center gap-2">
            <span class="live-dot"></span>
            <span class="font-medium">Live Updates</span>
        </span>
        <span class="w-px h-4 bg-slate-300 dark:bg-slate-700"></span>
        <span>Please wait for your number to be called</span>
    </div>
</div>
        
        <!-- Now Serving Section -->
        <div class="flex items-center justify-between mb-5">
            <div class="flex items-center gap-3">
                <i class="fas fa-bell text-sky-500 dark:text-sky-400 text-lg"></i>
                <h2 class="text-lg font-bold text-slate-900 dark:text-white">Now Serving</h2>
            </div>
            <span class="text-xs text-slate-500 dark:text-slate-400 font-medium bg-white dark:bg-slate-800 px-3 py-1 rounded-full border border-slate-200 dark:border-slate-700">
                <i class="fas fa-rotate-right text-sky-500 dark:text-sky-400 mr-1.5"></i> Auto-refresh
            </span>
        </div>
        
        <div class="serving-grid grid grid-cols-4 gap-4 mb-8" id="nowServingGrid">
            <!-- General Medicine -->
            <div class="serving-card" data-dept="General">
                <div class="flex items-center justify-center gap-2 mb-2">
                    <i class="fas fa-stethoscope text-sky-500 dark:text-sky-400 text-lg"></i>
                    <span class="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">General</span>
                </div>
                <div class="serving-number text-4xl font-extrabold text-slate-900 dark:text-white font-mono tracking-wider" id="generalNum">---</div>
                <div class="text-sm text-slate-500 dark:text-slate-400 font-medium mt-1" id="generalPatient">Waiting...</div>
            </div>
            
            <!-- Pediatrics -->
            <div class="serving-card" data-dept="Pediatrics">
                <div class="flex items-center justify-center gap-2 mb-2">
                    <i class="fas fa-child text-emerald-500 dark:text-emerald-400 text-lg"></i>
                    <span class="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Pediatrics</span>
                </div>
                <div class="serving-number text-4xl font-extrabold text-slate-900 dark:text-white font-mono tracking-wider" id="pedsNum">---</div>
                <div class="text-sm text-slate-500 dark:text-slate-400 font-medium mt-1" id="pedsPatient">Waiting...</div>
            </div>
            
            <!-- OB-Gyne -->
            <div class="serving-card" data-dept="OB-Gyne">
                <div class="flex items-center justify-center gap-2 mb-2">
                    <i class="fas fa-female text-rose-500 dark:text-rose-400 text-lg"></i>
                    <span class="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">OB-Gyne</span>
                </div>
                <div class="serving-number text-4xl font-extrabold text-slate-900 dark:text-white font-mono tracking-wider" id="obgynNum">---</div>
                <div class="text-sm text-slate-500 dark:text-slate-400 font-medium mt-1" id="obgynPatient">Waiting...</div>
            </div>
            
            <!-- Internal Medicine -->
            <div class="serving-card" data-dept="Internal Medicine">
                <div class="flex items-center justify-center gap-2 mb-2">
                    <i class="fas fa-heart-pulse text-purple-500 dark:text-purple-400 text-lg"></i>
                    <span class="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Internal Med</span>
                </div>
                <div class="serving-number text-4xl font-extrabold text-slate-900 dark:text-white font-mono tracking-wider" id="internalNum">---</div>
                <div class="text-sm text-slate-500 dark:text-slate-400 font-medium mt-1" id="internalPatient">Waiting...</div>
            </div>
        </div>
        
        <!-- Waiting Queue Section -->
        <div class="flex items-center justify-between mb-5">
            <div class="flex items-center gap-3">
                <i class="fas fa-list-ol text-sky-500 dark:text-sky-400 text-lg"></i>
                <h2 class="text-lg font-bold text-slate-900 dark:text-white">Waiting Queue</h2>
            </div>
            <span class="text-xs text-slate-500 dark:text-slate-400">Showing next 5 patients</span>
        </div>
        
        <div class="queue-grid grid grid-cols-4 gap-4" id="queueGrid">
            <!-- General Medicine Queue -->
            <div class="queue-card">
                <div class="queue-header">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-stethoscope text-sky-500 dark:text-sky-400 text-sm"></i>
                        <span class="text-sm font-bold text-slate-900 dark:text-white">General</span>
                    </div>
                    <span class="text-xs font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full" id="generalCount">0</span>
                </div>
                <ul class="queue-list" id="generalQueue">
                    <li class="empty-queue"><i class="fas fa-inbox"></i>No patients waiting</li>
                </ul>
            </div>
            
            <!-- Pediatrics Queue -->
            <div class="queue-card">
                <div class="queue-header">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-child text-emerald-500 dark:text-emerald-400 text-sm"></i>
                        <span class="text-sm font-bold text-slate-900 dark:text-white">Pediatrics</span>
                    </div>
                    <span class="text-xs font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full" id="pediatricsCount">0</span>
                </div>
                <ul class="queue-list" id="pediatricsQueue">
                    <li class="empty-queue"><i class="fas fa-inbox"></i>No patients waiting</li>
                </ul>
            </div>
            
            <!-- OB-Gyne Queue -->
            <div class="queue-card">
                <div class="queue-header">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-female text-rose-500 dark:text-rose-400 text-sm"></i>
                        <span class="text-sm font-bold text-slate-900 dark:text-white">OB-Gyne</span>
                    </div>
                    <span class="text-xs font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full" id="obgynCount">0</span>
                </div>
                <ul class="queue-list" id="obgynQueue">
                    <li class="empty-queue"><i class="fas fa-inbox"></i>No patients waiting</li>
                </ul>
            </div>
            
            <!-- Internal Medicine Queue -->
            <div class="queue-card">
                <div class="queue-header">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-heart-pulse text-purple-500 dark:text-purple-400 text-sm"></i>
                        <span class="text-sm font-bold text-slate-900 dark:text-white">Internal Med</span>
                    </div>
                    <span class="text-xs font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full" id="internalCount">0</span>
                </div>
                <ul class="queue-list" id="internalQueue">
                    <li class="empty-queue"><i class="fas fa-inbox"></i>No patients waiting</li>
                </ul>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="footer mt-8">
            <div class="flex items-center justify-center gap-6 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
                <span><i class="fas fa-info-circle text-sky-500 dark:text-sky-400 mr-1.5"></i> Please wait for your number to be called</span>
                <span class="w-px h-4 bg-slate-300 dark:bg-slate-700 hidden sm:block"></span>
                <span><i class="fas fa-bell text-amber-500 dark:text-amber-400 mr-1.5"></i> Kindly proceed to the assigned room</span>
                <span class="w-px h-4 bg-slate-300 dark:bg-slate-700 hidden sm:block"></span>
                <span id="lastUpdated" class="text-slate-400 dark:text-slate-500">
                    <i class="fas fa-clock mr-1.5"></i> Loading...
                </span>
            </div>
        </div>
    </div>

    <script>
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            if (htmlElement.classList.contains('dark')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });
        
        // ============================================
        // Queue Display Logic
        // ============================================
        const departments = [
            { name: 'General', apiName: 'General', numId: 'generalNum', patientId: 'generalPatient', queueId: 'generalQueue', countId: 'generalCount' },
            { name: 'Pediatrics', apiName: 'Pediatrics', numId: 'pedsNum', patientId: 'pedsPatient', queueId: 'pediatricsQueue', countId: 'pediatricsCount' },
            { name: 'OB-Gyne', apiName: 'OB-Gyne', numId: 'obgynNum', patientId: 'obgynPatient', queueId: 'obgynQueue', countId: 'obgynCount' },
            { name: 'Internal Medicine', apiName: 'Internal Medicine', numId: 'internalNum', patientId: 'internalPatient', queueId: 'internalQueue', countId: 'internalCount' }
        ];

        const basePath = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);

        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function getPriorityBadge(priority) {
            if (priority === 'Emergency') {
                return '<span class="priority-badge priority-Emergency"><i class="fas fa-triangle-exclamation mr-1"></i>Emergency</span>';
            } else if (priority === 'Senior') {
                return '<span class="priority-badge priority-Senior"><i class="fas fa-user-plus mr-1"></i>Senior</span>';
            } else if (priority === 'PWD') {
                return '<span class="priority-badge priority-PWD"><i class="fas fa-wheelchair mr-1"></i>PWD</span>';
            }
            return '';
        }

        async function loadDisplay() {
            try {
                for (const dept of departments) {
                    const response = await fetch(`${basePath}queue_api.php?action=get_queue&department=${encodeURIComponent(dept.apiName)}&status=Waiting`);
                    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
                    const queue = await response.json();
                    
                    const listEl = document.getElementById(dept.queueId);
                    const countEl = document.getElementById(dept.countId);
                    
                    if (countEl) countEl.textContent = queue.length;
                    
                    if (!queue || queue.length === 0) {
                        listEl.innerHTML = '<li class="empty-queue"><i class="fas fa-inbox"></i>No patients waiting</li>';
                    } else {
                        listEl.innerHTML = queue.slice(0, 5).map(q => `
                            <li>
                                <span class="font-mono font-bold text-sky-600 dark:text-sky-400 text-sm">${escapeHtml(q.display_number)}</span>
                                <div class="flex items-center gap-2">
                                    <span class="text-sm text-slate-800 dark:text-slate-200 font-medium">${escapeHtml(q.full_name)}</span>
                                    ${getPriorityBadge(q.priority)}
                                </div>
                            </li>
                        `).join('');
                    }
                    
                    const statsResponse = await fetch(`${basePath}queue_api.php?action=get_stats&department=${encodeURIComponent(dept.apiName)}`);
                    if (!statsResponse.ok) throw new Error(`HTTP error! status: ${statsResponse.status}`);
                    const stats = await statsResponse.json();
                    
                    const numElement = document.getElementById(dept.numId);
                    const patientElement = document.getElementById(dept.patientId);
                    const card = numElement?.closest('.serving-card');
                    
                    if (stats.currently_serving && stats.currently_serving.display_number) {
                        if (numElement) {
                            numElement.textContent = stats.currently_serving.display_number;
                            numElement.style.color = '#0ea5e9';
                        }
                        if (patientElement) {
                            patientElement.textContent = escapeHtml(stats.currently_serving.full_name) || '---';
                            patientElement.style.color = '#1f2937';
                        }
                        if (card) card.classList.add('has-patient');
                    } else {
                        if (numElement) {
                            numElement.textContent = '---';
                            numElement.style.color = '#9ca3af';
                        }
                        if (patientElement) {
                            patientElement.textContent = 'Waiting...';
                            patientElement.style.color = '#9ca3af';
                        }
                        if (card) card.classList.remove('has-patient');
                    }
                }
                
                const timestamp = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                const lastUpdated = document.getElementById('lastUpdated');
                if (lastUpdated) {
                    lastUpdated.innerHTML = `<i class="fas fa-clock mr-1.5"></i> Updated: ${timestamp}`;
                }
            } catch (error) {
                console.error('Error loading display:', error);
                const lastUpdated = document.getElementById('lastUpdated');
                if (lastUpdated) {
                    lastUpdated.innerHTML = `<i class="fas fa-triangle-exclamation text-rose-500 mr-1.5"></i> Connection error: ${error.message}`;
                }
            }
        }

        loadDisplay();
        setInterval(loadDisplay, 5000);
    </script>
</body>
</html>