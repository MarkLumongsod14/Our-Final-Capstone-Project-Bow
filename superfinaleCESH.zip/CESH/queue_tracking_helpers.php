<?php
function ensureQueueTrackingTokens(mysqli $conn): void
{
    $column = $conn->query("SHOW COLUMNS FROM queue LIKE 'tracking_token'");
    if (!$column) {
        throw new RuntimeException('Unable to inspect queue tracking schema: ' . $conn->error);
    }

    if ($column->num_rows === 0 && !$conn->query("ALTER TABLE queue ADD COLUMN tracking_token CHAR(64) DEFAULT NULL")) {
        $column = $conn->query("SHOW COLUMNS FROM queue LIKE 'tracking_token'");
        if (!$column || $column->num_rows === 0) {
            throw new RuntimeException('Unable to add queue tracking tokens: ' . $conn->error);
        }
    }

    $missing = $conn->query("SELECT id FROM queue WHERE tracking_token IS NULL OR tracking_token = ''");
    if (!$missing) {
        throw new RuntimeException('Unable to find queue entries missing tracking tokens: ' . $conn->error);
    }

    $update = $conn->prepare("UPDATE queue SET tracking_token = ? WHERE id = ? AND (tracking_token IS NULL OR tracking_token = '')");
    if (!$update) {
        throw new RuntimeException('Unable to prepare queue tracking token migration: ' . $conn->error);
    }

    while ($row = $missing->fetch_assoc()) {
        $token = bin2hex(random_bytes(32));
        $queueId = (int)$row['id'];
        $update->bind_param('si', $token, $queueId);
        if (!$update->execute()) {
            throw new RuntimeException('Unable to assign a queue tracking token: ' . $update->error);
        }
    }

    $update->close();
    $missing->free();
}
