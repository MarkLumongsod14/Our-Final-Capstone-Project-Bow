<?php
// get_patients_dropdown.php - Get patients for dropdown
require_once 'db.php';
require_once 'auth.php';

$auth->requireLogin();
header('Content-Type: application/json');

$result = $conn->query("SELECT mrn, first_name, last_name FROM patients WHERE status = 'Active' ORDER BY last_name, first_name");
$patients = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

echo json_encode($patients);
?>