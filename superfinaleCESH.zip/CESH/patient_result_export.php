<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once dirname(__DIR__) . '/queuv1/config/database.php';

$auth->requireRole(['doctor']);

function patientResultExportEscape($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$resultId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$mode = isset($_GET['mode']) && is_string($_GET['mode']) ? $_GET['mode'] : 'print';
if (!$resultId || $resultId < 1 || !in_array($mode, ['pdf', 'print'], true)) {
    http_response_code(400);
    exit('Invalid result request.');
}

$queueDatabase = new Database();
$queueDb = $queueDatabase->getConnection();
if (!$queueDb) {
    error_log('Patient result export: Could not connect to Smart Queueing.');
    http_response_code(503);
    exit('Patient result is temporarily unavailable.');
}

$resultStmt = $queueDb->prepare("
    SELECT cr.id, cr.patient_id, cr.result_data, cr.findings, cr.recommendations,
           cr.status, cr.submitted_at, p.mrn AS queue_mrn, p.date_of_birth,
           p.gender, c.name AS clinic_name, q.queue_number,
           u.full_name AS submitted_by
    FROM clinic_results cr
    JOIN patients p ON p.id = cr.patient_id
    JOIN clinics c ON c.id = cr.clinic_id
    LEFT JOIN queue_entries q ON q.id = cr.queue_entry_id
    LEFT JOIN users u ON u.id = cr.submitted_by
    WHERE cr.id = ?
    LIMIT 1
");
$resultStmt->execute([$resultId]);
$result = $resultStmt->fetch(PDO::FETCH_ASSOC);

if (!$result || !preg_match('/^MRN([0-9]{6})$/D', (string)$result['queue_mrn'], $mrnMatch)) {
    http_response_code(404);
    exit('Result not found for a linked CESH outpatient.');
}

$ceshMrn = (int)$mrnMatch[1];
$patientStmt = $conn->prepare("
    SELECT mrn, first_name, middle_name, last_name, suffix, dob, gender
    FROM patients
    WHERE mrn = ?
    LIMIT 1
");
$patientStmt->bind_param('i', $ceshMrn);
if (!$patientStmt->execute()) {
    error_log('Patient result export: CESH patient lookup failed: ' . $patientStmt->error);
    http_response_code(500);
    exit('Patient result is temporarily unavailable.');
}
$patient = $patientStmt->get_result()->fetch_assoc();
$patientStmt->close();

if (!$patient) {
    http_response_code(404);
    exit('Result not found for a linked CESH outpatient.');
}

$resultData = json_decode($result['result_data'] ?? '', true);
if (!is_array($resultData)) {
    $resultData = [];
}
$birthDate = !empty($patient['dob']) ? DateTime::createFromFormat('Y-m-d', $patient['dob']) : false;
$age = $birthDate ? $birthDate->diff(new DateTimeImmutable('today'))->y : null;
$patientName = trim(
    ($patient['last_name'] ?? '') . ', ' .
    ($patient['first_name'] ?? '') . ' ' .
    ($patient['middle_name'] ?? '') . ' ' .
    ($patient['suffix'] ?? '')
);
$logoPath = __DIR__ . '/assets/images/logo.png';
$logoExists = is_file($logoPath);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= patientResultExportEscape($patient['last_name'] . ' - ' . $result['clinic_name'] . ' Result') ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; padding: 20px; color: #222; background: #f1f5f9; font: 14px Arial, sans-serif; }
        .toolbar { display: flex; justify-content: center; gap: 10px; margin: 0 auto 18px; }
        .toolbar button { border: 0; border-radius: 6px; padding: 10px 16px; color: #fff; background: #2563eb; font-size: 14px; cursor: pointer; }
        .toolbar .close { background: #475569; }
        .report { max-width: 850px; min-height: 500px; margin: 0 auto; padding: 32px; background: #fff; box-shadow: 0 2px 16px #0002; }
        .hospital-header { padding-bottom: 16px; border-bottom: 2px solid #1a3a5c; text-align: center; }
        .hospital-header img { display: block; max-height: 64px; max-width: 180px; margin: 0 auto 8px; }
        .hospital-name { color: #1a3a5c; font-size: 18px; font-weight: 700; letter-spacing: 1px; }
        .hospital-sub { margin-top: 3px; color: #555; font-size: 11px; }
        .report-title { margin: 20px 0; text-align: center; font-size: 15px; font-weight: 700; text-decoration: underline; }
        table { width: 100%; border-collapse: collapse; }
        .patient-info { margin-bottom: 20px; font-size: 12px; }
        .patient-info th, .patient-info td, .results-table th, .results-table td { border: 1px solid #333; padding: 8px 10px; text-align: left; vertical-align: top; }
        .patient-info th, .results-table th { background: #f0f0f0; }
        .patient-info th { width: 18%; }
        .specimen { margin-bottom: 15px; font-size: 12px; }
        .results-table { margin-bottom: 20px; font-size: 11px; }
        .results-table th { text-align: center; }
        .interpretation { margin: 16px 0; font-size: 12px; line-height: 1.5; }
        .interpretation strong { display: block; margin-bottom: 5px; text-decoration: underline; }
        .signature { margin-top: 45px; text-align: right; font-size: 12px; }
        .signature-line { display: inline-block; min-width: 250px; padding-top: 6px; border-top: 1px solid #333; text-align: center; }
        .watermark { margin-top: 24px; padding-top: 10px; border-top: 1px solid #ccc; color: #777; text-align: center; font-size: 10px; }
        @page { size: A4; margin: 14mm; }
        @media print {
            body { padding: 0; background: #fff; }
            .no-print { display: none !important; }
            .report { max-width: none; min-height: 0; padding: 0; box-shadow: none; }
            .results-table tr, .patient-info tr { break-inside: avoid; }
        }
    </style>
</head>
<body>
    <div class="toolbar no-print">
        <button type="button" onclick="window.print()"><i class="fas fa-print"></i> Print / Save as PDF</button>
        <button type="button" class="close" onclick="window.close()">Close</button>
    </div>
    <main class="report">
        <header class="hospital-header">
            <?php if ($logoExists): ?><img src="assets/images/logo.png" alt="Camp Evangelista Station Hospital logo"><?php endif; ?>
            <div class="hospital-name">CAMP EVANGELISTA STATION HOSPITAL</div>
            <div class="hospital-sub">4th Infantry Division, Philippine Army</div>
            <div class="hospital-sub">Camp Evangelista, Cagayan de Oro City</div>
        </header>
        <h1 class="report-title">PATIENT CLINICAL RESULT REPORT</h1>
        <table class="patient-info">
            <tr>
                <th>Patient Name</th><td><?= patientResultExportEscape(strtoupper($patientName)) ?></td>
                <th>Age</th><td><?= $age === null ? '—' : (int)$age ?></td>
            </tr>
            <tr>
                <th>Hospital No. (MRN)</th><td><?= patientResultExportEscape(str_pad((string)$patient['mrn'], 6, '0', STR_PAD_LEFT)) ?></td>
                <th>Sex</th><td><?= patientResultExportEscape($patient['gender'] ?: '—') ?></td>
            </tr>
            <tr>
                <th>Clinic</th><td><?= patientResultExportEscape($result['clinic_name']) ?></td>
                <th>Date Submitted</th><td><?= patientResultExportEscape($result['submitted_at'] ? date('Y-m-d g:i A', strtotime($result['submitted_at'])) : '—') ?></td>
            </tr>
        </table>
        <p class="specimen">
            <strong>Queue Number:</strong> <?= patientResultExportEscape($result['queue_number'] ?? '—') ?>
            &nbsp; <strong>Status:</strong> <?= patientResultExportEscape(ucfirst($result['status'] ?? 'unknown')) ?>
            <?php if (!empty($result['submitted_by'])): ?>&nbsp; <strong>Submitted by:</strong> <?= patientResultExportEscape($result['submitted_by']) ?><?php endif; ?>
        </p>
        <table class="results-table">
            <thead><tr><th>Parameter</th><th>Result</th></tr></thead>
            <tbody>
                <?php $hasData = false; ?>
                <?php foreach ($resultData as $key => $value): ?>
                    <?php if ($value === '' || $value === null || $value === []) continue; ?>
                    <?php $hasData = true; ?>
                    <tr>
                        <td><?= patientResultExportEscape(ucwords(str_replace('_', ' ', (string)$key))) ?></td>
                        <td><?= patientResultExportEscape(is_scalar($value) ? $value : json_encode($value, JSON_UNESCAPED_UNICODE)) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$hasData): ?><tr><td colspan="2" style="text-align:center">No structured result data available.</td></tr><?php endif; ?>
            </tbody>
        </table>
        <?php if (!empty($result['findings'])): ?><div class="interpretation"><strong>INTERPRETATION / FINDINGS</strong><?= nl2br(patientResultExportEscape($result['findings'])) ?></div><?php endif; ?>
        <?php if (!empty($result['recommendations'])): ?><div class="interpretation"><strong>RECOMMENDATIONS</strong><?= nl2br(patientResultExportEscape($result['recommendations'])) ?></div><?php endif; ?>
        <div class="signature"><div class="signature-line"><?= patientResultExportEscape($result['submitted_by'] ?: 'Medical Officer') ?><br>Submitting Provider</div></div>
        <footer class="watermark">Generated <?= patientResultExportEscape(date('F d, Y h:i A')) ?> · Computer-generated document</footer>
    </main>
    <?php if ($mode === 'pdf'): ?><script>window.addEventListener('load', function() { window.setTimeout(function() { window.print(); }, 500); });</script><?php endif; ?>
</body>
</html>
