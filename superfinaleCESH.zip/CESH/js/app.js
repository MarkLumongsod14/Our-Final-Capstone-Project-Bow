(async function(){
    const monthLabel = document.getElementById('monthLabel');
    const calendarGrid = document.getElementById('calendarGrid');
    const appointmentsList = document.getElementById('appointmentsList');
    const appointmentsTitle = document.getElementById('appointmentsTitle');
    const prevBtn = document.getElementById('prevMonth');
    const nextBtn = document.getElementById('nextMonth');

    let today = new Date();
    const todayIso = today.toISOString().slice(0,10);
    let viewYear = today.getFullYear();
    let viewMonth = today.getMonth();
    let selectedIso = null;

    let appointments = {};

    async function fetchAppointments(){
        const res = await fetch('manage_appointments.php?action=get');
        appointments = await res.json();
    }

    function render(){
        calendarGrid.innerHTML = '';
        const first = new Date(viewYear, viewMonth, 1);
        const last = new Date(viewYear, viewMonth + 1, 0);
        monthLabel.textContent = first.toLocaleString(undefined,{month:'long', year:'numeric'});

        const startDay = first.getDay();
        for(let i=0;i<startDay;i++){
            const cell = document.createElement('div');
            cell.className = 'day inactive';
            calendarGrid.appendChild(cell);
        }

        for(let d=1; d<=last.getDate(); d++){
            const date = new Date(viewYear, viewMonth, d);
            const iso = date.toISOString().slice(0,10);
            const cell = document.createElement('div');
            cell.className = 'day';
            if(iso===todayIso) cell.classList.add('today');
            if(iso===selectedIso) cell.classList.add('selected');
            cell.innerHTML = `<div class="date">${d}</div>`;

            const list = appointments[iso];
            if(list && list.length){
                const badge = document.createElement('div');
                badge.className = 'count';
                badge.textContent = list.length;
                cell.appendChild(badge);
            }

            cell.addEventListener('click', ()=> {
                selectedIso = iso;
                render();
                showAppointments(iso, date);
            });

            calendarGrid.appendChild(cell);
        }
    }

    function showAppointments(iso, date){
        const list = appointments[iso] || [];
        appointmentsTitle.textContent = list.length ? `Appointments for ${date.toDateString()}` : `No appointments for ${date.toDateString()}`;
        appointmentsList.innerHTML = '';
        if(list.length){
            list.forEach(a=>{
                const li = document.createElement('li');
                li.innerHTML = `${a.time} — ${a.name} <button data-id="${a.id}" class="editBtn">Edit</button> <button data-id="${a.id}" class="delBtn">Delete</button>`;
                appointmentsList.appendChild(li);
            });

            document.querySelectorAll('.editBtn').forEach(btn=>{
                btn.addEventListener('click', ()=> openModal(iso, btn.dataset.id));
            });
            document.querySelectorAll('.delBtn').forEach(btn=>{
                btn.addEventListener('click', async ()=>{
                    if(confirm('Delete this appointment?')){
                        await fetch('manage_appointments.php?action=delete', {
                            method:'POST',
                            headers:{'Content-Type':'application/json'},
                            body:JSON.stringify({id:btn.dataset.id})
                        });
                        await fetchAppointments();
                        render();
                        showAppointments(iso, new Date(iso));
                    }
                });
            });
        }
    }

    prevBtn.addEventListener('click', ()=>{ viewMonth--; if(viewMonth<0){viewMonth=11; viewYear--;} render(); });
    nextBtn.addEventListener('click', ()=>{ viewMonth++; if(viewMonth>11){viewMonth=0; viewYear++;} render(); });

    await fetchAppointments();
    render();

    // ===== Modal =====
    const modalHTML = `
    <div id="aptModal" class="modal-backdrop" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);justify-content:center;align-items:center">
        <div style="background:#fff;padding:16px;border-radius:8px;min-width:300px;position:relative">
            <button id="closeModal" style="position:absolute;top:8px;right:8px;">×</button>
            <h3 id="modalTitle">Add Appointment</h3>
            <input id="aptTime" type="time" style="width:100%;margin:8px 0"/>
            <input id="aptName" type="text" placeholder="Patient Name" style="width:100%;margin:8px 0"/>
            <button id="saveApt" style="width:100%;padding:8px;background:#06b6d4;color:#fff;border:0;border-radius:6px;">Save</button>
        </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    const modal = document.getElementById('aptModal');
    const closeModalBtn = document.getElementById('closeModal');
    const saveBtn = document.getElementById('saveApt');
    const aptTime = document.getElementById('aptTime');
    const aptName = document.getElementById('aptName');
    let editingId = null, currentDate = null;

    function openModal(date, id=null){
        currentDate = date;
        editingId = id;
        modal.style.display = 'flex';
        if(id){
            const item = appointments[date].find(a=>a.id==id);
            aptTime.value = item.time;
            aptName.value = item.name;
            document.getElementById('modalTitle').textContent = 'Edit Appointment';
        } else {
            aptTime.value = '';
            aptName.value = '';
            document.getElementById('modalTitle').textContent = 'Add Appointment';
        }
    }

    closeModalBtn.addEventListener('click', ()=>{ modal.style.display='none'; });
    saveBtn.addEventListener('click', async ()=>{
        const data = {id:editingId, date:currentDate, time:aptTime.value, name:aptName.value};
        await fetch('manage_appointments.php?action=save',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(data)
        });
        modal.style.display='none';
        await fetchAppointments();
        render();
        showAppointments(currentDate,new Date(currentDate));
    });

})();
