console.log("Scheduled Patient JS Loaded");

(async function(){
	const scheduleList = document.getElementById('scheduleList');
	const filterDate = document.getElementById('filterDate');
	const filterBtn = document.getElementById('filterBtn');
	const clearBtn = document.getElementById('clearBtn');
	const addAppointmentBtn = document.getElementById('addAppointmentBtn');
	const modal = document.getElementById('scheduleModal');
	const closeModalBtn = document.getElementById('closeModal');
	const cancelModalBtn = document.getElementById('cancelSchedule');
	const scheduleForm = document.getElementById('scheduleForm');

	let appointments = [];
	let editingId = null;

	// -------------------------------
	// Fetch appointments from API
	// -------------------------------
	async function loadAppointments() {
		const res = await fetch('api/appointments.php?action=list');
		appointments = await res.json();
		renderAppointments();
	}

	// -------------------------------
	// Render appointments table
	// -------------------------------
	function renderAppointments() {
		if(!scheduleList) return;
		scheduleList.innerHTML = '';
		appointments.forEach(a => {
			const tr = document.createElement('tr');
			tr.dataset.id = a.id;
			tr.innerHTML = `
				<td>${a.appointment_time.slice(0,5)}</td>
				<td>${a.first_name} ${a.last_name}</td>
				<td>${a.mrn}</td>
				<td>${a.provider}</td>
				<td>${a.type}</td>
				<td class="${a.status === 'Confirmed' ? 'success' : 'muted'}">${a.status}</td>
				<td><button class="scheduleBtn" style="padding:6px 8px;border-radius:6px;background:#10b981;color:#fff;border:0;cursor:pointer">${a.status==='Confirmed'?'Reschedule':'Schedule'}</button></td>
				<td>
					<button class="deleteBtn" style="padding:6px 8px;border-radius:6px;background:#ef4444;color:#fff;border:0;cursor:pointer">Delete</button>
				</td>
			`;
			scheduleList.prepend(tr);
		});
		attachRowButtons();
	}

	// -------------------------------
	// Open modal with data
	// -------------------------------
	function openModal(data=null) {
		modal.style.display = 'flex';
		if(data){
			document.getElementById('aptDate').value = data.appointment_date;
			document.getElementById('aptTime').value = data.appointment_time;
			document.getElementById('aptPatient').value = `${data.first_name} ${data.last_name}`;
			document.getElementById('aptMRN').value = data.mrn;
			document.getElementById('aptProvider').value = data.provider;
			document.getElementById('aptType').value = data.type;
			document.getElementById('aptStatus').value = data.status;
			editingId = data.id;
		} else {
			scheduleForm.reset();
			editingId = null;
		}
	}

	// -------------------------------
	// Close modal
	// -------------------------------
	function closeModal() {
		modal.style.display = 'none';
		editingId = null;
	}

	// -------------------------------
	// Attach buttons
	// -------------------------------
	function attachRowButtons() {
		document.querySelectorAll('.scheduleBtn').forEach(btn => {
			btn.onclick = async (e) => {
				const tr = e.target.closest('tr');
				const id = parseInt(tr.dataset.id);
				const apt = appointments.find(a => a.id==id);
				if(apt) openModal(apt);
			};
		});
		document.querySelectorAll('.deleteBtn').forEach(btn => {
			btn.onclick = async (e) => {
				const tr = e.target.closest('tr');
				const id = parseInt(tr.dataset.id);
				if(!confirm('Delete this appointment?')) return;
				await fetch('api/appointments.php?action=delete', {
					method:'POST',
					headers:{'Content-Type':'application/json'},
					body: JSON.stringify({id})
				});
				appointments = appointments.filter(a => a.id!=id);
				renderAppointments();
			};
		});
	}

	// -------------------------------
	// Form submit
	// -------------------------------
	scheduleForm.addEventListener('submit', async e=>{
		e.preventDefault();
		const date = document.getElementById('aptDate').value;
		const time = document.getElementById('aptTime').value;
		const patientFull = document.getElementById('aptPatient').value.trim();
		const [first_name,last_name] = patientFull.split(' ').length>1 ? patientFull.split(' ') : [patientFull,''];
		const mrn = document.getElementById('aptMRN').value;
		const provider = document.getElementById('aptProvider').value;
		const type = document.getElementById('aptType').value;
		const status = document.getElementById('aptStatus').value;

		const payload = {date,time,first_name,last_name,mrn,provider,type,status};

		if(editingId){
			payload.id = editingId;
			await fetch('api/appointments.php?action=update',{
				method:'POST',
				headers:{'Content-Type':'application/json'},
				body: JSON.stringify(payload)
			});
			appointments = appointments.map(a=>a.id==editingId ? {...a,...payload} : a);
		} else {
			const res = await fetch('api/appointments.php?action=add',{
				method:'POST',
				headers:{'Content-Type':'application/json'},
				body: JSON.stringify(payload)
			});
			const newApt = await res.json();
			payload.id = newApt.id;
			appointments.unshift(payload);
		}

		closeModal();
		renderAppointments();
	});

	// -------------------------------
	// Modal open/close buttons
	// -------------------------------
	addAppointmentBtn?.addEventListener('click', ()=>openModal());
	closeModalBtn?.addEventListener('click', closeModal);
	cancelModalBtn?.addEventListener('click', closeModal);

	// -------------------------------
	// Filter appointments by date
	// -------------------------------
	filterBtn?.addEventListener('click', ()=>{
		const d = filterDate.value;
		document.querySelectorAll('#scheduleList tr').forEach(r=>{
			r.style.display = (!d || r.children[0].textContent===d) ? '' : 'none';
		});
	});

	clearBtn?.addEventListener('click', ()=>{
		filterDate.value = '';
		document.querySelectorAll('#scheduleList tr').forEach(r=>r.style.display='');
	});

	// -------------------------------
	// Initial load
	// -------------------------------
	loadAppointments();

})();
