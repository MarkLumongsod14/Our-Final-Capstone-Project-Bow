async function fetchAppointments() {
  const res = await fetch('api/appointments.php');
  return await res.json();
}
