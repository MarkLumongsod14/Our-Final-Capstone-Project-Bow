<?php

class UnifiedSession
{
    private const SESSION_KEYS = [
        'user_id',
        'username',
        'full_name',
        'email',
        'role',
        'assigned_department',
        'can_access_all_depts',
        'logged_in',
        'login_time',
        'clinic_id',
        'clinic_name',
        'last_activity',
    ];

    public static function loginUrl(): string
    {
        $configuredPath = getenv('CESH_BASE_PATH') ?: '/CESH';
        $configuredPath = trim(str_replace('\\', '/', $configuredPath), '/');
        $configuredPath = $configuredPath === '' ? '' : '/' . $configuredPath;
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        return $scheme . '://' . $host . $configuredPath . '/unified_login.php';
    }

    public static function logoutUrl(): string
    {
        return str_replace('/unified_login.php', '/unified_logout.php', self::loginUrl());
    }

    public static function activate(string $system, bool $required = true): bool
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        if (!in_array($system, ['outpatient', 'smart_queueing'], true)) {
            throw new InvalidArgumentException('Unknown application context.');
        }

        if ($system === 'smart_queueing' && !empty($_SESSION['sso_smart_queue_registration_only'])) {
            if ((int)($_SESSION['sso_smart_queue_registration_expires_at'] ?? 0) <= time()) {
                unset(
                    $_SESSION['sso_smart_queue_registration_only'],
                    $_SESSION['sso_smart_queue_registration_mrn'],
                    $_SESSION['sso_smart_queue_registration_priority'],
                    $_SESSION['sso_smart_queue_registration_expires_at'],
                    $_SESSION['sso_contexts']['smart_queueing']
                );
                header('Location: ' . self::loginUrl());
                exit;
            }

            $allowedScripts = [
                realpath(dirname(__DIR__) . DIRECTORY_SEPARATOR . 'queuv1' . DIRECTORY_SEPARATOR . 'staff' . DIRECTORY_SEPARATOR . 'registration.php'),
                realpath(dirname(__DIR__) . DIRECTORY_SEPARATOR . 'queuv1' . DIRECTORY_SEPARATOR . 'staff' . DIRECTORY_SEPARATOR . 'print-ticket.php'),
                realpath(dirname(__DIR__) . DIRECTORY_SEPARATOR . 'queuv1' . DIRECTORY_SEPARATOR . 'staff' . DIRECTORY_SEPARATOR . 'heartbeat.php'),
            ];
            $executedScripts = array_merge(
                [$_SERVER['SCRIPT_FILENAME'] ?? ''],
                get_included_files()
            );
            $isAllowedScript = false;
            foreach ($executedScripts as $executedScript) {
                $resolvedScript = realpath($executedScript);
                if ($resolvedScript !== false && in_array($resolvedScript, $allowedScripts, true)) {
                    $isAllowedScript = true;
                    break;
                }
            }
            if (!$isAllowedScript) {
                http_response_code(403);
                exit('This Outpatient account is authorized for Smart Queueing registration only.');
            }
        }

        $context = $_SESSION['sso_contexts'][$system] ?? null;
        if (
            empty($_SESSION['sso_identity_id'])
            || !is_array($context)
            || empty($context['logged_in'])
        ) {
            if ($required) {
                header('Location: ' . self::loginUrl());
                exit;
            }
            return false;
        }

        foreach (self::SESSION_KEYS as $key) {
            unset($_SESSION[$key]);
        }
        foreach (self::SESSION_KEYS as $key) {
            if (array_key_exists($key, $context)) {
                $_SESSION[$key] = $context[$key];
            }
        }
        if ($system === 'smart_queueing') {
            $_SESSION['last_activity'] = time();
        }
        $_SESSION['sso_current_system'] = $system;

        register_shutdown_function(static function () use ($system): void {
            if (session_status() !== PHP_SESSION_ACTIVE || !isset($_SESSION['sso_contexts'][$system])) {
                return;
            }
            foreach (self::SESSION_KEYS as $key) {
                if (array_key_exists($key, $_SESSION)) {
                    $_SESSION['sso_contexts'][$system][$key] = $_SESSION[$key];
                } else {
                    unset($_SESSION['sso_contexts'][$system][$key]);
                }
            }
        });

        return true;
    }

    public static function requireSystem(string $system): void
    {
        if (($_SESSION['sso_current_system'] ?? null) !== $system) {
            self::activate($system, true);
        }
    }
}
