<?php
// scheduled_patient.php - Appointment Management
// Camp Evangelista Station Hospital

require_once 'db.php';
require_once 'auth.php';
require_once 'brevo_mailer.php';

$auth->requireLogin();
$current_user = $auth->currentUser();

// Fetch patients for dropdown
$patientResult = $conn->query("SELECT mrn, first_name, last_name FROM patients WHERE status = 'Active' ORDER BY last_name, first_name");
$patients = $patientResult ? $patientResult->fetch_all(MYSQLI_ASSOC) : [];

// Fetch doctors for dropdown
$doctorResult = $conn->query("SELECT id, full_name, assigned_department FROM users WHERE status = 'Active' AND (role = 'admin' OR (role = 'doctor' AND is_available = 1)) ORDER BY full_name");
$doctors = $doctorResult ? $doctorResult->fetch_all(MYSQLI_ASSOC) : [];

// Handle adding/updating appointment via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])){
    $id = $_POST['id'] ?? '';
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $patient_mrn = $_POST['patient_mrn'] ?? '';
    $provider = $_POST['provider'] ?? '';
    $type     = $_POST['type'] ?? '';
    $status   = $_POST['status'] ?? 'Pending';
    $notes    = $_POST['notes'] ?? '';

    $errors = [];
    if (empty($date)) $errors[] = "Date is required";
    if (empty($time)) $errors[] = "Time is required";
    if (empty($patient_mrn)) $errors[] = "Patient is required";
    
    if (empty($errors)) {
        if($id){
            $stmt = $conn->prepare("UPDATE appointments SET date=?, time=?, patient_mrn=?, provider=?, type=?, status=?, notes=? WHERE id=?");
            $stmt->bind_param("ssissssi", $date, $time, $patient_mrn, $provider, $type, $status, $notes, $id);
        } else {
            $stmt = $conn->prepare("INSERT INTO appointments (date, time, patient_mrn, provider, type, status, notes) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param("ssissss", $date, $time, $patient_mrn, $provider, $type, $status, $notes);
        }
        
        if ($stmt->execute()) {
            $success = true;
            $appointmentId = $id ?: $stmt->insert_id;

            if (!$id) {
                $patientStmt = $conn->prepare("SELECT first_name, last_name, email FROM patients WHERE mrn = ? LIMIT 1");
                $patientStmt->bind_param('i', $patient_mrn);
                $patientStmt->execute();
                $patient = $patientStmt->get_result()->fetch_assoc();
                $patientStmt->close();

                if ($patient && !empty($patient['email'])) {
                    $patientName = trim($patient['first_name'] . ' ' . $patient['last_name']);
                    $dateText = date('F j, Y', strtotime($date));
                    $timeText = date('g:i A', strtotime($time));
                    $providerText = $provider ? '<br>Provider: ' . htmlspecialchars($provider, ENT_QUOTES, 'UTF-8') : '';
                    $email = sendBrevoEmail(
                        $patient['email'],
                        $patientName,
                        'Appointment scheduled - ' . $dateText,
                        buildAppointmentEmailHtml($patientName, $date, $time, $type, $provider, $notes)
                    );

                    if ($email['success']) {
                        $log = $conn->prepare("INSERT INTO appointment_email_log (appointment_id, email_type, recipient_email, sent_at) VALUES (?, 'confirmation', ?, NOW())");
                        $log->bind_param('is', $appointmentId, $patient['email']);
                        $log->execute();
                        $log->close();
                    }
                }
            }
        } else {
            $errors[] = "Database error: " . $stmt->error;
        }
        $stmt->close();
    }

    if(isset($_POST['ajax']) && $_POST['ajax']==1){
        if (empty($errors)) {
            echo json_encode(['success'=>true]);
        } else {
            echo json_encode(['success'=>false, 'errors'=>$errors]);
        }
        exit;
    }
}

// Return JSON API with patient info
if(isset($_GET['api']) && $_GET['api']==1){
    $search = trim($_GET['search'] ?? '');
    $searchPattern = '%' . $search . '%';
    $filterDate = trim($_GET['date'] ?? '');
    $page = max(1, (int)($_GET['page'] ?? 1));
    $pageSize = 10;
    $where = "(? = '' OR p.first_name LIKE ? OR p.last_name LIKE ? OR CONCAT(p.first_name, ' ', p.last_name) LIKE ? OR CONCAT(p.last_name, ', ', p.first_name) LIKE ? OR CAST(p.mrn AS CHAR) LIKE ? OR a.provider LIKE ? OR a.type LIKE ? OR a.status LIKE ?) AND (? = '' OR a.date = ?)";

    if (!empty($_GET['all'])) {
        $result = $conn->query("
            SELECT a.id, a.date, a.time, a.provider, a.type, a.status, a.notes,
                   p.first_name, p.last_name, p.mrn as patient_mrn
            FROM appointments a
            JOIN patients p ON a.patient_mrn = p.mrn
            ORDER BY a.date DESC, a.time DESC
        ");
        if (!$result) {
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Unable to load appointments']);
            exit;
        }
        $appointments = $result->fetch_all(MYSQLI_ASSOC);
        header('Content-Type: application/json');
        echo json_encode($appointments);
        exit;
    }

    $countStmt = $conn->prepare("SELECT COUNT(*) AS total FROM appointments a JOIN patients p ON a.patient_mrn = p.mrn WHERE $where");
    $countStmt->bind_param('sssssssssss', $search, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $filterDate, $filterDate);
    $countStmt->execute();
    $total = (int)$countStmt->get_result()->fetch_assoc()['total'];
    $countStmt->close();
    $totalPages = max(1, (int)ceil($total / $pageSize));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $pageSize;

    $stmt = $conn->prepare("
        SELECT a.id, a.date, a.time, a.provider, a.type, a.status, a.notes,
               p.first_name, p.last_name, p.mrn as patient_mrn
        FROM appointments a
        JOIN patients p ON a.patient_mrn = p.mrn
        WHERE $where
        ORDER BY a.date DESC, a.time DESC, a.id DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->bind_param('sssssssssssii', $search, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $searchPattern, $filterDate, $filterDate, $pageSize, $offset);
    if (!$stmt->execute()) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Unable to load appointments']);
        exit;
    }
    $appointments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    header('Content-Type: application/json');
    echo json_encode(['appointments' => $appointments, 'total' => $total, 'page' => $page, 'total_pages' => $totalPages]);
    exit;
}

// Delete appointment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $id = (int)$_POST['delete_id'];
    $conn->query("DELETE FROM appointments WHERE id=$id");
    echo json_encode(['success'=>true]);
    exit;
}

function formatMRN($mrn) {
    return str_pad($mrn, 6, '0', STR_PAD_LEFT);
}

function formatTime($time) {
    if (!$time) return '—';
    return date('g:i A', strtotime($time));
}

function formatDate($date) {
    if (!$date) return '—';
    return date('M d, Y', strtotime($date));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheduled Patients | 4ID Station Hospital</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes modalFadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        
        /* Sidebar */
        #sidebar::-webkit-scrollbar {
            width: 4px;
        }
        #sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        #sidebar::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 2px;
        }
        .dark #sidebar::-webkit-scrollbar-thumb {
            background: #475569;
        }
        .main-content {
            transition: margin-left 0.3s ease;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        
        /* Theme toggle switch */
        .theme-switch {
            position: relative;
            width: 48px;
            height: 26px;
            background: #e2e8f0;
            border-radius: 13px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(22px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 11px; }
        
        /* Modal styles */
        .modal-backdrop {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(4px);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            padding: 16px;
        }
        .modal-backdrop.show { display: flex; }
        .modal {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 20px;
            width: 100%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalFadeIn 0.2s ease;
        }
        .dark .modal {
            background: #1f2937;
            border-color: rgba(255,255,255,0.08);
        }
        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .dark .modal-header { border-bottom-color: rgba(255,255,255,0.06); }
        .modal-header h3 {
            font-size: 1.1rem;
            font-weight: 700;
            color: #1f2937;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .dark .modal-header h3 { color: #f1f5f9; }
        .modal-header h3 i { color: #0284c7; }
        .dark .modal-header h3 i { color: #38bdf8; }
        .modal-close {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            border: 1px solid #e5e7eb;
            background: transparent;
            color: #6b7280;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }
        .dark .modal-close { border-color: rgba(255,255,255,0.06); color: #9ca3af; }
        .modal-close:hover { background: #f3f4f6; }
        .dark .modal-close:hover { background: rgba(255,255,255,0.04); }
        .modal-body { padding: 24px; }
        .modal-actions {
            display: flex;
            gap: 12px;
            padding: 16px 24px 24px;
            border-top: 1px solid #e5e7eb;
        }
        .dark .modal-actions { border-top-color: rgba(255,255,255,0.06); }
        
        /* Form elements in modal */
        .form-group { margin-bottom: 16px; }
        .form-group label {
            display: block;
            font-size: 0.7rem;
            font-weight: 700;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }
        .dark .form-group label { color: #9ca3af; }
        .form-group label i { color: #9ca3af; margin-right: 4px; }
        .dark .form-group label i { color: #6b7280; }
        .form-group label .required { color: #ef4444; margin-left: 2px; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            background: #f8fafc;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            color: #1f2937;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s ease;
            outline: none;
        }
        .dark .form-group input, .dark .form-group select, .dark .form-group textarea {
            background: #111827;
            border-color: rgba(255,255,255,0.06);
            color: #f1f5f9;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: #0284c7;
            box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.08);
        }
        .dark .form-group input:focus, .dark .form-group select:focus, .dark .form-group textarea:focus {
            border-color: #38bdf8;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        .form-group select option {
            background: #ffffff;
            color: #1f2937;
        }
        .dark .form-group select option {
            background: #1f2937;
            color: #f1f5f9;
        }
        .form-group .help-text {
            font-size: 0.6rem;
            color: #6b7280;
            margin-top: 4px;
        }
        .dark .form-group .help-text { color: #9ca3af; }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }
        @media (max-width: 640px) { .form-row { grid-template-columns: 1fr; } }
        
        /* Toast */
        .toast {
            position: fixed;
            bottom: 24px;
            right: 24px;
            padding: 12px 20px;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 500;
            z-index: 3000;
            display: none;
            box-shadow: 0 8px 30px rgba(0,0,0,0.3);
            animation: fadeIn 0.3s ease;
        }
        .toast.success {
            background: #065f46;
            color: #6ee7b7;
            border: 1px solid rgba(6, 95, 70, 0.3);
        }
        .toast.error {
            background: #7f1d1d;
            color: #fca5a5;
            border: 1px solid rgba(127, 29, 29, 0.3);
        }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- SIDEBAR -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span>
                    <span>E</span>
                    <span>S</span>
                    <span>H</span>
                </div>

                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="index.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-gauge-high text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="medical_history.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-notes-medical text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Medical History</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_documents.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-file-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Documents</span>
                        </a>
                    </li>
                    <li>
                        <a href="scheduled_patient.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-calendar-check text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Scheduled Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_frontdesk.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-ticket text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue System</span>
                        </a>
                    </li>
                    <?php if (($current_user['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="admin/users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-shield text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i></div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                
                <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
                    <a href="logout.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                        <div class="w-6 h-6 flex items-center justify-center shrink-0">
                            <i class="fas fa-sign-out-alt text-base text-rose-400 group-hover/link:text-rose-500 transition-colors"></i>
                        </div>
                        <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
                    </a>
                </div>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 main-content">
        
        <!-- Header -->
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">Scheduled Patients</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">View and manage patient appointments</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($current_user['full_name']); ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400 font-medium"><?php echo ucfirst($current_user['role']); ?></div>
                </div>
                
                <!-- Dark Mode Toggle Switch -->
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-sun"></i></span>
                    <div class="theme-switch" id="themeToggle">
                        <div class="slider">
                            <span class="sun"><i class="fas fa-sun"></i></span>
                            <span class="moon"><i class="fas fa-moon"></i></span>
                        </div>
                    </div>
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-moon"></i></span>
                </div>

                <div class="w-10 h-10 rounded-full bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 flex items-center justify-center">
                    <i class="fas fa-user text-slate-400 dark:text-slate-500 text-sm"></i>
                </div>
            </div>
        </header>
        
        <!-- Appointments Panel -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <i class="fas fa-list-ul text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200">Appointment Schedule</span>
                </div>
                <div class="flex flex-wrap items-center gap-3">
                    <button id="addAppointmentBtn" class="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-2">
                        <i class="fas fa-plus"></i> Add Appointment
                    </button>
                    <div class="flex items-center gap-2 bg-white dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-full px-3 py-1.5">
                        <i class="fas fa-search text-slate-400 dark:text-slate-500 text-sm"></i>
                        <input type="search" id="searchInput" aria-label="Search scheduled patients" placeholder="Search name or MRN..." class="bg-transparent border-none outline-none text-sm text-slate-700 dark:text-slate-200 w-40 md:w-52">
                    </div>
                    <input type="date" id="filterDate" class="px-3 py-1.5 bg-white dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/50">
                    <button id="filterBtn" class="px-3 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-sm font-medium rounded-xl transition-colors">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                    <button id="clearBtn" class="px-3 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-sm font-medium rounded-xl transition-colors">
                        <i class="fas fa-times"></i> Clear
                    </button>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse min-w-[900px]">
                    <thead>
                        <tr class="bg-slate-50/50 dark:bg-slate-800/40 text-left border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.65rem] uppercase tracking-wider font-bold">
                            <th class="px-5 py-3.5">Date</th>
                            <th class="px-5 py-3.5">Time</th>
                            <th class="px-5 py-3.5">Patient Name</th>
                            <th class="px-5 py-3.5">MRN</th>
                            <th class="px-5 py-3.5">Provider</th>
                            <th class="px-5 py-3.5">Type</th>
                            <th class="px-5 py-3.5">Status</th>
                            <th class="px-5 py-3.5">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-300/80 dark:divide-slate-700/50 text-xs md:text-sm text-slate-700 dark:text-slate-200" id="scheduleList">
                        <tr>
                            <td colspan="8" class="text-center py-12 text-slate-400 dark:text-slate-400">
                                <i class="fas fa-spinner fa-pulse text-2xl mb-2 block text-slate-300 dark:text-slate-600"></i> Loading appointments...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div id="appointmentPagination" class="px-6 py-4 border-t border-slate-200 dark:border-slate-700/70 flex flex-wrap items-center justify-between gap-3"></div>
        </div>
    </main>

    <!-- Modal -->
    <div id="scheduleModal" class="modal-backdrop">
        <div class="modal">
            <div class="modal-header">
                <h3 id="modalTitle"><i class="fas fa-calendar-plus"></i> Schedule Appointment</h3>
                <button class="modal-close" id="closeModal">&times;</button>
            </div>
            <form id="scheduleForm">
                <div class="modal-body">
                    <input type="hidden" name="id" id="aptId">
                    <input type="hidden" name="action" value="save">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-calendar-alt"></i> Date <span class="required">*</span></label>
                            <input type="date" name="date" id="aptDate" required>
                            <div class="help-text">Select appointment date</div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-clock"></i> Time <span class="required">*</span></label>
                            <input type="time" name="time" id="aptTime" required>
                            <div class="help-text">Select appointment time</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Patient <span class="required">*</span></label>
                        <input type="search" id="aptPatientSearch" autocomplete="off" aria-label="Search patients by name or MRN" placeholder="Search by name or MRN..." class="w-full mb-2 px-4 py-2.5 border border-slate-300 dark:border-slate-600 rounded-xl bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/50">
                        <select name="patient_mrn" id="aptPatient" required>
                            <option value="">-- Select Patient --</option>
                            <?php foreach($patients as $p): ?>
                                <option value="<?= (int)$p['mrn'] ?>" data-search="<?= htmlspecialchars($p['last_name'] . ', ' . $p['first_name'] . ' ' . formatMRN($p['mrn']), ENT_QUOTES, 'UTF-8') ?>">
                                    <?= htmlspecialchars($p['last_name']) ?>, <?= htmlspecialchars($p['first_name']) ?> (MRN: <?= formatMRN($p['mrn']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p id="aptPatientNoResults" class="help-text" role="status" hidden>No patients match your search.</p>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-user-md"></i> Provider</label>
                            <select name="provider" id="aptProvider">
                                <option value="">-- Select Provider --</option>
                                <?php foreach($doctors as $doc): ?>
                                    <option value="<?= htmlspecialchars($doc['full_name']) ?>">
                                        Dr. <?= htmlspecialchars($doc['full_name']) ?> (<?= $doc['assigned_department'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="help-text">Optional: Assign a specific doctor</div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Type</label>
                            <select name="type" id="aptType">
                                <option value="">-- Select Type --</option>
                                <option value="Initial Consultation">Initial Consultation</option>
                                <option value="Follow-up">Follow-up</option>
                                <option value="Check-up">Check-up</option>
                                <option value="Vaccination">Vaccination</option>
                                <option value="Laboratory">Laboratory</option>
                                <option value="Physical Exam">Physical Exam</option>
                            </select>
                            <div class="help-text">Type of appointment</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-flag-checkered"></i> Status</label>
                        <select name="status" id="aptStatus">
                            <option value="Pending">Pending</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="Completed">Completed</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-sticky-note"></i> Notes</label>
                        <textarea name="notes" id="aptNotes" rows="2" placeholder="Additional notes..."></textarea>
                        <div class="help-text">Optional: Add special instructions or notes</div>
                    </div>
                </div>
                <div class="modal-actions">
                    <button type="button" id="deleteAppointmentBtn" class="px-4 py-2 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-sm font-bold rounded-xl transition-colors mr-auto flex items-center gap-2" style="display: none;">
                        <i class="fas fa-trash-alt"></i> Delete
                    </button>
                    <button type="button" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-sm font-bold rounded-xl transition-colors" id="cancelSchedule">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-2" id="saveBtn">
                        <i class="fas fa-save"></i> Save Appointment
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Toast -->
    <div id="toast" class="toast"></div>

    <script>
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            localStorage.setItem('theme', htmlElement.classList.contains('dark') ? 'dark' : 'light');
        });
        
        // ============================================
        // Mobile Menu
        // ============================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        });

        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('mobileMenuBtn');
            if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
        
        // ============================================
        // DOM Elements
        // ============================================
        const modal = document.getElementById('scheduleModal');
        const modalTitle = document.getElementById('modalTitle');
        const form = document.getElementById('scheduleForm');
        const addBtn = document.getElementById('addAppointmentBtn');
        const closeBtn = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelSchedule');
        const saveBtn = document.getElementById('saveBtn');
        const deleteBtn = document.getElementById('deleteAppointmentBtn');
        const toast = document.getElementById('toast');
        
        const aptId = document.getElementById('aptId');
        const aptDate = document.getElementById('aptDate');
        const aptTime = document.getElementById('aptTime');
        const aptPatient = document.getElementById('aptPatient');
        const aptPatientSearch = document.getElementById('aptPatientSearch');
        const aptPatientNoResults = document.getElementById('aptPatientNoResults');
        const aptProvider = document.getElementById('aptProvider');
        const aptType = document.getElementById('aptType');
        const aptStatus = document.getElementById('aptStatus');
        const aptNotes = document.getElementById('aptNotes');
        
        let currentEditId = null;
        
        // ============================================
        // Toast
        // ============================================
        function showToast(message, type = 'success') {
            toast.textContent = message;
            toast.className = `toast ${type}`;
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 3000);
        }
        
        // ============================================
        // Helper Functions
        // ============================================
        function getTodayString() {
            const d = new Date();
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${d.getFullYear()}-${month}-${day}`;
        }
        
        function formatDate(dateStr) {
            if (!dateStr) return '—';
            const date = new Date(dateStr);
            return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        }
        
        function formatTime(timeStr) {
            if (!timeStr) return '—';
            const [h, m] = timeStr.split(':');
            let hour = parseInt(h);
            const ampm = hour >= 12 ? 'PM' : 'AM';
            hour = hour % 12 || 12;
            return `${hour}:${m} ${ampm}`;
        }
        
        function formatMRN(mrn) {
            if (!mrn) return '—';
            return String(mrn).padStart(6, '0');
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function getStatusClass(status) {
            switch(status) {
                case 'Confirmed': return 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-400/20';
                case 'Completed': return 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-300 dark:border-sky-400/20';
                case 'Cancelled': return 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-300 dark:border-rose-400/20';
                default: return 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-300 dark:border-amber-400/20';
            }
        }
        
        // ============================================
        // Modal Controls
        // ============================================
        function openModal(data = null) {
            modal.classList.add('show');
            aptDate.min = getTodayString();
            aptPatientSearch.value = '';
            filterAppointmentPatients('');
            
            if (data) {
                currentEditId = data.id;
                modalTitle.innerHTML = '<i class="fas fa-edit"></i> Edit Appointment';
                aptId.value = data.id;
                aptDate.value = data.date;
                aptTime.value = data.time;
                aptProvider.value = data.provider || '';
                aptType.querySelectorAll('option[data-legacy-type="true"]').forEach(option => option.remove());
                if (data.type && !Array.from(aptType.options).some(option => option.value === data.type)) {
                    const legacyType = new Option(`${data.type} (existing)`, data.type);
                    legacyType.dataset.legacyType = 'true';
                    aptType.add(legacyType);
                }
                aptType.value = data.type || '';
                aptStatus.value = data.status || 'Pending';
                aptNotes.value = data.notes || '';
                deleteBtn.style.display = 'flex';
                
                const patientSelect = aptPatient;
                for (let i = 0; i < patientSelect.options.length; i++) {
                    if (patientSelect.options[i].value == data.patient_mrn) {
                        patientSelect.selectedIndex = i;
                        break;
                    }
                }
            } else {
                currentEditId = null;
                modalTitle.innerHTML = '<i class="fas fa-calendar-plus"></i> Schedule Appointment';
                aptType.querySelectorAll('option[data-legacy-type="true"]').forEach(option => option.remove());
                form.reset();
                aptId.value = '';
                aptDate.value = getTodayString();
                aptStatus.value = 'Pending';
                aptNotes.value = '';
                deleteBtn.style.display = 'none';
            }
        }
        
        function closeModalFunc() {
            modal.classList.remove('show');
            form.reset();
            filterAppointmentPatients('');
            currentEditId = null;
        }

        function filterAppointmentPatients(query) {
            const normalizedQuery = query.trim().toLocaleLowerCase();
            let visiblePatients = 0;
            Array.from(aptPatient.options).slice(1).forEach(option => {
                const matches = option.dataset.search.toLocaleLowerCase().includes(normalizedQuery);
                option.hidden = !matches;
                if (matches) visiblePatients++;
            });
            aptPatientNoResults.hidden = normalizedQuery === '' || visiblePatients > 0;
        }

        aptPatientSearch.addEventListener('input', () => {
            aptPatient.value = '';
            filterAppointmentPatients(aptPatientSearch.value);
        });
        
        addBtn.addEventListener('click', () => openModal());
        closeBtn.addEventListener('click', closeModalFunc);
        cancelBtn.addEventListener('click', closeModalFunc);
        
        window.addEventListener('click', (e) => {
            if (e.target === modal) closeModalFunc();
        });
        
        // ============================================
        // Delete Appointment
        // ============================================
        deleteBtn.addEventListener('click', async () => {
            if (currentEditId && confirm('Delete this appointment permanently?')) {
                const formData = new FormData();
                formData.append('delete_id', currentEditId);
                
                try {
                    const res = await fetch('scheduled_patient.php', { method: 'POST', body: formData });
                    const data = await res.json();
                    if (data.success) {
                        showToast('Appointment deleted successfully');
                        closeModalFunc();
                        loadAppointments();
                    } else {
                        showToast('Error deleting appointment.', 'error');
                    }
                } catch (error) {
                    showToast('Network error. Please try again.', 'error');
                }
            }
        });
        
        // ============================================
        // Load Appointments
        // ============================================
        let appointmentPage = 1;

        async function loadAppointments(page = appointmentPage) {
            try {
                const params = new URLSearchParams({
                    api: '1',
                    page: String(page),
                    search: searchInput ? searchInput.value.trim() : '',
                    date: dateFilter ? dateFilter.value : ''
                });
                const res = await fetch(`scheduled_patient.php?${params.toString()}`);
                if (!res.ok) {
                    throw new Error(`Unable to load appointments (HTTP ${res.status})`);
                }
                const result = await res.json();
                if (result.success === false) {
                    throw new Error(result.error || 'Unable to load appointments');
                }
                const tbody = document.getElementById('scheduleList');
                const data = result.appointments;
                appointmentPage = result.page;
                
                if (!data || data.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="8" class="text-center py-12 text-slate-400 dark:text-slate-400">
                        <i class="fas fa-calendar-times text-2xl mb-2 block text-slate-300 dark:text-slate-600"></i>
                        ${searchInput?.value || dateFilter?.value ? 'No appointments match these filters' : 'No appointments found'}
                        <p class="text-xs text-slate-400 dark:text-slate-500 mt-1">Click "Add Appointment" to create a new schedule</p>
                    </td></tr>`;
                    renderAppointmentPagination(result);
                    return;
                }
                
                tbody.innerHTML = data.map(a => `
                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors duration-150" 
                        data-id="${a.id}" data-date="${a.date}" data-time="${a.time}" 
                        data-patient="${escapeHtml(a.first_name)} ${escapeHtml(a.last_name)}" 
                        data-mrn="${a.patient_mrn}" data-provider="${escapeHtml(a.provider || '')}" 
                        data-type="${escapeHtml(a.type || '')}" data-status="${a.status}" 
                        data-notes="${escapeHtml(a.notes || '')}">
                        <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400 text-sm">${formatDate(a.date)}</td>
                        <td class="px-5 py-3.5"><span class="font-semibold text-slate-800 dark:text-slate-100">${formatTime(a.time)}</span></td>
                        <td class="px-5 py-3.5 font-medium text-slate-800 dark:text-slate-100">${escapeHtml(a.last_name)}, ${escapeHtml(a.first_name)}</td>
                        <td class="px-5 py-3.5"><span class="font-mono text-xs bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded-md text-slate-500 dark:text-slate-400">${formatMRN(a.patient_mrn)}</span></td>
                        <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400">${escapeHtml(a.provider) || '—'}</td>
                        <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400">${escapeHtml(a.type) || '—'}</td>
                        <td class="px-5 py-3.5"><span class="inline-block px-3 py-1 rounded-full text-[0.65rem] font-bold tracking-wide uppercase ${getStatusClass(a.status)}">${a.status}</span></td>
                        <td class="px-5 py-3.5">
                            <button class="px-3 py-1.5 bg-amber-50 dark:bg-amber-500/10 hover:bg-amber-100 dark:hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 text-xs font-bold rounded-lg transition-colors editBtn">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="px-3 py-1.5 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-bold rounded-lg transition-colors deleteBtn">
                                <i class="fas fa-trash-alt"></i> Delete
                            </button>
                        </td>
                    </tr>
                `).join('');
                
                attachEditButtons();
                attachDeleteButtons();
                renderAppointmentPagination(result);
            } catch (error) {
                console.error('Error loading appointments:', error);
                document.getElementById('scheduleList').innerHTML = `<tr><td colspan="8" class="text-center py-12 text-slate-400 dark:text-slate-400">
                    <i class="fas fa-triangle-exclamation text-2xl mb-2 block text-rose-500"></i>
                    Error loading appointments
                </td></tr>`;
            }
        }

        function renderAppointmentPagination(result) {
            const container = document.getElementById('appointmentPagination');
            const first = result.total === 0 ? 0 : (result.page - 1) * 10 + 1;
            const last = Math.min(result.page * 10, result.total);
            container.innerHTML = `
                <span class="text-xs text-slate-500 dark:text-slate-400">Showing ${first}–${last} of ${Number(result.total).toLocaleString()}</span>
                <nav class="flex items-center gap-2" aria-label="Appointment pagination">
                    ${result.page > 1 ? '<button type="button" data-page="' + (result.page - 1) + '" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Previous</button>' : ''}
                    <span class="text-xs font-semibold text-slate-600 dark:text-slate-300">Page ${result.page} of ${result.total_pages}</span>
                    ${result.page < result.total_pages ? '<button type="button" data-page="' + (result.page + 1) + '" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Next</button>' : ''}
                </nav>`;
            container.querySelectorAll('button[data-page]').forEach(button => {
                button.addEventListener('click', () => loadAppointments(Number(button.dataset.page)));
            });
        }
        
        // ============================================
        // Edit & Delete Button Handlers
        // ============================================
        function attachEditButtons() {
            document.querySelectorAll('.editBtn').forEach(btn => {
                btn.removeEventListener('click', handleEdit);
                btn.addEventListener('click', handleEdit);
            });
        }
        
        function handleEdit(e) {
            const tr = e.currentTarget.closest('tr');
            openModal({
                id: tr.dataset.id,
                date: tr.dataset.date,
                time: tr.dataset.time,
                patient_mrn: tr.dataset.mrn,
                patient_name: tr.dataset.patient,
                provider: tr.dataset.provider,
                type: tr.dataset.type,
                status: tr.dataset.status,
                notes: tr.dataset.notes
            });
        }
        
        function attachDeleteButtons() {
            document.querySelectorAll('.deleteBtn').forEach(btn => {
                btn.removeEventListener('click', handleDelete);
                btn.addEventListener('click', handleDelete);
            });
        }
        
        async function handleDelete(e) {
            const tr = e.currentTarget.closest('tr');
            const patientName = tr.dataset.patient;
            const date = formatDate(tr.dataset.date);
            const time = formatTime(tr.dataset.time);
            
            if (confirm(`Delete appointment for ${patientName} on ${date} at ${time}?`)) {
                const id = tr.dataset.id;
                const formData = new FormData();
                formData.append('delete_id', id);
                
                try {
                    const res = await fetch('scheduled_patient.php', { method: 'POST', body: formData });
                    const data = await res.json();
                    if (data.success) {
                        showToast('Appointment deleted successfully');
                        loadAppointments();
                    } else {
                        showToast('Error deleting appointment.', 'error');
                    }
                } catch (error) {
                    showToast('Network error. Please try again.', 'error');
                }
            }
        }
        
        // ============================================
        // Form Submit
        // ============================================
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(form);
            formData.set('ajax', '1');
            
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            
            try {
                const res = await fetch('scheduled_patient.php', { method: 'POST', body: formData });
                const data = await res.json();
                if (data.success) {
                    showToast(currentEditId ? 'Appointment updated successfully' : 'Appointment saved successfully');
                    closeModalFunc();
                    loadAppointments();
                } else {
                    if (data.errors && data.errors.length > 0) {
                        showToast(data.errors.join(', '), 'error');
                    } else {
                        showToast('Error saving appointment.', 'error');
                    }
                }
            } catch (error) {
                showToast('Network error. Please try again.', 'error');
            } finally {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Appointment';
            }
        });
        
        // ============================================
        // Filter Functions
        // ============================================
        const filterBtn = document.getElementById('filterBtn');
        const clearBtn = document.getElementById('clearBtn');
        const searchInput = document.getElementById('searchInput');
        const dateFilter = document.getElementById('filterDate');
        
        filterBtn.addEventListener('click', () => loadAppointments(1));
        
        clearBtn.addEventListener('click', () => {
            if (searchInput) searchInput.value = '';
            if (dateFilter) dateFilter.value = '';
            loadAppointments(1);
            showToast('Filters cleared');
        });
        
        let searchDebounce;
        searchInput.addEventListener('input', () => {
            clearTimeout(searchDebounce);
            searchDebounce = setTimeout(() => loadAppointments(1), 300);
        });
        dateFilter.addEventListener('change', () => loadAppointments(1));
        
        // ============================================
        // Initialize
        // ============================================
        loadAppointments();
    </script>
</body>
</html>