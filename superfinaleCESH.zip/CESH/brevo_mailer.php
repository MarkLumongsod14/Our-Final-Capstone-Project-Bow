<?php

require_once __DIR__ . '/brevo_config.php';

function brevoSmtpRead($connection) {
    $response = '';
    while (($line = fgets($connection, 515)) !== false) {
        $response .= $line;
        if (strlen($line) >= 4 && $line[3] === ' ') break;
    }
    return $response;
}

function brevoSmtpCommand($connection, $command, $expectedCodes) {
    if ($command !== '') fwrite($connection, $command . "\r\n");
    $response = brevoSmtpRead($connection);
    $code = (int)substr($response, 0, 3);
    if (!in_array($code, $expectedCodes, true)) {
        throw new RuntimeException('SMTP server returned HTTP-like code ' . $code . '.');
    }
    return $response;
}

function buildAppointmentEmailHtml($recipientName, $date, $time, $type, $provider, $notes, $isReminder = false) {
    $safeName = htmlspecialchars($recipientName, ENT_QUOTES, 'UTF-8');
    $safeDate = htmlspecialchars(date('F j, Y', strtotime($date)), ENT_QUOTES, 'UTF-8');
    $safeTime = htmlspecialchars(date('g:i A', strtotime($time)), ENT_QUOTES, 'UTF-8');
    $safeType = htmlspecialchars($type ?: 'Appointment', ENT_QUOTES, 'UTF-8');
    $safeProvider = htmlspecialchars($provider ?: 'To be assigned', ENT_QUOTES, 'UTF-8');
    $safeNotes = nl2br(htmlspecialchars(trim($notes), ENT_QUOTES, 'UTF-8'));
    $heading = $isReminder ? 'Appointment reminder' : 'Appointment confirmed';
    $intro = $isReminder
        ? 'This is a friendly reminder about your upcoming appointment.'
        : 'Your appointment has been successfully scheduled.';
    $notesBlock = trim($notes) !== ''
        ? '<tr><td style="padding:16px 0 0;"><div style="background:#f0f7ff;border-left:4px solid #1677b8;padding:14px 16px;color:#334155;font-size:14px;line-height:1.6;"><strong style="color:#0f4c75;">Notes from the hospital</strong><br>' . $safeNotes . '</div></td></tr>'
        : '';

    return '<!doctype html><html><body style="margin:0;background:#f4f7fa;font-family:Arial,Helvetica,sans-serif;color:#243447;">'
        . '<div style="max-width:620px;margin:28px auto;background:#ffffff;border:1px solid #dbe4ec;">'
        . '<div style="background:#0f4c75;padding:24px 30px;color:#ffffff;"><div style="font-size:12px;letter-spacing:1.5px;text-transform:uppercase;opacity:.85;">Camp Evangelista Station Hospital</div><div style="font-size:25px;font-weight:bold;margin-top:8px;">' . $heading . '</div></div>'
        . '<div style="padding:28px 30px;"><p style="font-size:16px;margin:0 0 12px;">Dear ' . $safeName . ',</p><p style="font-size:15px;line-height:1.7;margin:0;">' . $intro . '</p>'
        . '<table role="presentation" style="width:100%;border-collapse:collapse;margin-top:22px;border:1px solid #dbe4ec;"><tr><td style="padding:12px 16px;background:#eef5f9;color:#0f4c75;font-size:13px;font-weight:bold;">APPOINTMENT DETAILS</td></tr><tr><td style="padding:16px;"><table role="presentation" style="width:100%;border-collapse:collapse;font-size:14px;line-height:2;"><tr><td style="color:#64748b;width:38%;">Date</td><td style="font-weight:bold;">' . $safeDate . '</td></tr><tr><td style="color:#64748b;">Time</td><td style="font-weight:bold;">' . $safeTime . '</td></tr><tr><td style="color:#64748b;">Visit type</td><td>' . $safeType . '</td></tr><tr><td style="color:#64748b;">Provider</td><td>' . $safeProvider . '</td></tr></table></td></tr></table>'
        . $notesBlock
        . '<p style="font-size:14px;line-height:1.7;margin:24px 0 0;">Please arrive a little early and bring your hospital or patient identification.</p><p style="font-size:14px;line-height:1.7;margin:20px 0 0;">Thank you,<br><strong>4ID Station Hospital</strong></p></div>'
        . '<div style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:16px 30px;color:#64748b;font-size:12px;line-height:1.5;">This is an automated message. Please contact the hospital directly if you need to change your appointment.</div></div></body></html>';
}

function sendBrevoEmail($recipientEmail, $recipientName, $subject, $htmlContent) {
    if (!BREVO_SERVER || !BREVO_USERNAME || !BREVO_PASSWORD || !BREVO_FROM_EMAIL || !filter_var($recipientEmail, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'error' => 'Brevo SMTP configuration or recipient email is missing.'];
    }

    $connection = @stream_socket_client('tcp://' . BREVO_SERVER . ':' . BREVO_PORT, $errorNumber, $errorMessage, 15);
    if (!$connection) {
        return ['success' => false, 'error' => 'Could not connect to Brevo SMTP: ' . $errorMessage];
    }

    stream_set_timeout($connection, 15);
    $safeSubject = preg_replace('/[\r\n]+/', ' ', $subject);
    $safeRecipientName = preg_replace('/[\r\n]+/', ' ', $recipientName);
    $safeFromName = preg_replace('/[\r\n]+/', ' ', BREVO_FROM_NAME);
    $message = "From: " . $safeFromName . " <" . BREVO_FROM_EMAIL . ">\r\n"
        . "To: " . $safeRecipientName . " <" . $recipientEmail . ">\r\n"
        . "Subject: " . $safeSubject . "\r\n"
        . "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: 8bit\r\n\r\n" . $htmlContent;

    try {
        brevoSmtpCommand($connection, '', [220]);
        brevoSmtpCommand($connection, 'EHLO localhost', [250]);
        brevoSmtpCommand($connection, 'STARTTLS', [220]);
        if (!stream_socket_enable_crypto($connection, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            throw new RuntimeException('Could not enable TLS encryption.');
        }
        brevoSmtpCommand($connection, 'EHLO localhost', [250]);
        brevoSmtpCommand($connection, 'AUTH LOGIN', [334]);
        brevoSmtpCommand($connection, base64_encode(BREVO_USERNAME), [334]);
        brevoSmtpCommand($connection, base64_encode(BREVO_PASSWORD), [235]);
        brevoSmtpCommand($connection, 'MAIL FROM:<' . BREVO_FROM_EMAIL . '>', [250]);
        brevoSmtpCommand($connection, 'RCPT TO:<' . $recipientEmail . '>', [250, 251]);
        brevoSmtpCommand($connection, 'DATA', [354]);
        $message = preg_replace('/^\./m', '..', $message);
        fwrite($connection, $message . "\r\n.\r\n");
        brevoSmtpCommand($connection, '', [250]);
        brevoSmtpCommand($connection, 'QUIT', [221]);
        fclose($connection);
        return ['success' => true];
    } catch (Throwable $error) {
        fclose($connection);
        return ['success' => false, 'error' => 'Brevo SMTP failed: ' . $error->getMessage()];
    }
}
