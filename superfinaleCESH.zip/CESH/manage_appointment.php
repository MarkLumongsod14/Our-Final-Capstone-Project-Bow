<?php
// manage_appointment.php - Handle appointment CRUD operations with duplicate prevention
header('Content-Type: application/json');

require_once 'db.php';
require_once 'auth.php';
require_once 'brevo_mailer.php';

$auth->requireLogin();

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// GET appointments - including department and doctor info
if ($action === 'get') {
    $result = $conn->query("
        SELECT a.*, 
               CONCAT(p.first_name, ' ', p.last_name) as patient_name,
               p.mrn as patient_mrn,
               p.contact as patient_contact,
               u.full_name as doctor_name
        FROM appointments a 
        JOIN patients p ON a.patient_mrn = p.mrn 
        LEFT JOIN users u ON a.doctor_id = u.id
        ORDER BY a.date ASC, a.time ASC
    ");
    $appointments = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $appointments[] = $row;
        }
    }
    echo json_encode($appointments);
    exit;
}

// Function to check for duplicate appointments
function checkDuplicateAppointment($conn, $date, $time, $patient_mrn, $exclude_id = null) {
    // Check if the same patient already has an appointment on the same date and time
    $query = "SELECT id, status FROM appointments WHERE date = ? AND time = ? AND patient_mrn = ?";
    $params = [$date, $time, $patient_mrn];
    $types = "ssi";
    
    if ($exclude_id) {
        $query .= " AND id != ?";
        $params[] = $exclude_id;
        $types .= "i";
    }
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $existing = $result->fetch_assoc();
        if ($existing['status'] === 'Completed') {
            return "This patient already had a completed appointment on this date and time. Please schedule a follow-up on a different date/time.";
        }
        return "This patient already has an appointment scheduled on this date and time.";
    }
    $stmt->close();
    
    // Check for overlapping appointments for the same patient (within 1 hour)
    $time_obj = new DateTime($time);
    $time_plus_hour = clone $time_obj;
    $time_plus_hour->modify('+1 hour');
    $time_minus_hour = clone $time_obj;
    $time_minus_hour->modify('-1 hour');
    
    $overlap_query = "SELECT id, time, status FROM appointments WHERE date = ? AND patient_mrn = ? AND time BETWEEN ? AND ? AND status != 'Cancelled'";
    $overlap_params = [$date, $patient_mrn, $time_minus_hour->format('H:i:s'), $time_plus_hour->format('H:i:s')];
    $overlap_types = "siss";
    
    if ($exclude_id) {
        $overlap_query .= " AND id != ?";
        $overlap_params[] = $exclude_id;
        $overlap_types .= "i";
    }
    
    $stmt = $conn->prepare($overlap_query);
    $stmt->bind_param($overlap_types, ...$overlap_params);
    $stmt->execute();
    $overlap_result = $stmt->get_result();
    
    if ($overlap_result->num_rows > 0) {
        $overlap = $overlap_result->fetch_assoc();
        return "This patient already has an appointment scheduled at " . date('g:i A', strtotime($overlap['time'])) . " on this date. Please choose a different time (at least 1 hour apart).";
    }
    $stmt->close();
    
    return null;
}

// SAVE appointment (create or update)
if ($action === 'save') {
    $id = $_POST['id'] ?? '';
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $patient_mrn = $_POST['patient_mrn'] ?? '';
    $provider = $_POST['provider'] ?? '';
    $type = $_POST['type'] ?? '';
    $department = $_POST['department'] ?? 'General';
    $doctor_id = !empty($_POST['doctor_id']) ? $_POST['doctor_id'] : null;
    $status = $_POST['status'] ?? 'Pending';
    $contact = $_POST['contact'] ?? '';
    $notes = $_POST['notes'] ?? '';
    
    // Validate required fields
    if (empty($date) || empty($time) || empty($patient_mrn)) {
        echo json_encode(['success' => false, 'error' => 'Missing required fields: date, time, and patient are required']);
        exit;
    }
    
    // Validate date (cannot be in the past for new appointments unless completed)
    $today = date('Y-m-d');
    if ($date < $today && $status !== 'Completed' && empty($id)) {
        echo json_encode(['success' => false, 'error' => 'Cannot schedule appointments on past dates. Please select a future date.']);
        exit;
    }
    
    // Validate contact number format if provided
    if (!empty($contact)) {
        $contact_clean = preg_replace('/[^0-9]/', '', $contact);
        if (strlen($contact_clean) != 11) {
            echo json_encode(['success' => false, 'error' => 'Contact number must be exactly 11 digits']);
            exit;
        }
        if (!preg_match('/^09[0-9]{9}$/', $contact_clean)) {
            echo json_encode(['success' => false, 'error' => 'Contact number must start with 09 (e.g., 09123456789)']);
            exit;
        }
        $contact = $contact_clean;
    }
    
    // Check for duplicate appointments (skip for completed/cancelled status)
    if ($status !== 'Completed' && $status !== 'Cancelled') {
        $exclude_id = !empty($id) ? $id : null;
        $duplicate_error = checkDuplicateAppointment($conn, $date, $time, $patient_mrn, $exclude_id);
        
        if ($duplicate_error) {
            echo json_encode(['success' => false, 'error' => $duplicate_error]);
            exit;
        }
    }
    
    // Set completed_at if status is Completed
    $completed_at = null;
    if ($status === 'Completed') {
        $completed_at = date('Y-m-d H:i:s');
    }
    
    if (!empty($id)) {
        // Check if columns exist before updating
        $columns_check = $conn->query("SHOW COLUMNS FROM appointments LIKE 'department'");
        $has_department = ($columns_check && $columns_check->num_rows > 0);
        $columns_check2 = $conn->query("SHOW COLUMNS FROM appointments LIKE 'doctor_id'");
        $has_doctor_id = ($columns_check2 && $columns_check2->num_rows > 0);
        $columns_check3 = $conn->query("SHOW COLUMNS FROM appointments LIKE 'completed_at'");
        $has_completed_at = ($columns_check3 && $columns_check3->num_rows > 0);
        
        // Build update query dynamically based on existing columns
        $update_fields = "date = ?, time = ?, patient_mrn = ?, provider = ?, type = ?, status = ?, contact = ?, notes = ?";
        $params = [$date, $time, $patient_mrn, $provider, $type, $status, $contact, $notes];
        $types = "ssisssss";
        
        if ($has_department) {
            $update_fields .= ", department = ?";
            $params[] = $department;
            $types .= "s";
        }
        
        if ($has_doctor_id) {
            $update_fields .= ", doctor_id = ?";
            $params[] = $doctor_id;
            $types .= "i";
        }
        
        if ($has_completed_at && $completed_at) {
            $update_fields .= ", completed_at = ?";
            $params[] = $completed_at;
            $types .= "s";
        }
        
        $update_fields .= ", updated_at = NOW()";
        $params[] = $id;
        $types .= "i";
        
        $stmt = $conn->prepare("UPDATE appointments SET $update_fields WHERE id = ?");
        $stmt->bind_param($types, ...$params);
    } else {
        // Insert new appointment - check available columns
        $columns_check = $conn->query("SHOW COLUMNS FROM appointments LIKE 'department'");
        $has_department = ($columns_check && $columns_check->num_rows > 0);
        $columns_check2 = $conn->query("SHOW COLUMNS FROM appointments LIKE 'doctor_id'");
        $has_doctor_id = ($columns_check2 && $columns_check2->num_rows > 0);
        $columns_check3 = $conn->query("SHOW COLUMNS FROM appointments LIKE 'completed_at'");
        $has_completed_at = ($columns_check3 && $columns_check3->num_rows > 0);
        
        $insert_fields = "date, time, patient_mrn, provider, type, status, contact, notes, created_at";
        $placeholders = "?, ?, ?, ?, ?, ?, ?, ?, NOW()";
        $params = [$date, $time, $patient_mrn, $provider, $type, $status, $contact, $notes];
        $types = "ssisssss";
        
        if ($has_department) {
            $insert_fields .= ", department";
            $placeholders .= ", ?";
            $params[] = $department;
            $types .= "s";
        }
        
        if ($has_doctor_id) {
            $insert_fields .= ", doctor_id";
            $placeholders .= ", ?";
            $params[] = $doctor_id;
            $types .= "i";
        }
        
        if ($has_completed_at && $completed_at) {
            $insert_fields .= ", completed_at";
            $placeholders .= ", ?";
            $params[] = $completed_at;
            $types .= "s";
        }
        
        $stmt = $conn->prepare("INSERT INTO appointments ($insert_fields) VALUES ($placeholders)");
        $stmt->bind_param($types, ...$params);
    }
    
    $success = $stmt->execute();
    $error = $stmt->error;
    $appointmentId = $id ?: $stmt->insert_id;
    $stmt->close();
    
    if ($success) {
        if (empty($id)) {
            $patientStmt = $conn->prepare("SELECT first_name, last_name, email FROM patients WHERE mrn = ? LIMIT 1");
            $patientStmt->bind_param('i', $patient_mrn);
            $patientStmt->execute();
            $patient = $patientStmt->get_result()->fetch_assoc();
            $patientStmt->close();

            if ($patient && !empty($patient['email'])) {
                $patientName = trim($patient['first_name'] . ' ' . $patient['last_name']);
                $dateText = date('F j, Y', strtotime($date));
                $timeText = date('g:i A', strtotime($time));
                $providerText = $provider ? '<br>Provider: ' . htmlspecialchars($provider, ENT_QUOTES, 'UTF-8') : '';
                $email = sendBrevoEmail(
                    $patient['email'],
                    $patientName,
                    'Appointment scheduled - ' . $dateText,
                    buildAppointmentEmailHtml($patientName, $date, $time, $type, $provider, $notes)
                );

                if ($email['success']) {
                    $log = $conn->prepare("INSERT INTO appointment_email_log (appointment_id, email_type, recipient_email, sent_at) VALUES (?, 'confirmation', ?, NOW())");
                    $log->bind_param('is', $appointmentId, $patient['email']);
                    $log->execute();
                    $log->close();
                }
            }
        }
        if ($status === 'Completed') {
            echo json_encode(['success' => true, 'message' => 'Appointment marked as completed', 'completed' => true]);
        } else {
            echo json_encode(['success' => true, 'message' => 'Appointment saved successfully']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => $error]);
    }
    exit;
}

// DELETE appointment
if ($action === 'delete') {
    $id = $_POST['id'] ?? $_GET['id'] ?? '';
    
    if (empty($id)) {
        echo json_encode(['success' => false, 'error' => 'No ID provided']);
        exit;
    }
    
    $stmt = $conn->prepare("DELETE FROM appointments WHERE id = ?");
    $stmt->bind_param("i", $id);
    $success = $stmt->execute();
    $stmt->close();
    
    echo json_encode(['success' => $success]);
    exit;
}

// COMPLETE appointment (mark as done)
if ($action === 'complete') {
    $id = $_POST['id'] ?? '';
    
    if (empty($id)) {
        echo json_encode(['success' => false, 'error' => 'No ID provided']);
        exit;
    }
    
    // Check if completed_at column exists
    $col_check = $conn->query("SHOW COLUMNS FROM appointments LIKE 'completed_at'");
    $has_completed_at = ($col_check && $col_check->num_rows > 0);
    
    if ($has_completed_at) {
        $stmt = $conn->prepare("UPDATE appointments SET status = 'Completed', completed_at = NOW(), updated_at = NOW() WHERE id = ?");
    } else {
        $stmt = $conn->prepare("UPDATE appointments SET status = 'Completed', updated_at = NOW() WHERE id = ?");
    }
    $stmt->bind_param("i", $id);
    $success = $stmt->execute();
    $stmt->close();
    
    echo json_encode(['success' => $success]);
    exit;
}

// If no valid action
echo json_encode(['success' => false, 'error' => 'Invalid action: ' . $action]);
?>