<?php
session_start();
require_once __DIR__ . '/unified_auth.php';

$identityId = (int)($_SESSION['sso_identity_id'] ?? 0);
$system = (string)($_SESSION['sso_current_system'] ?? '');
if (
    $identityId <= 0
    || !in_array($system, ['outpatient', 'smart_queueing'], true)
    || empty($_SESSION['sso_contexts'][$system])
) {
    header('Location: unified_login.php');
    exit;
}

$auth = new UnifiedAuth();
if (!$auth->isSystemAdmin($identityId, $system)) {
    http_response_code(403);
    exit('Administrator access is required to manage linked application accounts.');
}

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!unified_csrf_valid()) {
        http_response_code(400);
        $error = 'Your request expired. Refresh the page and try again.';
    } elseif (!$auth->verifyAdminPassword($identityId, $system, (string)($_POST['current_password'] ?? ''))) {
        http_response_code(403);
        $error = 'The current administrator password could not be verified.';
    } else {
        $sourceIdentityId = (int)($_POST['source_identity_id'] ?? 0);
        $targetIdentityId = (int)($_POST['target_identity_id'] ?? 0);
        try {
            if ($sourceIdentityId === $identityId || $targetIdentityId === $identityId) {
                throw new RuntimeException('Do not select the administrator account as either identity.');
            }
            $auth->mergeIdentities($sourceIdentityId, $targetIdentityId);
            $success = 'The selected accounts are now linked. Your administrator sign-in was not changed.';
        } catch (Throwable $exception) {
            error_log('Unified account link failed: ' . $exception->getMessage());
            $error = 'Unable to link those accounts. Confirm the selection and try again.';
        }
    }
}

try {
    $identities = $auth->listIdentities();
} catch (Throwable $exception) {
    error_log('Unified identity list failed: ' . $exception->getMessage());
    http_response_code(503);
    exit('Account linking is temporarily unavailable.');
}
$csrfToken = unified_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link application accounts | 4ID Station Hospital</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-zinc-950 text-zinc-100">
    <main class="mx-auto max-w-4xl px-6 py-10">
        <a class="text-sm text-sky-400 hover:text-sky-300" href="<?php echo htmlspecialchars($_SESSION['sso_dashboard_url'] ?? 'unified_login.php', ENT_QUOTES, 'UTF-8'); ?>">&larr; Return to application</a>
        <h1 class="mt-4 text-3xl font-bold">Link application accounts</h1>
        <p class="mt-2 max-w-2xl text-sm text-zinc-400">
            Linking combines the access of two selected accounts under one identity. Your administrator identity
            stays separate. Accounts are never linked automatically based only on matching usernames.
        </p>
        <?php if ($error !== ''): ?>
            <p class="mt-5 rounded-lg border border-rose-800 bg-rose-950/50 p-3 text-sm text-rose-200">
                <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
            </p>
        <?php endif; ?>
        <section class="mt-8 rounded-2xl border border-zinc-800 bg-zinc-900 p-6">
            <h2 class="text-lg font-semibold">Link two verified account identities</h2>
            <p class="mt-2 text-sm text-zinc-400">
                Select the Outpatient and Smart Queueing accounts that belong to the same person, then confirm with your current administrator password.
            </p>
            <?php if ($success !== ''): ?>
                <p class="mt-4 rounded-lg border border-emerald-800 bg-emerald-950/50 p-3 text-sm text-emerald-200">
                    <?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?>
                </p>
            <?php endif; ?>
            <form method="post" class="mt-5 grid gap-4 sm:grid-cols-2">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                <?php foreach (['source_identity_id' => 'First account identity', 'target_identity_id' => 'Second account identity'] as $field => $label): ?>
                    <label class="block text-sm font-medium sm:col-span-2">
                    <?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?>
                    <select name="<?php echo htmlspecialchars($field, ENT_QUOTES, 'UTF-8'); ?>" required
                            class="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2.5 text-white">
                        <option value="">Select an identity</option>
                        <?php foreach ($identities as $identity): ?>
                            <?php if ((int)$identity['id'] === $identityId || empty($identity['accounts']) || strpos($identity['systems'], ',') !== false) { continue; } ?>
                            <option value="<?php echo (int)$identity['id']; ?>">
                                <?php echo htmlspecialchars(
                                    $identity['display_name'] . ' — ' . $identity['accounts'] . ' (identity ' . $identity['id'] . ')',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <?php endforeach; ?>
                <label class="block text-sm font-medium sm:col-span-2">
                    Current administrator password
                    <input name="current_password" type="password" autocomplete="current-password" required
                           class="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2.5 text-white">
                </label>
                <button class="rounded-lg bg-sky-600 px-4 py-3 font-semibold hover:bg-sky-500 sm:col-span-2">
                    Verify and link accounts
                </button>
            </form>
        </section>
        <section class="mt-8 overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900">
            <h2 class="border-b border-zinc-800 px-6 py-4 text-lg font-semibold">Existing identities</h2>
            <ul class="divide-y divide-zinc-800">
                <?php foreach ($identities as $identity): ?>
                    <li class="px-6 py-4">
                        <p class="font-medium"><?php echo htmlspecialchars($identity['display_name'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <p class="mt-1 text-xs text-zinc-400">
                            Identity <?php echo (int)$identity['id']; ?>:
                            <?php echo htmlspecialchars($identity['accounts'] ?: 'No linked accounts', ENT_QUOTES, 'UTF-8'); ?>
                        </p>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    </main>
</body>
</html>
