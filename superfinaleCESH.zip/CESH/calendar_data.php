<?php
// calendar_data.php
header('Content-Type: application/json');

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cesh_crm";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die(json_encode([]));

// Fetch appointments
$result = $conn->query("SELECT date, time, patient_name FROM appointments ORDER BY date, time");

$data = [];
while ($row = $result->fetch_assoc()) {
    $date = $row['date'];
    if (!isset($data[$date])) $data[$date] = [];
    $data[$date][] = ['time' => $row['time'], 'name' => $row['patient_name']];
}

echo json_encode($data);
