// In logout.php
<?php
header('Location: unified_logout.php');
exit;
session_start();
session_destroy();
header("Location: login.php");
exit();
?>