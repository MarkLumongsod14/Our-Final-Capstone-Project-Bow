CREATE TABLE IF NOT EXISTS login_activity (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT NULL,
    username VARCHAR(100) NOT NULL,
    full_name VARCHAR(150) NULL,
    ip_address VARCHAR(45) NOT NULL,
    status ENUM('Success', 'Failed') NOT NULL,
    reason VARCHAR(255) NOT NULL,
    attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_login_activity_time (attempted_at),
    KEY idx_login_activity_username (username),
    KEY idx_login_activity_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;