<?php
session_start();
header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

require_once 'db.php';

$historyLookupError = '';
$historyLookupPatient = null;
$medicalHistory = [];
$queueHistory = [];
$appointmentHistory = [];

function queueTrackingEscape($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function queueTrackingFormatDate($value): string
{
    if (!$value) {
        return '—';
    }
    $timestamp = strtotime((string)$value);
    return $timestamp === false ? (string)$value : date('M j, Y g:i A', $timestamp);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'lookup_history') {
    $now = time();
    if (
        !isset($_SESSION['queue_history_lookup'])
        || !is_array($_SESSION['queue_history_lookup'])
        || $now - (int)($_SESSION['queue_history_lookup']['window_started'] ?? 0) >= 900
    ) {
        $_SESSION['queue_history_lookup'] = ['window_started' => $now, 'failed_attempts' => 0, 'blocked_until' => 0];
    }

    $rateLimit = &$_SESSION['queue_history_lookup'];
    if ((int)$rateLimit['blocked_until'] > $now) {
        $historyLookupError = 'Too many unsuccessful attempts. Please wait 15 minutes before trying again.';
    } else {
        $mrnInput = $_POST['mrn'] ?? '';
        $dobInput = $_POST['dob'] ?? '';
        $validMrn = is_string($mrnInput) && preg_match('/^[0-9]{1,10}$/', $mrnInput) === 1 && (int)$mrnInput > 0;
        $dobDate = is_string($dobInput) ? DateTime::createFromFormat('!Y-m-d', $dobInput) : false;
        $dobErrors = DateTime::getLastErrors();
        $validDob = $dobDate
            && $dobDate->format('Y-m-d') === $dobInput
            && (!$dobErrors || ($dobErrors['warning_count'] === 0 && $dobErrors['error_count'] === 0));

        if ($validMrn && $validDob) {
            $patientStmt = $conn->prepare("SELECT mrn, first_name, middle_name, last_name, suffix, dob FROM patients WHERE mrn = ? AND dob = ? LIMIT 1");
            if (!$patientStmt) {
                error_log('Queue tracking patient lookup prepare failed: ' . $conn->error);
                $historyLookupError = 'Patient history is temporarily unavailable. Please try again later.';
            } else {
                $mrn = (int)$mrnInput;
                $dob = $dobDate->format('Y-m-d');
                $patientStmt->bind_param('is', $mrn, $dob);
                if (!$patientStmt->execute()) {
                    error_log('Queue tracking patient lookup failed: ' . $patientStmt->error);
                    $historyLookupError = 'Patient history is temporarily unavailable. Please try again later.';
                } else {
                    $historyLookupPatient = $patientStmt->get_result()->fetch_assoc();
                    if (!$historyLookupPatient) {
                        $rateLimit['failed_attempts'] = (int)$rateLimit['failed_attempts'] + 1;
                        if ($rateLimit['failed_attempts'] >= 6) {
                            $rateLimit['blocked_until'] = $now + 900;
                        }
                        $historyLookupError = 'We could not verify those details. Check the MRN and date of birth and try again.';
                    } else {
                        $rateLimit = ['window_started' => $now, 'failed_attempts' => 0, 'blocked_until' => 0];
                        $historyQueries = [
                            'medical' => [
                                "SELECT diagnosis, medications, allergies, notes, created_at FROM medical_history WHERE patient_mrn = ? ORDER BY created_at DESC, id DESC",
                                &$medicalHistory
                            ],
                            'queue' => [
                                "SELECT q.queue_number, q.priority, q.status, q.department, q.created_at, q.called_at, q.completed_at, CONCAT(COALESCE(qs.prefix, 'Q'), LPAD(q.queue_number, 3, '0')) AS display_number FROM queue q LEFT JOIN queue_settings qs ON qs.department = q.department WHERE q.patient_mrn = ? ORDER BY q.created_at DESC, q.id DESC",
                                &$queueHistory
                            ],
                            'appointments' => [
                                "SELECT `date`, `time`, provider, type, department, status, notes, doctor_notes, created_at, completed_at FROM appointments WHERE patient_mrn = ? ORDER BY `date` DESC, `time` DESC, id DESC",
                                &$appointmentHistory
                            ]
                        ];

                        foreach ($historyQueries as $queryName => &$historyQuery) {
                            $historyStmt = $conn->prepare($historyQuery[0]);
                            if (!$historyStmt) {
                                error_log('Queue tracking ' . $queryName . ' history prepare failed: ' . $conn->error);
                                $historyLookupError = 'Some patient history could not be loaded. Please try again later.';
                                $historyLookupPatient = null;
                                break;
                            }
                            $historyStmt->bind_param('i', $mrn);
                            if (!$historyStmt->execute()) {
                                error_log('Queue tracking ' . $queryName . ' history query failed: ' . $historyStmt->error);
                                $historyLookupError = 'Some patient history could not be loaded. Please try again later.';
                                $historyStmt->close();
                                $historyLookupPatient = null;
                                break;
                            }
                            $historyQuery[1] = $historyStmt->get_result()->fetch_all(MYSQLI_ASSOC);
                            $historyStmt->close();
                        }
                        unset($historyQuery);
                    }
                }
                $patientStmt->close();
            }
        } else {
            $rateLimit['failed_attempts'] = (int)$rateLimit['failed_attempts'] + 1;
            if ($rateLimit['failed_attempts'] >= 6) {
                $rateLimit['blocked_until'] = $now + 900;
            }
            $historyLookupError = 'We could not verify those details. Check the MRN and date of birth and try again.';
        }
    }
    unset($rateLimit);
}

$token = $_GET['token'] ?? '';
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="referrer" content="no-referrer">
    <title>Track Your Queue | CESH</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <script>
        if (localStorage.getItem('theme') !== 'light') {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        };
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/logo.png">
    <style>
        * { box-sizing: border-box; }
        html, body { min-height: 100%; }
        body {
            margin: 0;
            display: flex;
            flex-direction: column;
            background: #0A0F1E;
            color: #F3F4F6;
            font-family: 'Plus Jakarta Sans', sans-serif;
            line-height: 1.5;
            transition: background-color .3s ease, color .3s ease;
        }
        html:not(.dark) body { background: #F0F4F8; color: #1E293B; }
        .nav-bar {
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 10px 24px;
            background: #141B2B;
            border-bottom: 1px solid #2D3748;
        }
        html:not(.dark) .nav-bar { background: #fff; border-color: #E2E8F0; box-shadow: 0 2px 8px rgba(0,0,0,.04); }
        .nav-brand { display: flex; align-items: center; gap: 10px; color: #F3F4F6; text-decoration: none; font-size: .85rem; font-weight: 800; }
        html:not(.dark) .nav-brand { color: #0F172A; }
        .nav-logo { width: 38px; height: 38px; object-fit: contain; border-radius: 7px; }
        .nav-brand-copy { display: flex; flex-direction: column; line-height: 1.25; }
        .nav-brand-copy small { color: #94A3B8; font-size: .58rem; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; }
        .nav-actions { display: flex; align-items: center; gap: 10px; }
        .nav-current {
            padding: 6px 13px;
            border: 1px solid rgba(56,189,248,.55);
            border-radius: 20px;
            background: rgba(56,189,248,.1);
            color: #38BDF8;
            font-size: .7rem;
            font-weight: 600;
            text-decoration: none;
        }
        html:not(.dark) .nav-current { background: #EFF6FF; color: #2563EB; border-color: #93C5FD; }
        .theme-toggle {
            display: inline-flex;
            width: 36px;
            height: 36px;
            align-items: center;
            justify-content: center;
            border: 1px solid #334155;
            border-radius: 50%;
            background: #1E293B;
            color: #E2E8F0;
            cursor: pointer;
        }
        html:not(.dark) .theme-toggle { background: #fff; border-color: #E2E8F0; color: #1E293B; }
        .main-container { width: min(100% - 40px, 1400px); margin: 0 auto; padding: 26px 0 32px; flex: 1; }
        .search-section {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
            padding: 20px 24px;
            border: 1px solid #2D3748;
            border-radius: 16px;
            background: #141B2B;
        }
        html:not(.dark) .search-section { background: #fff; border-color: #E2E8F0; box-shadow: 0 4px 16px rgba(0,0,0,.06); }
        .search-heading { display: flex; flex: 1 1 250px; align-items: flex-start; gap: 12px; }
        .search-icon { margin-top: 2px; color: #38BDF8; font-size: 1.1rem; }
        html:not(.dark) .search-icon { color: #2563EB; }
        .search-title { display: block; color: #F3F4F6; font-size: .95rem; font-weight: 700; }
        html:not(.dark) .search-title { color: #0F172A; }
        .search-subtitle { display: block; margin-top: 3px; color: #94A3B8; font-size: .72rem; }
        html:not(.dark) .search-subtitle { color: #64748B; }
        .search-form { display: flex; flex: 2 1 420px; gap: 10px; }
        .search-input-wrap { position: relative; flex: 1; min-width: 0; }
        .search-input-icon { position: absolute; top: 50%; left: 14px; color: #38BDF8; transform: translateY(-50%); }
        html:not(.dark) .search-input-icon { color: #2563EB; }
        .search-input {
            width: 100%;
            padding: 11px 14px 11px 40px;
            border: 1px solid #2D3748;
            border-radius: 12px;
            outline: none;
            background: #1E293B;
            color: #F3F4F6;
            font: inherit;
            font-size: .82rem;
        }
        html:not(.dark) .search-input { border-color: #E2E8F0; background: #fff; color: #1E293B; }
        .search-input:focus { border-color: #38BDF8; box-shadow: 0 0 0 3px rgba(56,189,248,.12); }
        .btn-search {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 22px;
            border: 0;
            border-radius: 12px;
            background: #0D9488;
            color: #fff;
            cursor: pointer;
            font: inherit;
            font-size: .82rem;
            font-weight: 700;
            white-space: nowrap;
        }
        .btn-search:hover { background: #0F766E; }
        .status-message { margin: 0 0 18px; padding: 11px 15px; border-radius: 10px; font-size: .8rem; }
        .status-message.error { border-left: 3px solid #FF6F61; background: rgba(255,111,97,.1); color: #FF8D82; }
        .status-message.success { border-left: 3px solid #0D9488; background: rgba(13,148,136,.12); color: #5EEAD4; }
        html:not(.dark) .status-message.error { background: #FEF2F0; color: #B42318; }
        html:not(.dark) .status-message.success { background: #ECFDF5; color: #047857; }
        .tracking-result, .history-card {
            overflow: hidden;
            margin-bottom: 20px;
            border: 1px solid #2D3748;
            border-radius: 16px;
            background: #141B2B;
        }
        html:not(.dark) .tracking-result, html:not(.dark) .history-card { background: #fff; border-color: #E2E8F0; box-shadow: 0 4px 16px rgba(0,0,0,.05); }
        .tracking-ticket {
            position: relative;
            overflow: hidden;
            padding: 26px 28px;
            background: linear-gradient(120deg, #141B2B 0%, #1A2744 100%);
            text-align: center;
        }
        .tracking-ticket::before { position: absolute; inset: 0 0 auto; height: 3px; background: linear-gradient(90deg,#38BDF8,#0D9488,#38BDF8); content: ''; }
        .ticket-label { color: #94A3B8; font-size: .66rem; font-weight: 700; letter-spacing: .16em; text-transform: uppercase; }
        .ticket-number { margin: 5px 0; color: #38BDF8; font-family: 'JetBrains Mono', monospace; font-size: clamp(2.4rem, 8vw, 4rem); font-weight: 800; line-height: 1.15; }
        .ticket-department { color: #CBD5E1; font-size: .85rem; }
        .tracking-content { display: grid; gap: 12px; padding: 20px 24px; }
        .tracking-status-row, .tracking-detail-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
        .tracking-detail-row { padding: 13px 15px; border-radius: 10px; background: #1E293B; }
        html:not(.dark) .tracking-detail-row { background: #F1F5F9; }
        .tracking-caption { color: #94A3B8; font-size: .75rem; }
        .tracking-value { color: #F3F4F6; font-size: .8rem; font-weight: 700; }
        html:not(.dark) .tracking-value { color: #0F172A; }
        .history-heading { margin: 30px 0 14px; }
        .history-heading h2 { margin: 0; color: #F3F4F6; font-size: 1.1rem; font-weight: 800; }
        html:not(.dark) .history-heading h2 { color: #0F172A; }
        .history-heading p { margin: 5px 0 0; color: #94A3B8; font-size: .75rem; }
        html:not(.dark) .history-heading p { color: #64748B; }
        .history-card { padding: 20px; }
        .history-card h3 { margin: 0 0 14px; color: #F3F4F6; font-size: .9rem; font-weight: 700; }
        html:not(.dark) .history-card h3 { color: #0F172A; }
        .portal-footer { padding: 18px 20px; border-top: 1px solid #2D3748; color: #94A3B8; text-align: center; font-size: .68rem; }
        html:not(.dark) .portal-footer { border-color: #E2E8F0; }
        @media (max-width: 640px) {
            .nav-bar { padding: 9px 14px; }
            .nav-brand-copy { font-size: .75rem; }
            .main-container { width: min(100% - 24px, 1400px); padding-top: 16px; }
            .search-section { padding: 16px; }
            .search-form { flex-basis: 100%; }
            .btn-search { padding-inline: 16px; }
            .tracking-content { padding: 16px; }
        }
    </style>
</head>
<body>
    <nav class="nav-bar">
        <a href="queue_tracking.php" class="nav-brand">
            <img src="assets/images/logo.png" alt="CESH logo" class="nav-logo" onerror="this.style.display='none'">
            <span class="nav-brand-copy">4ID Station Hospital<small>Camp Evangelista</small></span>
        </a>
        <div class="nav-actions">
            <a href="queue_tracking.php" class="nav-current"><i class="fas fa-search mr-1"></i> Track Queue</a>
            <button type="button" class="theme-toggle" onclick="toggleTheme()" aria-label="Toggle dark mode">
                <i id="themeIcon" class="fas <?php echo isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
            </button>
        </div>
    </nav>

    <main class="main-container">
        <section class="search-section">
            <div class="search-heading">
                <i class="fas fa-search search-icon"></i>
                <div>
                    <span class="search-title">Track Your Queue</span>
                    <span class="search-subtitle">Enter the private tracking code printed on your ticket to check your visit status.</span>
                </div>
            </div>
            <form id="trackingForm" class="search-form">
                <label for="trackingCode" class="sr-only">Queue ticket tracking code</label>
                <div class="search-input-wrap">
                    <i class="fas fa-ticket-alt search-input-icon"></i>
                    <input id="trackingCode" type="text" required autocomplete="off" spellcheck="false"
                        placeholder="Enter your ticket tracking code"
                        class="search-input">
                </div>
                <button type="submit" class="btn-search"><i class="fas fa-arrow-right"></i> Track</button>
            </form>
        </section>

        <p id="trackingMessage" role="status" class="status-message hidden"></p>

        <section id="trackingResult" aria-live="polite" class="tracking-result hidden">
            <div class="tracking-ticket">
                <p class="ticket-label">Your Queue Number</p>
                <p id="queueNumber" class="ticket-number"></p>
                <p id="queueDepartment" class="ticket-department"></p>
            </div>
            <div class="tracking-content">
                <div class="tracking-status-row">
                    <span class="tracking-caption">Current status</span>
                    <span id="queueStatus" class="rounded-full px-3 py-1 text-xs font-bold"></span>
                </div>
                <div id="positionPanel" class="hidden rounded-xl bg-sky-50 p-4 dark:bg-sky-500/10">
                    <p class="text-xs font-bold uppercase tracking-wider text-sky-700 dark:text-sky-300"><i class="fas fa-users mr-1"></i>Your place in line</p>
                    <p class="mt-1 text-lg font-bold text-sky-900 dark:text-sky-100"><span id="queuePosition"></span></p>
                </div>
                <div id="servingPanel" class="tracking-detail-row hidden">
                    <span class="tracking-caption"><i class="fas fa-bullhorn mr-1 text-sky-500"></i>Currently serving</span>
                    <span id="currentlyServing" class="font-mono tracking-value"></span>
                </div>
                <p id="lastUpdated" class="text-center text-xs text-slate-400"></p>
            </div>
        </section>

        <section class="history-section">
            <div class="history-heading">
                <h2>View Your CESH Medical &amp; Visit History</h2>
                <p>Verify your identity with the MRN and date of birth on your patient record.</p>
            </div>
            <form method="post" action="queue_tracking.php" class="history-card mb-5 grid gap-3 sm:grid-cols-2">
                <input type="hidden" name="action" value="lookup_history">
                <div>
                    <label for="historyMrn" class="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Medical Record Number (MRN)</label>
                    <input id="historyMrn" name="mrn" type="text" inputmode="numeric" pattern="[0-9]{1,10}" maxlength="10" required autocomplete="off"
                        class="search-input !p-3">
                </div>
                <div>
                    <label for="historyDob" class="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Date of Birth</label>
                    <input id="historyDob" name="dob" type="date" required autocomplete="bday"
                        class="search-input !p-3">
                </div>
                <button type="submit" class="btn-search sm:col-span-2">
                    <i class="fas fa-lock"></i>Verify & View History
                </button>
            </form>

            <?php if ($historyLookupError !== ''): ?>
                <p role="alert" class="mb-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300"><?= queueTrackingEscape($historyLookupError) ?></p>
            <?php endif; ?>

            <?php if ($historyLookupPatient): ?>
                <?php
                $verifiedNameParts = array_filter([
                    $historyLookupPatient['first_name'],
                    $historyLookupPatient['middle_name'],
                    $historyLookupPatient['last_name'],
                    $historyLookupPatient['suffix']
                ], static fn($part) => trim((string)$part) !== '');
                ?>
                <div class="status-message success">
                    <p class="text-xs font-bold uppercase tracking-wide">Identity verified</p>
                    <p class="mt-1 font-bold"><?= queueTrackingEscape(implode(' ', $verifiedNameParts)) ?> · MRN <?= queueTrackingEscape(str_pad((string)$historyLookupPatient['mrn'], 6, '0', STR_PAD_LEFT)) ?></p>
                    <p class="text-xs">Only share this page with the patient or their authorized caregiver.</p>
                </div>

                <div class="space-y-5">
                    <section class="history-card">
                        <h3><i class="fas fa-notes-medical text-sky-500"></i> Medical History</h3>
                        <?php if (!$medicalHistory): ?><p class="text-sm text-slate-500 dark:text-slate-400">No medical history records are available.</p><?php endif; ?>
                        <?php foreach ($medicalHistory as $record): ?>
                            <article class="border-t border-slate-100 py-4 first:border-0 first:pt-0 dark:border-slate-800">
                                <p class="mb-3 text-xs text-slate-400"><?= queueTrackingEscape(queueTrackingFormatDate($record['created_at'])) ?></p>
                                <?php foreach (['diagnosis' => 'Diagnosis', 'medications' => 'Medications', 'allergies' => 'Allergies', 'notes' => 'Notes'] as $field => $label): ?>
                                    <?php if (trim((string)$record[$field]) !== ''): ?>
                                        <div class="mb-2">
                                            <p class="text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400"><?= $label ?></p>
                                            <p class="whitespace-pre-wrap break-words text-sm"><?= queueTrackingEscape($record[$field]) ?></p>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </article>
                        <?php endforeach; ?>
                    </section>

                    <section class="history-card">
                        <h3><i class="fas fa-ticket-alt text-amber-500"></i> Queue Transactions</h3>
                        <?php if (!$queueHistory): ?><p class="text-sm text-slate-500 dark:text-slate-400">No queue transactions are available.</p><?php endif; ?>
                        <?php foreach ($queueHistory as $record): ?>
                            <div class="border-t border-slate-100 py-3 first:border-0 first:pt-0 dark:border-slate-800">
                                <div class="flex flex-wrap items-center justify-between gap-2">
                                    <p class="font-mono font-bold"><?= queueTrackingEscape($record['display_number']) ?> <span class="font-sans font-normal">· <?= queueTrackingEscape($record['department'] === '0' ? 'Department not recorded' : $record['department']) ?></span></p>
                                    <span class="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold dark:bg-slate-800"><?= queueTrackingEscape($record['status']) ?></span>
                                </div>
                                <p class="text-xs text-slate-500 dark:text-slate-400"><?= queueTrackingEscape(queueTrackingFormatDate($record['created_at'])) ?> · <?= queueTrackingEscape($record['priority']) ?></p>
                            </div>
                        <?php endforeach; ?>
                    </section>

                    <section class="history-card">
                        <h3><i class="fas fa-calendar-check text-emerald-500"></i> Appointment Transactions</h3>
                        <?php if (!$appointmentHistory): ?><p class="text-sm text-slate-500 dark:text-slate-400">No appointment records are available.</p><?php endif; ?>
                        <?php foreach ($appointmentHistory as $record): ?>
                            <article class="border-t border-slate-100 py-3 first:border-0 first:pt-0 dark:border-slate-800">
                                <div class="flex flex-wrap items-center justify-between gap-2">
                                    <p class="font-semibold"><?= queueTrackingEscape($record['type'] ?: 'Appointment') ?> · <?= queueTrackingEscape($record['department'] ?: 'Department not recorded') ?></p>
                                    <span class="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold dark:bg-slate-800"><?= queueTrackingEscape($record['status']) ?></span>
                                </div>
                                <p class="text-xs text-slate-500 dark:text-slate-400"><?= queueTrackingEscape($record['date']) ?> <?= queueTrackingEscape($record['time']) ?> · <?= queueTrackingEscape($record['provider']) ?></p>
                                <?php foreach (['notes' => 'Notes', 'doctor_notes' => 'Provider notes'] as $field => $label): ?>
                                    <?php if (trim((string)$record[$field]) !== ''): ?>
                                        <p class="mt-2 whitespace-pre-wrap break-words text-sm"><span class="font-bold"><?= $label ?>:</span> <?= queueTrackingEscape($record[$field]) ?></p>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </article>
                        <?php endforeach; ?>
                    </section>
                </div>
            <?php endif; ?>
        </section>

    </main>
    <footer class="portal-footer">Your tracking code is private. Keep it with your queue ticket.</footer>

    <script>
        function toggleTheme() {
            const isDark = document.documentElement.classList.toggle('dark');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            document.getElementById('themeIcon').className = `fas ${isDark ? 'fa-sun' : 'fa-moon'}`;
        }

        const form = document.getElementById('trackingForm');
        const codeInput = document.getElementById('trackingCode');
        const message = document.getElementById('trackingMessage');
        const result = document.getElementById('trackingResult');
        let refreshTimer;

        function showMessage(text, isError = true) {
            message.textContent = text;
            message.className = `status-message ${isError ? 'error' : 'success'}`;
        }

        function formatDateTime(value) {
            if (!value) return '';
            const date = new Date(String(value).replace(' ', 'T'));
            return Number.isNaN(date.getTime()) ? '' : date.toLocaleString();
        }

        async function refreshTracking(token) {
            try {
                const response = await fetch(`queue_tracking_api.php?token=${encodeURIComponent(token)}`, {
                    cache: 'no-store',
                    headers: { 'Accept': 'application/json' }
                });
                const data = await response.json();
                if (!response.ok || !data.success) {
                    result.classList.add('hidden');
                    showMessage(data.error || 'Unable to load queue status.');
                    clearInterval(refreshTimer);
                    return;
                }

                document.getElementById('queueNumber').textContent = data.queue_number;
                document.getElementById('queueDepartment').textContent = data.department;
                const status = document.getElementById('queueStatus');
                status.textContent = data.status;
                const statusColors = {
                    'Waiting': 'bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300',
                    'In Consultation': 'bg-sky-100 text-sky-800 dark:bg-sky-500/15 dark:text-sky-300',
                    'Completed': 'bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300',
                    'Cancelled': 'bg-rose-100 text-rose-800 dark:bg-rose-500/15 dark:text-rose-300',
                    'No Show': 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200'
                };
                status.className = `rounded-full px-3 py-1 text-xs font-bold ${statusColors[data.status] || statusColors['No Show']}`;

                const positionPanel = document.getElementById('positionPanel');
                positionPanel.classList.toggle('hidden', data.status !== 'Waiting');
                if (data.status === 'Waiting') {
                    document.getElementById('queuePosition').textContent =
                        `You are #${data.position} in line.`;
                }

                const servingPanel = document.getElementById('servingPanel');
                servingPanel.classList.toggle('hidden', !data.currently_serving);
                servingPanel.style.display = data.currently_serving ? 'flex' : '';
                document.getElementById('currentlyServing').textContent = data.currently_serving || '';

                let updateText = `Registered ${formatDateTime(data.created_at)}`;
                if (data.status === 'In Consultation' && data.called_at) {
                    updateText = `Called ${formatDateTime(data.called_at)}`;
                } else if (data.status === 'Completed' && data.completed_at) {
                    updateText = `Completed ${formatDateTime(data.completed_at)}`;
                }
                document.getElementById('lastUpdated').textContent = updateText;
                message.classList.add('hidden');
                result.classList.remove('hidden');
                if (['Completed', 'Cancelled', 'No Show'].includes(data.status)) {
                    clearInterval(refreshTimer);
                }
            } catch (error) {
                showMessage('Could not refresh queue status. Check your connection and try again.');
                console.error('Queue tracking refresh failed:', error);
            }
        }

        form.addEventListener('submit', event => {
            event.preventDefault();
            const token = codeInput.value.trim();
            if (!/^[a-f0-9]{64}$/i.test(token)) {
                clearInterval(refreshTimer);
                result.classList.add('hidden');
                showMessage('The tracking code should contain 64 letters or numbers from your ticket.');
                return;
            }
            clearInterval(refreshTimer);
            refreshTracking(token);
            refreshTimer = setInterval(() => refreshTracking(token), 10000);
        });

        const initialToken = new URLSearchParams(window.location.search).get('token');
        if (initialToken) {
            codeInput.value = initialToken;
            form.requestSubmit();
        }
    </script>
</body>
</html>
