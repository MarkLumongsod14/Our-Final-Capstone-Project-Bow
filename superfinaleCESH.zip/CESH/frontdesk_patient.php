<?php
// frontdesk_patient.php - Front Desk Patient Registration with Validations
// Camp Evangelista Station Hospital
require_once 'db.php';
require_once 'auth.php';
require_once 'queue_assignment_helpers.php';
require_once 'queue_tracking_helpers.php';

$auth->requireRole(['admin', 'staff']);

$current_user = $auth->currentUser();
$user_department = $current_user['assigned_department'] ?? 'General';
$is_admin = $current_user['role'] === 'admin';
$is_general_frontdesk = $current_user['role'] === 'staff'
    && in_array($user_department, ['General', 'General Medicine'], true);
$department = $_GET['dept'] ?? $user_department;

if (!$auth->canAccessDepartment($department) && !$is_general_frontdesk) {
    die("Access denied. You are not authorized for this department.");
}

$accessible_depts = ($is_admin || $is_general_frontdesk)
    ? ['General', 'Pediatrics', 'OB-Gyne', 'Internal Medicine']
    : $auth->getAccessibleDepartments();

// Check if columns exist, if not, add them
$check_middle = $conn->query("SHOW COLUMNS FROM patients LIKE 'middle_name'");
if ($check_middle && $check_middle->num_rows == 0) {
    $conn->query("ALTER TABLE patients ADD COLUMN middle_name VARCHAR(100) DEFAULT NULL AFTER first_name");
}

$check_suffix = $conn->query("SHOW COLUMNS FROM patients LIKE 'suffix'");
if ($check_suffix && $check_suffix->num_rows == 0) {
    $conn->query("ALTER TABLE patients ADD COLUMN suffix VARCHAR(10) DEFAULT NULL AFTER last_name");
}

$patient_profile_columns = [
    'serial_no' => 'VARCHAR(50) DEFAULT NULL',
    'patient_type' => 'VARCHAR(20) DEFAULT NULL',
    'military_rank' => 'VARCHAR(60) DEFAULT NULL'
];
foreach ($patient_profile_columns as $column => $definition) {
    $column_check = $conn->query("SHOW COLUMNS FROM patients LIKE '" . $conn->real_escape_string($column) . "'");
    if (!$column_check) {
        die("Unable to inspect patient registration schema: " . htmlspecialchars($conn->error));
    }
    if ($column_check->num_rows === 0 && !$conn->query("ALTER TABLE patients ADD COLUMN `$column` $definition")) {
        die("Unable to initialize patient registration fields: " . htmlspecialchars($conn->error));
    }
}
ensureQueueTrackingTokens($conn);

// Suffix options
$suffixes = ['', 'Jr.', 'Sr.', 'II', 'III', 'IV', 'V'];
$militaryRanks = [
    'Enlisted Officers' => [
        'Private',
        'Private First Class',
        'Corporal',
        'Sergeant',
        'Staff Sergeant',
        'Technical Sergeant',
        'Master Sergeant',
        'Senior Master Sergeant',
        'Chief Master Sergeant',
        'First Chief Master Sergeant'
    ],
    'Commissioned Officers' => [
        'Second Lieutenant',
        'First Lieutenant',
        'Captain',
        'Major',
        'Lieutenant Colonel',
        'Colonel',
        'Brigadier General',
        'Major General',
        'Lieutenant General',
        'General'
    ]
];
$allowedMilitaryRanks = array_merge(...array_values($militaryRanks));

// Error messages array
$errors = [];
$success_msg = '';

function isValidPatientName($name) {
    return $name !== '' && preg_match('/^[\p{L}\p{M} -]+$/u', $name) === 1;
}

// ---------------- ADD PATIENT WITH VALIDATIONS ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_patient'])) {
    $first_name = trim($_POST['first_name'] ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $suffix = $_POST['suffix'] ?? '';
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $contact = trim($_POST['contact'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $primary_physician = trim($_POST['primary_physician'] ?? '');
    $serial_no = trim($_POST['serial_no'] ?? '');
    $patient_type = $_POST['patient_type'] ?? '';
    $military_rank = trim($_POST['military_rank'] ?? '');
    $queue_department_input = $_POST['queue_department'] ?? $department;
    $priority = $_POST['priority'] ?? 'Normal';

    $validDepartmentValues = array_map(
        static fn($accessibleDepartment) => $accessibleDepartment === 'General Medicine' ? 'General' : $accessibleDepartment,
        $accessible_depts
    );
    if (!is_string($queue_department_input) || !in_array($queue_department_input, $validDepartmentValues, true)) {
        $errors[] = "Please select a department you are authorized to access.";
    }
    $queue_department = $queue_department_input === 'General' ? 'General Medicine' : $queue_department_input;
    if (!in_array($queue_department, ['General Medicine', 'Pediatrics', 'OB-Gyne', 'Internal Medicine'], true)) {
        $errors[] = "Please select a valid department.";
    }
    if (!in_array($priority, ['Normal', 'Senior', 'PWD'], true)) {
        $errors[] = "Please select a valid queue priority.";
    }
    
    if (empty($first_name)) $errors[] = "First name is required";
    elseif (!isValidPatientName($first_name)) $errors[] = "First name can contain letters, spaces, and hyphens only";
    if ($middle_name !== '' && !isValidPatientName($middle_name)) $errors[] = "Middle name can contain letters, spaces, and hyphens only";
    if (empty($last_name)) $errors[] = "Last name is required";
    elseif (!isValidPatientName($last_name)) $errors[] = "Last name can contain letters, spaces, and hyphens only";
    if (empty($dob)) $errors[] = "Date of birth is required";
    if (empty($gender)) $errors[] = "Gender is required";
    if (empty($contact)) $errors[] = "Contact number is required";
    if (empty($address)) $errors[] = "Address is required";
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Please enter a valid email address";
    if ($serial_no === '') $errors[] = "Serial number is required";
    elseif (strlen($serial_no) > 50) $errors[] = "Serial number cannot exceed 50 characters";
    if (!in_array($patient_type, ['Military', 'Dependent'], true)) $errors[] = "Please select Military or Dependent as the patient type";
    if ($patient_type === 'Military' && !in_array($military_rank, $allowedMilitaryRanks, true)) $errors[] = "Please select a valid military rank";
    if ($patient_type !== 'Military') $military_rank = '';
    
    if (!empty($dob)) {
        $dob_date = DateTime::createFromFormat('!Y-m-d', $dob);
        $dob_errors = DateTime::getLastErrors();
        if (!$dob_date || $dob_date->format('Y-m-d') !== $dob || ($dob_errors && ($dob_errors['warning_count'] > 0 || $dob_errors['error_count'] > 0))) {
            $errors[] = "Please enter a valid date of birth";
        } else {
            date_default_timezone_set('Asia/Manila');
            $today = new DateTime('today');
            if ($dob_date > $today) $errors[] = "Date of birth cannot be in the future";
            if ($today->diff($dob_date)->y > 120) $errors[] = "Age cannot exceed 120 years";
        }
    }
    
    if (!empty($contact)) {
        $contact_clean = preg_replace('/[^0-9]/', '', $contact);
        if (strlen($contact_clean) != 11) $errors[] = "Contact number must be exactly 11 digits";
        elseif (!preg_match('/^09[0-9]{9}$/', $contact_clean)) $errors[] = "Contact number must start with 09 (e.g., 09123456789)";
        else $contact = $contact_clean;
    }
    
    if (empty($errors)) {
        $check_stmt = $conn->prepare("SELECT mrn FROM patients WHERE first_name = ? AND last_name = ? AND dob = ?");
        if ($check_stmt) {
            $check_stmt->bind_param("sss", $first_name, $last_name, $dob);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            if ($check_result->num_rows > 0) $errors[] = "A patient with the same name and date of birth already exists.";
            $check_stmt->close();
        }
    }
    
    if (empty($errors)) {
        $conn->begin_transaction();
        try {
            $settings = $conn->prepare("SELECT current_number, prefix FROM queue_settings WHERE department = ? FOR UPDATE");
            if (!$settings) {
                throw new RuntimeException('Unable to prepare queue number allocation: ' . $conn->error);
            }
            $settings->bind_param('s', $queue_department);
            if (!$settings->execute()) {
                throw new RuntimeException('Unable to load queue number settings: ' . $settings->error);
            }
            $queueSettings = $settings->get_result()->fetch_assoc();
            $settings->close();

            $doctor_id = getLeastLoadedAvailableDoctorId($conn, $queue_department);
            if ($doctor_id === null) {
                throw new DomainException('No available doctor is assigned to the selected department. The patient was not registered or queued.');
            }

            if ($queueSettings) {
                $queue_number = (int)$queueSettings['current_number'] + 1;
                $updateSettings = $conn->prepare("UPDATE queue_settings SET current_number = ?, last_reset_date = CURDATE() WHERE department = ?");
                if (!$updateSettings) {
                    throw new RuntimeException('Unable to prepare queue number update: ' . $conn->error);
                }
                $updateSettings->bind_param('is', $queue_number, $queue_department);
                if (!$updateSettings->execute()) {
                    throw new RuntimeException('Unable to update queue number: ' . $updateSettings->error);
                }
                $updateSettings->close();
                $queue_prefix = $queueSettings['prefix'] ?: 'Q';
            } else {
                $queue_number = 1;
                $queue_prefix = 'Q';
                $createSettings = $conn->prepare("INSERT INTO queue_settings (department, current_number, last_reset_date, prefix) VALUES (?, 1, CURDATE(), 'Q')");
                if (!$createSettings) {
                    throw new RuntimeException('Unable to prepare queue settings: ' . $conn->error);
                }
                $createSettings->bind_param('s', $queue_department);
                if (!$createSettings->execute()) {
                    throw new RuntimeException('Unable to create queue settings: ' . $createSettings->error);
                }
                $createSettings->close();
            }

            $stmt = $conn->prepare("INSERT INTO patients (first_name, middle_name, last_name, suffix, dob, gender, contact, email, address, primary_physician, serial_no, patient_type, military_rank, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')");
            if (!$stmt) {
                throw new RuntimeException('Database prepare error: ' . $conn->error);
            }
            $stmt->bind_param("sssssssssssss", $first_name, $middle_name, $last_name, $suffix, $dob, $gender, $contact, $email, $address, $primary_physician, $serial_no, $patient_type, $military_rank);
            if (!$stmt->execute()) {
                throw new RuntimeException('Error adding patient: ' . $stmt->error);
            }
            $new_mrn = (int)$stmt->insert_id;
            $stmt->close();

            $tracking_token = bin2hex(random_bytes(32));
            $queueInsert = $conn->prepare("INSERT INTO queue (patient_mrn, queue_number, priority, status, department, doctor_id, tracking_token, created_at) VALUES (?, ?, ?, 'Waiting', ?, ?, ?, NOW())");
            if (!$queueInsert) {
                throw new RuntimeException('Unable to prepare patient queue entry: ' . $conn->error);
            }
            $queueInsert->bind_param('iissis', $new_mrn, $queue_number, $priority, $queue_department, $doctor_id, $tracking_token);
            if (!$queueInsert->execute()) {
                throw new RuntimeException('Unable to add patient to queue: ' . $queueInsert->error);
            }
            $queue_id = (int)$queueInsert->insert_id;
            $queueInsert->close();
            $conn->commit();

            $patient_name = trim(implode(' ', array_filter([$first_name, $middle_name, $last_name, $suffix])));
            $_SESSION['registration_queue_ticket'] = [
                'queue_id' => $queue_id,
                'formatted_number' => $queue_prefix . str_pad((string)$queue_number, 3, '0', STR_PAD_LEFT),
                'patient_name' => $patient_name,
                'patient_mrn' => $new_mrn,
                'department' => $queue_department,
                'priority' => $priority,
                'created_at' => date('Y-m-d H:i:s'),
                'tracking_token' => $tracking_token
            ];
            header('Location: queue_frontdesk.php?dept=' . urlencode($queue_department === 'General Medicine' ? 'General' : $queue_department));
            exit();
        } catch (Throwable $error) {
            $conn->rollback();
            if ($error instanceof DomainException) {
                $errors[] = $error->getMessage();
            } else {
                error_log('Front desk patient registration and queueing failed: ' . $error->getMessage());
                $errors[] = 'Unable to register and queue this patient right now. No patient or queue record was saved. Please try again.';
            }
        }
    }
}

// Get next MRN for preview
$next_mrn_result = $conn->query("SHOW TABLE STATUS LIKE 'patients'");
$next_mrn = $next_mrn_result ? $next_mrn_result->fetch_assoc()['Auto_increment'] : 1000;

function formatMRN($mrn) {
    return str_pad($mrn, 6, '0', STR_PAD_LEFT);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Patient | 4ID Station Hospital</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        #sidebar::-webkit-scrollbar {
            width: 4px;
        }
        #sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        #sidebar::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 2px;
        }
        .dark #sidebar::-webkit-scrollbar-thumb {
            background: #475569;
        }
        .main-content {
            transition: margin-left 0.3s ease;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        
        .theme-switch {
            position: relative;
            width: 48px;
            height: 26px;
            background: #e2e8f0;
            border-radius: 13px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(22px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 11px; }
        
        /* User Dropdown */
        .user-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            min-width: 200px;
            z-index: 1000;
            overflow: hidden;
        }
        .dark .user-dropdown {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .user-dropdown.show {
            display: block;
        }
        .user-dropdown .dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        .dark .user-dropdown .dropdown-header {
            border-bottom-color: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-header strong {
            color: #1f2937;
            display: block;
            font-size: 0.85rem;
        }
        .dark .user-dropdown .dropdown-header strong {
            color: #f1f5f9;
        }
        .user-dropdown .dropdown-header small {
            color: #6b7280;
            font-size: 0.7rem;
        }
        .dark .user-dropdown .dropdown-header small {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            color: #374151;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
        }
        .dark .user-dropdown .dropdown-item {
            color: #e5e7eb;
        }
        .user-dropdown .dropdown-item:hover {
            background: #f3f4f6;
        }
        .dark .user-dropdown .dropdown-item:hover {
            background: rgba(255,255,255,0.04);
        }
        .user-dropdown .dropdown-item i {
            width: 18px;
            color: #6b7280;
        }
        .dark .user-dropdown .dropdown-item i {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-divider {
            height: 1px;
            background: #e5e7eb;
            margin: 4px 0;
        }
        .dark .user-dropdown .dropdown-divider {
            background: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-item.logout {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout i {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout:hover {
            background: rgba(239, 68, 68, 0.08);
        }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- SIDEBAR -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span>
                    <span>E</span>
                    <span>S</span>
                    <span>H</span>
                </div>

                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="frontdesk_dashboard.php?dept=<?php echo urlencode($department); ?>" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-gauge-high text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="frontdesk_patient.php?dept=<?php echo urlencode($department); ?>" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-plus text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Register Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_frontdesk.php?dept=<?php echo urlencode($department); ?>" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-ticket text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_display.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tv text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Display</span>
                        </a>
                    </li>
                    <?php if (($current_user['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="admin/users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-shield text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i></div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                
                <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
                    <a href="logout.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                        <div class="w-6 h-6 flex items-center justify-center shrink-0">
                            <i class="fas fa-sign-out-alt text-base text-rose-400 group-hover/link:text-rose-500 transition-colors"></i>
                        </div>
                        <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
                    </a>
                </div>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 main-content">
        
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">Register Patient</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">Add a new patient to the system</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($current_user['full_name']); ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400 font-medium">Front Desk Staff</div>
                </div>
                
                <!-- Dark Mode Toggle Switch -->
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 dark:text-slate-500">
                        <i class="fas fa-sun"></i>
                    </span>
                    <div class="theme-switch" id="themeToggle">
                        <div class="slider">
                            <span class="sun"><i class="fas fa-sun"></i></span>
                            <span class="moon"><i class="fas fa-moon"></i></span>
                        </div>
                    </div>
                    <span class="text-xs text-slate-400 dark:text-slate-500">
                        <i class="fas fa-moon"></i>
                    </span>
                </div>

                <!-- User Avatar with Click Dropdown -->
                <div class="relative">
                    <div class="w-10 h-10 rounded-full bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors" id="userAvatar">
                        <i class="fas fa-user text-slate-400 dark:text-slate-500 text-sm"></i>
                    </div>
                    <div class="user-dropdown" id="userDropdown">
                        <div class="dropdown-header">
                            <strong><?php echo htmlspecialchars($current_user['full_name']); ?></strong>
                            <small>Front Desk Staff</small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a href="logout.php" class="dropdown-item logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Department Tabs -->
        <div class="flex flex-wrap gap-2 mb-6 border-b border-slate-200 dark:border-slate-700/50 pb-3">
            <?php foreach ($accessible_depts as $dept): 
                $icon = 'fa-stethoscope';
                if ($dept === 'Pediatrics') $icon = 'fa-child';
                elseif ($dept === 'OB-Gyne') $icon = 'fa-female';
                elseif ($dept === 'Internal Medicine') $icon = 'fa-heart-pulse';
            ?>
                <a href="?dept=<?php echo urlencode($dept); ?>" class="px-4 py-2 rounded-full text-sm font-semibold transition-all duration-150 <?php echo $dept === $department ? 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50 border border-transparent'; ?>">
                    <i class="fas <?php echo $icon; ?> mr-2"></i> <?php echo htmlspecialchars($dept); ?>
                </a>
            <?php endforeach; ?>
        </div>
        
        <!-- Stats Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
                <div class="flex justify-between items-center mb-4">
                    <div class="w-11 h-11 bg-sky-50 dark:bg-sky-500/10 rounded-xl flex items-center justify-center text-sky-600 dark:text-sky-400 text-lg">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono" id="totalPatients">0</div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Total Patients</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
                <div class="flex justify-between items-center mb-4">
                    <div class="w-11 h-11 bg-emerald-50 dark:bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-lg">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                </div>
                <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono" id="todayRegistrations">0</div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Today's Registrations</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
                <div class="flex justify-between items-center mb-4">
                    <div class="w-11 h-11 bg-amber-50 dark:bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-600 dark:text-amber-400 text-lg">
                        <i class="fas fa-id-card"></i>
                    </div>
                </div>
                <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono"><?php echo formatMRN($next_mrn); ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Next MRN</div>
            </div>
        </div>
        
        <!-- Registration Form -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80">
                <div class="flex items-center gap-3">
                    <i class="fas fa-edit text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200">Patient Registration Form</span>
                </div>
            </div>
            <div class="p-6">
                
                <?php if (!empty($errors)): ?>
                    <div class="mb-6 p-4 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-400/20 rounded-xl">
                        <div class="flex items-start gap-3">
                            <i class="fas fa-triangle-exclamation text-rose-500 dark:text-rose-400 mt-0.5"></i>
                            <div>
                                <div class="text-sm font-bold text-rose-600 dark:text-rose-400">Please fix the following errors:</div>
                                <ul class="mt-2 space-y-1 text-sm text-rose-600 dark:text-rose-400">
                                    <?php foreach ($errors as $err): ?>
                                        <li class="flex items-center gap-2"><i class="fas fa-circle text-[6px]"></i> <?php echo htmlspecialchars($err); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- MRN Preview -->
                <div class="mb-6 p-3 bg-sky-50 dark:bg-sky-500/10 border border-sky-200 dark:border-sky-400/20 rounded-xl flex items-center gap-3">
                    <i class="fas fa-id-card text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm text-slate-600 dark:text-slate-300">MRN will be auto-generated:</span>
                    <span class="text-sm font-mono font-bold text-sky-600 dark:text-sky-400"><?php echo formatMRN($next_mrn); ?></span>
                </div>
                
                <form method="POST" id="registrationForm">
                    <input type="hidden" name="add_patient" value="1">
                    
                    <!-- Name Fields -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-user mr-1"></i> First Name <span class="text-rose-500">*</span>
                            </label>
                            <input type="text" name="first_name" id="firstName" placeholder="Enter first name" required
                                   autocomplete="given-name" title="Use letters, spaces, and hyphens only"
                                   value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-user mr-1"></i> Middle Name <span class="text-slate-400 font-normal">(Optional)</span>
                            </label>
                            <input type="text" name="middle_name" id="middleName" placeholder="Enter middle name"
                                   autocomplete="additional-name" title="Use letters, spaces, and hyphens only"
                                   value="<?php echo htmlspecialchars($_POST['middle_name'] ?? ''); ?>"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div>
                            <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-user mr-1"></i> Last Name <span class="text-rose-500">*</span>
                            </label>
                            <input type="text" name="last_name" id="lastName" placeholder="Enter last name" required
                                   autocomplete="family-name" title="Use letters, spaces, and hyphens only"
                                   value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-tag mr-1"></i> Suffix
                            </label>
                            <select name="suffix" id="suffix" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                                <option value="">-- None --</option>
                                <?php foreach ($suffixes as $suf): ?>
                                    <?php if (!empty($suf)): ?>
                                        <option value="<?php echo $suf; ?>" <?php echo (($_POST['suffix'] ?? '') === $suf) ? 'selected' : ''; ?>>
                                            <?php echo $suf; ?>
                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <!-- DOB & Gender -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div>
                            <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-calendar-alt mr-1"></i> Date of Birth <span class="text-rose-500">*</span>
                            </label>
                            <input type="date" name="dob" id="dob" required
                                   value="<?php echo htmlspecialchars($_POST['dob'] ?? ''); ?>"
                                   max="<?php echo date('Y-m-d'); ?>"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                            <p class="mt-1 text-xs text-slate-400 dark:text-slate-500">Cannot be future. Today is allowed. Max age 120 years.</p>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-venus-mars mr-1"></i> Gender <span class="text-rose-500">*</span>
                            </label>
                            <select name="gender" id="gender" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                                <option value="">Select Gender</option>
                                <option value="Male" <?php echo (($_POST['gender'] ?? '') === 'Male') ? 'selected' : ''; ?>>Male</option>
                                <option value="Female" <?php echo (($_POST['gender'] ?? '') === 'Female') ? 'selected' : ''; ?>>Female</option>
                                <option value="Other" <?php echo (($_POST['gender'] ?? '') === 'Other') ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div>
                            <label for="serialNo" class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-id-badge mr-1"></i> Serial No. <span class="text-rose-500">*</span>
                            </label>
                            <input type="text" name="serial_no" id="serialNo" maxlength="50" required placeholder="Enter serial number"
                                   value="<?php echo htmlspecialchars($_POST['serial_no'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                        </div>
                        <div>
                            <label for="patientType" class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                <i class="fas fa-users mr-1"></i> Patient Type <span class="text-rose-500">*</span>
                            </label>
                            <select name="patient_type" id="patientType" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                                <option value="">Select patient type</option>
                                <option value="Military" <?php echo (($_POST['patient_type'] ?? '') === 'Military') ? 'selected' : ''; ?>>Military</option>
                                <option value="Dependent" <?php echo (($_POST['patient_type'] ?? '') === 'Dependent') ? 'selected' : ''; ?>>Dependent</option>
                            </select>
                        </div>
                    </div>

                    <div id="militaryRankField" class="mt-4 hidden">
                        <label for="militaryRank" class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                            <i class="fas fa-medal mr-1"></i> Military Rank <span class="text-rose-500">*</span>
                        </label>
                        <select name="military_rank" id="militaryRank" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                            <option value="">Select military rank</option>
                            <?php foreach ($militaryRanks as $group => $ranks): ?>
                                <optgroup label="<?= htmlspecialchars($group, ENT_QUOTES, 'UTF-8') ?>">
                                    <?php foreach ($ranks as $rank): ?>
                                        <option value="<?= htmlspecialchars($rank, ENT_QUOTES, 'UTF-8') ?>" <?php echo (($_POST['military_rank'] ?? '') === $rank) ? 'selected' : ''; ?>>
                                            <?= htmlspecialchars($rank, ENT_QUOTES, 'UTF-8') ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Contact & Address -->
                    <div class="mt-4">
                        <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                            <i class="fas fa-phone mr-1"></i> Contact Number <span class="text-rose-500">*</span>
                        </label>
                        <input type="tel" name="contact" id="contact" placeholder="09123456789" required
                               value="<?php echo htmlspecialchars($_POST['contact'] ?? ''); ?>"
                               class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                        <p class="mt-1 text-xs text-slate-400 dark:text-slate-500">Must be 11 digits and start with 09 (e.g., 09123456789)</p>
                    </div>

                    <div class="mt-4">
                        <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                            <i class="fas fa-envelope mr-1"></i> Email Address <span class="text-slate-400 font-normal">(Optional)</span>
                        </label>
                        <input type="email" name="email" id="email" placeholder="patient@example.com"
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                               class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                        <p class="mt-1 text-xs text-slate-400 dark:text-slate-500">Appointment reminders will be sent to this address.</p>
                    </div>
                    
                    <div class="mt-4">
                        <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                            <i class="fas fa-map-marker-alt mr-1"></i> Address <span class="text-rose-500">*</span>
                        </label>
                        <input type="text" name="address" id="address" placeholder="Complete address" required
                               value="<?php echo htmlspecialchars($_POST['address'] ?? ''); ?>"
                               class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                    </div>
                    
                    <div class="mt-4">
                        <label class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                            <i class="fas fa-user-md mr-1"></i> Primary Physician <span class="text-slate-400 font-normal">(Optional)</span>
                        </label>
                        <input type="text" name="primary_physician" id="physician" placeholder="Doctor's name"
                               value="<?php echo htmlspecialchars($_POST['primary_physician'] ?? ''); ?>"
                               class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                    </div>

                    <div class="mt-6 border-t border-slate-200 pt-5 dark:border-slate-700/50">
                        <h2 class="mb-4 flex items-center gap-2 text-sm font-bold text-slate-800 dark:text-slate-200">
                            <i class="fas fa-ticket-alt text-sky-500"></i> Initial Queue Registration
                        </h2>
                        <p class="mb-4 text-xs text-slate-500 dark:text-slate-400">New patients are placed directly in the selected department queue. Use Queue Management for follow-up and return visits.</p>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="queueDepartment" class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                    <i class="fas fa-building mr-1"></i> Department <span class="text-rose-500">*</span>
                                </label>
                                <select name="queue_department" id="queueDepartment" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                                    <?php foreach ($accessible_depts as $queue_dept): ?>
                                        <?php $queue_dept_value = $queue_dept === 'General Medicine' ? 'General' : $queue_dept; ?>
                                        <?php $queue_dept_label = $queue_dept_value === 'General' ? 'General Medicine' : $queue_dept_value; ?>
                                        <option value="<?= htmlspecialchars($queue_dept_value, ENT_QUOTES, 'UTF-8') ?>" <?php echo ($queue_dept_value === ($department === 'General Medicine' ? 'General' : $department) || ($_POST['queue_department'] ?? '') === $queue_dept_value) ? 'selected' : ''; ?>>
                                            <?= htmlspecialchars($queue_dept_label, ENT_QUOTES, 'UTF-8') ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label for="queuePriority" class="block text-xs font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                                    <i class="fas fa-flag mr-1"></i> Queue Priority <span class="text-rose-500">*</span>
                                </label>
                                <select name="priority" id="queuePriority" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                                    <option value="Normal" <?php echo (($_POST['priority'] ?? 'Normal') === 'Normal') ? 'selected' : ''; ?>>Normal</option>
                                    <option value="Senior" <?php echo (($_POST['priority'] ?? '') === 'Senior') ? 'selected' : ''; ?>>Senior Citizen</option>
                                    <option value="PWD" <?php echo (($_POST['priority'] ?? '') === 'PWD') ? 'selected' : ''; ?>>Person with Disability (PWD)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="flex flex-wrap gap-3 mt-6 pt-4 border-t border-slate-200 dark:border-slate-700/50">
                        <button type="submit" class="px-6 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-2">
                            <i class="fas fa-save"></i> Register Patient
                        </button>
                        <button type="reset" class="px-6 py-2.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-sm font-bold rounded-xl transition-all flex items-center gap-2" onclick="this.form.reset();">
                            <i class="fas fa-undo"></i> Clear Form
                        </button>
                        <a href="queue_frontdesk.php?dept=<?php echo urlencode($department); ?>" class="px-6 py-2.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-sm font-bold rounded-xl transition-all flex items-center gap-2">
                            <i class="fas fa-ticket"></i> Go to Queue
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <script>
        const basePath = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);
        
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            if (htmlElement.classList.contains('dark')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });
        
        // ============================================
        // User Dropdown - Click to toggle
        // ============================================
        const userAvatar = document.getElementById('userAvatar');
        const userDropdown = document.getElementById('userDropdown');
        
        userAvatar.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });
        
        document.addEventListener('click', function(e) {
            if (!userAvatar.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('show');
            }
        });
        
        // ============================================
        // Mobile Menu
        // ============================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        });

        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('mobileMenuBtn');
            if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
        
        // ============================================
        // Load Stats
        // ============================================
        async function loadStats() {
            try {
                const res = await fetch(`${basePath}get_patient_count.php`);
                const data = await res.json();
                document.getElementById('totalPatients').textContent = data.total || 0;
                document.getElementById('todayRegistrations').textContent = data.today || 0;
            } catch (error) {
                console.error('Error loading stats:', error);
            }
        }
        
        // ============================================
        // Contact Number Validation
        // ============================================
        const contactInput = document.getElementById('contact');
        if (contactInput) {
            contactInput.addEventListener('input', function(e) {
                let value = this.value.replace(/[^0-9]/g, '');
                if (value.length > 11) value = value.slice(0, 11);
                this.value = value;
            });
        }
        
        // ============================================
        // DOB Validation
        // ============================================
        const dobInput = document.getElementById('dob');
        if (dobInput) {
            const today = new Date();
            const yyyy = today.getFullYear();
            const mm = String(today.getMonth() + 1).padStart(2, '0');
            const dd = String(today.getDate()).padStart(2, '0');
            dobInput.setAttribute('max', yyyy + '-' + mm + '-' + dd);
            
            dobInput.addEventListener('change', function(e) {
                const dob = new Date(this.value);
                const todayDate = new Date();
                todayDate.setHours(0, 0, 0, 0);
                dob.setHours(0, 0, 0, 0);
                
                if (dob > todayDate) {
                    alert('Date of birth cannot be in the future!\n\nPlease select a date that is today or earlier.');
                    this.value = '';
                    return;
                }
                
                if (this.value) {
                    let age = todayDate.getFullYear() - dob.getFullYear();
                    const monthDiff = todayDate.getMonth() - dob.getMonth();
                    if (monthDiff < 0 || (monthDiff === 0 && todayDate.getDate() < dob.getDate())) {
                        age--;
                    }
                    if (age > 100) {
                        alert('Note: Patient age is ' + age + ' years. Please verify the date of birth is correct.');
                    }
                    if (age > 120) {
                        alert('Age cannot exceed 120 years! Please correct the date of birth.');
                        this.value = '';
                    }
                }
            });
        }
        
        // ============================================
        // Form Validation
        // ============================================
        document.getElementById('registrationForm').addEventListener('submit', function(e) {
            const firstName = document.getElementById('firstName').value.trim();
            const middleName = document.getElementById('middleName').value.trim();
            const lastName = document.getElementById('lastName').value.trim();
            const dob = document.getElementById('dob').value;
            const gender = document.getElementById('gender').value;
            const contact = document.getElementById('contact').value.trim();
            const address = document.getElementById('address').value.trim();
            const serialNo = document.getElementById('serialNo').value.trim();
            const patientType = document.getElementById('patientType').value;
            const militaryRank = document.getElementById('militaryRank').value;
            
            let errors = [];
            
            if (!firstName) errors.push('First name is required');
            else if (!/^[\p{L}\p{M} -]+$/u.test(firstName)) errors.push('First name can contain letters, spaces, and hyphens only');
            if (middleName && !/^[\p{L}\p{M} -]+$/u.test(middleName)) errors.push('Middle name can contain letters, spaces, and hyphens only');
            if (!lastName) errors.push('Last name is required');
            else if (!/^[\p{L}\p{M} -]+$/u.test(lastName)) errors.push('Last name can contain letters, spaces, and hyphens only');
            if (!dob) errors.push('Date of birth is required');
            if (!gender) errors.push('Gender is required');
            if (!contact) errors.push('Contact number is required');
            if (contact.length > 0 && contact.length != 11) errors.push('Contact number must be exactly 11 digits');
            if (contact.length > 0 && !/^09[0-9]{9}$/.test(contact)) errors.push('Contact number must start with 09');
            if (!address) errors.push('Address is required');
            if (!serialNo) errors.push('Serial number is required');
            if (!patientType) errors.push('Patient type is required');
            if (patientType === 'Military' && !militaryRank) errors.push('Military rank is required');
            
            if (errors.length > 0) {
                e.preventDefault();
                alert('Please fix the following errors:\n\n• ' + errors.join('\n• '));
            }
        });

        const patientTypeSelect = document.getElementById('patientType');
        const militaryRankField = document.getElementById('militaryRankField');
        const militaryRankSelect = document.getElementById('militaryRank');
        function updateMilitaryRankField() {
            const isMilitary = patientTypeSelect.value === 'Military';
            militaryRankField.classList.toggle('hidden', !isMilitary);
            militaryRankSelect.required = isMilitary;
            if (!isMilitary) militaryRankSelect.value = '';
        }
        patientTypeSelect.addEventListener('change', updateMilitaryRankField);
        document.getElementById('registrationForm').addEventListener('reset', function() {
            window.setTimeout(updateMilitaryRankField, 0);
        });
        updateMilitaryRankField();
        
        loadStats();
    </script>
</body>
</html>