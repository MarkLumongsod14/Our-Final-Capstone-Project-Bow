<?php
require_once '../db.php';
require_once '../auth.php';

// Only admin can access this page
$auth->requireRole('admin');
$current_user = $auth->currentUser();

$message = '';
$error = '';
$twoFactorSetup = null;
$roles = ['admin', 'doctor', 'nurse', 'staff'];
$departments = ['General Medicine', 'Pediatrics', 'OB-Gyne', 'Internal Medicine'];

// Handle add user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $role = $_POST['role'] ?? 'staff';
    $department = $_POST['assigned_department'] ?? 'General Medicine';
    
    if (empty($username) || empty($password) || empty($full_name) || !in_array($role, $roles, true) || !in_array($department, $departments, true)) {
        $error = 'Please fill in all required fields';
    } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $result = $auth->addUser($username, $password, $full_name, $email, $role, $department);
        if ($result['success']) {
            $message = 'User added successfully';
        } else {
            $error = $result['message'] ?: 'Error adding user. Username may already exist.';
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['setup_2fa'])) {
    $setupUserId = (int)$_POST['setup_2fa'];
    $result = $auth->enableAdminTwoFactor($setupUserId);
    if ($result['success']) {
        $setupUser = $auth->getUserById($setupUserId);
        $twoFactorSetup = ['secret' => $result['secret'], 'username' => $setupUser['username'] ?? 'admin'];
    } else {
        $error = 'Could not enable two-factor authentication for this account.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $user_id = (int)($_POST['user_id'] ?? 0);
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? '';
    $status = $_POST['status'] ?? 'Active';
    $department = $_POST['assigned_department'] ?? 'General Medicine';
    $password = $_POST['password'] ?? '';

    if (!$user_id || empty($full_name) || !in_array($role, $roles, true) || !in_array($status, ['Active', 'Inactive'], true) || !in_array($department, $departments, true)) {
        $error = 'Please provide valid account details.';
    } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif ($user_id === (int)$_SESSION['user_id'] && $status !== 'Active') {
        $error = 'You cannot deactivate your own account.';
    } else {
        $result = $auth->updateUser($user_id, $full_name, $email, $role, $status, $department, $password);
        if ($result['success']) $message = 'User updated successfully';
        else $error = $result['message'] ?: 'Error updating user.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_action'])) {
    $user_id = (int)($_POST['user_id'] ?? 0);
    $user_action = $_POST['user_action'];

    if ($user_id < 1) {
        $error = 'Invalid user selected.';
    } elseif (!$auth->getUserById($user_id)) {
        $error = 'User not found.';
    } elseif ($user_action === 'deactivate' || $user_action === 'activate') {
        if ($user_action === 'deactivate' && $user_id === (int)$_SESSION['user_id']) {
            $error = 'You cannot deactivate your own account.';
        } else {
            $status = $user_action === 'deactivate' ? 'Inactive' : 'Active';
            $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
            $stmt->bind_param('si', $status, $user_id);
            if ($stmt->execute()) {
                $message = $status === 'Active' ? 'User activated successfully.' : 'User deactivated successfully.';
            } else {
                $error = 'Unable to update user status.';
            }
            $stmt->close();
        }
    } elseif ($user_action === 'reset_password') {
        $password = password_hash('clinic123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param('si', $password, $user_id);
        if ($stmt->execute()) {
            $message = 'Password reset to clinic123.';
        } else {
            $error = 'Unable to reset the user password.';
        }
        $stmt->close();
    } elseif ($user_action === 'delete') {
        $result = $auth->deleteUser($user_id);
        if ($result['success']) {
            $message = 'User deleted successfully';
        } else {
            $error = $result['message'] ?? 'Error deleting user';
        }
    }
}

$users = $auth->getAllUsers();
$loginActivity = $auth->getRecentLoginActivity();
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management | 4ID Station Hospital</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes modalFadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        
        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        /* Sidebar */
        #sidebar::-webkit-scrollbar {
            width: 4px;
        }
        #sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        #sidebar::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 2px;
        }
        .dark #sidebar::-webkit-scrollbar-thumb {
            background: #475569;
        }
        .main-content {
            transition: margin-left 0.3s ease;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        
        /* Theme toggle switch */
        .theme-switch {
            position: relative;
            width: 48px;
            height: 26px;
            background: #e2e8f0;
            border-radius: 13px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(22px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 11px; }
        
        /* User Dropdown */
        .user-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            min-width: 200px;
            z-index: 1000;
            overflow: hidden;
        }
        .dark .user-dropdown {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .user-dropdown.show {
            display: block;
        }
        .user-dropdown .dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        .dark .user-dropdown .dropdown-header {
            border-bottom-color: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-header strong {
            color: #1f2937;
            display: block;
            font-size: 0.85rem;
        }
        .dark .user-dropdown .dropdown-header strong {
            color: #f1f5f9;
        }
        .user-dropdown .dropdown-header small {
            color: #6b7280;
            font-size: 0.7rem;
        }
        .dark .user-dropdown .dropdown-header small {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            color: #374151;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
        }
        .dark .user-dropdown .dropdown-item {
            color: #e5e7eb;
        }
        .user-dropdown .dropdown-item:hover {
            background: #f3f4f6;
        }
        .dark .user-dropdown .dropdown-item:hover {
            background: rgba(255,255,255,0.04);
        }
        .user-dropdown .dropdown-item i {
            width: 18px;
            color: #6b7280;
        }
        .dark .user-dropdown .dropdown-item i {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-divider {
            height: 1px;
            background: #e5e7eb;
            margin: 4px 0;
        }
        .dark .user-dropdown .dropdown-divider {
            background: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-item.logout {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout i {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout:hover {
            background: rgba(239, 68, 68, 0.08);
        }
        
        /* Modal Styles */
        #addModal {
            background: rgba(0,0,0,0.5);
        }
        #addModal .modal-content {
            background: #ffffff;
            border-radius: 16px;
            animation: modalFadeIn 0.2s ease;
        }
        .dark #addModal .modal-content {
            background: #1f2937;
            border-color: #334155;
        }
        #addModal .modal-header {
            background: #f8fafc;
            border-bottom: 1px solid #e5e7eb;
        }
        .dark #addModal .modal-header {
            background: #111827;
            border-color: #334155;
        }
        #addModal .modal-header h3 {
            color: #0f172a;
        }
        .dark #addModal .modal-header h3 {
            color: #f8fafc;
        }
        #addModal .form-group label {
            color: #475569;
            font-size: 12px;
            font-weight: 600;
            display: block;
            margin-bottom: 4px;
        }
        .dark #addModal .form-group label {
            color: #cbd5e1;
        }
        #addModal .form-group input,
        #addModal .form-group select {
            background: #f8fafc;
            border: 1px solid #cbd5e1;
            color: #1e293b;
            width: 100%;
            padding: 10px 14px;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.2s;
        }
        .dark #addModal .form-group input,
        .dark #addModal .form-group select {
            background: #111827;
            border-color: #475569;
            color: #e2e8f0;
        }
        #addModal .form-group input:focus,
        #addModal .form-group select:focus {
            outline: none;
            border-color: #0ea5e9;
            box-shadow: 0 0 0 3px rgba(14,165,233,0.15);
        }
        
        /* Badge Styles */
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border: 1px solid transparent;
        }
        .badge-admin {
            background: rgba(14,165,233,0.12);
            color: #0284c7;
            border-color: rgba(14,165,233,0.25);
        }
        .badge-doctor {
            background: rgba(16,185,129,0.12);
            color: #059669;
            border-color: rgba(16,185,129,0.25);
        }
        .badge-nurse {
            background: rgba(99,102,241,0.12);
            color: #4f46e5;
            border-color: rgba(99,102,241,0.25);
        }
        .badge-staff {
            background: rgba(245,158,11,0.12);
            color: #d97706;
            border-color: rgba(245,158,11,0.25);
        }
        
        /* Button Styles */
        .btn {
            border-radius: 10px;
            font-weight: 700;
            transition: all 0.2s;
            cursor: pointer;
            font-size: 13px;
            padding: 8px 16px;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn:hover {
            transform: translateY(-1px);
        }
        .btn-primary {
            background: #0284c7;
            color: #fff;
        }
        .btn-primary:hover {
            background: #0369a1;
        }
        .btn-danger {
            background: rgba(244,63,94,0.1);
            color: #e11d48;
        }
        .btn-danger:hover {
            background: rgba(244,63,94,0.18);
        }
        .btn-success {
            background: #10b981;
            color: #fff;
        }
        .btn-success:hover {
            background: #059669;
        }
        .btn-ghost {
            background: transparent;
            color: #6b7280;
        }
        .btn-ghost:hover {
            background: #f3f4f6;
        }
        .dark .btn-ghost:hover {
            background: rgba(255,255,255,0.05);
        }
        
        .message {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 500;
        }
        .message-success {
            background: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
        }
        .message-error {
            background: #fff1f2;
            color: #be123c;
            border: 1px solid #fecdd3;
        }
        
        /* Table Styles */
        .table-wrapper {
            overflow-x: auto;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }
        .table th,
        .table td {
            padding: 14px 20px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
            font-size: 13px;
        }
        .dark .table th,
        .dark .table td {
            border-color: #334155;
        }
        .table th {
            background: #f8fafc;
            color: #64748b;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }
        .dark .table th {
            background: rgba(15,23,42,0.28);
            color: #94a3b8;
        }
        .table td {
            color: #475569;
        }
        .dark .table td {
            color: #cbd5e1;
        }
        .table tr:hover td {
            background: rgba(0,0,0,0.02);
        }
        .dark .table tr:hover td {
            background: rgba(255,255,255,0.02);
        }
        
        /* Status badge in table */
        .status-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .status-active {
            background: rgba(16,185,129,0.12);
            color: #059669;
        }
        .status-inactive {
            background: rgba(239,68,68,0.12);
            color: #dc2626;
        }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- SIDEBAR -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span>
                    <span>E</span>
                    <span>S</span>
                    <span>H</span>
                </div>

                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="../index.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-gauge-high text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="../patient_profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="../medical_history.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-notes-medical text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Medical History</span>
                        </a>
                    </li>
                    <li>
                        <a href="../patient_documents.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-file-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Documents</span>
                        </a>
                    </li>
                    <li>
                        <a href="../scheduled_patient.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-calendar-check text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Scheduled Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="../queue_frontdesk.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-ticket text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue System</span>
                        </a>
                    </li>
                    
                    <!-- Profile Link -->
                    <li>
                        <a href="../profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-circle text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">My Profile</span>
                        </a>
                    </li>
                    
                    <!-- User Management (Active) -->
                    <li>
                        <a href="users.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-shield text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                </ul>
                
                <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
                    <a href="../logout.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                        <div class="w-6 h-6 flex items-center justify-center shrink-0">
                            <i class="fas fa-sign-out-alt text-base text-rose-400 group-hover/link:text-rose-500 transition-colors"></i>
                        </div>
                        <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
                    </a>
                </div>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 main-content">
        
        <!-- Header -->
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                        <i class="fas fa-user-shield text-sky-500 dark:text-sky-400 mr-2"></i>User Management
                    </h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">Create and manage hospital staff accounts</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <a href="../unified_access.php" class="rounded-xl border border-sky-500/30 px-3 py-2 text-xs font-bold text-sky-600 hover:bg-sky-50 dark:text-sky-400 dark:hover:bg-sky-500/10">
                    Link System Accounts
                </a>
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($current_user['full_name']); ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400 font-medium"><?php echo ucfirst($current_user['role']); ?></div>
                </div>
                
                <!-- Dark Mode Toggle Switch -->
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-sun"></i></span>
                    <div class="theme-switch" id="themeToggle">
                        <div class="slider">
                            <span class="sun"><i class="fas fa-sun"></i></span>
                            <span class="moon"><i class="fas fa-moon"></i></span>
                        </div>
                    </div>
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-moon"></i></span>
                </div>

                <!-- User Avatar with Click Dropdown -->
                <div class="relative">
                    <div class="w-10 h-10 rounded-full bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors" id="userAvatar">
                        <i class="fas fa-user-shield text-slate-400 dark:text-slate-500 text-sm"></i>
                    </div>
                    <div class="user-dropdown" id="userDropdown">
                        <div class="dropdown-header">
                            <strong><?php echo htmlspecialchars($current_user['full_name']); ?></strong>
                            <small><?php echo ucfirst($current_user['role']); ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a href="../profile.php" class="dropdown-item">
                            <i class="fas fa-user-circle"></i> My Profile
                        </a>
                        <a href="../logout.php" class="dropdown-item logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Messages -->
        <?php if ($message): ?>
            <div class="message message-success">
                <i class="fas fa-check-circle mr-2"></i><?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="message message-error">
                <i class="fas fa-exclamation-circle mr-2"></i><?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($twoFactorSetup): ?>
            <?php $otpUri = 'otpauth://totp/' . rawurlencode('Camp Evangelista Station Hospital:' . $twoFactorSetup['username']) . '?secret=' . $twoFactorSetup['secret'] . '&issuer=' . rawurlencode('Camp Evangelista Station Hospital'); ?>
            <div class="mb-6 p-5 rounded-2xl border border-amber-300 bg-amber-50 dark:bg-amber-500/10 dark:border-amber-400/30 text-amber-800 dark:text-amber-200">
                <div class="font-bold mb-2"><i class="fas fa-shield-halved mr-2"></i>Google Authenticator setup for <?php echo htmlspecialchars($twoFactorSetup['username']); ?></div>
                <p class="text-sm mb-3">Scan this QR code in Google Authenticator, or enter the setup key manually. Save it securely before leaving this page.</p>
                <div class="flex flex-wrap items-center gap-4">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&amp;data=<?php echo rawurlencode($otpUri); ?>" alt="Google Authenticator QR code" width="150" height="150" class="bg-white p-2 rounded-lg">
                    <code class="px-3 py-2 bg-white dark:bg-slate-900 rounded-lg tracking-widest text-sm"><?php echo htmlspecialchars($twoFactorSetup['secret']); ?></code>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Add User Button & Stats -->
        <div class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-3">
                <span class="text-sm text-slate-500 dark:text-slate-400">
                    <i class="fas fa-users mr-1"></i> <?php echo count($users); ?> total users
                </span>
                <span class="text-sm text-slate-500 dark:text-slate-400">
                    <i class="fas fa-user-check text-emerald-500 mr-1"></i> 
                    <?php echo count(array_filter($users, function($u) { return $u['status'] === 'Active'; })); ?> active
                </span>
            </div>
            <button onclick="openAddUser()" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add User
            </button>
        </div>
        
        <!-- Users Table -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80">
                <div class="flex items-center gap-3">
                    <i class="fas fa-users text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200">System Users</span>
                </div>
            </div>
            <div class="table-wrapper">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Department</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-12 text-slate-400 dark:text-slate-500">
                                    <i class="fas fa-users text-3xl mb-3 block text-slate-300 dark:text-slate-600"></i>
                                    No users found
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td class="font-mono text-sm"><?php echo htmlspecialchars($user['username']); ?></td>
                                <td class="font-semibold text-slate-800 dark:text-slate-100"><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td class="text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($user['email'] ?: '—'); ?></td>
                                <td><span class="badge badge-<?php echo $user['role']; ?>"><?php echo ucfirst($user['role']); ?></span></td>
                                <td><?php echo htmlspecialchars($user['assigned_department'] ?? 'General Medicine'); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo strtolower($user['status']); ?>">
                                        <?php echo $user['status']; ?>
                                    </span>
                                </td>
                                <td class="text-sm text-slate-500 dark:text-slate-400">
                                    <?php echo $user['last_login'] ? date('M d, Y H:i', strtotime($user['last_login'])) : 'Never'; ?>
                                </td>
                                <td>
                                    <div class="flex items-center gap-2">
                                        <button type="button" class="btn btn-primary text-xs px-3 py-1.5 edit-user-btn"
                                                data-id="<?php echo $user['id']; ?>"
                                                data-username="<?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?>"
                                                data-full-name="<?php echo htmlspecialchars($user['full_name'], ENT_QUOTES); ?>"
                                                data-email="<?php echo htmlspecialchars($user['email'] ?? '', ENT_QUOTES); ?>"
                                                data-role="<?php echo htmlspecialchars($user['role'], ENT_QUOTES); ?>"
                                                data-status="<?php echo htmlspecialchars($user['status'], ENT_QUOTES); ?>"
                                                data-department="<?php echo htmlspecialchars($user['assigned_department'] ?? 'General Medicine', ENT_QUOTES); ?>">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <form method="POST" class="inline" onsubmit="return confirm('<?php echo $user['status'] === 'Active' ? 'Deactivate' : 'Activate'; ?> this user?')">
                                            <input type="hidden" name="user_id" value="<?php echo (int)$user['id']; ?>">
                                            <button type="submit" name="user_action" value="<?php echo $user['status'] === 'Active' ? 'deactivate' : 'activate'; ?>"
                                                    class="btn btn-danger text-xs px-3 py-1.5"
                                                    <?php echo $user['status'] === 'Active' && (int)$user['id'] === (int)$_SESSION['user_id'] ? 'disabled title="You cannot deactivate your own account."' : ''; ?>>
                                                <i class="fas fa-ban"></i> <?php echo $user['status'] === 'Active' ? 'Deactivate' : 'Activate'; ?>
                                            </button>
                                        </form>
                                        <form method="POST" class="inline" onsubmit="return confirm('Reset this user password to clinic123?')">
                                            <input type="hidden" name="user_id" value="<?php echo (int)$user['id']; ?>">
                                            <button type="submit" name="user_action" value="reset_password" class="btn btn-warning text-xs px-3 py-1.5">
                                                <i class="fas fa-key"></i> Reset
                                            </button>
                                        </form>
                                        <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to permanently delete this user?')">
                                            <input type="hidden" name="user_id" value="<?php echo (int)$user['id']; ?>">
                                            <button type="submit" name="user_action" value="delete" class="btn btn-danger text-xs px-3 py-1.5"
                                                    <?php echo (int)$user['id'] === (int)$_SESSION['user_id'] ? 'disabled title="You cannot delete your own account."' : ''; ?>>
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                        <?php if ($user['role'] === 'admin'): ?>
                                            <form method="POST" class="inline" onsubmit="return confirm('Generate a new Google Authenticator secret for this admin? The old code will stop working.')">
                                                <button type="submit" name="setup_2fa" value="<?php echo $user['id']; ?>" class="btn btn-warning text-xs px-3 py-1.5">
                                                    <i class="fas fa-shield-halved"></i> Setup 2FA
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Login Activity -->
        <div class="mt-6 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80">
                <div class="flex items-center gap-3">
                    <i class="fas fa-clock text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200">Recent Login Activity</span>
                </div>
            </div>
            <div class="table-wrapper">
                <table class="table">
                    <thead><tr><th>Time</th><th>Username</th><th>Full Name</th><th>IP Address</th><th>Status</th><th>Reason</th></tr></thead>
                    <tbody>
                    <?php if (empty($loginActivity)): ?>
                        <tr><td colspan="6" class="text-center py-8 text-slate-400 dark:text-slate-500">No login activity recorded yet.</td></tr>
                    <?php else: foreach ($loginActivity as $activity): ?>
                        <tr>
                            <td class="text-sm text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars(date('M d, Y h:i A', strtotime($activity['attempted_at']))); ?></td>
                            <td class="font-mono text-sm"><?php echo htmlspecialchars($activity['username']); ?></td>
                            <td class="font-semibold text-slate-800 dark:text-slate-100"><?php echo htmlspecialchars($activity['full_name'] ?: 'Unknown'); ?></td>
                            <td><code><?php echo htmlspecialchars($activity['ip_address']); ?></code></td>
                            <td><span class="status-badge status-<?php echo strtolower($activity['status']); ?>"><?php echo htmlspecialchars($activity['status']); ?></span></td>
                            <td><?php echo htmlspecialchars($activity['reason']); ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- User Modal -->
    <div id="addModal" style="display: none; position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 2000; backdrop-filter: blur(4px);">
        <div class="modal-content" style="background: white; border-radius: 16px; width: 90%; max-width: 520px; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
            <div class="modal-header" style="padding: 20px 24px; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 10; background: #f8fafc;">
                <h3 id="userModalTitle" style="font-size: 18px; font-weight: 700; color: #0f172a; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-user-plus text-sky-500"></i> Add New User
                </h3>
                <button onclick="document.getElementById('addModal').style.display='none'" style="background: none; border: none; font-size: 20px; color: #94a3b8; cursor: pointer; padding: 4px 8px; border-radius: 8px; transition: background 0.2s;" onmouseover="this.style.background='#f1f5f9'" onmouseout="this.style.background='transparent'">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST" style="padding: 24px;" id="userForm">
                <input type="hidden" name="user_id" id="userId">
                
                <div class="form-group">
                    <label>Username <span style="color: #ef4444;">*</span></label>
                    <input type="text" name="username" id="userUsername" required placeholder="Enter username">
                </div>
                
                <div class="form-group">
                    <label>Password <span style="color: #ef4444;">*</span></label>
                    <input type="password" name="password" id="userPassword" placeholder="Enter password" minlength="6" pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{6,}" title="Include at least one uppercase letter, one lowercase letter, one number, one special character, and at least 6 characters.">
                    <small id="passwordHint" style="color: #94a3b8; font-size: 11px; display: block; margin-top: 4px;">Required for new accounts. Use uppercase, lowercase, number, and special character (minimum 6 characters).</small>
                </div>
                
                <div class="form-group">
                    <label>Full Name <span style="color: #ef4444;">*</span></label>
                    <input type="text" name="full_name" id="userFullName" required placeholder="Enter full name">
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" id="userEmail" placeholder="Enter email address">
                </div>
                
                <div class="form-group">
                    <label>Role <span style="color: #ef4444;">*</span></label>
                    <select name="role" id="userRole" required>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?php echo $role; ?>"><?php echo ucfirst($role); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" id="statusGroup" style="display:none;">
                    <label>Status <span style="color: #ef4444;">*</span></label>
                    <select name="status" id="userStatus">
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Department <span style="color: #ef4444;">*</span></label>
                    <select name="assigned_department" id="userDepartment">
                        <?php foreach ($departments as $department): ?>
                            <option value="<?php echo htmlspecialchars($department); ?>"><?php echo htmlspecialchars($department); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="display: flex; gap: 12px; margin-top: 24px; padding-top: 16px; border-top: 1px solid #e5e7eb;">
                    <button type="submit" name="add_user" id="userSubmit" class="btn btn-primary" style="flex: 1; justify-content: center;">
                        <i class="fas fa-save"></i> Add User
                    </button>
                    <button type="button" onclick="document.getElementById('addModal').style.display='none'" class="btn btn-ghost" style="padding: 8px 20px;">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            localStorage.setItem('theme', htmlElement.classList.contains('dark') ? 'dark' : 'light');
        });
        
        // ============================================
        // User Dropdown - Click to toggle
        // ============================================
        const userAvatar = document.getElementById('userAvatar');
        const userDropdown = document.getElementById('userDropdown');
        
        userAvatar.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });
        
        document.addEventListener('click', function(e) {
            if (!userAvatar.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('show');
            }
        });
        
        // ============================================
        // Mobile Menu
        // ============================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        });

        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('mobileMenuBtn');
            if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
        
        // ============================================
        // Modal Functions
        // ============================================
        function openAddUser() {
            const form = document.getElementById('userForm');
            form.reset();
            form.querySelector('input[name="update_user"]')?.remove();
            document.getElementById('userModalTitle').innerHTML = '<i class="fas fa-user-plus text-sky-500"></i> Add New User';
            document.getElementById('userPassword').required = true;
            document.getElementById('passwordHint').textContent = 'Required for new accounts';
            document.getElementById('userSubmit').textContent = 'Add User';
            document.getElementById('userSubmit').setAttribute('name', 'add_user');
            document.getElementById('statusGroup').style.display = 'none';
            document.getElementById('userId').value = '';
            document.getElementById('addModal').style.display = 'flex';
            document.getElementById('addModal').style.justifyContent = 'center';
            document.getElementById('addModal').style.alignItems = 'center';
        }

        document.querySelectorAll('.edit-user-btn').forEach(function (button) {
            button.addEventListener('click', function () {
                const form = document.getElementById('userForm');
                form.querySelector('input[name="update_user"]')?.remove();
                form.insertAdjacentHTML('afterbegin', '<input type="hidden" name="update_user" value="1">');
                document.getElementById('userSubmit').removeAttribute('name');
                document.getElementById('userModalTitle').innerHTML = '<i class="fas fa-user-edit text-amber-500"></i> Edit User: ' + this.dataset.username;
                document.getElementById('userId').value = this.dataset.id;
                document.getElementById('userUsername').value = this.dataset.username;
                document.getElementById('userUsername').disabled = true;
                document.getElementById('userFullName').value = this.dataset.fullName;
                document.getElementById('userEmail').value = this.dataset.email;
                document.getElementById('userRole').value = this.dataset.role;
                document.getElementById('userStatus').value = this.dataset.status;
                document.getElementById('userDepartment').value = this.dataset.department;
                document.getElementById('userPassword').required = false;
                document.getElementById('passwordHint').textContent = 'Leave blank to keep current password';
                document.getElementById('userSubmit').textContent = 'Save Changes';
                document.getElementById('statusGroup').style.display = 'block';
                document.getElementById('addModal').style.display = 'flex';
                document.getElementById('addModal').style.justifyContent = 'center';
                document.getElementById('addModal').style.alignItems = 'center';
            });
        });

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('addModal');
            if (event.target === modal) {
                modal.style.display = 'none';
                // Re-enable username field if it was disabled
                document.getElementById('userUsername').disabled = false;
            }
        }

        // Reset username disabled state when modal closes via other methods
        document.querySelector('#addModal .modal-header button')?.addEventListener('click', function() {
            document.getElementById('userUsername').disabled = false;
        });
    </script>
</body>
</html>