<?php
// medical_history.php - Patient Medical History Management
// Camp Evangelista Station Hospital

require_once 'db.php';
require_once 'auth.php';

$auth->requireLogin();
$current_user = $auth->currentUser();

// Fetch active patients for the history form dropdown.
$patientsResult = $conn->query("SELECT mrn, first_name, last_name FROM patients WHERE status = 'Active' ORDER BY last_name, first_name");
$patients = $patientsResult ? $patientsResult->fetch_all(MYSQLI_ASSOC) : [];

// Handle CRUD for medical history
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $mh_id = $_POST['id'] ?? null;
    $patient_mrn = $_POST['patient_mrn'] ?? null;
    $allergies = $_POST['allergies'] ?? '';
    $medications = $_POST['medications'] ?? '';
    $diagnosis = $_POST['diagnosis'] ?? '';
    $notes = $_POST['notes'] ?? '';

    if ($action === 'add' && $patient_mrn) {
        $stmt = $conn->prepare("INSERT INTO medical_history (patient_mrn, allergies, medications, diagnosis, notes) VALUES (?,?,?,?,?)");
        $stmt->bind_param("issss", $patient_mrn, $allergies, $medications, $diagnosis, $notes);
        $stmt->execute();
        $stmt->close();
    }

    if ($action === 'update' && $mh_id) {
        $stmt = $conn->prepare("UPDATE medical_history SET allergies=?, medications=?, diagnosis=?, notes=? WHERE id=?");
        $stmt->bind_param("ssssi", $allergies, $medications, $diagnosis, $notes, $mh_id);
        $stmt->execute();
        $stmt->close();
    }

    if ($action === 'delete' && $mh_id) {
        $stmt = $conn->prepare("DELETE FROM medical_history WHERE id=?");
        $stmt->bind_param("i", $mh_id);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: medical_history.php?patient_mrn=" . (int)$patient_mrn);
    exit;
}

// Selected patient
$selected_patient_mrn = !empty($_GET['patient_mrn']) ? (int)$_GET['patient_mrn'] : null;
$page_size = 10;
$patient_page = max(1, (int)($_GET['patient_page'] ?? 1));
$patient_search = trim($_GET['patient_search'] ?? '');
$patient_search_pattern = '%' . $patient_search . '%';
$patient_count_stmt = $conn->prepare("SELECT COUNT(*) AS total FROM patients WHERE status = 'Active' AND (? = '' OR first_name LIKE ? OR last_name LIKE ? OR CAST(mrn AS CHAR) LIKE ? OR contact LIKE ?)");
$patient_count_stmt->bind_param('sssss', $patient_search, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern);
$patient_count_stmt->execute();
$patient_directory_total = (int)$patient_count_stmt->get_result()->fetch_assoc()['total'];
$patient_count_stmt->close();
$patient_total_pages = max(1, (int)ceil($patient_directory_total / $page_size));
$patient_page = min($patient_page, $patient_total_pages);
$patient_offset = ($patient_page - 1) * $page_size;
$patient_list_stmt = $conn->prepare("
    SELECT p.mrn, p.first_name, p.last_name, p.gender, p.dob, p.contact, p.email,
           COUNT(mh.id) AS history_count
    FROM patients p
    LEFT JOIN medical_history mh ON mh.patient_mrn = p.mrn
    WHERE p.status = 'Active'
      AND (? = '' OR p.first_name LIKE ? OR p.last_name LIKE ? OR CAST(p.mrn AS CHAR) LIKE ? OR p.contact LIKE ?)
    GROUP BY p.mrn, p.first_name, p.last_name, p.gender, p.dob, p.contact, p.email
    ORDER BY p.last_name, p.first_name
    LIMIT ? OFFSET ?
");
$patient_list_stmt->bind_param('sssssii', $patient_search, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern, $patient_search_pattern, $page_size, $patient_offset);
$patient_list_stmt->execute();
$patient_directory = $patient_list_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$patient_list_stmt->close();
$history = [];
$patient = null;
$history_page = max(1, (int)($_GET['history_page'] ?? 1));
$history_search = trim($_GET['history_search'] ?? '');
$history_search_pattern = '%' . $history_search . '%';
$history_total = 0;
$history_total_pages = 1;
$history_offset = 0;

if ($selected_patient_mrn) {
    $history_count_stmt = $conn->prepare("SELECT COUNT(*) AS total FROM medical_history WHERE patient_mrn = ? AND (? = '' OR diagnosis LIKE ? OR medications LIKE ? OR allergies LIKE ? OR notes LIKE ?)");
    $history_count_stmt->bind_param('isssss', $selected_patient_mrn, $history_search, $history_search_pattern, $history_search_pattern, $history_search_pattern, $history_search_pattern);
    $history_count_stmt->execute();
    $history_counts = $history_count_stmt->get_result()->fetch_assoc();
    $history_total = (int)$history_counts['total'];
    $history_count_stmt->close();
    $history_total_pages = max(1, (int)ceil($history_total / $page_size));
    $history_page = min($history_page, $history_total_pages);
    $history_offset = ($history_page - 1) * $page_size;

    $stmt = $conn->prepare("
        SELECT * FROM medical_history
        WHERE patient_mrn = ?
          AND (? = '' OR diagnosis LIKE ? OR medications LIKE ? OR allergies LIKE ? OR notes LIKE ?)
        ORDER BY id DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->bind_param("isssssii", $selected_patient_mrn, $history_search, $history_search_pattern, $history_search_pattern, $history_search_pattern, $history_search_pattern, $page_size, $history_offset);
    $stmt->execute();
    $res = $stmt->get_result();
    $history = $res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $stmt = $conn->prepare("SELECT *, CONCAT(first_name, ' ', last_name) as full_name FROM patients WHERE mrn=?");
    $stmt->bind_param("i", $selected_patient_mrn);
    $stmt->execute();
    $res = $stmt->get_result();
    $patient = $res->fetch_assoc();
    $stmt->close();
}

// Format MRN function
function formatMRN($mrn) {
    return str_pad($mrn, 6, '0', STR_PAD_LEFT);
}

function medicalHistoryPageUrl($page, $pageKey, $patientMrn, $searchKey, $search) {
    $params = [$pageKey => $page];
    if ($patientMrn) $params['patient_mrn'] = $patientMrn;
    if ($search !== '') $params[$searchKey] = $search;
    return 'medical_history.php?' . http_build_query($params) . ($patientMrn ? '#patient-records' : '#patient-directory');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical History | 4ID Station Hospital</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes modalFadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        #sidebar::-webkit-scrollbar {
            width: 4px;
        }
        #sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        #sidebar::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 2px;
        }
        .dark #sidebar::-webkit-scrollbar-thumb {
            background: #475569;
        }
        .main-content {
            transition: margin-left 0.3s ease;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        
        .theme-switch {
            position: relative;
            width: 48px;
            height: 26px;
            background: #e2e8f0;
            border-radius: 13px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(22px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 11px; }
        
        /* User Dropdown */
        .user-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            min-width: 200px;
            z-index: 1000;
            overflow: hidden;
        }
        .dark .user-dropdown {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .user-dropdown.show {
            display: block;
        }
        .user-dropdown .dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        .dark .user-dropdown .dropdown-header {
            border-bottom-color: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-header strong {
            color: #1f2937;
            display: block;
            font-size: 0.85rem;
        }
        .dark .user-dropdown .dropdown-header strong {
            color: #f1f5f9;
        }
        .user-dropdown .dropdown-header small {
            color: #6b7280;
            font-size: 0.7rem;
        }
        .dark .user-dropdown .dropdown-header small {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            color: #374151;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
        }
        .dark .user-dropdown .dropdown-item {
            color: #e5e7eb;
        }
        .user-dropdown .dropdown-item:hover {
            background: #f3f4f6;
        }
        .dark .user-dropdown .dropdown-item:hover {
            background: rgba(255,255,255,0.04);
        }
        .user-dropdown .dropdown-item i {
            width: 18px;
            color: #6b7280;
        }
        .dark .user-dropdown .dropdown-item i {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-divider {
            height: 1px;
            background: #e5e7eb;
            margin: 4px 0;
        }
        .dark .user-dropdown .dropdown-divider {
            background: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-item.logout {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout i {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout:hover {
            background: rgba(239, 68, 68, 0.08);
        }
        
        /* Modal styles */
        .modal-backdrop {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(4px);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            padding: 16px;
        }
        .modal-backdrop.show { display: flex; }
        .modal {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 20px;
            width: 100%;
            max-width: 560px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalFadeIn 0.2s ease;
        }
        .dark .modal {
            background: #1f2937;
            border-color: rgba(255,255,255,0.08);
        }
        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .dark .modal-header { border-bottom-color: rgba(255,255,255,0.06); }
        .modal-header h3 {
            font-size: 1.1rem;
            font-weight: 700;
            color: #1f2937;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .dark .modal-header h3 { color: #f1f5f9; }
        .modal-header h3 i { color: #0284c7; }
        .dark .modal-header h3 i { color: #38bdf8; }
        .modal-close {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            border: 1px solid #e5e7eb;
            background: transparent;
            color: #6b7280;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }
        .dark .modal-close { border-color: rgba(255,255,255,0.06); color: #9ca3af; }
        .modal-close:hover { background: #f3f4f6; }
        .dark .modal-close:hover { background: rgba(255,255,255,0.04); }
        .modal-body { padding: 24px; }
        .modal-actions {
            display: flex;
            gap: 12px;
            padding: 16px 24px 24px;
            border-top: 1px solid #e5e7eb;
        }
        .dark .modal-actions { border-top-color: rgba(255,255,255,0.06); }
        
        .form-group { margin-bottom: 16px; }
        .form-group label {
            display: block;
            font-size: 0.7rem;
            font-weight: 700;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }
        .dark .form-group label { color: #9ca3af; }
        .form-group label i { color: #9ca3af; margin-right: 4px; }
        .dark .form-group label i { color: #6b7280; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            background: #f8fafc;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            color: #1f2937;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s ease;
            outline: none;
        }
        .dark .form-group input, .dark .form-group select, .dark .form-group textarea {
            background: #111827;
            border-color: rgba(255,255,255,0.06);
            color: #f1f5f9;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: #0284c7;
            box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.08);
        }
        .dark .form-group input:focus, .dark .form-group select:focus, .dark .form-group textarea:focus {
            border-color: #38bdf8;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        .form-group select option {
            background: #ffffff;
            color: #1f2937;
        }
        .dark .form-group select option {
            background: #1f2937;
            color: #f1f5f9;
        }
        .form-group .help-text {
            font-size: 0.6rem;
            color: #6b7280;
            margin-top: 4px;
        }
        .dark .form-group .help-text { color: #9ca3af; }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- SIDEBAR -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span>
                    <span>E</span>
                    <span>S</span>
                    <span>H</span>
                </div>

                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="index.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-gauge-high text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="medical_history.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-notes-medical text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Medical History</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_documents.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-file-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Documents</span>
                        </a>
                    </li>
                    <li>
                        <a href="scheduled_patient.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-calendar-check text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Scheduled Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_frontdesk.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-ticket text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue System</span>
                        </a>
                    </li>
                    
                    <!-- Profile Link -->
                    <li>
                        <a href="profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-circle text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">My Profile</span>
                        </a>
                    </li>
                    <?php if (($current_user['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="admin/users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-shield text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i></div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                
                <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
                    <a href="logout.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                        <div class="w-6 h-6 flex items-center justify-center shrink-0">
                            <i class="fas fa-sign-out-alt text-base text-rose-400 group-hover/link:text-rose-500 transition-colors"></i>
                        </div>
                        <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
                    </a>
                </div>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 main-content">
        
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">Medical History</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">View and manage patient medical records</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($current_user['full_name']); ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400 font-medium"><?php echo ucfirst($current_user['role']); ?></div>
                </div>
                
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 dark:text-slate-500">
                        <i class="fas fa-sun"></i>
                    </span>
                    <div class="theme-switch" id="themeToggle">
                        <div class="slider">
                            <span class="sun"><i class="fas fa-sun"></i></span>
                            <span class="moon"><i class="fas fa-moon"></i></span>
                        </div>
                    </div>
                    <span class="text-xs text-slate-400 dark:text-slate-500">
                        <i class="fas fa-moon"></i>
                    </span>
                </div>

                <!-- User Avatar with Click Dropdown -->
                <div class="relative">
                    <div class="w-10 h-10 rounded-full bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors" id="userAvatar">
                        <i class="fas fa-user text-slate-400 dark:text-slate-500 text-sm"></i>
                    </div>
                    <div class="user-dropdown" id="userDropdown">
                        <div class="dropdown-header">
                            <strong><?php echo htmlspecialchars($current_user['full_name']); ?></strong>
                            <small><?php echo ucfirst($current_user['role']); ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user-circle"></i> My Profile
                        </a>
                        <a href="logout.php" class="dropdown-item logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Patient Directory -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm mb-8">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <i class="fas fa-user-search text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200">Patient Medical History</span>
                </div>
                <form method="GET" action="medical_history.php" class="flex items-center gap-2 bg-white dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-full px-3 py-1.5">
                    <i class="fas fa-search text-slate-400 dark:text-slate-500 text-sm"></i>
                    <input type="search" name="patient_search" value="<?= htmlspecialchars($patient_search) ?>" placeholder="Search patient..." class="bg-transparent border-none outline-none text-sm text-slate-700 dark:text-slate-200 w-36 md:w-48">
                    <button type="submit" class="text-sky-600 dark:text-sky-400 text-xs font-bold">Search</button>
                </form>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse min-w-[850px]">
                    <thead><tr class="bg-slate-50/50 dark:bg-slate-800/40 text-left border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.65rem] uppercase tracking-wider font-bold"><th class="px-5 py-3.5">Patient</th><th class="px-5 py-3.5">MRN</th><th class="px-5 py-3.5">DOB / Gender</th><th class="px-5 py-3.5">Contact</th><th class="px-5 py-3.5">Records</th><th class="px-5 py-3.5">Action</th></tr></thead>
                    <tbody id="patientDirectory" class="divide-y divide-slate-300/80 dark:divide-slate-700/50 text-xs md:text-sm text-slate-700 dark:text-slate-200">
                    <?php foreach($patient_directory as $p): ?>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                            <td class="px-5 py-3.5 font-semibold text-slate-800 dark:text-slate-100"><?= htmlspecialchars($p['last_name'] . ', ' . $p['first_name']) ?></td>
                            <td class="px-5 py-3.5"><span class="font-mono text-xs bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded-md text-slate-500 dark:text-slate-400"><?= formatMRN($p['mrn']) ?></span></td>
                            <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400"><?= $p['dob'] ? date('M d, Y', strtotime($p['dob'])) : '—' ?> / <?= htmlspecialchars($p['gender'] ?: '—') ?></td>
                            <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400"><?= htmlspecialchars($p['email'] ?: ($p['contact'] ?: '—')) ?></td>
                            <td class="px-5 py-3.5"><span class="text-sky-600 dark:text-sky-400 font-bold"><?= (int)$p['history_count'] ?></span></td>
                            <td class="px-5 py-3.5"><a href="medical_history.php?patient_mrn=<?= (int)$p['mrn'] ?>&patient_page=<?= $patient_page ?>&patient_search=<?= urlencode($patient_search) ?>#patient-records" class="px-3 py-1.5 bg-sky-50 dark:bg-sky-500/10 hover:bg-sky-100 dark:hover:bg-sky-500/20 text-sky-600 dark:text-sky-400 text-xs font-bold rounded-lg inline-flex items-center gap-1"><i class="fas fa-eye"></i> View History</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-700/70 flex flex-wrap items-center justify-between gap-3">
                <span class="text-xs text-slate-500 dark:text-slate-400">Showing <?= $patient_directory_total === 0 ? 0 : $patient_offset + 1 ?>–<?= min($patient_offset + count($patient_directory), $patient_directory_total) ?> of <?= number_format($patient_directory_total) ?></span>
                <?php if ($patient_total_pages > 1): ?>
                    <nav class="flex items-center gap-2" aria-label="Patient directory pagination">
                        <?php if ($patient_page > 1): ?><a href="<?= htmlspecialchars(medicalHistoryPageUrl($patient_page - 1, 'patient_page', null, 'patient_search', $patient_search)) ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Previous</a><?php endif; ?>
                        <span class="text-xs font-semibold text-slate-600 dark:text-slate-300">Page <?= $patient_page ?> of <?= $patient_total_pages ?></span>
                        <?php if ($patient_page < $patient_total_pages): ?><a href="<?= htmlspecialchars(medicalHistoryPageUrl($patient_page + 1, 'patient_page', null, 'patient_search', $patient_search)) ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Next</a><?php endif; ?>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if($selected_patient_mrn && $patient): ?>
        <!-- Patient Records Panel -->
        <div id="patientRecordsModal" class="modal-backdrop show">
        <div id="patient-records" class="modal bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
            <div class="relative px-6 py-4 pr-24 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <i class="fas fa-user-circle text-sky-500 dark:text-sky-400"></i>
                    <span class="text-sm font-bold text-slate-800 dark:text-slate-200">Patient Records</span>
                    <span class="text-xs text-slate-400 dark:text-slate-400 font-medium"><?= number_format($history_total) ?> record(s)</span>
                </div>
                <form method="GET" action="medical_history.php" class="flex items-center gap-2 bg-white dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-full px-3 py-1.5">
                    <input type="hidden" name="patient_mrn" value="<?= (int)$selected_patient_mrn ?>">
                    <input type="hidden" name="patient_page" value="<?= $patient_page ?>">
                    <input type="hidden" name="patient_search" value="<?= htmlspecialchars($patient_search) ?>">
                    <i class="fas fa-search text-slate-400 dark:text-slate-500 text-sm"></i>
                    <input type="search" name="history_search" value="<?= htmlspecialchars($history_search) ?>" placeholder="Search records..." class="bg-transparent border-none outline-none text-sm text-slate-700 dark:text-slate-200 w-36 md:w-48">
                    <button type="submit" class="text-sky-600 dark:text-sky-400 text-xs font-bold">Search</button>
                </form>
                <a href="medical_history.php" class="absolute top-4 right-4 px-3 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-xs font-bold rounded-lg inline-flex items-center gap-1"><i class="fas fa-times"></i> Close</a>
                <button id="addHistoryBtn" class="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-2">
                    <i class="fas fa-plus"></i> Add Record
                </button>
            </div>
            <div class="p-6">
                <!-- Patient Info Bar -->
                <div class="mb-6 p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <h4 class="text-base font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></h4>
                        <p class="text-sm text-slate-500 dark:text-slate-400">MRN: <?= formatMRN($patient['mrn']) ?> | DOB: <?= date('M d, Y', strtotime($patient['dob'])) ?> | Gender: <?= $patient['gender'] ?></p>
                    </div>
                    <div class="px-4 py-2 bg-sky-50 dark:bg-sky-500/10 border border-sky-200 dark:border-sky-400/20 rounded-full text-sm font-semibold text-sky-600 dark:text-sky-400">
                        <i class="fas fa-notes-medical mr-1.5"></i> <?= number_format($history_total) ?> Record(s)
                    </div>
                </div>
                
                <?php if(empty($history)): ?>
                    <div class="text-center py-12 text-slate-400 dark:text-slate-400">
                        <i class="fas fa-notes-medical text-3xl mb-3 block text-slate-300 dark:text-slate-600"></i>
                        <p class="font-medium">No medical history records found</p>
                        <p class="text-sm text-slate-400 dark:text-slate-500 mt-1">Click "Add Record" to create a new medical history entry</p>
                    </div>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse min-w-[600px]">
                            <thead>
                                <tr class="bg-slate-50/50 dark:bg-slate-800/40 text-left border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.65rem] uppercase tracking-wider font-bold">
                                    <th class="px-5 py-3.5" style="width: 30%">Diagnosis</th>
                                    <th class="px-5 py-3.5" style="width: 25%">Medications</th>
                                    <th class="px-5 py-3.5" style="width: 25%">Allergies</th>
                                    <th class="px-5 py-3.5" style="width: 20%">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-300/80 dark:divide-slate-700/50 text-xs md:text-sm text-slate-700 dark:text-slate-200" id="historyList">
                                <?php foreach($history as $h): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors duration-150" 
                                    data-id="<?= $h['id'] ?>" 
                                    data-allergies="<?= htmlspecialchars($h['allergies'] ?? '') ?>" 
                                    data-medications="<?= htmlspecialchars($h['medications'] ?: '—') ?>" 
                                    data-diagnosis="<?= htmlspecialchars($h['diagnosis'] ?: '—') ?>"
                                    data-notes="<?= htmlspecialchars($h['notes'] ?: '') ?>">
                                    <td class="px-5 py-3.5">
                                        <span class="font-semibold text-slate-800 dark:text-slate-100"><?= htmlspecialchars($h['diagnosis'] ?: '—') ?></span>
                                        <?php if(!empty($h['notes'])): ?>
                                            <br><span class="text-xs text-slate-400 dark:text-slate-500"><?= htmlspecialchars(substr($h['notes'], 0, 100)) ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-5 py-3.5"><?= htmlspecialchars($h['medications'] ?: '—') ?></td>
                                    <td class="px-5 py-3.5"><?= htmlspecialchars($h['allergies'] ?: '—') ?></td>
                                    <td class="px-5 py-3.5">
                                        <button class="px-3 py-1.5 bg-amber-50 dark:bg-amber-500/10 hover:bg-amber-100 dark:hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 text-xs font-bold rounded-lg transition-colors editHistoryBtn">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?= $h['id'] ?>">
                                            <input type="hidden" name="patient_mrn" value="<?= $selected_patient_mrn ?>">
                                            <button type="submit" class="px-3 py-1.5 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-bold rounded-lg transition-colors" onclick="return confirm('Are you sure you want to delete this medical history record? This action cannot be undone.')">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                <?php if ($history_total_pages > 1): ?>
                    <div class="mt-4 flex flex-wrap items-center justify-between gap-3">
                        <span class="text-xs text-slate-500 dark:text-slate-400">Showing <?= $history_offset + 1 ?>–<?= min($history_offset + count($history), $history_total) ?> of <?= number_format($history_total) ?> records</span>
                        <nav class="flex items-center gap-2" aria-label="Medical history pagination">
                            <?php if ($history_page > 1): ?><a href="<?= htmlspecialchars(medicalHistoryPageUrl($history_page - 1, 'history_page', $selected_patient_mrn, 'history_search', $history_search)) ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Previous</a><?php endif; ?>
                            <span class="text-xs font-semibold text-slate-600 dark:text-slate-300">Page <?= $history_page ?> of <?= $history_total_pages ?></span>
                            <?php if ($history_page < $history_total_pages): ?><a href="<?= htmlspecialchars(medicalHistoryPageUrl($history_page + 1, 'history_page', $selected_patient_mrn, 'history_search', $history_search)) ?>" class="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200">Next</a><?php endif; ?>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        </div>
        <?php endif; ?>
    </main>

    <!-- Add/Edit Modal -->
    <div id="historyModal" class="modal-backdrop">
        <div class="modal">
            <div class="modal-header">
                <h3 id="modalTitle"><i class="fas fa-notes-medical"></i> Medical History</h3>
                <button class="modal-close" id="closeModal">&times;</button>
            </div>
            <form method="POST" id="historyForm">
                <div class="modal-body">
                    <input type="hidden" name="action" id="action" value="add">
                    <input type="hidden" name="id" id="historyId">
                    <input type="hidden" name="patient_mrn" value="<?= $selected_patient_mrn ?>">
                    
                    <div class="form-group">
                        <label><i class="fas fa-stethoscope"></i> Diagnosis / Condition</label>
                        <textarea name="diagnosis" id="diagnosis" rows="3" placeholder="Enter diagnosis or clinical notes..."></textarea>
                        <div class="help-text">Describe the diagnosis or condition</div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-pills"></i> Medications</label>
                        <input type="text" name="medications" id="medications" placeholder="e.g., Paracetamol 500mg, Amoxicillin 250mg">
                        <div class="help-text">List prescribed medications</div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-allergies"></i> Allergies</label>
                        <input type="text" name="allergies" id="allergies" placeholder="e.g., Penicillin, Peanuts, Dust">
                        <div class="help-text">Document any known allergies</div>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-file-alt"></i> Additional Notes</label>
                        <textarea name="notes" id="notes" rows="2" placeholder="Additional notes..."></textarea>
                    </div>
                </div>
                <div class="modal-actions">
                    <button type="button" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-sm font-bold rounded-xl transition-colors" id="cancelBtn">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-2" id="saveBtn">
                        <i class="fas fa-save"></i> Save Record
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            if (htmlElement.classList.contains('dark')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });
        
        // ============================================
        // User Dropdown - Click to toggle
        // ============================================
        const userAvatar = document.getElementById('userAvatar');
        const userDropdown = document.getElementById('userDropdown');
        
        userAvatar.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });
        
        document.addEventListener('click', function(e) {
            if (!userAvatar.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('show');
            }
        });

        // ============================================
        // Mobile Menu
        // ============================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        });

        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('mobileMenuBtn');
            if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
        
        // ============================================
        // DOM Elements
        // ============================================
        const modal = document.getElementById('historyModal');
        const modalTitle = document.getElementById('modalTitle');
        const form = document.getElementById('historyForm');
        const addBtn = document.getElementById('addHistoryBtn');
        const closeBtn = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');
        const saveBtn = document.getElementById('saveBtn');
        
        const actionField = document.getElementById('action');
        const historyId = document.getElementById('historyId');
        const diagnosis = document.getElementById('diagnosis');
        const medications = document.getElementById('medications');
        const allergies = document.getElementById('allergies');
        const notes = document.getElementById('notes');
        
        // ============================================
        // Modal Controls
        // ============================================
        function closeModal() {
            modal.classList.remove('show');
            form.reset();
        }
        
        if (addBtn) {
            addBtn.addEventListener('click', () => {
                modalTitle.innerHTML = '<i class="fas fa-plus-circle"></i> Add Medical Record';
                actionField.value = 'add';
                historyId.value = '';
                diagnosis.value = '';
                medications.value = '';
                allergies.value = '';
                notes.value = '';
                modal.classList.add('show');
            });
        }
        
        closeBtn.addEventListener('click', closeModal);
        cancelBtn.addEventListener('click', closeModal);
        window.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
        
        // ============================================
        // Edit Button Handler
        // ============================================
        function attachEditHandlers() {
            document.querySelectorAll('.editHistoryBtn').forEach(btn => {
                btn.removeEventListener('click', handleEditClick);
                btn.addEventListener('click', handleEditClick);
            });
        }
        
        function handleEditClick(e) {
            const btn = e.currentTarget;
            const tr = btn.closest('tr');
            modalTitle.innerHTML = '<i class="fas fa-edit"></i> Edit Medical Record';
            actionField.value = 'update';
            historyId.value = tr.dataset.id;
            diagnosis.value = tr.dataset.diagnosis;
            medications.value = tr.dataset.medications;
            allergies.value = tr.dataset.allergies;
            notes.value = tr.dataset.notes || '';
            modal.classList.add('show');
        }
        
        attachEditHandlers();
        
        // ============================================
        // Form Validation
        // ============================================
        form.addEventListener('submit', (e) => {
            if (!diagnosis.value.trim() && !medications.value.trim() && !allergies.value.trim()) {
                e.preventDefault();
                alert('Please enter at least one of: diagnosis, medications, or allergies');
                diagnosis.focus();
                return;
            }
        });
    </script>
</body>
</html>