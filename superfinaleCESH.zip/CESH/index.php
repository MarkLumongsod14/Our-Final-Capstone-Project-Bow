<?php
// index.php - Main Dashboard for Camp Evangelista Station Hospital
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db.php';
require_once 'auth.php';

// The main dashboard is restricted to administrators.
$auth->requireRole('admin');

$current_user = $auth->currentUser();

// ============================================
// STATISTICS QUERIES FOR CHARTS
// ============================================

// Patient Statistics
$totalPatientsRes = $conn->query("SELECT COUNT(*) as total FROM patients WHERE status = 'Active'");
$totalPatients = $totalPatientsRes ? $totalPatientsRes->fetch_assoc()['total'] : 0;

$scheduledPatientsRes = $conn->query("SELECT COUNT(*) as total FROM appointments WHERE date >= CURDATE() AND status != 'Completed' AND status != 'Cancelled'");
$scheduledPatients = $scheduledPatientsRes ? $scheduledPatientsRes->fetch_assoc()['total'] : 0;

$todayAppointmentsRes = $conn->query("SELECT COUNT(*) as total FROM appointments WHERE date = CURDATE() AND status != 'Cancelled'");
$todayAppointments = $todayAppointmentsRes ? $todayAppointmentsRes->fetch_assoc()['total'] : 0;

$pendingAppointmentsRes = $conn->query("SELECT COUNT(*) as total FROM appointments WHERE status = 'Pending' AND date >= CURDATE()");
$pendingAppointments = $pendingAppointmentsRes ? $pendingAppointmentsRes->fetch_assoc()['total'] : 0;

$completedAppointmentsRes = $conn->query("SELECT COUNT(*) as total FROM appointments WHERE status = 'Completed'");
$completedAppointments = $completedAppointmentsRes ? $completedAppointmentsRes->fetch_assoc()['total'] : 0;

// Gender Distribution
$maleCount = $conn->query("SELECT COUNT(*) as count FROM patients WHERE gender = 'Male'")->fetch_assoc()['count'] ?? 0;
$femaleCount = $conn->query("SELECT COUNT(*) as count FROM patients WHERE gender = 'Female'")->fetch_assoc()['count'] ?? 0;

// Weekly Appointments Trend
$weeklyData = [];
$weeklyLabels = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $weeklyLabels[] = date('D', strtotime($date));
    $count = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE date = '$date' AND status != 'Cancelled'")->fetch_assoc()['count'] ?? 0;
    $weeklyData[] = $count;
}

// Age Distribution
$ageGroups = ['0-12' => 0, '13-19' => 0, '20-35' => 0, '36-50' => 0, '51-65' => 0, '65+' => 0];
$ageQuery = $conn->query("SELECT dob FROM patients WHERE status = 'Active' AND dob IS NOT NULL");
if ($ageQuery) {
    $today = new DateTime();
    while ($row = $ageQuery->fetch_assoc()) {
        $dob = new DateTime($row['dob']);
        $age = $today->diff($dob)->y;
        if ($age <= 12) $ageGroups['0-12']++;
        elseif ($age <= 19) $ageGroups['13-19']++;
        elseif ($age <= 35) $ageGroups['20-35']++;
        elseif ($age <= 50) $ageGroups['36-50']++;
        elseif ($age <= 65) $ageGroups['51-65']++;
        else $ageGroups['65+']++;
    }
}

// Department Performance
$deptPerformance = [
    'General Medicine' => 75,
    'Pediatrics' => 60,
    'OB-Gyne' => 80,
    'Internal Medicine' => 70
];

// Queue Statistics
$waitingQueue = $conn->query("SELECT COUNT(*) as count FROM queue WHERE status = 'Waiting'")->fetch_assoc()['count'] ?? 0;
$inConsultation = $conn->query("SELECT COUNT(*) as count FROM queue WHERE status = 'In Consultation'")->fetch_assoc()['count'] ?? 0;
$completedToday = $conn->query("SELECT COUNT(*) as count FROM queue WHERE status = 'Completed' AND DATE(completed_at) = CURDATE()")->fetch_assoc()['count'] ?? 0;

// Appointment Type Distribution
$typeData = [];
$typeQuery = $conn->query("SELECT type, COUNT(*) as count FROM appointments WHERE type IS NOT NULL AND LOWER(TRIM(type)) != 'emergency' AND status != 'Cancelled' GROUP BY type LIMIT 5");
if ($typeQuery) {
    while ($row = $typeQuery->fetch_assoc()) {
        $typeData[$row['type']] = $row['count'];
    }
}

// Get patients for dropdown
$patientResult = $conn->query("SELECT mrn, first_name, last_name, middle_name, suffix, contact FROM patients WHERE status = 'Active' ORDER BY last_name, first_name");
$patients = $patientResult ? $patientResult->fetch_all(MYSQLI_ASSOC) : [];

// Get doctors for dropdown
$doctorResult = $conn->query("SELECT id, full_name, assigned_department FROM users WHERE status = 'Active' AND (role = 'admin' OR (role = 'doctor' AND is_available = 1)) ORDER BY full_name");
$doctors = $doctorResult ? $doctorResult->fetch_all(MYSQLI_ASSOC) : [];

// Get departments for dropdown
$departments = ['General Medicine', 'Pediatrics', 'OB-Gyne', 'Internal Medicine'];

$recentAppointmentsRes = $conn->query("
    SELECT a.*, p.first_name, p.last_name, p.mrn as patient_mrn, u.full_name as doctor_name
    FROM appointments a 
    JOIN patients p ON a.patient_mrn = p.mrn 
    LEFT JOIN users u ON a.doctor_id = u.id
    ORDER BY a.date DESC, a.time DESC
");
$recentAppointments = $recentAppointmentsRes ? $recentAppointmentsRes->fetch_all(MYSQLI_ASSOC) : [];

function formatMRN($mrn) {
    return str_pad($mrn, 6, '0', STR_PAD_LEFT);
}

function formatTime($time) {
    if (!$time) return '—';
    return date('g:i A', strtotime($time));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>if (localStorage.getItem('theme') !== 'light') document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | 4ID Station Hospital</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes modalFadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        
        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        /* Sidebar */
        #sidebar::-webkit-scrollbar {
            width: 4px;
        }
        #sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        #sidebar::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 2px;
        }
        .dark #sidebar::-webkit-scrollbar-thumb {
            background: #475569;
        }
        .main-content {
            transition: margin-left 0.3s ease;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        
        /* Theme toggle switch */
        .theme-switch {
            position: relative;
            width: 48px;
            height: 26px;
            background: #e2e8f0;
            border-radius: 13px;
            cursor: pointer;
            transition: background 0.3s ease;
            flex-shrink: 0;
        }
        .dark .theme-switch {
            background: #334155;
        }
        .theme-switch .slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .theme-switch .slider .sun { display: none; }
        .theme-switch .slider .moon { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider { transform: translateX(22px); }
        .dark .theme-switch .slider .sun { display: flex; align-items: center; justify-content: center; font-size: 12px; color: #f59e0b; }
        .dark .theme-switch .slider .moon { display: none; }
        .theme-switch .slider i { font-size: 11px; }
        
        /* User Dropdown */
        .user-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            min-width: 200px;
            z-index: 1000;
            overflow: hidden;
        }
        .dark .user-dropdown {
            background: #1f2937;
            border-color: rgba(255,255,255,0.06);
        }
        .user-dropdown.show {
            display: block;
        }
        .user-dropdown .dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        .dark .user-dropdown .dropdown-header {
            border-bottom-color: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-header strong {
            color: #1f2937;
            display: block;
            font-size: 0.85rem;
        }
        .dark .user-dropdown .dropdown-header strong {
            color: #f1f5f9;
        }
        .user-dropdown .dropdown-header small {
            color: #6b7280;
            font-size: 0.7rem;
        }
        .dark .user-dropdown .dropdown-header small {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            color: #374151;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
        }
        .dark .user-dropdown .dropdown-item {
            color: #e5e7eb;
        }
        .user-dropdown .dropdown-item:hover {
            background: #f3f4f6;
        }
        .dark .user-dropdown .dropdown-item:hover {
            background: rgba(255,255,255,0.04);
        }
        .user-dropdown .dropdown-item i {
            width: 18px;
            color: #6b7280;
        }
        .dark .user-dropdown .dropdown-item i {
            color: #9ca3af;
        }
        .user-dropdown .dropdown-divider {
            height: 1px;
            background: #e5e7eb;
            margin: 4px 0;
        }
        .dark .user-dropdown .dropdown-divider {
            background: rgba(255,255,255,0.06);
        }
        .user-dropdown .dropdown-item.logout {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout i {
            color: #ef4444;
        }
        .user-dropdown .dropdown-item.logout:hover {
            background: rgba(239, 68, 68, 0.08);
        }
        
      /* Chart containers */
.chart-container {
    position: relative;
    height: 100%;
    width: 100%;
}
        
        .chart-container .pie-chart {
            height: 170px;
            max-width: 220px;
            margin: 0 auto;
        }
        
        /* Appointments container */
        .appointments-container {
            max-height: 200px;
            overflow-y: auto;
            min-height: 30px;
        }
        .appointments-container::-webkit-scrollbar {
            width: 4px;
        }
        .appointments-container::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.02);
            border-radius: 2px;
        }
        .appointments-container::-webkit-scrollbar-thumb {
            background: #0284c7;
            border-radius: 2px;
        }
        
        #appointmentsList {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        #appointmentsList .appointment-item {
            padding: 4px 8px;
            margin-bottom: 2px;
            border-radius: 6px;
            background: rgba(255,255,255,0.03);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 4px;
            font-size: 0.7rem;
        }
        #appointmentsList .appointment-item:hover {
            background: rgba(255,255,255,0.06);
        }
        .dark #appointmentsList .appointment-item {
            background: rgba(255,255,255,0.03);
        }
        .dark #appointmentsList .appointment-item:hover {
            background: rgba(255,255,255,0.06);
        }
        #appointmentsList .appointment-item .appt-time {
            font-family: 'JetBrains Mono', monospace;
            color: #6b7280;
            font-size: 0.6rem;
            min-width: 45px;
        }
        .dark #appointmentsList .appointment-item .appt-time {
            color: #9ca3af;
        }
        #appointmentsList .appointment-item .appt-name {
            color: #1f2937;
            font-weight: 500;
            font-size: 0.7rem;
            flex: 1;
        }
        .dark #appointmentsList .appointment-item .appt-name {
            color: #f1f5f9;
        }
        #appointmentsList .appointment-item .appt-status {
            font-size: 0.5rem;
            font-weight: 600;
            padding: 1px 6px;
            border-radius: 10px;
        }
        #appointmentsList .appointment-item .appt-actions {
            display: flex;
            gap: 2px;
        }
        #appointmentsList .appointment-item .appt-actions button {
            background: none;
            border: none;
            color: #6b7280;
            cursor: pointer;
            padding: 2px 4px;
            border-radius: 4px;
            font-size: 0.6rem;
            transition: all 0.2s;
        }
        .dark #appointmentsList .appointment-item .appt-actions button {
            color: #9ca3af;
        }
        #appointmentsList .appointment-item .appt-actions button:hover {
            color: #1f2937;
            background: rgba(255,255,255,0.05);
        }
        .dark #appointmentsList .appointment-item .appt-actions button:hover {
            color: #f1f5f9;
            background: rgba(255,255,255,0.05);
        }
        #appointmentsList .appointment-item .appt-actions .btn-complete-appt { color: #10b981; }
        #appointmentsList .appointment-item .appt-actions .btn-complete-appt:hover { background: rgba(16, 185, 129, 0.1); }
        #appointmentsList .appointment-item .appt-actions .btn-edit-appt { color: #f59e0b; }
        #appointmentsList .appointment-item .appt-actions .btn-edit-appt:hover { background: rgba(251, 191, 36, 0.1); }
        #appointmentsList .appointment-item .appt-actions .btn-delete-appt { color: #ef4444; }
        #appointmentsList .appointment-item .appt-actions .btn-delete-appt:hover { background: rgba(239, 68, 68, 0.1); }
        #appointmentsList .appointment-item.completed { opacity: 0.5; }
        #appointmentsList .appointment-item .status-confirmed { color: #10b981; }
        #appointmentsList .appointment-item .status-pending { color: #f59e0b; }
        #appointmentsList .appointment-item .status-completed { color: #0ea5e9; }
        
        .appointments-toggle {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 10px;
            border-radius: 12px;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.06);
            color: #6b7280;
            font-size: 0.6rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            font-family: 'Plus Jakarta Sans', sans-serif;
            margin-top: 4px;
        }
        .dark .appointments-toggle {
            color: #9ca3af;
            border-color: rgba(255,255,255,0.06);
        }
        .appointments-toggle:hover {
            background: rgba(255,255,255,0.08);
            color: #1f2937;
        }
        .dark .appointments-toggle:hover {
            color: #f1f5f9;
        }
        .appointments-toggle i { font-size: 0.5rem; }
        .appointments-hidden { display: none !important; }
        
        /* Calendar */
        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 3px;
        }
        .calendar-weekdays {
            margin-bottom: 6px;
        }
        .calendar-weekdays div {
            text-align: center;
            font-size: 0.55rem;
            font-weight: 700;
            color: #6b7280;
            padding: 6px 0;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .dark .calendar-weekdays div {
            color: #9ca3af;
        }
        .calendar-days .day {
            text-align: center;
            padding: 8px 0;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.75rem;
            font-weight: 500;
            color: #6b7280;
            transition: all 0.2s;
            position: relative;
            background: transparent;
            border: 1px solid transparent;
        }
        .dark .calendar-days .day {
            color: #9ca3af;
        }
        .calendar-days .day:hover:not(.past-date) {
            background: rgba(2, 132, 199, 0.1);
            border-color: rgba(2, 132, 199, 0.2);
        }
        .calendar-days .day.has-appointment {
            background: rgba(2, 132, 199, 0.08);
            color: #0284c7;
            border-color: rgba(2, 132, 199, 0.1);
        }
        .dark .calendar-days .day.has-appointment {
            color: #38bdf8;
        }
        .calendar-days .day.has-completed {
            background: rgba(16, 185, 129, 0.08);
            color: #10b981;
            border-color: rgba(16, 185, 129, 0.1);
        }
        .calendar-days .day.past-date {
            color: #9ca3af;
            cursor: not-allowed;
            opacity: 0.5;
        }
        .dark .calendar-days .day.past-date {
            color: #4b5563;
        }
        .calendar-days .day.today {
            background: rgba(2, 132, 199, 0.15);
            color: #1f2937;
            border-color: rgba(2, 132, 199, 0.3);
            font-weight: 700;
        }
        .dark .calendar-days .day.today {
            color: #f1f5f9;
        }
        .calendar-days .day .badge-count {
            position: absolute;
            top: -4px;
            right: -4px;
            background: #ef4444;
            color: white;
            font-size: 0.45rem;
            padding: 1px 4px;
            border-radius: 20px;
            min-width: 14px;
            font-weight: 700;
        }
        .calendar-days .day .badge-completed {
            background: #065f46;
        }
        
        .cal-nav {
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.06);
            width: 32px;
            height: 32px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.85rem;
            color: #6b7280;
            transition: all 0.2s;
        }
        .dark .cal-nav {
            color: #9ca3af;
        }
        .cal-nav:hover {
            background: rgba(255,255,255,0.08);
            color: #1f2937;
        }
        .dark .cal-nav:hover {
            color: #f1f5f9;
        }
    </style>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- SIDEBAR -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span>
                    <span>E</span>
                    <span>S</span>
                    <span>H</span>
                </div>

                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="index.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-gauge-high text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="medical_history.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-notes-medical text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Medical History</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient_documents.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-file-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Documents</span>
                        </a>
                    </li>
                    <li>
                        <a href="scheduled_patient.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-calendar-check text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Scheduled Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue_frontdesk.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-ticket text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue System</span>
                        </a>
                    </li>
                    
                    <!-- Profile Link (Admin Only) -->
                    <li>
                        <a href="profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-circle text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">My Profile</span>
                        </a>
                    </li>
                    <?php if (($current_user['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="admin/users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0"><i class="fas fa-user-shield text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i></div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                
                <div class="border-t border-slate-200 dark:border-slate-700/50 mt-6 pt-4">
                    <a href="logout.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                        <div class="w-6 h-6 flex items-center justify-center shrink-0">
                            <i class="fas fa-sign-out-alt text-base text-rose-400 group-hover/link:text-rose-500 transition-colors"></i>
                        </div>
                        <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
                    </a>
                </div>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 main-content">
        
        <!-- Header -->
        <header class="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">Dashboard</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">Outpatient Record Management &amp; Smart Queueing System</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden sm:block">
                    <div class="text-sm font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($current_user['full_name']); ?></div>
                    <div class="text-xs text-slate-500 dark:text-slate-400 font-medium"><?php echo ucfirst($current_user['role']); ?></div>
                </div>
                
                <!-- Dark Mode Toggle Switch -->
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-sun"></i></span>
                    <div class="theme-switch" id="themeToggle">
                        <div class="slider">
                            <span class="sun"><i class="fas fa-sun"></i></span>
                            <span class="moon"><i class="fas fa-moon"></i></span>
                        </div>
                    </div>
                    <span class="text-xs text-slate-400 dark:text-slate-500"><i class="fas fa-moon"></i></span>
                </div>

                <!-- User Avatar with Click Dropdown -->
                <div class="relative">
                    <div class="w-10 h-10 rounded-full bg-white dark:bg-[#1f2937] border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors" id="userAvatar">
                        <i class="fas fa-user-shield text-slate-400 dark:text-slate-500 text-sm"></i>
                    </div>
                    <div class="user-dropdown" id="userDropdown">
                        <div class="dropdown-header">
                            <strong><?php echo htmlspecialchars($current_user['full_name']); ?></strong>
                            <small><?php echo ucfirst($current_user['role']); ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user-circle"></i> My Profile
                        </a>
                        <a href="logout.php" class="dropdown-item logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>
        
      <!-- Stats Grid -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
        <div class="flex justify-between items-center mb-4">
            <div class="w-11 h-11 bg-sky-50 dark:bg-sky-500/10 rounded-xl flex items-center justify-center text-sky-600 dark:text-sky-400 text-lg"><i class="fas fa-hospital-user"></i></div>
        </div>
        <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono"><?php echo number_format($totalPatients); ?></div>
        <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Total Active Patients</div>
    </div>
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
        <div class="flex justify-between items-center mb-4">
            <div class="w-11 h-11 bg-emerald-50 dark:bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-lg"><i class="fas fa-calendar-alt"></i></div>
        </div>
        <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono"><?php echo number_format($scheduledPatients); ?></div>
        <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Upcoming Appointments</div>
    </div>
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
        <div class="flex justify-between items-center mb-4">
            <div class="w-11 h-11 bg-amber-50 dark:bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-600 dark:text-amber-400 text-lg"><i class="fas fa-calendar-day"></i></div>
        </div>
        <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono"><?php echo number_format($todayAppointments); ?></div>
        <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Today's Appointments</div>
    </div>
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
        <div class="flex justify-between items-center mb-4">
            <div class="w-11 h-11 bg-blue-50 dark:bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-600 dark:text-blue-400 text-lg"><i class="fas fa-check-circle"></i></div>
        </div>
        <div class="text-3xl font-bold text-slate-900 dark:text-white mb-1 font-mono"><?php echo number_format($completedAppointments); ?></div>
        <div class="text-slate-400 dark:text-slate-400 text-[0.7rem] font-bold uppercase tracking-wider">Completed</div>
    </div>
</div>

<!-- Dashboard Grid - Calendar & Queue (Moved Up) -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
    <!-- Calendar -->
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
        <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex justify-between items-center flex-wrap gap-2">
            <div class="flex items-center gap-3"><i class="fas fa-calendar-alt text-sky-500 dark:text-sky-400"></i><span class="text-sm font-bold text-slate-800 dark:text-slate-200">Appointment Calendar</span></div>
            <button class="text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 bg-white dark:bg-slate-700/50 px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-600 transition-colors" onclick="fetchAppointments()"><i class="fas fa-sync-alt mr-1.5"></i> Refresh</button>
        </div>
        <div class="p-6">
            <div class="flex items-center justify-between mb-4">
                <button id="prevMonth" class="cal-nav"><i class="fas fa-chevron-left"></i></button>
                <div id="monthLabel" class="text-sm font-semibold text-slate-900 dark:text-white">Loading...</div>
                <button id="nextMonth" class="cal-nav"><i class="fas fa-chevron-right"></i></button>
            </div>
            <div class="calendar-grid calendar-weekdays"><div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div></div>
            <div id="calendarGrid" class="calendar-grid calendar-days"></div>
            
            <div class="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700/50">
                <div class="flex items-center justify-between mb-2 flex-wrap gap-2">
                    <span class="text-xs font-semibold text-slate-500 dark:text-slate-400" id="appointmentsTitle"><i class="fas fa-list"></i> Select a date</span>
                    <button id="addAppointmentBtn" class="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-1.5"><i class="fas fa-plus"></i> Add</button>
                </div>
                <div id="appointmentsContainer" class="appointments-container">
                    <ul id="appointmentsList"><li class="text-center text-xs text-slate-500 dark:text-slate-400 py-3"><i class="fas fa-calendar-day mr-1.5"></i> Click on a date</li></ul>
                    <div id="appointmentsToggleContainer" class="text-center hidden">
                        <button id="appointmentsToggleBtn" class="appointments-toggle"><i class="fas fa-chevron-down"></i><span id="appointmentsToggleText">Show More</span></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Queue & Performance -->
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
        <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80">
            <div class="flex items-center gap-3"><i class="fas fa-chart-simple text-sky-500 dark:text-sky-400"></i><span class="text-sm font-bold text-slate-800 dark:text-slate-200">Queue &amp; Performance</span></div>
        </div>
        <div class="p-6">
            <div class="grid grid-cols-3 gap-3 mb-4">
                <div class="text-center p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700">
                    <div class="text-2xl font-bold text-sky-600 dark:text-sky-400 font-mono"><?php echo $waitingQueue; ?></div>
                    <div class="text-[0.6rem] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mt-0.5">Waiting</div>
                </div>
                <div class="text-center p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700">
                    <div class="text-2xl font-bold text-amber-500 font-mono"><?php echo $inConsultation; ?></div>
                    <div class="text-[0.6rem] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mt-0.5">In Consultation</div>
                </div>
                <div class="text-center p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700">
                    <div class="text-2xl font-bold text-emerald-500 font-mono"><?php echo $completedToday; ?></div>
                    <div class="text-[0.6rem] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mt-0.5">Completed Today</div>
                </div>
            </div>
            
            <?php foreach ($deptPerformance as $dept => $percent): ?>
            <div class="flex items-center gap-3 mb-3 last:mb-0">
                <span class="w-28 text-xs font-medium text-slate-600 dark:text-slate-400 flex-shrink-0"><?php echo $dept; ?></span>
                <div class="flex-1 h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div class="h-full bg-gradient-to-r from-sky-500 to-sky-400 rounded-full transition-all duration-500" style="width: <?php echo $percent; ?>%;"></div>
                </div>
                <span class="text-xs font-bold text-sky-600 dark:text-sky-400 w-8 text-right"><?php echo $percent; ?>%</span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>


<!-- Charts Grid - Analytics (Moved Down) -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
    <!-- 1. Weekly Appointment Trend -->
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
        <div class="px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex justify-between items-center">
            <div class="flex items-center gap-2"><i class="fas fa-chart-line text-sky-500 dark:text-sky-400 text-sm"></i><span class="text-xs font-bold text-slate-800 dark:text-slate-200">Weekly Trend</span></div>
            <i class="fas fa-calendar-week text-slate-400 dark:text-slate-500 text-xs"></i>
        </div>
        <div class="p-3"><div class="chart-container" style="height:220px;width:100%;"><canvas id="trendChart"></canvas></div></div>
    </div>
    
    <!-- 2. Age Group Distribution -->
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
        <div class="px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex justify-between items-center">
            <div class="flex items-center gap-2"><i class="fas fa-chart-bar text-sky-500 dark:text-sky-400 text-sm"></i><span class="text-xs font-bold text-slate-800 dark:text-slate-200">Age Groups</span></div>
            <i class="fas fa-users text-slate-400 dark:text-slate-500 text-xs"></i>
        </div>
        <div class="p-3"><div class="chart-container" style="height:220px;width:100%;"><canvas id="ageChart"></canvas></div></div>
    </div>
    
    <!-- 3. Gender Distribution -->
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
        <div class="px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex justify-between items-center">
            <div class="flex items-center gap-2"><i class="fas fa-venus-mars text-sky-500 dark:text-sky-400 text-sm"></i><span class="text-xs font-bold text-slate-800 dark:text-slate-200">Gender</span></div>
            <i class="fas fa-chart-pie text-slate-400 dark:text-slate-500 text-xs"></i>
        </div>
        <div class="p-3 flex items-center justify-center">
            <div style="height:240px;width:240px;max-width:100%;position:relative;">
                <canvas id="genderChart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- 4. Appointment Types -->
    <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
        <div class="px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex justify-between items-center">
            <div class="flex items-center gap-2"><i class="fas fa-chart-donut text-sky-500 dark:text-sky-400 text-sm"></i><span class="text-xs font-bold text-slate-800 dark:text-slate-200">Types</span></div>
            <i class="fas fa-tags text-slate-400 dark:text-slate-500 text-xs"></i>
        </div>
        <div class="p-3 flex items-center justify-center">
            <div style="height:240px;width:240px;max-width:100%;position:relative;">
                <canvas id="typeChart"></canvas>
            </div>
        </div>
    </div>
</div>
        

        
        <!-- Recent Activity -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl overflow-hidden shadow-sm">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3"><i class="fas fa-history text-sky-500 dark:text-sky-400"></i><span class="text-sm font-bold text-slate-800 dark:text-slate-200">Appointment Report</span></div>
                <div class="flex items-center gap-2">
                    <label for="reportDateSort" class="text-xs font-semibold text-slate-500 dark:text-slate-400">Sort by date</label>
                    <select id="reportDateSort" class="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/50">
                        <option value="desc">Newest first</option>
                        <option value="asc">Oldest first</option>
                    </select>
                    <button type="button" id="exportReportBtn" class="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold transition-colors">
                        <i class="fas fa-download mr-1"></i> Export CSV
                    </button>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse min-w-[700px]">
                    <thead>
                        <tr class="bg-slate-50/50 dark:bg-slate-800/40 text-left border-b border-slate-300 dark:border-slate-700/80 text-slate-400 dark:text-slate-400 text-[0.65rem] uppercase tracking-wider font-bold">
                            <th class="px-5 py-3.5">Date</th><th class="px-5 py-3.5">Time</th><th class="px-5 py-3.5">Patient</th><th class="px-5 py-3.5">Doctor</th><th class="px-5 py-3.5">Status</th>
                        </tr>
                    </thead>
                    <tbody id="reportTableBody" class="divide-y divide-slate-300/80 dark:divide-slate-700/50 text-xs md:text-sm text-slate-700 dark:text-slate-200">
                        <?php if (empty($recentAppointments)): ?>
                        <tr><td colspan="5" class="text-center py-12 text-slate-400 dark:text-slate-400"><i class="fas fa-inbox text-2xl mb-2 block text-slate-300 dark:text-slate-600"></i> No recent appointments</td></tr>
                        <?php else: ?>
                        <?php foreach ($recentAppointments as $appt): ?>
                        <tr class="report-row hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors duration-150" data-date="<?php echo htmlspecialchars($appt['date']); ?>" data-time="<?php echo htmlspecialchars($appt['time']); ?>">
                            <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400 text-sm"><?php echo date('M d, Y', strtotime($appt['date'])); ?></td>
                            <td class="px-5 py-3.5 font-mono text-slate-500 dark:text-slate-400 text-sm"><?php echo formatTime($appt['time']); ?></td>
                            <td class="px-5 py-3.5 font-semibold text-slate-800 dark:text-slate-100"><?php echo htmlspecialchars($appt['last_name'] . ', ' . $appt['first_name']); ?></td>
                            <td class="px-5 py-3.5 text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($appt['doctor_name'] ?: '—'); ?></td>
                            <td class="px-5 py-3.5">
                                <?php 
                                    $statusClass = '';
                                    if ($appt['status'] === 'Confirmed') $statusClass = 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-400/20';
                                    elseif ($appt['status'] === 'Completed') $statusClass = 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-300 dark:border-sky-400/20';
                                    elseif ($appt['status'] === 'Cancelled') $statusClass = 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-300 dark:border-rose-400/20';
                                    else $statusClass = 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-300 dark:border-amber-400/20';
                                ?>
                                <span class="inline-block px-3 py-1 rounded-full text-[0.65rem] font-bold tracking-wide uppercase <?php echo $statusClass; ?>"><?php echo $appt['status']; ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Appointment Modal -->
    <div id="appointmentModal" class="fixed inset-0 bg-slate-900/60 dark:bg-black/70 z-[2000] hidden items-center justify-center p-4 backdrop-blur-sm">
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-2xl w-full max-w-[600px] max-h-[90vh] overflow-y-auto shadow-2xl animate-[modalFadeIn_0.2s_ease]">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-800 border-b border-slate-300 dark:border-slate-700 flex justify-between items-center sticky top-0 z-10">
                <h3 id="modalTitle" class="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2.5"><i class="fas fa-calendar-plus text-sky-500 dark:text-sky-400"></i> Schedule Appointment</h3>
                <button class="w-8 h-8 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600 flex items-center justify-center text-slate-400 dark:text-slate-500 transition-colors" id="closeModal"><i class="fas fa-times"></i></button>
            </div>
            <form id="appointmentForm" class="p-6">
                <input type="hidden" name="id" id="appointmentId">
                <input type="hidden" name="action" value="save">
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5"><i class="fas fa-calendar-alt mr-1"></i> Date <span class="text-rose-500">*</span></label>
                        <input type="date" name="date" id="appointmentDate" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                    </div>
                    <div class="form-group">
                        <label class="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5"><i class="fas fa-clock mr-1"></i> Time <span class="text-rose-500">*</span></label>
                        <input type="time" name="time" id="appointmentTime" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                    </div>
                </div>
                
                <div class="form-group mt-4">
                    <label class="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5"><i class="fas fa-user mr-1"></i> Patient <span class="text-rose-500">*</span></label>
                    <input type="search" id="appointmentPatientSearch" autocomplete="off" aria-label="Search patients by name or MRN" placeholder="Search by name or MRN..." class="w-full mb-2 px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                    <select name="patient_mrn" id="appointmentPatient" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                        <option value="">-- Select Patient --</option>
                        <?php foreach($patients as $p): ?>
                            <option value="<?= (int)$p['mrn'] ?>" data-search="<?= htmlspecialchars($p['last_name'] . ', ' . $p['first_name'] . ' ' . formatMRN($p['mrn']), ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($p['last_name']) ?>, <?= htmlspecialchars($p['first_name']) ?> [MRN: <?= formatMRN($p['mrn']) ?>]</option>
                        <?php endforeach; ?>
                    </select>
                    <p id="appointmentPatientNoResults" class="mt-1 text-xs text-rose-500" role="status" hidden>No patients match your search.</p>
                </div>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                    <div class="form-group">
                        <label class="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5"><i class="fas fa-user-md mr-1"></i> Provider</label>
                        <select name="provider" id="appointmentProvider" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                            <option value="">-- Select Provider --</option>
                            <?php foreach($doctors as $doc): ?>
                                <option value="<?= htmlspecialchars($doc['full_name']) ?>">Dr. <?= htmlspecialchars($doc['full_name']) ?> (<?= $doc['assigned_department'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5"><i class="fas fa-tag mr-1"></i> Type</label>
                        <select name="type" id="appointmentType" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                            <option value="">-- Select Type --</option>
                            <option value="Initial Consultation">Initial Consultation</option>
                            <option value="Follow-up">Follow-up</option>
                            <option value="Check-up">Check-up</option>
                            <option value="Vaccination">Vaccination</option>
                            <option value="Laboratory">Laboratory</option>
                            <option value="Physical Exam">Physical Exam</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group mt-4">
                    <label class="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5"><i class="fas fa-flag-checkered mr-1"></i> Status</label>
                    <select name="status" id="appointmentStatus" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500">
                        <option value="Pending">Pending</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </div>
                
                <div class="form-group mt-4">
                    <label class="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5"><i class="fas fa-sticky-note mr-1"></i> Notes</label>
                    <textarea name="notes" id="appointmentNotes" rows="2" placeholder="Additional notes..." class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500 resize-none"></textarea>
                </div>
                
                <div class="flex flex-wrap gap-3 mt-6 pt-4 border-t border-slate-200 dark:border-slate-700/50">
                    <button type="button" id="deleteAppointmentBtn" class="px-4 py-2 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-sm font-bold rounded-xl transition-colors mr-auto flex items-center gap-2" style="display: none;"><i class="fas fa-trash-alt"></i> Delete</button>
                    <button type="button" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 text-sm font-bold rounded-xl transition-colors" id="cancelSchedule">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold rounded-xl transition-all shadow-sm hover:shadow-md flex items-center gap-2" id="saveBtn"><i class="fas fa-save"></i> Save Appointment</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // ============================================
        // Dark Mode Toggle
        // ============================================
        const htmlElement = document.documentElement;
        const themeToggle = document.getElementById('themeToggle');
        
        if (localStorage.getItem('theme') === 'light') {
            htmlElement.classList.remove('dark');
        } else {
            htmlElement.classList.add('dark');
        }
        
        themeToggle.addEventListener('click', function() {
            htmlElement.classList.toggle('dark');
            localStorage.setItem('theme', htmlElement.classList.contains('dark') ? 'dark' : 'light');
        });
        
        // ============================================
        // User Dropdown - Click to toggle
        // ============================================
        const userAvatar = document.getElementById('userAvatar');
        const userDropdown = document.getElementById('userDropdown');
        
        userAvatar.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });
        
        document.addEventListener('click', function(e) {
            if (!userAvatar.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('show');
            }
        });
        
        // ============================================
        // Mobile Menu
        // ============================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        });

        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('mobileMenuBtn');
            if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
        
        // ============================================
        // Chart Data from PHP
        // ============================================
        const weeklyLabels = <?php echo json_encode($weeklyLabels); ?>;
        const weeklyData = <?php echo json_encode($weeklyData); ?>;
        const genderMale = <?php echo $maleCount; ?>;
        const genderFemale = <?php echo $femaleCount; ?>;
        const ageLabels = <?php echo json_encode(array_keys($ageGroups)); ?>;
        const ageData = <?php echo json_encode(array_values($ageGroups)); ?>;
        const typeLabels = <?php echo json_encode(array_keys($typeData)); ?>;
        const typeCounts = <?php echo json_encode(array_values($typeData)); ?>;
        
       // Weekly Trend Chart - Larger
new Chart(document.getElementById('trendChart'), {
    type: 'line',
    data: {
        labels: weeklyLabels,
        datasets: [{
            label: 'Appointments',
            data: weeklyData,
            borderColor: '#0ea5e9',
            backgroundColor: 'rgba(14,165,233,0.08)',
            borderWidth: 3,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#0ea5e9',
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 8
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: { display: false },
            tooltip: { 
                backgroundColor: '#1f2937', 
                borderColor: 'rgba(255,255,255,0.05)', 
                borderWidth: 1,
                bodyFont: { size: 12 },
                titleFont: { size: 12 }
            }
        },
        scales: {
            y: { 
                beginAtZero: true, 
                grid: { color: 'rgba(0,0,0,0.04)' }, 
                ticks: { color: '#6b7280', font: { size: 11 } } 
            },
            x: { 
                grid: { display: false }, 
                ticks: { color: '#6b7280', font: { size: 11 } } 
            }
        }
    }
});
        
        // Gender Distribution Chart
new Chart(document.getElementById('genderChart'), {
    type: 'doughnut',
    data: {
        labels: ['Male', 'Female'],
        datasets: [{
            data: [genderMale, genderFemale],
            backgroundColor: ['#0ea5e9', '#10b981'],
            borderWidth: 0,
            hoverOffset: 8
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        cutout: '60%',
        plugins: {
            legend: { 
                position: 'bottom', 
                labels: { 
                    color: '#6b7280', 
                    font: { size: 13, weight: '500' },
                    padding: 12,
                    boxWidth: 16,
                    boxHeight: 16,
                    usePointStyle: true,
                    pointStyle: 'circle'
                } 
            }
        }
    }
});
        
       // Age Distribution Chart - Larger
new Chart(document.getElementById('ageChart'), {
    type: 'bar',
    data: {
        labels: ageLabels,
        datasets: [{
            label: 'Patients',
            data: ageData,
            backgroundColor: 'rgba(14,165,233,0.6)',
            borderColor: '#0ea5e9',
            borderWidth: 2,
            borderRadius: 6,
            barPercentage: 0.7
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: { display: false },
            tooltip: { 
                backgroundColor: '#1f2937', 
                borderColor: 'rgba(255,255,255,0.05)', 
                borderWidth: 1,
                bodyFont: { size: 12 },
                titleFont: { size: 12 }
            }
        },
        scales: {
            y: { 
                beginAtZero: true, 
                grid: { color: 'rgba(0,0,0,0.04)' }, 
                ticks: { color: '#6b7280', font: { size: 11 } } 
            },
            x: { 
                grid: { display: false }, 
                ticks: { color: '#6b7280', font: { size: 11 } } 
            }
        }
    }
});
        
       // Appointment Type Chart
if (typeLabels.length > 0) {
    new Chart(document.getElementById('typeChart'), {
        type: 'pie',
        data: {
            labels: typeLabels,
            datasets: [{
                data: typeCounts,
                backgroundColor: ['#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
                borderWidth: 0,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { 
                    position: 'bottom', 
                    labels: { 
                        color: '#6b7280', 
                        font: { size: 13, weight: '500' },
                        padding: 12,
                        boxWidth: 16,
                        boxHeight: 16,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    } 
                }
            }
        }
    });
}
        
        // ============================================
        // Calendar Logic
        // ============================================
        let selectedDate = null;
        let today = new Date();
        let viewYear = today.getFullYear();
        let viewMonth = today.getMonth();
        let appointments = {};
        let currentEditId = null;
        let appointmentsExpanded = false;
        
        function getTodayString() {
            const d = new Date();
            return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
        }

        function formatCalendarDate(dateString) {
            const parts = dateString.split('-').map(Number);
            const date = new Date(parts[0], parts[1] - 1, parts[2]);
            return date.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
        
        function isPastDate(dateString) {
            return dateString < getTodayString();
        }
        
        function formatTimeDisplay(time) {
            if (!time) return '--:--';
            const parts = time.split(':');
            let hour = parseInt(parts[0]);
            const ampm = hour >= 12 ? 'PM' : 'AM';
            hour = hour % 12 || 12;
            return hour + ':' + parts[1] + ' ' + ampm;
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function setupAppointmentToggle() {
            const toggleContainer = document.getElementById('appointmentsToggleContainer');
            const toggleBtn = document.getElementById('appointmentsToggleBtn');
            const toggleText = document.getElementById('appointmentsToggleText');
            const items = document.querySelectorAll('#appointmentsList .appointment-item');
            
            if (items.length <= 3) {
                toggleContainer.classList.add('hidden');
                items.forEach(function(item) {
                    item.classList.remove('appointments-hidden');
                });
                return;
            }
            
            toggleContainer.classList.remove('hidden');
            
            if (!appointmentsExpanded) {
                items.forEach(function(item, index) {
                    if (index >= 3) {
                        item.classList.add('appointments-hidden');
                    } else {
                        item.classList.remove('appointments-hidden');
                    }
                });
                toggleText.textContent = 'Show More (' + (items.length - 3) + ' more)';
                toggleBtn.querySelector('i').className = 'fas fa-chevron-down';
            } else {
                items.forEach(function(item) {
                    item.classList.remove('appointments-hidden');
                });
                toggleText.textContent = 'Show Less';
                toggleBtn.querySelector('i').className = 'fas fa-chevron-up';
            }
        }
        
        document.getElementById('appointmentsToggleBtn').addEventListener('click', function() {
            appointmentsExpanded = !appointmentsExpanded;
            setupAppointmentToggle();
        });
        
        async function fetchAppointments() {
            try {
                const res = await fetch('manage_appointment.php?action=get');
                const data = await res.json();
                appointments = {};
                if (Array.isArray(data)) {
                    data.forEach(function(a) {
                        if (!appointments[a.date]) appointments[a.date] = [];
                        appointments[a.date].push(a);
                    });
                }
                renderCalendar();
            } catch (e) {
                console.error('Error fetching appointments:', e);
            }
        }
        
        function renderCalendar() {
            const calendarGrid = document.getElementById('calendarGrid');
            if (!calendarGrid) return;
            
            calendarGrid.innerHTML = '';
            const firstDay = new Date(viewYear, viewMonth, 1);
            const lastDay = new Date(viewYear, viewMonth + 1, 0);
            const startDay = firstDay.getDay();
            const todayStr = getTodayString();
            
            for (var i = 0; i < startDay; i++) {
                const blankCell = document.createElement('div');
                blankCell.className = 'day day-empty';
                calendarGrid.appendChild(blankCell);
            }
            
            for (var d = 1; d <= lastDay.getDate(); d++) {
                const date = new Date(viewYear, viewMonth, d);
                const iso = viewYear + '-' + String(viewMonth + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
                const dayAppointments = appointments[iso] || [];
                const hasActive = dayAppointments.some(function(a) {
                    return a.status !== 'Completed' && a.status !== 'Cancelled';
                });
                const hasCompleted = dayAppointments.some(function(a) {
                    return a.status === 'Completed';
                });
                
                const cell = document.createElement('div');
                cell.className = 'day';
                cell.textContent = d;
                cell.style.position = 'relative';
                cell.style.cursor = isPastDate(iso) ? 'not-allowed' : 'pointer';
                
                if (isPastDate(iso)) {
                    cell.classList.add('past-date');
                }
                
                if (iso === todayStr) {
                    cell.classList.add('today');
                }
                
                if (hasActive) {
                    cell.classList.add('has-appointment');
                }
                
                if (hasCompleted && !hasActive) {
                    cell.classList.add('has-completed');
                }
                
                const badge = document.createElement('span');
                badge.className = 'badge-count';
                
                if (hasCompleted && !hasActive) {
                    badge.textContent = '✓';
                    badge.classList.add('badge-completed');
                } else {
                    const count = hasActive
                        ? dayAppointments.filter(function(a) {
                            return a.status !== 'Completed' && a.status !== 'Cancelled';
                        }).length
                        : dayAppointments.length;
                    badge.textContent = count;
                }
                
                cell.appendChild(badge);
                
                if (!isPastDate(iso)) {
                    cell.addEventListener('click', (function(selectedDateStr) {
                        return function() {
                            selectedDate = selectedDateStr;
                            appointmentsExpanded = false;
                            loadAppointmentsForDate(selectedDateStr);
                        };
                    })(iso));
                }
                
                calendarGrid.appendChild(cell);
            }
            
            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            document.getElementById('monthLabel').textContent = monthNames[viewMonth] + ' ' + viewYear;
        }
        
        function loadAppointmentsForDate(date) {
            const list = appointments[date] || [];
            const formattedDate = formatCalendarDate(date);
            document.getElementById('appointmentsTitle').innerHTML = '<i class="fas fa-list"></i> ' + formattedDate;
            
            const listContainer = document.getElementById('appointmentsList');
            const toggleContainer = document.getElementById('appointmentsToggleContainer');
            
            if (list.length === 0) {
                listContainer.innerHTML = '<li class="text-center text-xs text-slate-500 dark:text-slate-400 py-3"><i class="fas fa-calendar-day mr-1.5"></i> No appointments</li>';
                toggleContainer.classList.add('hidden');
                return;
            }
            
            const sortedList = list.slice().sort(function(a, b) {
                if (a.status === 'Completed' && b.status !== 'Completed') return 1;
                if (a.status !== 'Completed' && b.status === 'Completed') return -1;
                return (a.time || '00:00').localeCompare(b.time || '00:00');
            });
            
            listContainer.innerHTML = sortedList.map(function(a) {
                var statusClass = a.status === 'Confirmed' ? 'status-confirmed' : 
                                 (a.status === 'Completed' ? 'status-completed' : 'status-pending');
                var completedClass = a.status === 'Completed' ? 'completed' : '';
                var completeBtn = a.status !== 'Completed' ? 
                    '<button class="btn-complete-appt" onclick="markAsCompleted(' + a.id + ')" title="Mark as completed"><i class="fas fa-check"></i></button>' : '';
                
                return '<li class="appointment-item ' + completedClass + '" data-appt-id="' + a.id + '">' +
                    '<span class="appt-time">' + formatTimeDisplay(a.time) + '</span>' +
                    '<span class="appt-name">' + escapeHtml(a.patient_name || 'Unknown') + '</span>' +
                    '<span class="appt-status ' + statusClass + '">' + a.status + '</span>' +
                    '<div class="appt-actions">' +
                        completeBtn +
                        '<button class="btn-edit-appt" onclick="editAppointment(' + a.id + ')" title="Edit"><i class="fas fa-edit"></i></button>' +
                        '<button class="btn-delete-appt" onclick="deleteAppointment(' + a.id + ')" title="Delete"><i class="fas fa-trash-alt"></i></button>' +
                    '</div>' +
                '</li>';
            }).join('');
            
            appointmentsExpanded = false;
            setupAppointmentToggle();
        }
        
        // ============================================
        // Appointment CRUD Functions
        // ============================================
        async function markAsCompleted(id) {
            if (!confirm('Mark this appointment as completed?')) return;
            try {
                const formData = new FormData();
                formData.append('action', 'complete');
                formData.append('id', id);
                const res = await fetch('manage_appointment.php', { method: 'POST', body: formData });
                const data = await res.json();
                if (data.success) {
                    await fetchAppointments();
                    if (selectedDate) loadAppointmentsForDate(selectedDate);
                }
            } catch (e) { console.error(e); }
        }
        
        async function deleteAppointment(id) {
            if (!confirm('Delete this appointment permanently?')) return;
            try {
                const formData = new FormData();
                formData.append('action', 'delete');
                formData.append('id', id);
                const res = await fetch('manage_appointment.php', { method: 'POST', body: formData });
                const data = await res.json();
                if (data.success) {
                    document.getElementById('appointmentModal').style.display = 'none';
                    await fetchAppointments();
                    if (selectedDate) loadAppointmentsForDate(selectedDate);
                }
            } catch (e) { console.error(e); }
        }
        
        function openAddModal() {
            if (!selectedDate) {
                alert('Please select a date first by clicking on a day in the calendar.');
                return;
            }
            currentEditId = null;
            document.getElementById('modalTitle').innerHTML = '<i class="fas fa-calendar-plus"></i> Schedule Appointment';
            document.getElementById('appointmentForm').reset();
            resetAppointmentPatientSearch();
            document.getElementById('appointmentId').value = '';
            document.getElementById('appointmentDate').value = selectedDate;
            document.getElementById('appointmentDate').min = getTodayString();
            document.getElementById('appointmentType').querySelectorAll('option[data-legacy-type="true"]').forEach(option => option.remove());
            document.getElementById('deleteAppointmentBtn').style.display = 'none';
            document.getElementById('appointmentModal').style.display = 'flex';
        }
        
        async function editAppointment(id) {
            let appointment = null;
            for (const date in appointments) {
                const found = appointments[date].find(function(a) { return a.id == id; });
                if (found) {
                    appointment = found;
                    break;
                }
            }
            if (!appointment) {
                alert('Appointment not found');
                return;
            }
            
            currentEditId = id;
            document.getElementById('modalTitle').innerHTML = '<i class="fas fa-edit"></i> Edit Appointment';
            document.getElementById('appointmentId').value = id;
            document.getElementById('appointmentDate').value = appointment.date;
            document.getElementById('appointmentDate').min = getTodayString();
            document.getElementById('appointmentTime').value = appointment.time || '';
            document.getElementById('appointmentProvider').value = appointment.provider || '';
            const appointmentType = document.getElementById('appointmentType');
            appointmentType.querySelectorAll('option[data-legacy-type="true"]').forEach(option => option.remove());
            if (appointment.type && !Array.from(appointmentType.options).some(option => option.value === appointment.type)) {
                const legacyType = new Option(`${appointment.type} (existing)`, appointment.type);
                legacyType.dataset.legacyType = 'true';
                appointmentType.add(legacyType);
            }
            appointmentType.value = appointment.type || '';
            document.getElementById('appointmentStatus').value = appointment.status || 'Pending';
            document.getElementById('appointmentNotes').value = appointment.notes || '';
            document.getElementById('deleteAppointmentBtn').style.display = 'flex';
            
            const patientSelect = document.getElementById('appointmentPatient');
            resetAppointmentPatientSearch();
            for (var i = 0; i < patientSelect.options.length; i++) {
                if (patientSelect.options[i].value == appointment.patient_mrn) {
                    patientSelect.selectedIndex = i;
                    break;
                }
            }
            document.getElementById('appointmentModal').style.display = 'flex';
        }

        function filterAppointmentPatientOptions(query) {
            const patientSelect = document.getElementById('appointmentPatient');
            const noResults = document.getElementById('appointmentPatientNoResults');
            const normalizedQuery = query.trim().toLocaleLowerCase();
            let visiblePatients = 0;

            Array.from(patientSelect.options).slice(1).forEach(function(option) {
                const matches = option.dataset.search.toLocaleLowerCase().includes(normalizedQuery);
                option.hidden = !matches;
                if (matches) visiblePatients++;
            });

            noResults.hidden = normalizedQuery === '' || visiblePatients > 0;
        }

        function resetAppointmentPatientSearch() {
            const search = document.getElementById('appointmentPatientSearch');
            const patientSelect = document.getElementById('appointmentPatient');
            search.value = '';
            patientSelect.value = '';
            filterAppointmentPatientOptions('');
        }

        document.getElementById('appointmentPatientSearch').addEventListener('input', function() {
            const patientSelect = document.getElementById('appointmentPatient');
            patientSelect.value = '';
            filterAppointmentPatientOptions(this.value);
        });
        
        // ============================================
        // Modal Controls
        // ============================================
        document.getElementById('addAppointmentBtn').addEventListener('click', openAddModal);
        document.getElementById('closeModal').addEventListener('click', function() {
            document.getElementById('appointmentModal').style.display = 'none';
        });
        document.getElementById('cancelSchedule').addEventListener('click', function() {
            document.getElementById('appointmentModal').style.display = 'none';
        });
        document.getElementById('deleteAppointmentBtn').addEventListener('click', function() {
            if (currentEditId) deleteAppointment(currentEditId);
        });
        window.addEventListener('click', function(e) {
            if (e.target === document.getElementById('appointmentModal')) {
                document.getElementById('appointmentModal').style.display = 'none';
            }
        });
        
        // ============================================
        // Form Submit
        // ============================================
        document.getElementById('appointmentForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(document.getElementById('appointmentForm'));
            const patientSelect = document.getElementById('appointmentPatient');
            const selectedOption = patientSelect.options[patientSelect.selectedIndex];
            const patientName = selectedOption ? selectedOption.text.split(' [')[0] : '';
            formData.append('patient_name', patientName);
            formData.append('ajax', '1');
            
            try {
                const res = await fetch('manage_appointment.php', { method: 'POST', body: formData });
                const data = await res.json();
                if (data.success) {
                    alert(currentEditId ? 'Appointment updated!' : 'Appointment scheduled!');
                    document.getElementById('appointmentModal').style.display = 'none';
                    await fetchAppointments();
                    if (selectedDate) loadAppointmentsForDate(selectedDate);
                } else {
                    alert('Error: ' + (data.error || 'Unknown error'));
                }
            } catch (err) {
                alert('Network error. Please try again.');
            }
        });
        
        // ============================================
        // Month Navigation
        // ============================================
        document.getElementById('prevMonth').addEventListener('click', function() {
            viewMonth--;
            if (viewMonth < 0) {
                viewMonth = 11;
                viewYear--;
            }
            renderCalendar();
        });
        document.getElementById('nextMonth').addEventListener('click', function() {
            viewMonth++;
            if (viewMonth > 11) {
                viewMonth = 0;
                viewYear++;
            }
            renderCalendar();
        });

        const reportBody = document.getElementById('reportTableBody');
        const reportSort = document.getElementById('reportDateSort');
        const exportReportBtn = document.getElementById('exportReportBtn');

        if (reportBody && reportSort) {
            reportSort.addEventListener('change', function () {
                const rows = Array.from(reportBody.querySelectorAll('.report-row'));
                rows.sort(function (first, second) {
                    const firstDate = first.dataset.date + ' ' + first.dataset.time;
                    const secondDate = second.dataset.date + ' ' + second.dataset.time;
                    const direction = reportSort.value === 'asc' ? 1 : -1;
                    return direction * (firstDate.localeCompare(secondDate));
                });
                rows.forEach(row => reportBody.appendChild(row));
            });
        }

        if (exportReportBtn) {
            exportReportBtn.addEventListener('click', function () {
                const rows = Array.from(document.querySelectorAll('#reportTableBody .report-row'));
                if (rows.length === 0) {
                    alert('There are no appointments to export.');
                    return;
                }
                const csvRows = [['Appointment Report'], [], ['Date', 'Time', 'Patient', 'Doctor', 'Status']];
                rows.forEach(function (row) {
                    csvRows.push(Array.from(row.querySelectorAll('td')).map(cell => cell.textContent.trim()));
                });
                csvRows.push([], ['Weekly Trend'], ['Day', 'Appointments']);
                weeklyLabels.forEach((label, index) => csvRows.push([label, weeklyData[index]]));
                csvRows.push([], ['Age Groups'], ['Age Group', 'Patients']);
                ageLabels.forEach((label, index) => csvRows.push([label, ageData[index]]));
                csvRows.push([], ['Gender'], ['Gender', 'Patients'], ['Male', genderMale], ['Female', genderFemale]);
                csvRows.push([], ['Types'], ['Appointment Type', 'Appointments']);
                typeLabels.forEach((label, index) => csvRows.push([label, typeCounts[index]]));
                const escapeCsvValue = value => '"' + String(value ?? '').replace(/"/g, '""') + '"';
                const csv = csvRows.map(row => row.map(escapeCsvValue).join(',')).join('\r\n');
                const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = 'appointment-report-<?php echo date('Y-m-d'); ?>.csv';
                link.click();
                URL.revokeObjectURL(url);
            });
        }
        
        // ============================================
        // Initialize
        // ============================================
        fetchAppointments();
    </script>
</body>
</html>