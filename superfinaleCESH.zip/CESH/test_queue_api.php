<?php
// test_queue_api.php - Test the queue API
require_once 'db.php';

echo "<h2>Queue API Test</h2>";

// Test 1: Check if tables exist
$tables = ['queue', 'queue_settings', 'queue_display'];
foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result->num_rows > 0) {
        echo "✅ Table '$table' exists<br>";
    } else {
        echo "❌ Table '$table' is MISSING!<br>";
    }
}

// Test 2: Check if we can fetch from queue_api.php
echo "<hr>";
echo "<h3>Testing API endpoints:</h3>";

// Test get_waiting_count
$url = "queue_api.php?action=get_waiting_count&department=General";
echo "Testing: $url<br>";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . "/" . $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode == 200) {
    echo "✅ API responded with HTTP 200<br>";
    $data = json_decode($response, true);
    if ($data) {
        echo "Response: " . print_r($data, true) . "<br>";
    } else {
        echo "❌ Invalid JSON response: $response<br>";
    }
} else {
    echo "❌ API returned HTTP $httpCode<br>";
}

// Test 3: Direct database insert test
echo "<hr>";
echo "<h3>Testing direct database insert:</h3>";

// Check if there's a patient to test with
$patient_result = $conn->query("SELECT id FROM patients LIMIT 1");
if ($patient_result && $patient_result->num_rows > 0) {
    $test_patient = $patient_result->fetch_assoc();
    echo "✅ Found test patient ID: " . $test_patient['id'] . "<br>";
    
    // Insert test queue entry
    $test_number = 999;
    $test_status = 'Waiting';
    $test_dept = 'General';
    
    $stmt = $conn->prepare("INSERT INTO queue (patient_id, queue_number, priority, status, department) VALUES (?, ?, 'Normal', ?, ?)");
    $stmt->bind_param("iiss", $test_patient['id'], $test_number, $test_status, $test_dept);
    if ($stmt->execute()) {
        echo "✅ Test queue entry inserted successfully!<br>";
        $stmt->close();
        
        // Clean up test entry
        $conn->query("DELETE FROM queue WHERE queue_number = 999");
        echo "✅ Test entry cleaned up<br>";
    } else {
        echo "❌ Insert failed: " . $conn->error . "<br>";
    }
} else {
    echo "❌ No patients found in database. Please add a patient first.<br>";
}

echo "<hr>";
echo "<a href='queue_frontdesk.php'>Go back to Queue Front Desk</a>";
?>