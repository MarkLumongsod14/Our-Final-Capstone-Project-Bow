<?php
header('Location: unified_login.php');
exit;
// login.php - Role-based login with Hospital Design Language
// Camp Evangelista Station Hospital
require_once 'db.php';
require_once 'auth.php';

// If already logged in, redirect based on role
if ($auth->isLoggedIn()) {
    $dept = $auth->getDepartment();
    $role = $_SESSION['role'];
    
    if ($role === 'admin') {
        header("Location: index.php");
    } elseif ($role === 'doctor') {
        header("Location: queue_doctor.php?dept=" . urlencode($dept));
    } else {
        header("Location: frontdesk_dashboard.php?dept=" . urlencode($dept));
    }
    exit();
}

$error = ($_GET['error'] ?? '') === 'unauthorized' ? 'You are not authorized to access that page.' : '';
$showTwoFactor = isset($_SESSION['pending_2fa_user']);
if (!isset($_SESSION['captcha_a'], $_SESSION['captcha_b'])) {
    $_SESSION['captcha_a'] = random_int(1, 9);
    $_SESSION['captcha_b'] = random_int(1, 9);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $twoFactorCode = trim($_POST['two_factor_code'] ?? '');
    
    if ($showTwoFactor && $twoFactorCode !== '') {
        $result = $auth->verifyTwoFactor($twoFactorCode);
        if ($result['success']) {
            header("Location: index.php");
            exit();
        }
        $error = $result['message'];
    } elseif (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
    } else {
        if ((int)($_POST['captcha_answer'] ?? -1) !== ((int)$_SESSION['captcha_a'] + (int)$_SESSION['captcha_b'])) {
            $result = $auth->recordFailedLogin($username, 'Incorrect security check');
        } else {
            $result = $auth->login($username, $password);
        }
        
        if (!empty($result['requires_2fa'])) {
            $showTwoFactor = true;
            $error = $result['message'];
        } elseif (!empty($result['success'])) {
            $dept = $auth->getDepartment();
            $role = $_SESSION['role'];
            
            if ($role === 'admin') {
                header("Location: index.php");
            } elseif ($role === 'doctor') {
                header("Location: queue_doctor.php?dept=" . urlencode($dept));
            } else {
                header("Location: frontdesk_dashboard.php?dept=" . urlencode($dept));
            }
            exit();
        } elseif (isset($result)) {
            $error = $result['message'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" type="image/png" sizes="32x32" href="https://4idstationhospital.wuaze.com/assets/images/logo.png">
    <script>document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Login | 4ID Station Hospital | Camp Evangelista</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: { 
                        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'] 
                    },
                    keyframes: {
                        slideIn: {
                            '0%': { opacity: '0', transform: 'translateY(-8px)' },
                            '100%': { opacity: '1', transform: 'translateY(0)' }
                        }
                    },
                    animation: { 
                        'slide-in': 'slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1)' 
                    }
                }
            }
        }
    </script>
    
    <style>
        .login-shell {
            background-color: #09090b;
            color: #d4d4d8;
        }
        #loginForm input:not([type="checkbox"]) {
            background-color: #18181b;
            color: #ffffff;
            border-color: #27272a;
        }
        html.dark #brandingPanel {
            background-color: #18181b !important;
            border-color: rgb(39 39 42 / 0.5) !important;
        }
        html.dark #loginForm input:not([type="checkbox"]) {
            background-color: #18181b !important;
            color: #ffffff !important;
            border-color: #27272a !important;
        }
    </style>
</head>
<body class="login-shell font-sans antialiased min-h-screen flex flex-col lg:flex-row">

    <!-- LEFT SECTION: Branding & Information -->
    <div id="brandingPanel" class="hidden lg:flex lg:w-5/12 xl:w-1/2 bg-zinc-900 relative flex-col justify-between p-12 xl:p-16 overflow-hidden border-r border-zinc-800/50">
        
        <!-- Abstract Background Effects -->
        <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:32px_32px]"></div>
        <div class="absolute -top-40 -left-40 w-96 h-96 bg-sky-600/20 rounded-full blur-[100px]"></div>
        <div class="absolute -bottom-40 -right-40 w-96 h-96 bg-sky-500/10 rounded-full blur-[100px]"></div>

        <!-- Top Badge -->
        <div class="relative z-10 flex items-center justify-center gap-3">
            <i class="fas fa-shield-halved text-sky-500 text-xl"></i>
            <span class="font-bold tracking-widest text-xs text-zinc-400 uppercase">Military Healthcare Portal</span>
        </div>

        <!-- Center Content -->
        <div class="relative z-10 my-auto flex flex-col items-center text-center">
            <div class="w-28 h-28 bg-zinc-800/50 border border-zinc-700/50 rounded-full flex items-center justify-center p-4 mb-8 backdrop-blur-md shadow-[0_0_30px_rgba(14,165,233,0.15)] overflow-hidden">
                <img src="assets/images/logo.png" alt="4ID Station Hospital Logo" class="w-full h-full object-contain">
            </div>
            
            <h1 class="text-4xl xl:text-5xl font-extrabold tracking-tight mb-5 text-white leading-tight">
                4ID Station Hospital
            </h1>
            
            <p class="text-lg xl:text-xl text-zinc-400 font-medium max-w-md leading-relaxed mb-8 mx-auto">
                Camp Evangelista Outpatient Record Management &amp; Smart Queueing System.
            </p>

            <div class="inline-flex items-center gap-3 bg-zinc-800/50 border border-zinc-700/50 px-4 py-2 rounded-full text-xs font-semibold text-zinc-300 backdrop-blur-sm">
                <span class="relative flex h-2 w-2">
                    <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-sky-500"></span>
                </span>
                Secure System Active
            </div>
        </div>

        <!-- Footer -->
        <div class="relative z-10 text-xs text-zinc-500 font-medium text-center">
            &copy; <?php echo date('Y'); ?> 4th Infantry Division. All rights reserved.
        </div>
    </div>

    <!-- RIGHT SECTION: Login Form -->
    <div class="flex-1 flex items-center justify-center min-h-screen relative p-6 sm:p-12 lg:p-16">
        
        <div class="w-full max-w-md relative z-10">
            
            <!-- Mobile Header -->
            <div id="mobileHeader" class="lg:hidden text-center mb-10 mt-4">
                <div class="w-20 h-20 bg-zinc-900 border border-zinc-800 rounded-full flex items-center justify-center mx-auto p-4 mb-4 shadow-[0_0_20px_rgba(14,165,233,0.1)] overflow-hidden">
                    <img src="assets/images/logo.png" alt="4ID Station Hospital Logo" class="w-full h-full object-contain">
                </div>
                <h2 class="text-2xl font-extrabold text-white tracking-tight">4ID Station Hospital</h2>
                <p class="text-xs text-zinc-400 mt-1 font-medium">Camp Evangelista</p>
            </div>

            <!-- Welcome Text -->
            <div class="mb-8">
                <h2 id="welcomeTitle" class="text-3xl font-bold text-white mb-2">Welcome Back</h2>
                <p id="welcomeCopy" class="text-sm text-zinc-400 font-medium">
                    Enter your credentials to access the Outpatient Record Management System.
                </p>
            </div>

            <!-- Error Message -->
            <?php if ($error): ?>
                <div class="flex items-start gap-3 px-4 py-3.5 rounded-xl mb-6 text-xs font-medium bg-rose-900/20 border border-rose-800/30 text-rose-400 animate-slide-in shadow-sm">
                    <i class="fas fa-circle-exclamation text-sm mt-0.5 text-rose-500 shrink-0"></i>
                    <div class="leading-relaxed"><?php echo htmlspecialchars($error); ?></div>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form id="loginForm" method="POST" class="space-y-5">
                <!-- Role Selector -->
                

                <?php if (!$showTwoFactor): ?>
                <!-- Username -->
                <div>
                    <label class="block mb-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">
                        Username
                    </label>
                    <div class="relative flex items-center">
                        <span class="absolute left-4 text-zinc-500">
                            <i class="fas fa-user"></i>
                        </span>
                        <input type="text" name="username" id="username"
                               class="w-full pl-11 pr-4 py-3.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm font-medium transition duration-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none placeholder:text-zinc-600 shadow-sm"
                               placeholder="Enter your username" required autofocus>
                    </div>
                </div>

                <!-- Password -->
                <div>
                    <label class="block mb-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">
                        Password
                    </label>
                    <div class="relative flex items-center">
                        <span class="absolute left-4 text-zinc-500">
                            <i class="fas fa-lock"></i>
                        </span>
                        <input type="password" name="password" id="password" <?php echo $showTwoFactor ? 'disabled' : 'required'; ?>
                               class="w-full pl-11 pr-12 py-3.5 rounded-xl text-sm font-medium focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none placeholder:text-zinc-600 shadow-sm"
                               placeholder="Enter your password" required>
                        <button type="button" id="togglePassword" aria-label="Show password" aria-pressed="false" class="absolute right-4 z-10 text-zinc-500 hover:text-zinc-300 transition">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>

                    <?php if ($showTwoFactor): ?>
                    <div>
                        <label class="block mb-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">Google Authenticator Code</label>
                        <input type="text" name="two_factor_code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autofocus class="w-full px-4 py-3.5 rounded-xl text-sm tracking-[0.35em] text-center focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none" placeholder="000000">
                    </div>
                    <?php else: ?>
                    <div>
                        <label class="block mb-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">Security Check</label>
                        <div class="flex items-center gap-3"><span class="text-white font-bold px-4 py-3.5 bg-zinc-900 border border-zinc-800 rounded-xl">What is <?php echo $_SESSION['captcha_a'] . ' + ' . $_SESSION['captcha_b']; ?>?</span><input type="number" name="captcha_answer" required class="w-full px-4 py-3.5 rounded-xl text-sm focus:border-sky-500 outline-none" placeholder="Answer"></div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                    <input type="hidden" name="username" value="<?php echo htmlspecialchars($_SESSION['pending_2fa_user']['username'] ?? '', ENT_QUOTES); ?>">
                    <div>
                        <label class="block mb-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">Google Authenticator Code</label>
                        <input type="text" name="two_factor_code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autofocus class="w-full px-4 py-3.5 rounded-xl text-sm tracking-[0.35em] text-center focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none" placeholder="000000">
                    </div>
                <?php endif; ?>

                <button type="submit"
                        class="w-full py-3.5 px-5 mt-2 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 rounded-xl text-white text-sm font-bold flex items-center justify-center gap-2 transition duration-200 shadow-[0_0_20px_rgba(14,165,233,0.2)] cursor-pointer">
                    <i class="fas fa-right-to-bracket"></i> Sign In
                </button>
            </form>

            

            <!-- Footer -->
            <div class="mt-8 text-center text-[10px] text-zinc-500 font-medium">
                <span>4th Infantry Division • Camp Evangelista Station Hospital</span>
            </div>

        </div>
    </div>

    <script>
        const usernameInput = document.getElementById('username');
        usernameInput.addEventListener('input', () => {
            usernameInput.dataset.userModified = 'true';
        });
        
        // ============================================
        // Demo Credential Auto-fill
        // ============================================
        document.querySelectorAll('.demo-credential').forEach(cred => {
            cred.addEventListener('click', () => {
                const username = cred.dataset.username;
                const passwordInput = document.getElementById('password');
                
                if (username) {
                    usernameInput.value = username;
                    usernameInput.dataset.userModified = 'false';
                    passwordInput.value = 'admin123';
                    passwordInput.focus();
                    
                }
            });
        });
        
        // ============================================
        // Toggle Password Visibility
        // ============================================
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        
        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', () => {
                const showPassword = passwordInput.type === 'password';
                passwordInput.type = showPassword ? 'text' : 'password';
                togglePassword.setAttribute('aria-label', showPassword ? 'Hide password' : 'Show password');
                togglePassword.setAttribute('aria-pressed', String(showPassword));
                const icon = togglePassword.querySelector('i');
                if (icon) {
                    icon.classList.toggle('fa-eye', !showPassword);
                    icon.classList.toggle('fa-eye-slash', showPassword);
                }
            });
        }
        
        // ============================================
        // Disable button on submit
        // ============================================
        document.querySelector('form').addEventListener('submit', function(e) {
            const btn = this.querySelector('button[type="submit"]');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        });
    </script>
</body>
</html>