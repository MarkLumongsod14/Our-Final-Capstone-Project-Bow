<?php
session_start();
require_once __DIR__ . '/unified_auth.php';

if (empty($_SESSION['sso_identity_id'])) {
    header('Location: unified_login.php');
    exit;
}

$auth = new UnifiedAuth();
$error = '';
$system = (string)($_SESSION['sso_pending_system'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!unified_csrf_valid()) {
        http_response_code(400);
        $error = 'Your verification form expired. Refresh the page and try again.';
    } else {
        if ($system === '') {
            http_response_code(400);
            $error = 'Sign-in verification has expired. Please sign in again.';
        } else {
            try {
                $result = $auth->enterSystem(
                    (int)$_SESSION['sso_identity_id'],
                    $system,
                    isset($_POST['two_factor_code']) ? trim((string)$_POST['two_factor_code']) : null
                );
                if ($result['success']) {
                    $_SESSION['sso_dashboard_url'] = $result['url'];
                    if (
                        $system === 'smart_queueing'
                        && isset($_SESSION['sso_smart_queue_transfer_mrn'])
                        && (int)$_SESSION['sso_smart_queue_transfer_mrn'] > 0
                    ) {
                        $transferMrn = (int)$_SESSION['sso_smart_queue_transfer_mrn'];
                        unset($_SESSION['sso_smart_queue_transfer_mrn']);
                        header('Location: ../queuv1/staff/registration.php?crm_mrn=' . urlencode((string)$transferMrn));
                        exit;
                    }
                    header('Location: ' . $result['url']);
                    exit;
                }
                if (!empty($result['requires_2fa'])) {
                    $error = $result['message'] ?? '';
                } else {
                    http_response_code(403);
                    $error = $result['message'];
                }
            } catch (Throwable $exception) {
                error_log('Unified application entry failed: ' . $exception->getMessage());
                http_response_code(503);
                $error = 'Application access is temporarily unavailable.';
            }
        }
    }
} else {
    if ($system === '') {
        header('Location: unified_login.php');
        exit;
    }
}
$csrfToken = unified_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/logo.png">
    <script>document.documentElement.classList.add('dark');</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Login | 4ID Station Hospital | Camp Evangelista</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: { sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'] },
                    keyframes: {
                        slideIn: {
                            '0%': { opacity: '0', transform: 'translateY(-8px)' },
                            '100%': { opacity: '1', transform: 'translateY(0)' }
                        }
                    },
                    animation: { 'slide-in': 'slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1)' }
                }
            }
        }
    </script>
    <style>
        .login-shell { background-color: #09090b; color: #d4d4d8; }
        #verificationForm input {
            background-color: #18181b;
            color: #ffffff;
            border-color: #27272a;
        }
        html.dark #brandingPanel {
            background-color: #18181b !important;
            border-color: rgb(39 39 42 / 0.5) !important;
        }
    </style>
</head>
<body class="login-shell font-sans antialiased min-h-screen flex flex-col lg:flex-row">
    <div id="brandingPanel" class="hidden lg:flex lg:w-5/12 xl:w-1/2 bg-zinc-900 relative flex-col justify-between p-12 xl:p-16 overflow-hidden border-r border-zinc-800/50">
        <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:32px_32px]"></div>
        <div class="absolute -top-40 -left-40 w-96 h-96 bg-sky-600/20 rounded-full blur-[100px]"></div>
        <div class="absolute -bottom-40 -right-40 w-96 h-96 bg-sky-500/10 rounded-full blur-[100px]"></div>

        <div class="relative z-10 flex items-center justify-center gap-3">
            <i class="fas fa-shield-halved text-sky-500 text-xl"></i>
            <span class="font-bold tracking-widest text-xs text-zinc-400 uppercase">Military Healthcare Portal</span>
        </div>

        <div class="relative z-10 my-auto flex flex-col items-center text-center">
            <div class="w-28 h-28 bg-zinc-800/50 border border-zinc-700/50 rounded-full flex items-center justify-center p-4 mb-8 backdrop-blur-md shadow-[0_0_30px_rgba(14,165,233,0.15)] overflow-hidden">
                <img src="assets/images/logo.png" alt="4ID Station Hospital Logo" class="w-full h-full object-contain">
            </div>
            <h1 class="text-4xl xl:text-5xl font-extrabold tracking-tight mb-5 text-white leading-tight">4ID Station Hospital</h1>
            <p class="text-lg xl:text-xl text-zinc-400 font-medium max-w-md leading-relaxed mb-8 mx-auto">
                Camp Evangelista Outpatient Record Management &amp; Smart Queueing System.
            </p>
            <div class="inline-flex items-center gap-3 bg-zinc-800/50 border border-zinc-700/50 px-4 py-2 rounded-full text-xs font-semibold text-zinc-300 backdrop-blur-sm">
                <span class="relative flex h-2 w-2">
                    <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-sky-500"></span>
                </span>
                Secure System Active
            </div>
        </div>

        <div class="relative z-10 text-xs text-zinc-500 font-medium text-center">
            &copy; <?php echo date('Y'); ?> 4th Infantry Division. All rights reserved.
        </div>
    </div>

    <div class="flex-1 flex items-center justify-center min-h-screen relative p-6 sm:p-12 lg:p-16">
        <main class="w-full max-w-md relative z-10">
            <div id="mobileHeader" class="lg:hidden text-center mb-10 mt-4">
                <div class="w-20 h-20 bg-zinc-900 border border-zinc-800 rounded-full flex items-center justify-center mx-auto p-4 mb-4 shadow-[0_0_20px_rgba(14,165,233,0.1)] overflow-hidden">
                    <img src="assets/images/logo.png" alt="4ID Station Hospital Logo" class="w-full h-full object-contain">
                </div>
                <h2 class="text-2xl font-extrabold text-white tracking-tight">4ID Station Hospital</h2>
                <p class="text-xs text-zinc-400 mt-1 font-medium">Camp Evangelista</p>
            </div>

            <div class="mb-8">
                <h2 class="text-3xl font-bold text-white mb-2">Verify Your Identity</h2>
                <p class="text-sm text-zinc-400 font-medium">
                    Enter the Google Authenticator code for <?php echo $system === 'outpatient' ? 'Outpatient' : 'Smart Queueing'; ?>.
                </p>
            </div>

            <?php if ($error !== ''): ?>
                <div class="flex items-start gap-3 px-4 py-3.5 rounded-xl mb-6 text-xs font-medium bg-rose-900/20 border border-rose-800/30 text-rose-400 animate-slide-in shadow-sm">
                    <i class="fas fa-circle-exclamation text-sm mt-0.5 text-rose-500 shrink-0"></i>
                    <div class="leading-relaxed"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
            <?php endif; ?>

            <form id="verificationForm" method="post" class="space-y-5">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                <div>
                    <label class="block mb-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">Google Authenticator Code</label>
                    <div class="relative flex items-center">
                        <span class="absolute left-4 text-zinc-500"><i class="fas fa-shield-halved"></i></span>
                        <input name="two_factor_code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6"
                               autocomplete="one-time-code" required autofocus
                               class="w-full pl-11 pr-4 py-3.5 border rounded-xl text-sm font-semibold tracking-[0.35em] focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none"
                               placeholder="000000">
                    </div>
                </div>
                <button type="submit" class="w-full py-3.5 px-5 mt-2 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 rounded-xl text-white text-sm font-bold flex items-center justify-center gap-2 transition duration-200 shadow-[0_0_20px_rgba(14,165,233,0.2)] cursor-pointer">
                    <i class="fas fa-check"></i> Verify and Continue
                </button>
            </form>

            <a class="mt-6 inline-flex items-center gap-2 text-sm text-sky-400 hover:text-sky-300" href="unified_logout.php">
                <i class="fas fa-arrow-left"></i> Cancel and sign in again
            </a>

            <div class="mt-8 text-center text-[10px] text-zinc-500 font-medium">
                <span>4th Infantry Division • Camp Evangelista Station Hospital</span>
            </div>
        </main>
    </div>

    <script>
        const verificationForm = document.getElementById('verificationForm');
        if (verificationForm) {
            verificationForm.addEventListener('submit', function () {
                const button = this.querySelector('button[type="submit"]');
                if (button) {
                    button.disabled = true;
                    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
                }
            });
        }
    </script>
</body>
</html>
